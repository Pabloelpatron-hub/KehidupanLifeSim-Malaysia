// Fasa 4 return journey: separate, idempotent ICN -> KUL lifecycle.
import {findFlights,quoteFlight} from './flight-booking.js';
import {transitionTravel} from './travel-foundation.js';
import {nextDay} from './engine.js';
const STEPS=['CHECK_IN','BAG_DROP','SECURITY','IMMIGRATION','GATE','BOARDING'];
const LABEL={CHECK_IN:'Daftar masuk',BAG_DROP:'Serahan bagasi',SECURITY:'Pemeriksaan keselamatan',IMMIGRATION:'Imigresen Korea',GATE:'Pengesahan gate',BOARDING:'Boarding'};
const esc=x=>String(x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function quoteReturn(s,departureDay,seatClass='economy',checkedBags=0){
 if(s.travel?.status!=='ABROAD'||s.travel.location?.city!=='Seoul')throw Error('Tempahan pulang hanya tersedia ketika berada di Seoul');
 if(!Number.isSafeInteger(departureDay)||departureDay<=s.day||departureDay>s.day+365)throw Error('Pilih hari berlepas dalam 1–365 hari akan datang');
 const outbound=s.travel.activeTrip;
 const flight=findFlights('ICN','KUL',departureDay)[0];
 const quote=quoteFlight(flight,{passengers:outbound?.quote?.passengers||1,checkedBags,seatClass,bookingDay:s.day});
 return {id:'return-'+outbound.id,routeId:flight.id,from:'ICN',to:'KUL',departureDay,departureLocalHour:9,durationMinutes:flight.durationMinutes,quote,paidSen:quote.totalSen,status:'QUOTED'};
}
export function bookReturn(s,departureDay,seatClass='economy',checkedBags=0){
 const ticket=quoteReturn(s,departureDay,seatClass,checkedBags);
 if(s.travel.activeTrip.returnFlight)throw Error('Tiket pulang sudah ditempah');
 // Return flight may be booked while hotel is active; checkout occurs before airport departure.
 ticket.status='CONFIRMED';
 s.travel.activeTrip.returnFlight=ticket;
 return ticket;
}
export function beginReturn(s){
 const t=s.travel,trip=t?.activeTrip,ret=trip?.returnFlight;
 if(t?.status!=='ABROAD'||!ret||ret.status!=='CONFIRMED')throw Error('Tiket pulang yang telah dibayar diperlukan');
 if(s.day!==ret.departureDay)throw Error('Proses pulang hanya pada hari penerbangan');
 
 if(t.seoul?.hotel&&t.seoul.hotel.checkoutDay>s.day)throw Error('Daftar keluar hotel dahulu sebelum ke airport');
 transitionTravel(s,'RETURNING');
 s.travel.location={country:'KR',city:'Seoul',district:null,venue:'Incheon International Airport'};
 return ret;
}
export function returnAirportStep(s,step){
 const t=s.travel,ret=t?.activeTrip?.returnFlight;
 if(t?.status!=='RETURNING'||!ret||s.day!==ret.departureDay)throw Error('Proses airport pulang sudah tamat atau belum bermula');
 const done=ret.airportCompleted||[];
 if(!STEPS.includes(step)||STEPS[done.length]!==step)throw Error('Selesaikan proses airport mengikut turutan');
 ret.airportCompleted=[...done,step];
 if(step==='BOARDING')ret.airportReady=true;
 return step;
}
export function startReturnFlight(s){
 const t=s.travel,ret=t?.activeTrip?.returnFlight;
 if(t?.status!=='RETURNING'||!ret?.airportReady||s.day!==ret.departureDay)throw Error('Boarding atau waktu berlepas tidak sah');
 transitionTravel(s,'AT_AIRPORT');
 transitionTravel(s,'IN_FLIGHT');
 s.travel.activeTrip.returnFlight.flightPhase='TAKEOFF';
 s.travel.activeTrip.returnFlight.departureClock={day:s.day,minuteMalaysia:s.hour*60,timezone:'Asia/Seoul'};
 return ret;
}
export function advanceReturnFlight(s){
 const ret=s.travel?.activeTrip?.returnFlight;
 if(s.travel?.status!=='IN_FLIGHT'||!s.travel.returnJourney||!ret)throw Error('Penerbangan pulang belum bermula');
 const phases=['TAKEOFF','CRUISE','DESCENT','LANDED'];
 const index=phases.indexOf(ret.flightPhase);
 if(index<0||index===3)throw Error('Fasa penerbangan tidak sah');
 ret.flightPhase=phases[index+1];return ret.flightPhase;
}
export function finishReturn(s){
 const t=s.travel,trip=t?.activeTrip,ret=trip?.returnFlight;
 if(t?.status!=='IN_FLIGHT'||!t.returnJourney||ret?.flightPhase!=='LANDED')throw Error('Pesawat pulang belum mendarat');
 const event='return-arrival:'+trip.id;
 if(t.processedEvents.includes(event))throw Error('Ketibaan pulang telah diproses');
 const clock=ret.departureClock;
 if(!clock||s.day!==clock.day)throw Error('Hari game berubah ketika penerbangan');
 const total=clock.minuteMalaysia+ret.durationMinutes;
 const arrivalDay=clock.day+Math.floor(total/1440);
 while(s.day<arrivalDay)nextDay(s);
 s.hour=Math.min(23,Math.ceil((total%1440)/60));
 ret.arrivalDay=s.day;ret.arrivalClock={day:s.day,minuteMalaysia:total%1440,timezone:'Asia/Kuala_Lumpur'};
 t.processedEvents.push(event);
 transitionTravel(s,'RETURNED');
 s.travel.arrivalTrip=structuredClone(trip);
 return event;
}
export function returnHome(s){if(s.travel?.status!=='RETURNED')throw Error('Perjalanan belum selesai');transitionTravel(s,'AT_HOME');}
export function returnPanel(s){
 const t=s.travel,ret=t?.activeTrip?.returnFlight;
 if(t?.status==='RETURNED')return '<section class="card"><h3>🇲🇾 Selamat pulang ke Malaysia</h3><button class="btn" data-action="return-home">Selesaikan perjalanan</button></section>';
 if(!['ABROAD','RETURNING','IN_FLIGHT'].includes(t?.status)||t.status==='IN_FLIGHT'&&!t.returnJourney)return '';
 if(t.status==='ABROAD'&&!ret)return `<section class="card"><h3>✈ Penerbangan Pulang · ICN → KUL</h3><p class="smalltext">Tempah tiket pulang. Berlepas 09:00 KST; tempoh 7 jam; harga simulasi MYR.</p><button class="btn" data-action="return-book-open">Cari tiket pulang</button></section>`;
 if(!ret)return '';
 const intro=`<h3>✈ Pulang ke Malaysia · ICN → KUL</h3><p>Hari ke-${ret.departureDay+1} · 09:00 KST · Tiket RM ${(ret.paidSen/100).toFixed(2)}</p>`;
 if(t.status==='ABROAD')return `<section class="card">${intro}${s.day>ret.departureDay||(false)?'<p class="notice">Penerbangan terlepas. <button class="btn" data-action="return-rebook">Jadual semula tiket</button></p>':''}<button class="btn" data-action="return-begin" ${s.day!==ret.departureDay?'disabled':''}>Pergi ke Incheon Airport</button><p class="smalltext">Check-out hotel sebelum berangkat. Proses airport pada hari penerbangan.</p></section>`;
 if(t.status==='RETURNING'){const done=ret.airportCompleted||[];const next=STEPS[done.length];if(s.day>ret.departureDay||(false))return `<section class="card">${intro}<p class="notice">Penerbangan pulang terlepas ketika proses airport. Jadualkan semula untuk memulakan check-in baharu.</p><button class="btn" data-action="return-rebook">Jadual semula tiket</button></section>`;return `<section class="card">${intro}<p>${STEPS.map(x=>(done.includes(x)?'✓ ':'○ ')+LABEL[x]).join(' · ')}</p>${next?`<button class="btn" data-action="return-airport-step" data-id="${next}">${esc(LABEL[next])}</button>`:'<button class="btn" data-action="return-flight-start">Mulakan penerbangan pulang</button>'}</section>`;}
 const phase=ret.flightPhase;return `<section class="card">${intro}<p>Penerbangan pulang aktif · ICN → KUL</p><button class="btn" data-action="aerotrace-open">Lihat Flight Tracker</button></section>`;
}
