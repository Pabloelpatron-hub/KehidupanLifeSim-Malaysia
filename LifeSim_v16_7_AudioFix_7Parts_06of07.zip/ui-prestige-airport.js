/* P7 First Class airport skin: presentation only, based on actual rendered ticket. */
(()=>{'use strict';
let pending=false;
function update(){
 pending=false;
 for(const screen of document.querySelectorAll('.airport-screen')){
  const flight=[...screen.querySelectorAll('.airport-white')].find(x=>/Your Flight/i.test(x.querySelector('h2')?.textContent||''));
  const line=flight?.querySelector('p')?.textContent||'';
  // Use the actual class shown on the player's ticket; never infer from airport or airline.
  const first=/(?:^|·)\s*first(?:\s+class)?\s*(?:·|$)/i.test(line);
  screen.classList.toggle('ui-first-class-airport',first);
 }
}
const observer=new MutationObserver(()=>{if(!pending){pending=true;requestAnimationFrame(update)}});
observer.observe(document.body,{childList:true,subtree:true});
update();
})();
