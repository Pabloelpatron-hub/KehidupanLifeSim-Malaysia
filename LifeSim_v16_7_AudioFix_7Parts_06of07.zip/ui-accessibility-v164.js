/* v16.4: repair collapsible-workspace accessibility and preserve focus. */
(()=>{'use strict';
const app=document.getElementById('app');if(!app)return;
let pending=false;
function reconcile(){pending=false;
 const content=app.querySelector(':scope > .shell > .content');if(!content)return;
 for(const panel of content.querySelectorAll(':scope > .ui159-workspace')){
  const toggle=panel.querySelector(':scope > .ui159-fold');if(!toggle)continue;
  // A button must not claim to control its own ancestor: remove invalid aria-controls.
  if(toggle.getAttribute('aria-controls')===panel.id)toggle.removeAttribute('aria-controls');
  const closed=panel.classList.contains('ui159-closed');
  if(toggle.getAttribute('aria-expanded')!==String(!closed))toggle.setAttribute('aria-expanded',String(!closed));
  const heading=panel.querySelector(':scope > .ui159-original-heading');
  if(heading){
   if(!heading.id)heading.id='ui164-heading-'+Array.prototype.indexOf.call(content.children,panel);
   toggle.setAttribute('aria-labelledby',heading.id);
  }
  // Never conceal the currently focused gameplay control.
  if(closed&&panel.contains(document.activeElement)&&document.activeElement!==toggle)toggle.click();
 }
}
function schedule(){if(pending)return;pending=true;requestAnimationFrame(reconcile)}
new MutationObserver(schedule).observe(app,{childList:true,subtree:true});
app.addEventListener('focusin',schedule,true);
schedule();
})();
