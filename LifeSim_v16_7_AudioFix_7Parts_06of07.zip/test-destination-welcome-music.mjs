import assert from 'node:assert/strict';
import {DESTINATION_CODES} from './js-release-v8-9-20261114/universal-destination.js';
import {destinationWelcomeCount,destinationWelcomeView,welcomeKey} from './js-release-v8-9-20261114/destination-welcome.js';
import {destinationMusicCount} from './js-release-v8-9-20261114/destination-music.js';
import {readFileSync} from 'node:fs';
assert.equal(destinationWelcomeCount,30);
assert.equal(destinationMusicCount,30);
assert.equal(DESTINATION_CODES.length,30);
for(const code of DESTINATION_CODES){
 const s={day:682,globalJourney:{activeJourney:{id:'abc',status:'AT_DESTINATION',currentAirport:code,segments:[{}]}}};
 const view=destinationWelcomeView(s);
 assert.match(view,/Welcome to/);
 assert.match(view,new RegExp('data-id="'+code+'"'));
 assert.match(view,/destination-welcome-enter/);
 assert.equal(welcomeKey(s),'abc|1|'+code);
 s.globalJourney.activeJourney.status='BOOKED';s.globalJourney.activeJourney.segments.push({});
 assert.equal(welcomeKey(s),'abc|1|'+code,'outbound visit retained when booking next segment');
}
const app=readFileSync('./js-release-v8-9-20261114/app.js','utf8');
assert.match(app,/if\(!s\.destinationWelcome\.entered\[key\]\)/);
assert.match(app,/if\(a==='destination-welcome-enter'\)/);
assert.match(app,/stopDestinationMusic\(\)/);
assert.match(app,/playDestinationMusic\(code/);
console.log('PASS: 30 welcome pages, 30 music profiles, save keys, entry gate, audio lifecycle');
