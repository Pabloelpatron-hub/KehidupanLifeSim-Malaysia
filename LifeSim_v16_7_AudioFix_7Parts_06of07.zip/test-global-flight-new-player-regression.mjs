import assert from 'node:assert/strict';
import {globalFlightChoices} from './js-release-v8-9-20261114/global-flight-checkout.js';
import {initial} from './js-release-v8-9-20261114/state.js';
const s=initial();
assert.equal(s.day,0);
for(const to of ['PNH','CGK','RGN']){
 for(const seatClass of ['economy','business']){
  const choices=globalFlightChoices(s,{from:'KUL',to,departureDay:s.day+2,seatClass});
  assert.ok(choices.length>0,`${to} ${seatClass} should work on day 0`);
  assert.equal(choices[0].quote.bookingDay,0);
 }
}
console.log('PASS fresh game day 0 flight searches for PNH CGK RGN');
