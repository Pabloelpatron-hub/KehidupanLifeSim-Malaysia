/* v15.5: navigation restructuring without touching gameplay state. */
(()=>{'use strict';
const app=document.getElementById('app');if(!app)return;
function enhance(){
 const shell=app.querySelector(':scope > .shell');if(!shell)return;
 const sidebar=shell.querySelector('.sidebar'),content=shell.querySelector('.content'),top=shell.querySelector('.topbar');if(!sidebar||!content||!top)return;
 // The previous release inserted an extra decorative masthead above the real page title.
 // Replace it with a compact, contextual breadcrumb instead of duplicating page headers.
 const old=content.querySelector(':scope > .ui154-mast');if(old)old.remove();
 const active=sidebar.querySelector('.navitem.active');
 const title=active?.textContent?.replace(/\s+/g,' ').trim()||'Utama';
 const crumb=top.querySelector('.breadcrumb');
 if(crumb&&crumb.dataset.ui155!==title){crumb.dataset.ui155=title;crumb.replaceChildren();
  const parent=document.createElement('span');parent.className='ui155-path';parent.textContent='KEHIDUPAN';
  const sep=document.createElement('span');sep.className='ui155-path-sep';sep.textContent='/';
  const current=document.createElement('strong');current.textContent=title;
  crumb.append(parent,sep,current);
 }
 if(sidebar.querySelector('.ui155-search'))return;
 const search=document.createElement('div');search.className='ui155-search';
 const input=document.createElement('input');input.type='search';input.placeholder='Cari halaman…';input.setAttribute('aria-label','Cari halaman permainan');input.autocomplete='off';
 const status=document.createElement('span');status.className='ui155-search-status';status.setAttribute('aria-live','polite');
 search.append(input,status);const brand=sidebar.querySelector('.brand');if(brand)brand.after(search);else sidebar.prepend(search);
 const groups=[...sidebar.querySelectorAll('.ui154-navgroup')];
 function filter(){const q=input.value.trim().toLocaleLowerCase('ms');let count=0;
  for(const group of groups){let hits=0;for(const button of group.querySelectorAll('.navitem')){
    const match=!q||button.textContent.toLocaleLowerCase('ms').includes(q);
    button.hidden=!match;if(match)hits++;
  }count+=hits;group.hidden=!!q&&!hits;
   if(q&&hits){group.querySelector('.ui154-group-items').hidden=false;group.querySelector('.ui154-group-trigger')?.setAttribute('aria-expanded','true');}
   if(!q){for(const button of group.querySelectorAll('.navitem'))button.hidden=false;
    const trigger=group.querySelector('.ui154-group-trigger');const items=group.querySelector('.ui154-group-items');
    if(trigger&&items){const closed=group.classList.contains('is-collapsed');items.hidden=closed;trigger.setAttribute('aria-expanded',String(!closed));}}
  }
  status.textContent=q?(count?count+' halaman dijumpai':'Tiada halaman dijumpai'):'';
 }
 input.addEventListener('input',filter);
 input.addEventListener('keydown',e=>{if(e.key==='Escape'){input.value='';filter();input.blur()}else if(e.key==='Enter'){
  const first=sidebar.querySelector('.navitem:not([hidden])');if(first){e.preventDefault();first.click()}
 }});
 // Keep filtered navigation functional; no cloned buttons, no replacement handlers.
}
new MutationObserver(enhance).observe(app,{childList:true});enhance();
})();
