# Fasa 4 — Seoul Tourism Starter

Baseline: Fasa 3 Integration QA Development ZIP. No live deployment.

Implemented: Seoul panel shown only after arrival in Seoul; five tourist destinations; per-trip/per-day duplicate-visit prevention; three fictional hotel tiers; one-night booking UI; hotel booking guard; simulated MYR charges via existing `spend` ledger; existing `mutate` transaction rollback and one-action cost; visit location saved in travel location; data persists through normal save.

Tests: `node test-seoul-tourism.mjs`; `node test-flight-booking.mjs`; `node test-flight-payment.mjs`; `node test-airport-experience.mjs`; syntax check app and module.

Limitations: Fasa 4 is a starter only. No return flight, local transport, hotel stay consumption engine, foreign currency or exchange-rate handling, tourism NPCs, real attraction pricing, or real Safari browser verification. Flight experience regression test may require browser globals (Image) and cannot be run directly under plain Node.
