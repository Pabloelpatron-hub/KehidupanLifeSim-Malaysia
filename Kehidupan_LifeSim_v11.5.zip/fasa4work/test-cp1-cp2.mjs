import assert from 'node:assert/strict';
import {initial,serialize,deserialize} from './js-release-v8-9-20261114/state.js';
import {GLOBAL_AIRPORTS} from './js-release-v8-9-20261114/global-flight-network.js';
import {DESTINATION_CODES,destinationCatalogExpanded,destinationAction,destinationNextDayGuard} from './js-release-v8-9-20261114/universal-destination.js';
import {currencyForAirport,formatForeign,ensureInternationalWallet,fxQuote,exchangeTravelCash} from './js-release-v8-9-20261114/international-wallet.js';
assert.equal(DESTINATION_CODES.length,30);
for(const code of DESTINATION_CODES){const c=destinationCatalogExpanded(code);assert.equal(c.currency,GLOBAL_AIRPORTS[code].currency);assert.equal(currencyForAirport(code),c.currency);assert.equal(c.hotel.length,8);assert.equal(new Set(c.hotel.map(h=>h.name)).size,8);for(const h of c.hotel){assert.ok(h.nightly>0);assert.ok(h.name.length>4);assert.ok(['Standard','Deluxe','Suite'].includes(h.room));assert.ok(formatForeign(h.nightly,c.currency));}}
const s=initial('CP12');s.day=100;s.globalJourney={activeJourney:{id:'cp12',status:'AT_DESTINATION',currentAirport:'ICN',segments:[{from:'KUL',to:'ICN'}]}};ensureInternationalWallet(s);s.internationalWallet.cash.KRW=10000000;
const before=s.internationalWallet.cash.KRW;const hotel={...destinationCatalogExpanded('ICN').hotel[3]};hotel.nightly=Math.round(hotel.nightly*1);destinationAction(s,{type:'hotel',id:hotel.id,nights:4});assert.equal(s.internationalWallet.cash.KRW,before-hotel.nightly*4);assert.equal(destinationNextDayGuard(s),true);
destinationAction(s,{type:'extend',nights:1});assert.equal(s.globalDestination.visits['cp12|1|ICN'].hotel.checkoutDay,105);
s.day=102;destinationAction(s,{type:'checkout'});assert.equal(s.globalDestination.visits['cp12|1|ICN'].hotel,null);assert.throws(()=>destinationNextDayGuard(s),/penginapan/);assert.equal(s.internationalWallet.history.filter(x=>x.type==='REFUND').length,1);assert.throws(()=>destinationAction(s,{type:'checkout'}));
const saved=deserialize(serialize(s));assert.equal(saved.internationalWallet.cash.KRW,s.internationalWallet.cash.KRW);
const q=fxQuote(s,'JPY',10000);assert.ok(q.simulated);assert.ok(q.units>0);assert.equal(q.currency,'JPY');
console.log('PASS CP1/CP2: 30 currencies, 240 curated hotel candidates, pricing, checkout, extension, refund, duplicate guard, save/load');
