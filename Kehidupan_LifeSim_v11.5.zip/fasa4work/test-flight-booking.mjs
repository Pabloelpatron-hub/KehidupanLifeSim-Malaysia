import assert from 'node:assert/strict';
import {findFlights,quoteFlight} from './js-release-v8-9-20261114/flight-booking.js';
const f=findFlights('KUL','ICN',100);assert.equal(f.length,1);
const q=quoteFlight(f[0],{passengers:2,checkedBags:1});assert.equal(q.totalSen,Math.round(145000*2*1.15)+8500+2*12500);
assert.equal(q.simulated,true);assert.throws(()=>findFlights('KUL','XXX',1));
assert.throws(()=>quoteFlight(f[0],{passengers:0}));assert.throws(()=>quoteFlight(f[0],{checkedBags:3}));
assert.equal(findFlights('ICN','KUL',100).length,1);console.log('PASS: Phase 2 flight catalog and fare quote tests');
