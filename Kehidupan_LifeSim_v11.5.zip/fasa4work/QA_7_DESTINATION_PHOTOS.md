# Seven destination photo integration

Hero images cropped from user second collage: AKL, AMS, CMB, DAC, JED, KTM, MLE

Attraction mappings use cropped synthetic collage tiles. They are visual illustrations and not verified real photographs. Some attraction cards remain without images rather than assign a misleading photo. No production deployment.

{
  "AKL": {
    "Auckland Harbour Bridge": "destination-assets/akl-user-attraction-01.webp",
    "One Tree Hill": "destination-assets/akl-user-attraction-02.webp",
    "Rangitoto Island": "destination-assets/akl-user-attraction-03.webp",
    "Wynyard Quarter": "destination-assets/akl-user-attraction-04.webp"
  },
  "AMS": {
    "Royal Palace Amsterdam": "destination-assets/ams-user-attraction-01.webp",
    "NEMO Science Museum": "destination-assets/ams-user-attraction-02.webp"
  },
  "CMB": {
    "Independence Memorial Hall": "destination-assets/cmb-user-attraction-01.webp",
    "Colombo Lotus Tower": "destination-assets/cmb-user-attraction-02.webp",
    "Mount Lavinia Beach": "destination-assets/cmb-user-attraction-03.webp"
  },
  "DAC": {
    "Shaheed Minar": "destination-assets/dac-user-attraction-01.webp",
    "Curzon Hall": "destination-assets/dac-user-attraction-02.webp",
    "Sadarghat": "destination-assets/dac-user-attraction-03.webp"
  },
  "JED": {
    "Al Rahma Mosque": "destination-assets/jed-user-attraction-01.webp",
    "Obhur Beach": "destination-assets/jed-user-attraction-02.webp"
  },
  "KTM": {
    "Kathmandu Durbar Square": "destination-assets/ktm-user-attraction-01.webp",
    "Bhaktapur Durbar Square": "destination-assets/ktm-user-attraction-02.webp"
  },
  "MLE": {
    "Grand Friday Mosque": "destination-assets/mle-user-attraction-01.webp",
    "Villingili Island": "destination-assets/mle-user-attraction-02.webp",
    "Rasfannu Beach": "destination-assets/mle-user-attraction-03.webp"
  }
}