# Travel Foundation — Checkpoint 6 QA

Baseline: v9.5 Travel Foundation Checkpoint 5. No Netlify deployment.

## Changes
- Added conservative `PHYSICAL_UI_ACTIONS` and `PHYSICAL_UI_FORMS` policy in `travel-foundation.js`.
- Added capture-phase click and submit guards in `app.js`, preventing listed physical actions from reaching legacy handlers when player is abroad.
- Remote banking, messages, restaurant/contractor and gang management are **not blanket-blocked**.
- Existing core engine physical action checks remain intact.

## Automated tests
- JavaScript syntax: passed for `app.js` and `travel-foundation.js`.
- Checkpoint 4 travel state tests: run (see console log for details).
- Checkpoint 5 relocation, expenses, daily process, ledger and save round-trip: passed.
- Checkpoint 6 action-policy tests: passed for all listed actions/forms and representative remote actions.
- ZIP integrity: checked separately.

## Remaining gaps
- This is a targeted UI guard, **not a complete classification** of hundreds of legacy actions and forms. A full action-by-action audit and domain-layer checks remain necessary.
- UI guard alone cannot protect direct module function calls; high-risk physical domain operations need dedicated checks.
- No automated browser/iPhone Safari E2E tests were executed.
- Overseas booking, flight, hotels, tourism spending and in-game travel activation are out of scope for Fasa 1.
- Do not deploy to production or call Fasa 1 fully complete yet.
