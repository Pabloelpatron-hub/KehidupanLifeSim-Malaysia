import assert from 'node:assert/strict';
import {DESTINATION_CODES,destinationCatalog,destinationCatalogExpanded,destinationAction,destinationNextDayGuard,destinationView} from './js-release-v8-9-20261114/universal-destination.js';
import {GLOBAL_AIRPORTS} from './js-release-v8-9-20261114/global-flight-network.js';
assert.equal(DESTINATION_CODES.length,30);
for(const code of DESTINATION_CODES){const c=destinationCatalog(code);assert.equal(c.currency,GLOBAL_AIRPORTS[code].currency);for(const type of ['hotel','activities','dining','shopping','transport'])assert.ok(c[type].length>0);}
const s={day:10,sequence:0,accounts:{travelInternational:{balance:100000}},internationalWallet:{version:1,cash:{JPY:1000000},history:[],processed:[]},globalJourney:{activeJourney:{id:'journey-test',status:'AT_DESTINATION',currentAirport:'NRT',segments:[{id:'seg-1'}]}}};
assert.match(destinationView(s,'stay'),/Tokyo/);
assert.throws(()=>destinationNextDayGuard(s),/penginapan/);
const before=s.internationalWallet.cash.JPY;
destinationAction(s,{type:'hotel',id:destinationCatalogExpanded('NRT').hotel[0].id,nights:2});assert.ok(s.internationalWallet.cash.JPY<before);
destinationNextDayGuard(s);s.day++;destinationNextDayGuard(s);s.day++;assert.throws(()=>destinationNextDayGuard(s),/penginapan/);
const after=s.internationalWallet.cash.JPY;assert.throws(()=>destinationAction(s,{type:'shopping',id:'wrong'}));assert.equal(s.internationalWallet.cash.JPY,after);
destinationAction(s,{type:'dining',id:destinationCatalogExpanded('NRT').dining[0].id});assert.ok(s.internationalWallet.history.some(x=>x.type==='SPEND'));
assert.equal(s.globalDestination.visits['journey-test|1|NRT'].history.length,2);
console.log('PASS: 30 destination catalogs, currencies, hotel nights, wallet, invalid purchase, UI');
