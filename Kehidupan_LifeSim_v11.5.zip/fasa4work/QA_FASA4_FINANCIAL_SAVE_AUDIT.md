# Fasa 4 — Financial & Save Audit

Baseline: Kehidupan_LifeSim_Fasa4_Audit_Recovery_Dev.zip. No Netlify deployment.

## Changes
- Added `test-fasa4-financial-integrity.mjs`: actual `initial()` state, outbound ticket, Seoul hotel, extension, subway, meal, paid attraction, checkout, return ticket; journal balancing, exact main-account debit, `validate`, JSON `serialize`/`deserialize` round-trip, and tourism history persistence.
- Fixed stale Seoul tourism footer claiming return travel unavailable; now points to the Return Flight panel.
- Return-flight airport button now disables after check-in cutoff (the backend already rejected it).
- Corrected `test-flight-experience.mjs` Node-only harness to supply a minimal `Image` shim before dynamically importing the shared browser-dependent module. This does not change game runtime.

## Test outcome
- 17/17 `test-*.mjs` pass in Node with the browser shim where required.
- This is synthetic integration coverage, **not** reconciliation against a user-provided real save.
- Browser/WebGL/MapLibre/Safari visual performance, tile provider, and full real-save migration remain unverified.
