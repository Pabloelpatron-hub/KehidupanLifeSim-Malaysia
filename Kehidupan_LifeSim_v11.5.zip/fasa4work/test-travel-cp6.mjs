import assert from 'node:assert/strict';
import {physicalUiEligibility,PHYSICAL_UI_ACTIONS,PHYSICAL_UI_FORMS} from './js-release-v8-9-20261114/travel-foundation.js';
const home={character:{city:1},travel:{version:1,status:'AT_HOME',location:{country:'MY',cityId:1},activeTrip:null,trips:[],processedEvents:[],returnJourney:false}};
const abroad=structuredClone(home);abroad.travel.status='ABROAD';abroad.travel.location={country:'KR',city:'Seoul'};abroad.travel.activeTrip={id:'trip-1'};
for(const action of PHYSICAL_UI_ACTIONS){assert.equal(physicalUiEligibility(home,'action',action).allowed,true,action);assert.equal(physicalUiEligibility(abroad,'action',action).allowed,false,action);}
for(const form of PHYSICAL_UI_FORMS){assert.equal(physicalUiEligibility(home,'form',form).allowed,true,form);assert.equal(physicalUiEligibility(abroad,'form',form).allowed,false,form);}
for(const remote of ['bank-transfer','ct-work','group-task-confirm','message','restaurant-manage'])assert.equal(physicalUiEligibility(abroad,'action',remote).allowed,true,remote);
assert.equal(physicalUiEligibility(abroad,'action','venue').reason.length>0,true);
console.log('PASS: '+PHYSICAL_UI_ACTIONS.length+' physical UI actions, '+PHYSICAL_UI_FORMS.length+' forms, remote exceptions');
