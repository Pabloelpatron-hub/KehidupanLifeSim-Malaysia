# Fasa 4 — Shopping & KRW Budget (Development)

Baseline: Fasa4 Hotel Expiry Audit ZIP.

Implemented: Seoul shopping catalogue, fixed simulated conversion RM1 = KRW320, MYR bank debit via existing `spend`, persisted per-trip purchases, optional KRW spending cap and budget form. Purchasing requires active Seoul travel status. Purchase is performed inside `mutate`, so a failed bank debit rolls back the purchase state.

Tests: `test-fasa4-shopping.mjs` validates pricing, budget guard, JSON persistence, status guard, panel. Other test files are regression coverage. Note: FX is a simulation, not live rate. Browser Safari and production CDN map/3D tests remain pending; user save import not provided. Do not deploy production.
