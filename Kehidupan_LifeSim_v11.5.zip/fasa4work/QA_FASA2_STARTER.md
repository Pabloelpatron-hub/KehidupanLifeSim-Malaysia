# Phase 2 — Flight Booking Starter

Implemented: simulated KUL↔ICN route catalog, search by game day, deterministic MYR-sen quote calculation, passengers, baggage and class validation.

Not implemented: booking transaction, financial ledger debit, UI, airport workflow, return itinerary, time-zone progression, Three.js, MapLibre. No production deployment.

The route fares are gameplay examples, NOT live fares. This starter module is not imported by the game UI yet.
