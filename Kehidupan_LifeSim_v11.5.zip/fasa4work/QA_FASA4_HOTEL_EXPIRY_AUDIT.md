# Fasa 4 — Hotel Expiry Audit

Baseline: Kehidupan_LifeSim_Fasa4_Financial_Save_Audit_Dev.zip.

## Fix
- `ensureSeoul` settles expired active hotel stays once when `checkoutDay <= s.day`.
- Historical booking is marked `COMPLETED`, with `actualCheckoutDay` set to the original scheduled checkout day. Cost and duration remain unchanged.
- Active hotel pointer cleared; new hotel bookings are possible. No duplicate history entries on repeated calls.
- Existing early checkout behavior remains `CHECKED_OUT`.

## Tests
- Added `test-seoul-hotel-expiry.mjs` covering expiration, history, idempotence, no extension/checkout of expired booking, rebooking, and JSON roundtrip.
- All 18 `test-*.mjs` passed in Node.
- `node --check` of changed module passed; ZIP integrity checked.

## Remaining limitations
- No user-provided real save was available for migration/reconciliation.
- Three.js/MapLibre visual output and iPhone Safari touch/performance have not been tested in a real browser.
- This is a development build, not production approval. Netlify production was not changed.
