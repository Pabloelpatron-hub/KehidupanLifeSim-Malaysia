# CP6 — Integrasi Global & Audit Akhir (14 November 2026)

## Keputusan
**32/32 ujian Node automatik LULUS** (termasuk ujian CP6 baharu); **30/30 destinasi**, **180/180 paparan tab simulasi**, **240 hotel**, **450 tarikan**, **450 makanan/minuman**, **450 barangan**, **90 mod pengangkutan** diperiksa secara programatik. Tiada ID berulang dalam katalog setiap destinasi; tiada hero/hotel image yang hilang. Ini **TEST BUILD, BUKAN RELEASE CANDIDATE PRODUCTION**.

## 6.1 Integrasi katalog
- 30 kod destinasi dipadankan dengan mata wang dalam GLOBAL_AIRPORTS; setiap destinasi mempunyai 8 hotel, >=15 aktiviti, >=15 makanan/minuman, >=15 produk dan 3 mod pengangkutan.
- Enam tab Stay, Activities, Dining, Shopping, Finance, Travel dirender untuk setiap destinasi dengan state perjalanan contoh yang mempunyai rekod pembayaran sah. 180 paparan berjaya tanpa exception.
- 30 fail hero dan 90 imej bilik WebP yang dipautkan dalam katalog wujud di dalam ZIP. Gambar bilik merupakan ilustrasi kategori, bukan bukti bilik sebenar di hotel bernama itu.
- Nama hotel, lokasi tarikan, waktu operasi dan harga adalah katalog curated offline; tidak disahkan secara individu terhadap sumber rasmi. Item produk dan menu tidak mewakili stok peniaga sebenar.

## 6.2 World simulation dan multi-city
- Ujian existing global flight network, booking, checkout, Fasa 5 dan international travel regression lulus. Ujian CP6 baharu menguji state bagi semua 30 destinasi, booking/checkout hotel, penolakan hotel berganda, pembelian, debit wallet, dan roundtrip serialize/deserialize untuk hotel dan shopping inventory.
- Integrasi perjalanan antarabangsa menggunakan globalJourney, sementara sistem Seoul/legacy travel masih mempunyai model berasingan. Status silang antara model ini **belum terbukti konsisten dalam semua edge case**.
- Tick world simulation utama masih dipanggil melalui nextDay(s), tetapi audit menyeluruh setiap subsistem Malaysia semasa pemain berada di luar negara **belum dilakukan**. Tiada dakwaan bahawa semua event, cukai, pinjaman, payroll, NPC dan perniagaan telah diuji secara manual.
- Jadual zon masa antarabangsa, transit rentas tengah malam, pertukaran destinasi ketika hotel masih aktif dan sambungan save lama sebenar memerlukan pengesahan browser end-to-end.

## 6.3 Ujian regresi & pembaikan
- Dibaiki ujian lama `test-universal-destination.mjs`: ID hotel `standard` tidak lagi sah selepas katalog CP2 menggantikannya dengan `real-1`..`real-8`; ujian kini menggunakan ID katalog semasa. Ujian itu lulus semula. Tiada penukaran game state dibuat semata-mata untuk menepati ujian lapuk.
- Ditambah `test-cp6-global-audit.mjs` yang memeriksa semua 30 destinasi, katalog, nilai integer harga, aset hotel/hero, keenam-enam tab, wallet debit, inventori, hotel stay, save roundtrip, checkout dan guard.
- Kesemua 32 fail test-*.mjs lulus. Node syntax check untuk app.js, universal-destination.js, global-journey-booking.js, global-flight-network.js lulus.
- Pemeriksaan ini automatik menggunakan Node, bukan pengesahan visual/audio iPhone Safari. Tidak deploy Netlify.

## Isu belum selesai / release blockers
1. Pengesahan hotel sebenar, status operasi, room type, harga dan 450 tempat lawatan, waktu operasi/tiket melalui sumber rasmi.
2. Simulasi FX bukan kadar live; minor unit bagi beberapa mata wang masih mempunyai model legacy dan memerlukan migrasi berhati-hati.
3. Ujian manual Safari iPhone: responsif, overflow, scrolling, popup, gambar, audio airport/flight.
4. End-to-end pelbagai negara sebenar dengan transit dan flight clock zon masa, save JSON lama, kegagalan pembayaran, refund dan kembali ke Malaysia; model `travel` vs `globalJourney` perlu regression lebih mendalam.
5. Inventori pembelian luar negara kekal di `travelShoppingInventory`; paparan dalam halaman Aset Malaysia belum disahkan.
6. Simulasi world Malaysia: semak semua subsistem kewangan, NPC, kontraktor, restoran dan event semasa hari luar negara berlalu.
7. Gambar tarikan/produk/makanan bukan 1:1 authenticated photo; foto bilik dari kolaj pengguna tidak membuktikan hotel tertentu.

## Kesimpulan
CP6 **audit automatik selesai dan 32/32 lulus**; ini bukan pengesahan bahawa seluruh expansion telah memenuhi setiap acceptance criterion atau production-ready. Fail ZIP ialah checkpoint untuk ujian lanjut, tanpa deployment.
