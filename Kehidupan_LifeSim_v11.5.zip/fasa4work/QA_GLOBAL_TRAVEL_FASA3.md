# Fasa 3 — Universal Destination Engine (TEST BUILD, NOT FINAL)

Implemented: 30 destination registries with six navigable tabs (Stay, Activities, Dining, Shopping, Finance, Travel), city-specific game catalogues, hotel bookings and checkout, activity/transport/meal/shopping spending in each destination currency, transaction history, next-day lodging guard, bank-to-travel funding and local-currency FX form, FLEX onward/return flight search. Global arrival after universal airport EXIT now enters destination view. Seoul's original standalone travel flow remains intact.

Limitations: local offers and prices are illustrative simulation, not independently verified businesses/real prices. Some destinations have only two hotel tiers, one activity, two food choices and one product: content breadth is incomplete versus intended full real-world destination databases. The shared generic editorial visual is used for all cities; city-specific photography and themes are Fasa 4. Return ticket/overnight travel and full browser end-to-end checks remain for Fasa 5–6. No Safari device validation or production deployment.

QA: test-universal-destination.mjs; test-global-flight-network.mjs; test-global-flight-checkout.mjs; test-universal-airport.mjs; node --check app.js.
