# Fasa 4 — Audit & Missed Return Airport Recovery

Baseline: Kehidupan_LifeSim_Fasa4_Missed_Flight_Dev.zip. Production/Netlify unchanged.

## Fixed
- Rebooking for a missed return flight now supports RETURNING status (player already at Incheon Airport).
- On successful rebooking, RETURNING resets to ABROAD, returnJourney=false, location Seoul, and airport checklist/boarding state clears; bank debit remains delegated to existing app mutate+spend handler.
- Return airport steps reject expired departure time. Return panel shows rebooking action when flight was missed during airport processing.
- Added regression test for missed return flight after partial airport check-in, state recovery and duplicate guard.

## Automated tests
- PASS 15 of 16 test-*.mjs (airport, booking, payment, flight clock browser shim, midnight, missed flight, Seoul tourism/transport/hotel/return, travel CP4–CP8).
- `test-flight-experience.mjs` fails in plain Node due to existing face-mesh.js top-level browser Image dependency (`ReferenceError: Image is not defined`). `test-flight-clock-browser-shim.mjs` passes and covers flight clock using browser shim. Not a proven browser runtime defect; still unresolved test harness issue.
- No physical iPhone Safari/WebGL/MapLibre rendering verification.

## Still pending
- Full financial reconciliation against real save files; representative save fixtures and end-to-end import/export test.
- Production tile provider/offline asset handling, Three.js rendering on Safari.
- Departure/boarding UX timing consistency, hotel conflicts and comprehensive day rollover tests.
