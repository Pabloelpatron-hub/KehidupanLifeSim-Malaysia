import assert from 'node:assert/strict';
import {searchGlobalRoutes} from './js-release-v8-9-20261114/global-flight-network.js';
import {buildGlobalFlightPlan,createGlobalJourneyState,commitPaidGlobalBooking,advanceGlobalJourney} from './js-release-v8-9-20261114/global-journey-booking.js';
let s=createGlobalJourneyState();
for(const [from,to,id] of [['KUL','ICN','A'],['ICN','NRT','B'],['NRT','KUL','C']]){
 const itinerary=searchGlobalRoutes(from,to)[0];
 const p=buildGlobalFlightPlan(itinerary,{departureDay:20,bookingDay:15});
 assert.equal(p.legs[0].from,from);assert.equal(p.legs.at(-1).to,to);
 for(let i=1;i<p.legs.length;i++)assert.ok(p.legs[i].departureAbsoluteMinute-p.legs[i-1].arrivalAbsoluteMinute>=90);
 const receipt={bookingId:id,paymentId:'pay-'+id,paymentSource:'bank:main',paidSen:p.quote.totalSen};
 s=commitPaidGlobalBooking(s,p,receipt);
 assert.throws(()=>commitPaidGlobalBooking(s,p,receipt));
 for(const e of ['AT_AIRPORT','IN_FLIGHT','ARRIVED','AT_DESTINATION'])s=advanceGlobalJourney(s,id,e);
}
assert.equal(s.activeJourney,null);assert.equal(s.history.length,1);assert.equal(s.history[0].segments.length,3);
console.log('PASS FLEX booking lifecycle and idempotent paid receipts');
