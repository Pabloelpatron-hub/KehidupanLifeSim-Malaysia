globalThis.Image=class {set src(v){};set decoding(v){}};
await import('./test-flight-experience.mjs');
