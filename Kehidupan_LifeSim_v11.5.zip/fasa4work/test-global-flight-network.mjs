import assert from 'node:assert/strict';
import {GLOBAL_AIRPORTS,GLOBAL_AIRLINES,GLOBAL_DIRECT_ROUTES,searchGlobalRoutes,quoteGlobalItinerary,directFlights} from './js-release-v8-9-20261114/global-flight-network.js';
assert.equal(Object.keys(GLOBAL_AIRPORTS).length,31);
assert.equal(Object.keys(GLOBAL_AIRLINES).length,33);
for(const route of GLOBAL_DIRECT_ROUTES){assert(GLOBAL_AIRPORTS[route.from]&&GLOBAL_AIRPORTS[route.to]);assert(route.airlines.length);for(const id of route.airlines)assert(GLOBAL_AIRLINES[id]);}
let pairs=0;for(const a of Object.keys(GLOBAL_AIRPORTS))for(const b of Object.keys(GLOBAL_AIRPORTS)){if(a===b)continue;const options=searchGlobalRoutes(a,b);assert(options.length,`No route ${a}-${b}`);for(const opt of options){assert.equal(opt.legs[0].from,a);assert.equal(opt.legs.at(-1).to,b);assert(opt.stops<=2);}pairs++;}
assert.equal(pairs,930);
assert.equal(directFlights('KUL','JFK').length,0);
const trip=searchGlobalRoutes('KUL','JFK')[0];const quote=quoteGlobalItinerary(trip,{departureDay:21,bookingDay:15});assert(quote.totalSen>0);assert.equal(quote.legs.length,trip.legs.length);
assert.throws(()=>quoteGlobalItinerary(trip,{departureDay:21,bookingDay:22}));
assert.throws(()=>quoteGlobalItinerary(trip,{departureDay:21,bookingDay:15,airlineIds:['ZZ']}));
console.log('PASS phase 1 global registry, route search, airline checks, 930 airport pairs, fare quotes');
