import assert from 'node:assert/strict';
globalThis.Image=class {set src(x){} };
const {quoteReturn,bookReturn}=await import('./js-release-v8-9-20261114/seoul-return.js');
import {DIRECT_AIRLINES} from './js-release-v8-9-20261114/flight-booking.js';
for(const airline of DIRECT_AIRLINES){const s={day:20,travel:{status:'ABROAD',location:{city:'Seoul'},activeTrip:{id:'out1',quote:{passengers:1}}}};const q=quoteReturn(s,22,'economy',0,airline.id);assert.equal(q.airlineName,airline.name);assert.equal(q.airlineId,airline.id);assert.ok(q.flightNumber.startsWith(airline.id));const t=bookReturn(s,22,'economy',0,airline.id);assert.equal(t.airlineName,airline.name);assert.equal(t.aircraft,airline.aircraft);assert.equal(t.paidSen,q.paidSen);assert.equal(s.travel.activeTrip.returnFlight.airlineId,airline.id)}
const s={day:20,travel:{status:'ABROAD',location:{city:'Seoul'},activeTrip:{id:'out2',quote:{passengers:1}}}};
assert.throws(()=>quoteReturn(s,22,'first',0,'D7'),/Kelas tidak ditawarkan/);
console.log('PASS four return airlines, pricing, ticket metadata, unsupported class');
