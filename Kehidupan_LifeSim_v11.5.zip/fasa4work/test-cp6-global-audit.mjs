import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {initial,serialize,deserialize} from './js-release-v8-9-20261114/state.js';
import {DESTINATION_CODES,destinationCatalogExpanded,destinationAction,destinationNextDayGuard,destinationView,validateGlobalDepartureStay} from './js-release-v8-9-20261114/universal-destination.js';
import {GLOBAL_AIRPORTS} from './js-release-v8-9-20261114/global-flight-network.js';
import {ensureInternationalWallet,formatForeign} from './js-release-v8-9-20261114/international-wallet.js';
const assetDir=path.resolve('destination-assets');
const stats={destinations:0,hotels:0,activities:0,dining:0,shopping:0,transport:0,missingPhotos:[],duplicateIds:[],missingCurrency:[],brokenViews:[]};
for(const code of DESTINATION_CODES){
 const c=destinationCatalogExpanded(code);stats.destinations++;
 assert.equal(c.currency,GLOBAL_AIRPORTS[code].currency,`${code} currency`);
 for(const [k,min] of [['hotel',8],['activities',15],['dining',15],['shopping',15],['transport',3]]){
  assert.ok(c[k].length>=min,`${code} ${k} minimum`);stats[k==='hotel'?'hotels':k]+=c[k].length;
  const ids=c[k].map(x=>x.id);if(new Set(ids).size!==ids.length)stats.duplicateIds.push(`${code}:${k}`);
  for(const x of c[k])assert.ok(Number.isSafeInteger(x.nightly??x.price)&&(x.nightly??x.price)>=0,`${code} ${k} invalid price`);
 }
 for(const f of [c.hero,...c.hotel.map(h=>h.photo)])if(!fs.existsSync(path.join(assetDir,path.basename(f))))stats.missingPhotos.push(`${code}:${f}`);
 const s=initial('CP6');s.day=100;s.hour=10;s.globalJourney={activeJourney:{id:'cp6-'+code,status:'AT_DESTINATION',currentAirport:code,segments:[{id:'seg-'+code,from:'KUL',to:code,status:'ARRIVED',payment:{id:'pay-'+code,amountSen:50000,source:'bank'}}]}};
 ensureInternationalWallet(s);s.internationalWallet.cash[c.currency]=900000000;
 for(const tab of ['stay','activities','dining','shopping','finance','travel']){
  try{const html=destinationView(s,tab);assert.ok(html.includes(c.city),`${code} ${tab} city`);assert.ok(html.includes(formatForeign(900000000,c.currency).replace(/[^0-9.,]/g,'').slice(0,2))||tab==='travel',`${code} ${tab} amount`)}catch(e){stats.brokenViews.push(`${code}:${tab}:${e.message}`)}
 }
 const item=c.shopping[0];const b=s.internationalWallet.cash[c.currency];destinationAction(s,{type:'shopping',id:item.id});assert.equal(s.internationalWallet.cash[c.currency],b-item.price);assert.equal(s.travelShoppingInventory.at(-1).airport,code);
 const hotel=c.hotel[0];destinationAction(s,{type:'hotel',id:hotel.id,nights:2});destinationNextDayGuard(s);
 assert.equal(deserialize(serialize(s)).globalDestination.visits[`cp6-${code}|1|${code}`].hotel.checkoutDay,102,`${code} hotel save`);
 assert.equal(deserialize(serialize(s)).travelShoppingInventory.at(-1).airport,code,`${code} shopping save`);
 assert.throws(()=>destinationAction(s,{type:'hotel',id:hotel.id,nights:1}),/Daftar keluar/);
 const cash=s.internationalWallet.cash[c.currency];destinationAction(s,{type:'checkout'});assert.equal(s.internationalWallet.cash[c.currency],cash,'nonrefundable hotel refund');
 assert.throws(()=>destinationNextDayGuard(s),/penginapan/);
}
assert.deepEqual(stats.duplicateIds,[],'duplicate IDs');assert.deepEqual(stats.missingPhotos,[],'missing images');assert.deepEqual(stats.brokenViews,[],'broken views');
console.log('PASS CP6 global audit',JSON.stringify(stats));
