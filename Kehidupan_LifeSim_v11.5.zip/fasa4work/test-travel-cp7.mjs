import assert from 'node:assert/strict';
import {requireMalaysiaPresence,isMalaysiaPresent} from './js-release-v8-9-20261114/travel-foundation.js';
globalThis.Image=class {set src(v){} set decoding(v){}};
const {crimeAction}=await import('./js-release-v8-9-20261114/crime.js');
const {pilotMeet}=await import('./js-release-v8-9-20261114/npc-vertical-slice.js');
const home={character:{city:1},travel:{status:'AT_HOME',location:{country:'MY',cityId:1}}};
const abroad=structuredClone(home);abroad.travel.status='ABROAD';abroad.travel.location={country:'KR',city:'Seoul'};
assert.equal(isMalaysiaPresent(home),true);assert.equal(isMalaysiaPresent(abroad),false);
assert.doesNotThrow(()=>requireMalaysiaPresence(home));assert.throws(()=>requireMalaysiaPresence(abroad),/Malaysia/);
for(const type of ['prepare','challenge']){
 const before=JSON.stringify(abroad);
 assert.throws(()=>crimeAction(abroad,type,{}),/Malaysia/);
 assert.equal(JSON.stringify(abroad),before,'rejected crime action must not mutate state');
}
const before=JSON.stringify(abroad);
assert.throws(()=>pilotMeet(abroad,[]),/Malaysia/);
assert.equal(JSON.stringify(abroad),before);
console.log('PASS: physical domain guards reject overseas calls without state mutation');
