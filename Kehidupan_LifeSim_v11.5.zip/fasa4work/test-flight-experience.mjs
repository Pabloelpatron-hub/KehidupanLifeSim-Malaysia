import assert from 'node:assert/strict';
// Browser Image is required by the shared state dependency graph.
globalThis.Image=class {set src(v){} };
const {startFlight,advanceFlight,arriveSeoul}=await import('./js-release-v8-9-20261114/flight-experience.js');
const trip={id:'flight-100',departureDay:12,departureLocalHour:9,durationMinutes:390,airportReady:true,airportCompleted:['CHECK_IN','BAG_DROP','SECURITY','IMMIGRATION','GATE','BOARDING']};
const s={day:12,hour:8,character:{city:'kuala-lumpur'},travel:{version:1,status:'AT_AIRPORT',location:{country:'MY',cityId:'kuala-lumpur'},activeTrip:trip,trips:[],processedEvents:[],returnJourney:false}};
assert.equal(startFlight(s),'TAKEOFF');assert.equal(s.travel.status,'IN_FLIGHT');assert.throws(()=>startFlight(s));
assert.equal(advanceFlight(s),'CRUISE');assert.equal(advanceFlight(s),'DESCENT');assert.equal(advanceFlight(s),'LANDED');assert.throws(()=>advanceFlight(s));
assert.equal(arriveSeoul(s),'arrival:flight-100');assert.equal(s.hour,14);assert.equal(s.travel.activeTrip.arrivalClock.minuteSeoul,930);assert.equal(s.travel.status,'ABROAD');assert.equal(s.travel.location.city,'Seoul');assert.equal(s.travel.processedEvents.length,1);assert.throws(()=>arriveSeoul(s));
console.log('PASS flight lifecycle and idempotent arrival');
