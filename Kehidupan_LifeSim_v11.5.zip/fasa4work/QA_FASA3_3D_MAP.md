# Fasa 3 — Three.js + MapLibre integration (development build)

- Three.js 0.170 dynamic ESM import from jsDelivr. Procedural aircraft with camera orbit, light, cloud layers and resize/dispose.
- MapLibre GL JS 4.7.1 from unpkg; MapLibre demo tiles for proof of concept; route illustrative, not live tracking.
- Both lazy-load only on click; CSS 2D fallback remains. No state or ledger mutations by visual components.
- **Known limitations:** CDN/tiles require network; not bundled offline. MapLibre demo tiles not suitable as production provider. No verified iPhone Safari gameplay; no actual high-quality GLB airplane; no cinematic automated camera or flight-time synchronization yet.
- Run syntax check and ZIP integrity; browser visual QA still required.
