# CP1 & CP2 — development test build (NOT production)
Baseline: Global_Travel_Fasa5_MultiCity_Finance_World_TEST.zip.

## CP1
- 30 airport destinations mapped to local currencies; 28? distinct currencies (shared EUR).
- Fixed FX quote precision, locked quote verification, transaction rate/spread and source metadata, currency label in UI.
- Existing balanced journal, cash ledger, save/load retained. Rates are OFFLINE SIMULATION, not live market rates. Minor-unit treatment for IDR/KHR/LAK remains legacy game representation for save compatibility, and needs a dedicated migration before claiming strict ISO 4217 minor-unit conformity.
- Test: test-international-wallet.mjs and test-cp1-cp2.mjs.

## CP2
- Replaced 4 fictional generic hotel labels per city with 8 individually curated hotel name CANDIDATES for each of 30 cities (240 entries). Candidate names, current operating status and location have NOT been independently verified against official hotel sources. They MUST NOT be presented as live verified hotel inventory.
- 3 room category simulations, 3 cancellation tiers, seasonal nightly rates, 1-night extension, early checkout with tier-dependent refund for unused nights, flight departure checkout guard.
- Prices and room categories are SIMULATED; no real-time room inventory or guaranteed room-type verification.
- Existing save hotel objects kept compatible by nullish default refund rate. No destructive save schema change.
- Test: test-cp1-cp2.mjs, test-global-phase5.mjs.

## Outstanding for FULL acceptance
- Independently verify every hotel candidate's existence, location, current operations and available room types; replace outdated/closed candidates.
- Validate per-destination market price ranges with cited sources, tax/service charge rules and real seasonal calendars.
- Audit all 30 currencies for strict ISO minor-unit accounting and migrate legacy saves before changing underlying stored units.
- Real Safari/iPhone UI testing and full-game integration regression (automated Node tests are not a substitute).
- Do not deploy production.
