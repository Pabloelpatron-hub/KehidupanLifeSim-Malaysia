# Fasa 2 — Universal Airport & AEROTRACE checkpoint

## Implemented in this checkpoint
- `js-release-v8-9-20261114/universal-airport.js`: generic airport/flight lifecycle driven by the active paid FLEX segment and each leg's IATA airport codes.
- Ordered departure: CHECK_IN → BAG_DROP → SECURITY → IMMIGRATION → GATE → BOARDING.
- Flight phases: TAKEOFF → CRUISE → DESCENT → LANDED.
- Ordered arrival: LANDING → IMMIGRATION_ARRIVAL → BAGGAGE_CLAIM → CUSTOMS → EXIT.
- Transit moves to the next booked leg without closing the journey; final arrival marks the destination; homeward arrival at KUL archives journey.
- Domain functions return new state without mutating the input; invalid/duplicate/out-of-order actions throw.

## QA
- `node test-universal-airport.mjs`: PASS for a two-leg KUL → transit → JFK journey, including premature, repeated, and out-of-order steps.
- Airport codes and cities read from the 31-airport global registry.

## NOT YET DONE
- Not yet connected to live app action handlers or UI, AEROTRACE rendering, airport sound, or legacy Seoul flow.
- Flight timings are game simulations, not real airline schedules. Actual airport-specific procedures vary and must be refined.
- No full iPhone Safari end-to-end QA. No production deployment.
