# Fasa 2 UI/AEROTRACE integration checkpoint (NOT FINAL)

Implemented: FLEX global flight search now exposes quotation confirmation and bank-account payment using existing atomic checkout; paid global journeys display universal airport UI; departure steps use ordered state machine; AEROTRACE iframe accepts current leg's airport IATA codes; landing messages transition universal flight through phases to arrival; airport/jet ambience follows UI; arrival steps and transit leg switching use same domain state. Legacy Seoul flow is retained.

Automated checks: node --check app.js; test-global-flight-checkout.mjs; test-universal-airport.mjs; test-global-flight-network.mjs.

Important limitations: UI has not been exercised in real iPhone Safari; browser end-to-end interaction and AEROTRACE rendering across all 31 airports remain unverified. Existing AEROTRACE visual geography may require route-specific validation. Global journey currently does not transition into universal destination UI (Fasa 3). Do not deploy to production.
