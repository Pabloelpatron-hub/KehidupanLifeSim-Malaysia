import assert from 'node:assert/strict';
import {searchGlobalRoutes} from './js-release-v8-9-20261114/global-flight-network.js';
import {buildGlobalFlightPlan,createGlobalJourneyState,commitPaidGlobalBooking,advanceGlobalJourney,globalJourneyLedger,globalNextDeparture} from './js-release-v8-9-20261114/global-journey-booking.js';
import {validateGlobalDepartureStay} from './js-release-v8-9-20261114/universal-destination.js';
let state=createGlobalJourneyState();
for(const [i,[from,to]] of [['KUL','ICN'],['ICN','NRT'],['NRT','KUL']].entries()){
 const plan=buildGlobalFlightPlan(searchGlobalRoutes(from,to)[0],{departureDay:20+i*5,bookingDay:15+i*5});
 const id='phase5-'+i;state=commitPaidGlobalBooking(state,plan,{bookingId:id,paymentId:'paid-'+id,paymentSource:'bank:main',paidSen:plan.quote.totalSen});
 assert.equal(globalNextDeparture(state).from,from);
 assert.equal(globalJourneyLedger(state).segments.length,i+1);
 if(i===1){const s={day:25,globalJourney:state,globalDestination:{visits:{[state.activeJourney.id+'|1|ICN']:{code:'ICN',hotel:{checkoutDay:28}}}}};assert.throws(()=>validateGlobalDepartureStay(s),/Daftar keluar/);s.globalDestination.visits[state.activeJourney.id+'|1|ICN'].hotel=null;assert.equal(validateGlobalDepartureStay(s),true);}
 for(const e of ['AT_AIRPORT','IN_FLIGHT','ARRIVED','AT_DESTINATION'])state=advanceGlobalJourney(state,id,e);
}
const ledger=globalJourneyLedger(state);assert.equal(ledger.segments.length,3);assert.equal(ledger.completedJourneys,1);assert.equal(state.activeJourney,null);assert.equal(ledger.totalPaidSen,state.history[0].segments.reduce((n,x)=>n+x.payment.amountSen,0));
const tampered=structuredClone(state);tampered.history[0].segments[1].payment.id=tampered.history[0].segments[0].payment.id;assert.throws(()=>globalJourneyLedger(tampered),/berulang/);
console.log('PASS Phase 5: 3-city journey, return, hotel departure, ledger, duplicate-payment audit');
