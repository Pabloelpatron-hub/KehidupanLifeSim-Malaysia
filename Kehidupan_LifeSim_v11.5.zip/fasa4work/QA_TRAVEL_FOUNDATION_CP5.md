# Travel Foundation — Checkpoint 5 QA
Baseline: Checkpoint 4 (derived from v9.5).

## Changes
- Synchronize `travel.location.cityId` after the existing domestic relocation action changes `character.city` while travel status is AT_HOME.
- Skip existing Malaysia 'Daily food and transport' obligation while `travel.location.country` is not MY; other daily/monthly obligations remain unchanged.

## Tests executed
- `node --check js-release-v8-9-20261114/engine.js`: PASS.
- `node test-travel-cp4.mjs`: PASS (atomic transitions, round trip, location eligibility).
- `node --experimental-default-type=module test-travel-cp5.mjs`: PASS (domestic relocation sync and validate, one-day advance home vs abroad, no Malaysia food/transport debit abroad, ledger reconciliation, JSON save roundtrip).
- ZIP CRC test: PASS.

## Limitations / follow-up
- Seoul tourism costs have NOT been implemented. This checkpoint only prevents overlapping Malaysia food/transport daily expense.
- Physical presence checks in restaurant, contractor, NPC and gang expansion actions are not comprehensively enforced yet.
- Browser-based iPhone Safari regression testing is outstanding.
- Do not deploy production; checkpoint is not a final Fasa 1 release.
