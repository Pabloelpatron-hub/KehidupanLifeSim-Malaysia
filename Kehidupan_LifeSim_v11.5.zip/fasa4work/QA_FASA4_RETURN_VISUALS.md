# Fasa 4 — Return Flight Visuals

- Return flight phase panel now offers Three.js 3D aircraft and MapLibre route ICN → KUL.
- Existing flight visuals module reused; reverse route only for return flight, with phase-based approximate aircraft position.
- Map is illustrative and not live GPS. Requires internet for libraries and map tiles.
- Three.js aircraft is procedural geometry, not a licensed realistic aircraft model.
- JavaScript syntax checks passed for `flight-visuals.js` and `seoul-return.js`.
- Automated tests passed: return flight, hotel, Seoul transport, flight booking.
- Safari / actual WebGL rendering has NOT been tested; this is a development build.
- Netlify production untouched.
