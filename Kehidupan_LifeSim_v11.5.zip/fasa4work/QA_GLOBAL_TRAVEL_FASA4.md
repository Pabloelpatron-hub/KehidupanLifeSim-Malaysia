# Fasa 4 visual asset QA

30 local city hero images, 90 derivative city atmosphere card images, 30 distinct themes. All images are AI-generated, NOT verified location photography. Detail cards are cropped from the corresponding hero, and should not be described as specific venue photographs. Seoul standalone assets preserved. Safari device testing pending.
