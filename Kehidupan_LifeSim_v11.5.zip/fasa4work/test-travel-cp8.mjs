import assert from 'node:assert/strict';
import {gangLifeAction} from './js-release-v8-9-20261114/gang-life.js';
const abroad={character:{city:'kuala-lumpur'},travel:{version:1,status:'ABROAD',location:{country:'KR',city:'Seoul'},activeTrip:{id:'trip-1'},trips:[],processedEvents:[],returnJourney:false},gang:{life:{pending:{kind:'initiation'}}}};
for(const type of ['apply','lafaz','welcome','recruit','accept']){
 const state=structuredClone(abroad),before=JSON.stringify(state);
 assert.throws(()=>gangLifeAction(state,type,{}),/kehadiran di Malaysia/);
 assert.equal(JSON.stringify(state),before,`Rejected ${type} must not mutate state`);
}
console.log('PASS: gang in-person action guards reject abroad without mutation');
