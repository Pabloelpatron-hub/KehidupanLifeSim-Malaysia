# CP3, CP4, CP5 — Development test (not production)

## Delivered
- CP3: 30 destination catalogs with at least 15 named real-world places each (450 entries); free/paid simulated options, visit duration, simulated opening hours, in-game hour advancement, repeat-visit guard, transaction history. Place names curated offline; individual live verification is NOT complete. Entry fees and hours are gameplay estimates, not official published rates. Guided experiences are categorized heuristically, not real booked tour operators.
- CP4: 30 catalogs with at least 15 recognizable locally relevant foods/drinks and 15 locally relevant retail item types each (450+ each); variable simulated prices; purchases added to `travelShoppingInventory` with item ID, quantity, paid amount, currency, city, airport, day and journey ID. Save/load serialization tested. Purchases are not a real retailer's stock.
- CP5: 30 destination-specific public transport/taxi/app labels; simulated prices and journey-duration metadata. Existing 30 city palettes and city hero images preserved; Seoul theme preserved. Repeated city stock images have been REMOVED from individual offer cards rather than falsely representing each item as an authentic item photo.

## Not complete / release blockers
- CP3: Verify 450 place names and operating status against current primary sources; confirm actual opening hours, admission rates, age limits and ticket types; replace simulated hours and prices where possible. Current activity duration is a simulation. No live availability.
- CP4: Verify availability and local pricing by venue, including currency and taxes. Inventory is maintained in a new persistent travelShoppingInventory array; the main Malaysia possessions screen has not yet been verified to display these items.
- CP5: No 1:1 photographs for 450+ attractions, 450+ dishes and 450+ products. Existing city-wide assets are AI illustrations, NOT authenticated documentary photographs. 30 distinct full typography systems are not newly built. Real Safari iPhone layout and audio not manually tested. Transport journey times are approximations, not routing calculations.
- Entire build is a test checkpoint, not a release candidate. Production Netlify not deployed.
