# Seoul merge finance checkpoint — NOT FINAL

Completed:
- Persistent International Travel Account created lazily during state migration.
- Balanced bank transfer from eligible personal accounts into Travel Account.
- Offline FX registry for 30 airports and multi-currency wallet.
- KRW conversion, wallet spend/refund primitives, validation and JSON save/load.
- International finance controls on existing Overview when travel status is ABROAD.
- Unit tests pass for wallet, ledger and save roundtrip; original financial and travel regression tests pass.

NOT completed / NOT production ready:
- Dark Editorial Seoul screen page has NOT yet replaced the old overview.
- Hotel/activities/dining/shopping have NOT yet been rewired to the authoritative wallet.
- Early checkout/refund has NOT yet been connected to hotel records.
- Return flight bank selection has NOT yet been connected to main game accounts.
- Enter Seoul button, full travel UI lock and Developer Test Mode removal NOT complete.
- Full journey and Safari browser QA NOT completed.

Do not deploy as final. Production untouched.
