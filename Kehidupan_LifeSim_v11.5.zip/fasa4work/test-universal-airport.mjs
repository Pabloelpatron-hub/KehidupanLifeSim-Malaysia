import assert from 'node:assert/strict';
import {searchGlobalRoutes} from './js-release-v8-9-20261114/global-flight-network.js';
import {buildGlobalFlightPlan,createGlobalJourneyState,reserveGlobalItinerary} from './js-release-v8-9-20261114/global-journey-booking.js';
import {UNIVERSAL_AIRPORT_STEPS,UNIVERSAL_ARRIVAL_STEPS,performUniversalDepartureStep,startUniversalFlight,advanceUniversalFlight,performUniversalArrivalStep,getUniversalAirportView} from './js-release-v8-9-20261114/universal-airport.js';
const route=searchGlobalRoutes('KUL','JFK',{maxStops:1}).find(r=>r.legs.length===2);assert(route);
const plan=buildGlobalFlightPlan(route,{departureDay:20,bookingDay:10});
let s=reserveGlobalItinerary(createGlobalJourneyState(),plan,{bookingId:'booking1',paymentId:'payment1',paymentSource:'bank',paidSen:plan.quote.totalSen});
for(let leg=0;leg<2;leg++){
 const day=plan.legs[leg].departureDay;
 assert.throws(()=>performUniversalDepartureStep(s,'BOARDING',{day}));
 assert.throws(()=>performUniversalDepartureStep(s,'CHECK_IN',{day:day-1}));
 for(const step of UNIVERSAL_AIRPORT_STEPS)s=performUniversalDepartureStep(s,step,{day});
 assert.throws(()=>performUniversalDepartureStep(s,'BOARDING',{day}));
 s=startUniversalFlight(s,{day});assert.throws(()=>startUniversalFlight(s,{day}));
 for(let i=0;i<3;i++)s=advanceUniversalFlight(s);
 assert.throws(()=>advanceUniversalFlight(s));
 for(const step of UNIVERSAL_ARRIVAL_STEPS)s=performUniversalArrivalStep(s,step);
 assert.throws(()=>performUniversalArrivalStep(s,'EXIT'));
 if(leg===0){assert.equal(getUniversalAirportView(s).legIndex,1);assert.equal(s.activeJourney.currentAirport,plan.legs[0].to);}
}
assert.equal(s.activeJourney.status,'AT_DESTINATION');assert.equal(s.activeJourney.currentAirport,'JFK');
assert.equal(s.history.length,0);console.log('PASS universal airport: two-leg transit, ordered departure, flight, arrival, duplicate guards');
