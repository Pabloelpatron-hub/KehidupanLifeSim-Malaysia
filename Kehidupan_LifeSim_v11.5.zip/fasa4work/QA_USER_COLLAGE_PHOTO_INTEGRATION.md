# User collage integration — development test

Source: four user-uploaded photographic collages. The images were divided into 140 individual local WebP tiles (50 + 30 + 30 + 30). The fourth collage contains hotel photos with embedded text and is retained as cropped source assets, not used as landmark photographs.

- 44 attraction-name-to-image mappings verified against the actual destination catalogue (23 supported destinations).
- 23 supported destination hero images replaced with user-provided collage crops; the remaining 7 keep their previous local hero images, not mismatched pictures.
- The attraction list renders a photo only when the exact curated name matches the current city and attraction; otherwise it remains text-only.
- Photographs are embedded under `destination-assets/user-landmarks/` and do not require remote image requests.
- These are crops from user-supplied collages, not independent original high-resolution photos; some source tiles are small and may be visibly soft when used as full-width heroes.
- Image-to-landmark matching is manual visual identification; no claim of forensic or geolocation verification.
- Existing finance, booking, travel and save structures were not modified.

Automated regression tests: `node test-cp3-cp5.mjs`, `node test-travel-cp5.mjs` passed. Actual iPhone Safari visual testing is still required. No production deployment performed.
