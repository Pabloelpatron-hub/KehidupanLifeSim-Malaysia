# Fasa 4 — Seoul → Malaysia Return Journey (development)

Added `seoul-return.js`, overview return panel, app action handlers, and ticket review form. Return ticket ICN–KUL uses simulated 09:00 KST departure, 420-minute duration, integer-sen MYR quote and existing `spend` ledger path. Ticket document appended to game documents. Return airport has six ordered idempotent steps; return flight has four phases; landing updates Malaysia game clock and closes itinerary with `RETURNED`, then player can finalize `AT_HOME`. Hotel overlap prevents booking and active hotel requires checkout before airport. Outbound airport and flight panels are suppressed during return journey to avoid duplicated controls.

## Tests run
- `test-flight-booking.mjs`: PASS
- `test-flight-payment.mjs`: PASS
- `test-airport-experience.mjs`: PASS
- `test-seoul-tourism.mjs`: PASS
- `test-seoul-hotel.mjs`: PASS
- `test-seoul-return.mjs`: PASS
- `test-flight-clock-browser-shim.mjs`: PASS
- JavaScript syntax `app.js`, `seoul-return.js`: PASS

## Remaining limitations
- No actual Safari/WebGL visual testing.
- Return flight currently uses a functional phase panel, not its own Three.js cinematic scene or map.
- Late/missed flights, refunds, rescheduling, travel insurance and comprehensive save migration audit not implemented.
- Return airport uses simulated steps and does not validate real visa or passport data.
- Return flight time engine assumes game Malaysia clock; user must be at airport before simulated 09:00 KST.
- Netlify production not deployed.
