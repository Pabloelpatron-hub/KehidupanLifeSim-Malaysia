# Fasa 4 — Seoul Transport & Dining

- Added local travel via subway, bus and taxi to five existing Seoul destinations.
- Travel changes player location, records trip/day/mode/destination, and debits simulated MYR via the existing bank ledger and action system.
- Added three dining purchases, recorded against the active trip and venue.
- Existing active hotel booking disables new hotel booking buttons.
- Existing travel location guards prevent actions outside Seoul.
- Prices and travel durations are fictional gameplay values, not live Seoul fares.
- Automated tests: `node test-seoul-tourism.mjs` and `node test-seoul-transport.mjs`.
- Safari UI and actual bank ledger end-to-end testing still pending. Return journey is not yet implemented.
