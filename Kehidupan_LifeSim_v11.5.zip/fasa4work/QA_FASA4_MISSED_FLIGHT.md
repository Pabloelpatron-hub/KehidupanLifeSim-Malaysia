# Fasa 4 — Missed Flight Rebooking

- Outbound KUL–ICN: when departure day/time has passed, offer rebooking for next in-game day; reset airport check-in and boarding steps.
- Return ICN–KUL: when missed before airport, offer rebooking for next in-game day.
- Simulated change fee: 15% of original ticket price, minimum RM20; original fare retained, no automatic refund.
- Charge is recorded by existing app `spend` ledger transaction; mutation rolls back on failed payment.
- Store `rebookHistory` and block repeat rebooking while ticket is not missed.
- Known limitation: return missed flights after entering RETURNING airport state are not yet recoverable; airport checks and missed-flight timing remain coarse whole-hour simulation.
- Browser/iPhone Safari UI not tested; visual Three.js/MapLibre not validated.
