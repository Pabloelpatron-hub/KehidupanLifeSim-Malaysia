# Seoul merge checkpoint — NOT FINAL

Baseline: Kehidupan_Airport_Contrast_Fix_REDOWNLOAD(2).zip; standalone: Seoul_Standalone_V3_1_Hotel_Logic_Audit_Fix_TEST(1).zip.

Changes applied to main game:
- Next Day while ABROAD in Seoul now checks hotel coverage before advancing through the existing nextDay engine.
- Next Day on booked return departure day is blocked, directing player to airport.
- Return airport panel now enables airport entry on the actual departure day (previously one day early).
- Booking a return flight no longer refuses a future flight solely because the hotel booking extends beyond departure; early checkout remains mandatory before airport entry.

Not integrated / DO NOT DEPLOY AS FINAL:
- Standalone dark editorial Seoul screen UI and photography into main app navigation.
- Multi-bank MYR Travel Account and KRW wallet in real double-entry financial state.
- Hotel room tier pricing, KRW charges, partial refund and dining/shopping in main state.
- Full save migration, cross-module regression and end-to-end browser QA.

This is an intermediate audit checkpoint, not a completed merge.
