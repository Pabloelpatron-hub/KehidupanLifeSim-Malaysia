# Fasa 3 — Flight Clock Integration (development)

- Penerbangan KUL–ICN berlepas pada 09:00 MYT, 390 minit, tiba 15:30 MYT / 16:30 KST.
- Flight start rejects attempts after departure hour; duration validated.
- Departure and arrival clock metadata persisted in travel.activeTrip.
- On arrival, main Malaysia game hour advances to 16:00 (whole-hour rounding); no extra action charge.
- For future flights crossing midnight, uses existing nextDay engine per elapsed day, not a second economy clock.
- Idempotent arrival event guard retained. All changes occur within existing app.mutate rollback.

## Caveats
- Current flight 390 minutes does not cross midnight, so multi-day integration remains untested with full complex game state.
- Local destination time shown as metadata; main UI remains Malaysia-time.
- No real Safari GPU/gesture verification; map tiles still require internet.
- Airport step currently does not model time spent; flight-start checks 09:00 cutoff.
- Not production-ready.

## Verified automated checks
- `node --check flight-experience.js`: PASS
- `test-flight-experience.mjs` via minimal Image browser shim: PASS (including hour and Seoul clock)
- `test-flight-booking.mjs`: PASS
- `test-flight-payment.mjs`: PASS
- `test-airport-experience.mjs`: PASS
- ZIP CRC integrity: PASS
