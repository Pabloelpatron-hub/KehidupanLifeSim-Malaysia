# Fasa 2 — Flight Booking & Payment (development)

Baseline: Fasa 2 Flight Booking Starter. No Netlify deployment.

Implemented: KUL→ICN booking UI on overview, departure day, economy/business, passengers, checked bags, fare breakdown, confirmation, atomic debit via existing finance ledger inside app.mutate, travel BOOKED state, active itinerary and e-ticket document. All prices are fictional simulation MYR values. UI deliberately does not claim airport check-in or boarding is available.

Tests executed: node --check app.js, flight-booking.js, travel-foundation.js; node test-flight-booking.mjs; node test-flight-payment.mjs; node test-travel-cp8.mjs; zip integrity.

Limitations: No real Safari device test, no real-world airline data, no cancellation/refund mechanism, no boarding/airport flow, no return flight booking, no live deployment. Do not replace production. A booking is permitted only when travel status AT_HOME; departure 1–365 days ahead. UI uses existing game action consumption and main account. End-to-end browser click testing not performed.
