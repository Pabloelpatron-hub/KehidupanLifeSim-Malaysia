# Fasa 3 — Cinematic Camera & Tracker QA

## Changes
- Three.js phase-specific takeoff/descent/landing camera and aircraft pose transitions.
- Orbit by pointer drag, two-finger pinch zoom, cinematic camera reset.
- Approximate 30 FPS rendering cap, adaptive pixel ratio, reduced-motion preference.
- WebGL resource cleanup, ResizeObserver cleanup, WebGL context-loss message, async load request guard.
- MapLibre simulated position marker derived from flight phase (not live tracking).
- Existing 2D fallback retained; no changes to economic or save engine.

## Automated checks
- `node --check js-release-v8-9-20261114/flight-visuals.js`: PASS
- `test-flight-booking.mjs`: PASS
- `test-flight-payment.mjs`: PASS
- `test-airport-experience.mjs`: PASS
- `test-flight-experience.mjs`: PASS
- `test-travel-cp4.mjs` through `test-travel-cp8.mjs`: PASS

## Limitations
- 3D rendering, MapLibre tile loading, gestures and performance have NOT been verified on a real iPhone Safari.
- Libraries and demo map tiles still require an internet connection; demo tiles are not a production tile service.
- Camera sequence is an in-scene visual, not a physics simulation; time-of-flight and international clock advancement remain pending.
- Airplane is procedural, not a licensed photorealistic aircraft asset.
- Do not deploy to production without browser QA.
