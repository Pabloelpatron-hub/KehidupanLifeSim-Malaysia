# Fasa 4 — Audit visual Three.js / MapLibre / Safari

## Pembaikan
1. Internet/CDN dibenarkan oleh pengguna. Library Three.js dan MapLibre kekal dimuat secara on-demand melalui CDN. Fail game kekal kecil; mesej kegagalan Three.js diperjelas. Ini bukan pembungkusan offline.
2. MapLibre tidak lagi menggunakan `demotiles.maplibre.org/style.json`. Peta menggunakan gaya raster CARTO basemap dengan atribusi OpenStreetMap dan CARTO. Ketersediaan dan syarat penggunaan penyedia tiles perlu disahkan sebelum deployment production.
3. Penanda pesawat kini diinterpolasi setiap animation frame selama maksimum 90 saat dalam segmen fasa semasa (takeoff, cruise, descent, landing), bukan sekadar melompat ke satu kedudukan statik. Kedudukan tetap anggaran visual, bukan telemetri sebenar atau pergerakan berdasarkan jam game.
4. Pengendalian error tiles dipertingkat: error counter, timeout 18 saat, mesej status, dan fallback laluan teks apabila peta gagal. Sumber WebGL dan animation frame dibersihkan apabila menukar visual. Had pixel ratio 1.25 membantu mengurangkan beban peranti.

## Pengesahan sebenar
- Sintaks modul: lulus.
- Ujian automatik Node.js: lihat keputusan yang disertakan dalam laporan pengeluaran.
- Chromium headless dicuba pada 390×844, DPR 3, touch enabled, tetapi permintaan ke localhost ditolak oleh persekitaran (`ERR_BLOCKED_BY_ADMINISTRATOR`). Oleh itu tiada bukti rendering Three.js atau MapLibre yang berjaya.
- Internet/CDN luaran juga tidak boleh diakses dari runtime ini (DNS gagal), jadi tiles tidak boleh disahkan dimuat sepenuhnya.
- Chromium emulasi viewport iPhone bukan Safari/WebKit iOS. Prestasi dan touch gesture pada iPhone Safari sebenar tidak boleh disahkan di sini.

## Keperluan sebelum production
- Uji melalui Netlify preview (bukan production) pada iPhone Safari sebenar; semak model pesawat, orbit/pinch, peta penuh, timeout/fallback, dan memori/peranti panas.
- Semak polisi/kuota penyedia tiles dan guna endpoint production yang diluluskan jika perlu.
- Tiada deployment dilakukan.
