// Canonical helpers for Lieutenant Caporegime succession and arrest cases.
// All values are in cents, matching finance.js. No account balances are mutated here.
import {groupAccount} from './lieutenant-group.js';
import {spend} from './finance.js';
import {CAPO_ARREST_SCENARIOS,OFFICER_DIALOGS,arrestNarrative,officerDialogue} from './lieutenant-capo-events.js';
export const KAWTIM_RANGES={Balai:[1000000,3000000],IPD:[3000000,6000000],IPK:[6000000,10000000]};
export const INSTITUTION_WEIGHT={Balai:0,IPD:17,IPK:34};
const clamp=(x,a=0,b=100)=>Math.max(a,Math.min(b,x));
export function lieutenantPeople(s){return s.gang.factions.find(f=>f.id===s.gang.membership)?.people||[];}
export function lieutenantCapos(s){return lieutenantPeople(s).filter(p=>p.rank===2&&['player-lieutenant','player'].includes(p.parent)&&!['Meninggal','Dipenjara'].includes(p.status)&&!p.replacedBy);}
export function capoCrew(s,capoId){return lieutenantPeople(s).filter(p=>p.rank===1&&(p.parent===capoId||(p.parent==null&&p.capoId===capoId)||(p.parent==null&&p.leaderId===capoId)));}
export function capoCandidates(s){const state=s.gang.life.lieutenantState,world=s.gang.world?.districts||{};return lieutenantPeople(s).filter(p=>p.rank===1&&p.status==='Aktif'&&!p.actingFor&&!p.transfer&&((world[p.district]?.state===state)||p.parent==='player')&&(!p.parent||['player','player-lieutenant'].includes(p.parent))).map(p=>({id:p.id,name:p.name,district:p.district,rank:p.rank,loyalty:p.loyalty,needsTransfer:world[p.district]?.state!==state}));}
export function appointCapo(s,personId,districtId){const l=s.gang.life,world=s.gang.world?.districts||{};if(s.gang.rank!==3)throw Error('Hanya Lieutenant boleh melantik Caporegime.');if(world[districtId]?.state!==l.lieutenantState)throw Error('Daerah di luar negeri Lieutenant.');if(lieutenantCapos(s).length>=3)throw Error('Ketiga-tiga slot Caporegime sudah penuh.');const candidate=capoCandidates(s).find(x=>x.id===personId);if(!candidate)throw Error('Calon tidak layak.');if(candidate.needsTransfer)throw Error('Soldier mesti selesai berpindah dahulu.');const p=lieutenantPeople(s).find(x=>x.id===personId);if(p.transfer)throw Error('Perpindahan masih berjalan.');p.rank=2;p.parent='player-lieutenant';p.district=districtId;p.actingFor=null;p.status='Aktif';return p;}
export function startTransfer(s,personId,districtId,days){const candidate=capoCandidates(s).find(x=>x.id===personId);if(!candidate||!candidate.needsTransfer)throw Error('Perpindahan tidak diperlukan atau calon tidak sah.');const p=lieutenantPeople(s).find(x=>x.id===personId);if(s.gang.world?.districts?.[districtId]?.state!==s.gang.life.lieutenantState)throw Error('Daerah penempatan tidak sah.');if(p.transfer)throw Error('Perpindahan sudah berlangsung.');if(!Number.isInteger(days)||days<3||days>7)throw Error('Tempoh perpindahan mesti 3–7 hari.');p.transfer={from:p.district,to:districtId,finish:s.day+days};p.status='Dalam Perpindahan';return p.transfer;}
export function completeTransfers(s){for(const p of lieutenantPeople(s)){if(p.transfer&&p.transfer.finish<=s.day){p.district=p.transfer.to;p.status='Aktif';delete p.transfer;}}}
// A local candidate search is an explicit timed recruitment, not a free instant Caporegime.
// It also supports a crew left without eligible Soldiers after permanent loss.
export function requestLocalSoldier(s,districtId,formerCapoId=null){
 const state=s.gang.life.lieutenantState,world=s.gang.world?.districts||{};
 if(s.gang.rank!==3||world[districtId]?.state!==state)throw Error('Daerah recruitment tidak sah.');
 const t=s.gang.life.lt??={};t.localRecruitments??=[];
 if(formerCapoId){
  const c=(t.capoCases||[]).find(c=>c.person===formerCapoId&&c.final&&['CONVICTED','DECEASED'].includes(c.status)&&!c.successorId);
  if(!c)throw Error('Crew ini tidak memerlukan pengganti tetap.');
  if(!lieutenantPeople(s).some(p=>p.id===formerCapoId))throw Error('Caporegime lama tidak ditemui.');
 }else if(lieutenantCapos(s).length>=3)throw Error('Semua slot Caporegime sudah diisi.');
 if(t.localRecruitments.some(x=>x.districtId===districtId&&x.formerCapoId===formerCapoId&&x.status==='pending'))throw Error('Pengambilan anggota di lokasi ini sedang berjalan.');
 const job={id:'lt-local-recruit-'+(++s.sequence),districtId,formerCapoId,createdDay:s.day,finishDay:s.day+3+((s.sequence*7)%5),status:'pending'};
 t.localRecruitments.push(job);return job;
}
export function completeLocalRecruitments(s){
 const t=s.gang.life.lt;if(!t?.localRecruitments)return [];
 const faction=s.gang.factions.find(f=>f.id===s.gang.membership);if(!faction)return [];
 const completed=[];
 for(const job of t.localRecruitments){
  if(job.status!=='pending'||job.finishDay>s.day)continue;
  if(job.formerCapoId){
   const c=(t.capoCases||[]).find(c=>c.person===job.formerCapoId&&c.final&&!c.successorId);
   if(!c){job.status='cancelled';continue;}
  }
  const id='lt-local-soldier-'+(++s.sequence);
  const name='Rekrut Tempatan '+String(s.sequence).padStart(4,'0');
  const recruit={id,name,rank:1,parent:job.formerCapoId||'player',district:job.districtId,status:'Aktif',loyalty:55,skill:45,resentment:0,recruitedDay:s.day};
  faction.people.push(recruit);faction.members=faction.people.length;
  job.status='completed';job.soldierId=id;completed.push(recruit);
  s.notices??=[];s.notices.unshift({day:s.day,title:'CALON SOLDIER TEMPATAN',text:name+' kini tersedia di '+(s.gang.world?.districts?.[job.districtId]?.name||job.districtId)+'.'});
 }
 return completed;
}
export function newCapoCase(s,capoId,scenarioIndex){const p=lieutenantCapos(s).find(x=>x.id===capoId&&x.status==='Aktif');if(!p)throw Error('Caporegime tidak tersedia.');const t=s.gang.life.lt??={};t.capoCases??=[];if(t.capoCases.some(x=>x.person===capoId&&!x.final))throw Error('Caporegime mempunyai kes yang masih aktif.');const scene=CAPO_ARREST_SCENARIOS[scenarioIndex];if(!scene)throw Error('Senario tangkapan tidak sah.');const id='lt-capo-case-'+(++s.sequence);const c={id,person:p.id,remandUntil:null,scenarioId:scene.id,unit:scene.unit,charge:scene.charge,day:s.day,status:'DITANGKAP',final:false,officerId:null,dialogMode:null,dialogIndex:null,kawtimCost:0,kawtimPaid:false,actingId:null,events:[{day:s.day,type:'arrest'}]};t.capoCases.push(c);p.status='Ditahan';p.capoCaseId=id;return {...c,narrative:arrestNarrative(scene.id,p.name)};}
export function policeContacts(s){const t=s.gang.life.lt||{};const state=s.gang.life.lieutenantState,world=s.gang.world?.districts||{};return Object.entries(t.police||{}).filter(([key,p])=>p.connected===true&&key===p.id&&(p.level==='IPK'?p.scope===state:world[p.scope]?.state===state)&&['Balai','IPD','IPK'].includes(p.level)&&Number.isFinite(Number(p.relationship))).map(([,p])=>({id:p.id,name:p.name,level:p.level,scope:p.scope,relationship:p.relationship,trust:p.trust,authority:p.authority,pressure:p.pressure}));}
export function officerChance(p){if(!p||!Object.hasOwn(INSTITUTION_WEIGHT,p.level))throw Error('Institusi pegawai tidak sah.');return clamp(9+INSTITUTION_WEIGHT[p.level]+Number(p.relationship||0)*.20+Number(p.trust||0)*.08+Number(p.authority||0)*.03-Number(p.pressure||0)*.06,5,88);}
export function kawtimCost(level,roll){const range=KAWTIM_RANGES[level];if(!range)throw Error('Institusi tidak sah.');return range[0]+Math.floor(clamp(roll,0,.999999)*((range[1]-range[0])/100000+1))*100000;}
export function contactOfficer(s,caseId,officerId,roll,dialogRoll){const c=findOpenCase(s,caseId);if(c.status!=='DITANGKAP'||c.officerId)throw Error('Permintaan bantuan sudah diputuskan.');const p=policeContacts(s).find(p=>p.id===officerId);if(!p)throw Error('Pegawai bukan kenalan polis yang sah.');const success=clamp(roll,0,.999999)*100<officerChance(p);c.officerId=officerId;c.dialogMode=success?'accept':'reject';c.dialogIndex=Math.min(4,Math.floor(clamp(dialogRoll,0,.999999)*5));c.dialogText=officerDialogue(c.dialogMode,c.dialogIndex,s.gang.life.nickname);c.kawtimCost=success?kawtimCost(p.level,dialogRoll):0;c.status=success?'MENUNGGU_BAYARAN':'DITANGKAP';c.events.push({day:s.day,type:success?'officer-accepted':'officer-rejected',officerId});if(!success)remandCase(s,caseId);return {success,dialog:c.dialogText,cost:c.kawtimCost,chance:officerChance(p)};}
function updatePerson(s,id,values){const p=lieutenantPeople(s).find(p=>p.id===id);if(!p)throw Error('NPC tidak ditemui.');Object.assign(p,values);return p;}
export function findOpenCase(s,id){const c=(s.gang.life.lt?.capoCases||[]).find(c=>c.id===id&&!c.final);if(!c)throw Error('Kes Caporegime tidak aktif.');return c;}
export function remandCase(s,id){const c=findOpenCase(s,id);if(c.status==='DALAM TAHANAN REMAN')return c;if(!['DITANGKAP','MENUNGGU_BAYARAN'].includes(c.status))throw Error('Kes tidak boleh masuk reman.');c.status='DALAM TAHANAN REMAN';c.remandUntil=s.day+14+Math.floor(Math.random()*22);c.events.push({day:s.day,type:'remand'});updatePerson(s,c.person,{status:'DALAM TAHANAN REMAN'});return c;}
export function actingCandidates(s,id){const c=findOpenCase(s,id);return capoCrew(s,c.person).filter(p=>p.status==='Aktif'&&!p.actingFor);}
export function appointActing(s,id,soldierId){const c=findOpenCase(s,id);if(c.status!=='DALAM TAHANAN REMAN'||c.actingId)throw Error('Pengganti sementara belum boleh dilantik.');const p=actingCandidates(s,id).find(p=>p.id===soldierId);if(!p)throw Error('Soldier bukan daripada crew Caporegime tersebut.');c.actingId=p.id;p.actingFor=c.person;updatePerson(s,c.person,{actingId:p.id});c.events.push({day:s.day,type:'acting',person:p.id});return p;}
export function closeCapoCase(s,id,outcome){const c=findOpenCase(s,id);if(!['RELEASED','CONVICTED','DECEASED'].includes(outcome))throw Error('Keputusan kes tidak sah.');if(outcome==='RELEASED'&&c.status==='MENUNGGU_BAYARAN'&&!c.kawtimPaid)throw Error('Kos Kawtim belum dibayar.');if(outcome==='RELEASED'&&!['DALAM TAHANAN REMAN','MENUNGGU_BAYARAN'].includes(c.status))throw Error('Pembebasan memerlukan keputusan reman atau bayaran yang sah.');c.status=outcome;c.final=true;c.closedDay=s.day;c.events.push({day:s.day,type:outcome});const p=updatePerson(s,c.person,{status:outcome==='RELEASED'?'Aktif':outcome==='CONVICTED'?'Dipenjara':'Meninggal'});if(outcome==='RELEASED'&&c.actingId){const acting=lieutenantPeople(s).find(x=>x.id===c.actingId);if(acting)delete acting.actingFor;delete p.actingId;}if(outcome!=='RELEASED'){p.vacantSince=s.day;}p.capoCaseId=null;const t=s.gang.life.lt;t.capoNotices??=[];const noticeId=c.id+'-'+outcome;if(!t.capoNotices.some(n=>n.id===noticeId))t.capoNotices.push({id:noticeId,caseId:c.id,day:s.day,person:c.person,type:outcome,read:false});return c;}
export function confirmKawtimPaid(s,id){const c=findOpenCase(s,id);if(c.status!=='MENUNGGU_BAYARAN'||c.kawtimPaid)throw Error('Bayaran tidak diperlukan atau sudah dibuat.');const fund=groupAccount(s);if(!Number.isSafeInteger(c.kawtimCost)||c.kawtimCost<=0)throw Error('Kos Kawtim tidak sah.');if((s.accounts[fund]?.balance||0)<c.kawtimCost)throw Error('Tabung Group tidak mencukupi.');spend(s,fund,c.kawtimCost,'Kos Kawtim kes '+c.id,'lt-capo-kawtim');c.kawtimPaid=true;c.events.push({day:s.day,type:'kawtim-paid',amount:c.kawtimCost});return closeCapoCase(s,id,'RELEASED');}
export function promoteActingToCapo(s,id){const c=(s.gang.life.lt?.capoCases||[]).find(c=>c.id===id&&c.final&&['CONVICTED','DECEASED'].includes(c.status));if(!c||!c.actingId||c.successorId)throw Error('Tiada pemangku yang boleh dinaikkan pangkat.');if(lieutenantCapos(s).length>=3)throw Error('Semua slot Caporegime sudah diisi.');const old=lieutenantPeople(s).find(p=>p.id===c.person),p=lieutenantPeople(s).find(p=>p.id===c.actingId&&p.actingFor===c.person);if(!old||!p)throw Error('Pemangku tidak ditemui.');p.rank=2;p.parent='player-lieutenant';p.status='Aktif';p.district=old.district;p.racket=old.racket;delete p.actingFor;for(const soldier of capoCrew(s,old.id)){if(soldier.id!==p.id){soldier.parent=p.id;if(soldier.capoId===old.id)soldier.capoId=p.id;if(soldier.leaderId===old.id)soldier.leaderId=p.id;}}c.successorId=p.id;old.replacedBy=p.id;delete old.actingId;delete p.actingFor;return p;}

// Shared daily transition: one case, one outcome, one notification per event.
export function capoCaseDay(s,randomFn=Math.random){
 const t=s.gang.life.lt;if(!t)return [];t.capoNotices??=[];const emitted=[];
 completeTransfers(s);
 completeLocalRecruitments(s);
 for(const c of t.capoCases||[]){
  if(c.final||c.status!=='DALAM TAHANAN REMAN')continue;
  c.remandUntil??=c.day+14+Math.floor(randomFn()*22);
  if(s.day<c.remandUntil)continue;
  const outcome=randomFn()<.52?'RELEASED':'CONVICTED';
  closeCapoCase(s,c.id,outcome);
  const n=t.capoNotices.find(x=>x.id===c.id+'-'+outcome);if(n)emitted.push(n);
 }
 return emitted;
}
export function lieutenantCaseHistory(s){return [...(s.gang.life.lt?.capoCases||[])].reverse();}
export function inheritCapoTerritories(s,oldId,newId){
 const own=s.gang.membership;let count=0;
 for(const z of s.gang.territories||[]){if(z.owner===own&&(z.manager===oldId||z.capoId===oldId||z.leaderId===oldId)){if(z.manager===oldId)z.manager=newId;if(z.capoId===oldId)z.capoId=newId;if(z.leaderId===oldId)z.leaderId=newId;count++;}}
 return count;
}
// Permanent succession may proceed even when the crew had no acting leader.
// Only an active Soldier of the vacated crew can inherit its leadership.
export function permanentSuccessorCandidates(s,caseId){
 const c=(s.gang.life.lt?.capoCases||[]).find(x=>x.id===caseId&&x.final&&['CONVICTED','DECEASED'].includes(x.status)&&!x.successorId);
 if(!c)return [];
 return capoCrew(s,c.person).filter(p=>p.status==='Aktif'&&(!p.actingFor||p.actingFor===c.person));
}
export function appointPermanentSuccessor(s,caseId,soldierId){
 const c=(s.gang.life.lt?.capoCases||[]).find(x=>x.id===caseId&&x.final&&['CONVICTED','DECEASED'].includes(x.status)&&!x.successorId);
 if(!c)throw Error('Tiada kekosongan tetap bagi kes ini.');
 const p=permanentSuccessorCandidates(s,caseId).find(p=>p.id===soldierId);
 if(!p)throw Error('Pilih Soldier aktif daripada crew yang kehilangan Caporegime.');
 if(c.actingId&&c.actingId!==soldierId){const former=lieutenantPeople(s).find(x=>x.id===c.actingId);if(former)delete former.actingFor;}
 c.actingId=soldierId;p.actingFor=c.person;
 return finalizeCapoSuccessor(s,caseId);
}
export function finalizeCapoSuccessor(s,caseId){
 const p=promoteActingToCapo(s,caseId);
 const c=(s.gang.life.lt.capoCases||[]).find(x=>x.id===caseId);
 c.inheritedRackets=inheritCapoTerritories(s,c.person,p.id);
 // An in-flight Group operation stays attributed to its original commander in history;
 // the new commander inherits the living crew and the current territory portfolio only.
 c.replacementSoldierNeeded=true;
 const recruitment=s.gang.life.lt.group?.recruitment;
 if(recruitment){delete recruitment[c.person];delete recruitment[p.id];}
 // Recruitment runs on the next Group daily tick, never inserts an untracked Soldier.
 const g=s.gang.life.lt.group;
 if(g)g.lastRecruitDay=-1; 
 s.gang.life.lt.capoNotices??=[];
 s.gang.life.lt.capoNotices.push({id:caseId+'-successor',caseId,person:p.id,type:'SUCCESSOR',day:s.day,read:false});
 return p;
}

// Convert an existing save's legacy Lieutenant arrest to the canonical case once.
export function migrateLegacyCapoCrises(s,roll=Math.random){
 const t=s.gang?.life?.lt;if(!t)return 0;t.capoCases??=[];let count=0;
 for(const ev of t.capoCrises||[]){
  if(!ev||ev.canonicalCaseId||ev.resolved)continue;
  const p=lieutenantPeople(s).find(p=>p.id===ev.person);if(t.capoCases.some(c=>c.person===ev.person&&!c.final)){ev.resolved=true;continue;}
  if(!p){ev.resolved=true;continue;}
  const scene=CAPO_ARREST_SCENARIOS[Math.min(CAPO_ARREST_SCENARIOS.length-1,Math.floor(roll()*CAPO_ARREST_SCENARIOS.length))];
  const id='lt-capo-case-'+(++s.sequence);
  t.capoCases.push({id,person:p.id,scenarioId:scene.id,unit:scene.unit,charge:scene.charge,day:s.day,status:'DITANGKAP',final:false,officerId:null,dialogMode:null,dialogIndex:null,kawtimCost:0,kawtimPaid:false,actingId:null,events:[{day:s.day,type:'arrest'}]});
  p.capoCaseId=id;p.status='Ditahan';ev.canonicalCaseId=id;ev.resolved=true;count++;
 }
 return count;
}
export function capoCaseNarrative(s,c){return arrestNarrative(c.scenarioId,lieutenantPeople(s).find(p=>p.id===c.person)?.name||'Caporegime');}
export function activeCapoCase(s){return (s.gang?.life?.lt?.capoCases||[]).find(c=>!c.final)||null;}

export function acknowledgeCapoNotice(s,id){const n=(s.gang.life.lt?.capoNotices||[]).find(n=>n.id===id);if(!n)throw Error('Notifikasi tidak ditemui.');n.read=true;return n;}

// Convert an actual Caporegime death into a permanent vacancy, preserving the crew and rackets.
export function recordCapoDeath(s,capoId){
 const p=lieutenantPeople(s).find(x=>x.id===capoId);if(!p||p.rank!==2||!['player-lieutenant','player'].includes(p.parent))return null;
 const t=s.gang.life.lt??={};t.capoCases??=[];t.capoNotices??=[];
 const prior=t.capoCases.find(x=>x.person===capoId&&x.status==='DECEASED');if(prior)return prior;
 let c=t.capoCases.find(x=>x.person===capoId&&!x.final);
 if(c){closeCapoCase(s,c.id,'DECEASED');return c;}
 const id='lt-capo-death-'+(++s.sequence);
 c={id,person:capoId,day:s.day,scenarioId:null,charge:'',status:'DECEASED',final:true,closedDay:s.day,actingId:p.actingId||null,events:[{day:s.day,type:'death'}]};
 t.capoCases.push(c);p.status='Meninggal';
 t.capoNotices.push({id:id+'-DECEASED',caseId:id,day:s.day,person:capoId,type:'DECEASED',read:false});
 return c;
}

// Read-only projection of the same canonical case IDs into the main PDRM screen.
// Do not insert these into crime.cases: those are player/justice-engine cases.
export function lieutenantPdrmRecords(s){
 return (s.gang?.life?.lt?.capoCases||[]).map(c=>({
  ...c,personName:lieutenantPeople(s).find(p=>p.id===c.person)?.name||'Caporegime',
  narrative:c.scenarioId?capoCaseNarrative(s,c):'Kematian Caporegime direkodkan.',
  history:(c.events||[]).map(e=>({day:e.day,event:e.type,amount:e.amount}))
 })).reverse();
}
