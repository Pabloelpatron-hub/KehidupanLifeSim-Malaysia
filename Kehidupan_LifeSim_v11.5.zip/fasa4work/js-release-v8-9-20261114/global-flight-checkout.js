import {spend} from './finance.js';
// Global travel phase 1: atomic state-level checkout adapter.
// Integrate with the existing app mutation boundary; never invoke from render.
import {searchGlobalRoutes,GLOBAL_AIRPORTS,GLOBAL_DIRECT_ROUTES} from './global-flight-network.js';
import {buildGlobalFlightPlan,createGlobalJourneyState,reserveGlobalItinerary} from './global-journey-booking.js';
const copy=x=>JSON.parse(JSON.stringify(x));
export function globalFlightChoices(state,{from,to,departureDay,seatClass='economy',checkedBags=0,passengers=1,maxOptions=8}={}){
 if(!state||!Number.isSafeInteger(state.day))throw Error('Tarikh game tidak sah');
 if(!GLOBAL_AIRPORTS[from]||!GLOBAL_AIRPORTS[to]||from===to)throw Error('Destinasi tidak sah');
 if(!Number.isSafeInteger(departureDay)||departureDay<state.day||departureDay>state.day+365)throw Error('Hari berlepas tidak sah');
 return searchGlobalRoutes(from,to,{maxOptions}).flatMap(itinerary=>{
  try {return [buildGlobalFlightPlan(itinerary,{departureDay,bookingDay:state.day,seatClass,checkedBags,passengers})];}
  catch{return [];}
 });
}
export function checkoutGlobalFlight(state,plan,{accountId='main',bookingId,paymentId}={}){
 if(!state||!plan||!Number.isSafeInteger(state.day))throw Error('Data tempahan tidak sah');
 if(typeof accountId!=='string'||!accountId.trim()||['__proto__','constructor','prototype'].includes(accountId))throw Error('Akaun pembayaran tidak sah');
 if(!['main','wallet','travelInternational','savings'].includes(accountId))throw Error('Akaun pembayaran tidak dibenarkan');
 if(typeof bookingId!=='string'||!bookingId.trim()||typeof paymentId!=='string'||!paymentId.trim())throw Error('ID transaksi diperlukan');
 if(state.globalTravelPayments?.some(x=>x.id===paymentId||x.bookingId===bookingId))throw Error('Bayaran atau tempahan sudah direkodkan');
 const active=state.globalJourney?.activeJourney;
 const origin=active?.currentAirport||'KUL';
 if(active&&active.status!=='AT_DESTINATION')throw Error('Perjalanan masih aktif');
 if(plan.from!==origin)throw Error('Airport asal tidak sepadan');
 if(plan.legs?.[0]?.departureDay<state.day)throw Error('Penerbangan sudah berlalu');
 // Validate the client quote against registered routes and current pricing before debiting.
 if(!Array.isArray(plan.legs)||!plan.legs.length||plan.legs.length>3)throw Error('Segmen penerbangan tidak sah');
 const routes=plan.legs.map(leg=>{const r=GLOBAL_DIRECT_ROUTES.find(r=>r.id===leg.routeId&&r.from===leg.from&&r.to===leg.to);if(!r)throw Error('Laluan penerbangan tidak berdaftar');return r;});
 if(routes[0].from!==plan.from||routes.at(-1).to!==plan.to||routes.some((r,i)=>i&&routes[i-1].to!==r.from))throw Error('Laluan tidak bersambung');
 if(new Set([plan.from,...routes.map(r=>r.to)]).size!==routes.length+1)throw Error('Laluan berulang');
 const expected=buildGlobalFlightPlan({legs:routes},{departureDay:plan.legs[0].departureDay,departureMinute:plan.legs[0].departureMinute,connectionMinutes:plan.connectionMinutes,bookingDay:state.day,passengers:plan.quote?.passengers,seatClass:plan.quote?.seatClass,checkedBags:plan.quote?.checkedBags,airlineIds:plan.legs.map(l=>l.airlineId)});
 if(JSON.stringify(expected)!==JSON.stringify(plan))throw Error('Harga atau jadual tiket telah berubah. Cari penerbangan semula');
 const amount=plan.quote?.totalSen;
 if(!Number.isSafeInteger(amount)||amount<=0)throw Error('Jumlah bayaran tidak sah');
 const account=state.accounts?.[accountId];
 if(!account||!Number.isSafeInteger(account.balance)||account.balance<amount)throw Error('Baki akaun tidak mencukupi');
 const next=copy(state);
 const journey=createGlobalJourneyState(next.globalJourney);
 // Reserve first, then debit, all on a copy. Caller commits this returned state atomically.
 next.globalJourney=reserveGlobalItinerary(journey,plan,{bookingId,paymentId,paymentSource:accountId,paidSen:amount});
 spend(next,accountId,amount,'Tiket FLEX '+plan.from+' → '+plan.to,'travel');
 next.globalTravelPayments=Array.isArray(next.globalTravelPayments)?next.globalTravelPayments:[];
 if(next.globalTravelPayments.some(x=>x.id===paymentId))throw Error('Bayaran sudah direkodkan');
 next.globalTravelPayments.push({id:paymentId,bookingId,accountId,amountSen:amount,currency:'MYR',day:state.day,type:'GLOBAL_FLIGHT',status:'PAID'});
 return next;
}
