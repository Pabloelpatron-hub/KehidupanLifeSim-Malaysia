// Optional browser visualizations. No game state mutation. Network required for CDN libraries/tiles.
let disposeActive=()=>{};
const THREE_URL='https://cdn.jsdelivr.net/npm/three@0.170.0/build/three.module.js';
const MAP_JS='https://unpkg.com/maplibre-gl@4.7.1/dist/maplibre-gl.js';
const MAP_CSS='https://unpkg.com/maplibre-gl@4.7.1/dist/maplibre-gl.css';
const MAP_STYLE={version:8,sources:{carto:{type:'raster',tiles:['https://a.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png','https://b.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png'],tileSize:256,attribution:'© OpenStreetMap contributors © CARTO'}},layers:[{id:'carto-base',type:'raster',source:'carto'}]};
const KUL=[101.7072,2.7456], ICN=[126.4505,37.4602];
function status(host,msg){host.textContent=msg;}
function flightRoute(reverse){return reverse?[ICN,[121,29],[114,21],[106,10],KUL]:[KUL,[106,10],[114,21],[121,29],ICN];}
function interpolate(route,progress){const n=Math.max(0,Math.min(1,Number(progress)||0))*(route.length-1),i=Math.min(route.length-2,Math.floor(n)),f=n-i;return route[i].map((v,j)=>v+(route[i+1][j]-v)*f);}
function fallbackMap(host,reverse,message){host.replaceChildren();const d=document.createElement('div');d.className='flight-map-fallback';d.setAttribute('role','img');d.setAttribute('aria-label','Laluan penerbangan antara Kuala Lumpur dan Incheon');d.innerHTML='<strong>✈ '+(reverse?'ICN → KUL':'KUL → ICN')+'</strong><p>Laluan penerbangan tersedia dalam mod ringkas. Peta interaktif tidak dapat dimuatkan.</p>';const e=document.createElement('p');e.className='smalltext';e.textContent=message;host.append(d,e);}

function loadScript(url){return new Promise((resolve,reject)=>{const s=document.createElement('script');s.src=url;s.onload=resolve;s.onerror=()=>reject(Error('Tidak dapat memuat library peta'));document.head.append(s);});}
function airplane(T){const g=new T.Group();const white=new T.MeshStandardMaterial({color:0xe9eff4,metalness:.35,roughness:.48});const blue=new T.MeshStandardMaterial({color:0x125d83,metalness:.25,roughness:.5});const dark=new T.MeshStandardMaterial({color:0x1c3344});function part(geo,mat,x,y,z,rx=0,ry=0,rz=0){const m=new T.Mesh(geo,mat);m.position.set(x,y,z);m.rotation.set(rx,ry,rz);g.add(m);return m;}part(new T.CylinderGeometry(.43,.58,8,16),white,0,0,0,Math.PI/2);part(new T.ConeGeometry(.43,1.6,16),white,0,0,-4.75,-Math.PI/2);part(new T.ConeGeometry(.58,1.25,16),white,0,0,4.55,Math.PI/2);part(new T.BoxGeometry(12,.14,1.7),white,0,0,.15);part(new T.BoxGeometry(4.8,.12,1.05),blue,0,.1,3.3);part(new T.BoxGeometry(.15,2.25,1.4),blue,0,1.1,3.55);for(const x of [-2.8,2.8]){part(new T.CylinderGeometry(.29,.33,1.45,12),dark,x,-.42,.25,Math.PI/2);part(new T.CylinderGeometry(.24,.24,1.5,12),white,x,-.42,.25,Math.PI/2);}for(let i=-3;i<=3;i++)for(const x of [-.44,.44])part(new T.SphereGeometry(.055,6,6),dark,x,.15,i*.76);return g;}
// All visual state is disposable and separate from the authoritative game state.
let visualRequest=0;
export async function openFlight3D(host,phase='CRUISE') {
  disposeActive(); const request=++visualRequest; host.replaceChildren(); status(host,'Memuatkan Three.js…');
  let T; try { T=await import(THREE_URL); } catch { if(request===visualRequest)status(host,'Three.js gagal dimuatkan. Semak sambungan internet; visual 2D masih tersedia.'); return; }
  if(request!==visualRequest||!host.isConnected)return;
  host.replaceChildren(); const area=document.createElement('div');area.className='flight-webgl';host.append(area);
  let renderer;try{renderer=new T.WebGLRenderer({antialias:true,powerPreference:'low-power'});}catch{status(host,'WebGL tidak tersedia. Gunakan visual 2D.');return;}
  renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.25));area.append(renderer.domElement);
  const scene=new T.Scene();scene.background=new T.Color(phase==='DESCENT'||phase==='LANDED'?0x9dc4d6:0x67b5e7);
  scene.fog=new T.Fog(scene.background,35,115);scene.add(new T.HemisphereLight(0xffffff,0x6b8fa9,2));
  const sun=new T.DirectionalLight(0xffffff,2);sun.position.set(-10,15,8);scene.add(sun);
  const plane=airplane(T);scene.add(plane);
  const cloudMaterial=new T.MeshStandardMaterial({color:0xffffff,transparent:true,opacity:.78});
  const clouds=[];for(let i=0;i<20;i++){const c=new T.Mesh(new T.SphereGeometry(1.1+(i%3)*.4,8,6),cloudMaterial);c.scale.set(1.9,.35,.85);c.position.set((i%7-3)*5,-3-(i%3)*.7,(Math.floor(i/7)-1)*13);scene.add(c);clouds.push(c);}
  const camera=new T.PerspectiveCamera(48,1,.1,140);
  let yaw=.55,pitch=.22,zoom=15,manual=false,down=null,running=true,raf=0,lastFrame=0;
  const canvas=renderer.domElement;canvas.style.touchAction='none';
  const pointers=new Map();let pinchDistance=null;
  const distance=()=>{const v=[...pointers.values()];return Math.hypot(v[0].x-v[1].x,v[0].y-v[1].y);};
  function pointerDown(e){pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});canvas.setPointerCapture(e.pointerId);if(pointers.size===2)pinchDistance=distance();else down={x:e.clientX,y:e.clientY};}
  function pointerMove(e){if(!pointers.has(e.pointerId))return;const previous=pointers.get(e.pointerId);pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});if(pointers.size===2){const d=distance();if(pinchDistance)zoom=Math.max(8,Math.min(25,zoom*pinchDistance/d));pinchDistance=d;manual=true;}else{yaw+=(e.clientX-previous.x)*.006;pitch=Math.max(-.35,Math.min(.9,pitch+(e.clientY-previous.y)*.005));manual=true;}}
  function pointerUp(e){pointers.delete(e.pointerId);pinchDistance=null;down=null;}
  function wheel(e) {
    e.preventDefault();
    const direction = Math.sign(e.deltaY);
    zoom = Math.max(8, Math.min(25, zoom + direction));
    manual = true;
  }
  canvas.addEventListener('pointerdown',pointerDown);canvas.addEventListener('pointermove',pointerMove);canvas.addEventListener('pointerup',pointerUp);canvas.addEventListener('pointercancel',pointerUp);canvas.addEventListener('wheel',wheel,{passive:false});
  const controls=document.createElement('div');controls.className='flight-visual-actions';const reset=document.createElement('button');reset.type='button';reset.className='btn';reset.textContent='Kamera sinematik';reset.addEventListener('click',()=>{manual=false;zoom=15;});controls.append(reset);host.append(controls);
  const note=document.createElement('p');note.className='smalltext';note.textContent='Three.js 3D · Seret untuk orbit · Cubit untuk zoom · Kamera sinematik untuk kembali ke paparan automatik.';host.append(note);
  function resize(){if(!area.isConnected)return;const w=Math.max(1,area.clientWidth),h=Math.max(220,Math.min(460,w*.55));renderer.setSize(w,h);camera.aspect=w/h;camera.updateProjectionMatrix();}
  const observer=typeof ResizeObserver==='function'?new ResizeObserver(resize):null;observer?.observe(area);window.addEventListener('resize',resize);resize();
  const start=performance.now();const reduced=window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches||false;
  function frame(ms){if(!running)return;if(document.hidden){raf=requestAnimationFrame(frame);return;}if(ms-lastFrame<32){raf=requestAnimationFrame(frame);return;}lastFrame=ms;
    const t=reduced?1:Math.min(1,(ms-start)/6500),smooth=t*t*(3-2*t);
    plane.rotation.x=Math.sin(ms*.0005)*.012;
    plane.rotation.z=phase==='TAKEOFF'?.02+.13*smooth:phase==='DESCENT'?-.03-.10*smooth:phase==='LANDED'?0:.012*Math.sin(ms*.0002);
    plane.position.y=phase==='TAKEOFF'?-1+smooth*2.4:phase==='DESCENT'?1.2-smooth*2.1:phase==='LANDED'?-.9:0;
    for(let i=0;i<clouds.length;i++){const c=clouds[i];c.position.z+=.045;if(c.position.z>22)c.position.z=-23;}
    if(!manual){yaw=phase==='TAKEOFF'?.25+.6*smooth:phase==='DESCENT'?1.1-.5*smooth:phase==='LANDED'?.4:.6+.16*Math.sin(ms*.00015);pitch=phase==='TAKEOFF'?.15+.15*smooth:phase==='DESCENT'?.4-.2*smooth:.22;}
    camera.position.set(Math.sin(yaw)*zoom*Math.cos(pitch),Math.sin(pitch)*zoom+2,Math.cos(yaw)*zoom*Math.cos(pitch));camera.lookAt(0,plane.position.y,0);
    try{renderer.render(scene,camera);}catch(err){running=false;status(host,'Rendering WebGL gagal. Visual 2D masih tersedia.');return;}raf=requestAnimationFrame(frame);
  }raf=requestAnimationFrame(frame);
  function contextLost(e){e.preventDefault();running=false;status(host,'Sambungan grafik terputus. Buka semula 3D atau gunakan visual 2D.');}
  canvas.addEventListener('webglcontextlost',contextLost);
  disposeActive=()=>{running=false;cancelAnimationFrame(raf);observer?.disconnect();window.removeEventListener('resize',resize);canvas.removeEventListener('webglcontextlost',contextLost);scene.traverse(o=>{if(o.geometry)o.geometry.dispose();});const materials=new Set();scene.traverse(o=>{if(o.material)(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>materials.add(m));});materials.forEach(m=>m.dispose());renderer.dispose();canvas.remove();};
}
export async function openFlightMap(host,progress=.52,reverse=false){
  disposeActive();const request=++visualRequest;host.replaceChildren();status(host,'Memuatkan MapLibre…');
  try{if(!document.querySelector('[data-flight-map-css]')){const link=document.createElement('link');link.rel='stylesheet';link.href=MAP_CSS;link.dataset.flightMapCss='1';document.head.append(link);}if(!window.maplibregl)await loadScript(MAP_JS);}catch(err){if(request===visualRequest)fallbackMap(host,reverse,'Library MapLibre tidak dapat dimuatkan. Semak internet atau CDN.');return;}
  if(request!==visualRequest||!host.isConnected)return;
  host.replaceChildren();const area=document.createElement('div');area.className='flight-maplibre';host.append(area);
  const route=flightRoute(reverse);let map,marker,raf=0,active=true,loaded=false,errors=0;
  const info=document.createElement('p');info.className='smalltext';info.textContent='Memuatkan data peta…';host.append(info);
  const fail=(reason)=>{if(!active)return;active=false;cancelAnimationFrame(raf);try{map?.remove();}catch{}fallbackMap(host,reverse,reason);};
  const timeout=setTimeout(()=>{if(!loaded)fail('Data peta mengambil masa terlalu lama untuk dimuatkan.');},18000);
  try{
    map=new window.maplibregl.Map({container:area,style:MAP_STYLE,center:[114,21],zoom:2.6,attributionControl:true,failIfMajorPerformanceCaveat:false});
    map.on('error',e=>{errors++;if(!loaded&&errors>=3)fail('Peta tidak dapat memuatkan tiles. Semak internet atau sekatan penyedia peta.');else if(loaded)info.textContent='Sesetengah tiles gagal dimuatkan; cuba sambungan internet lain.';});
    map.on('load',()=>{
      if(!active)return;loaded=true;clearTimeout(timeout);
      map.addSource('flight-route',{type:'geojson',data:{type:'Feature',geometry:{type:'LineString',coordinates:route}}});
      map.addLayer({id:'flight-route-line',type:'line',source:'flight-route',paint:{'line-color':'#e18426','line-width':3,'line-dasharray':[2,1]}});
      new window.maplibregl.Marker().setLngLat(KUL).setPopup(new window.maplibregl.Popup().setText('KUL · Kuala Lumpur')).addTo(map);
      new window.maplibregl.Marker().setLngLat(ICN).setPopup(new window.maplibregl.Popup().setText('ICN · Incheon')).addTo(map);
      const plane=document.createElement('div');plane.textContent='✈';plane.style.cssText='font-size:26px;filter:drop-shadow(0 1px 2px #000);';plane.setAttribute('aria-label','Kedudukan anggaran penerbangan');
      marker=new window.maplibregl.Marker({element:plane}).setLngLat(interpolate(route,progress)).addTo(map);
      const start=performance.now(),initial=Math.max(0,Math.min(1,Number(progress)||0));
      // Visual-only interpolation; game state remains authoritative. A 90-second loop advances only within the current flight segment.
      const phaseEnd=initial>=1?1:initial<.2?.2:initial<.8?.8:1;
      function tick(now){if(!active)return;const p=Math.min(phaseEnd,initial+(phaseEnd-initial)*Math.min(1,(now-start)/90000));marker.setLngLat(interpolate(route,p));info.textContent='Kedudukan anggaran '+Math.round(p*100)+'% · simulasi, bukan GPS langsung';raf=requestAnimationFrame(tick);}
      raf=requestAnimationFrame(tick);map.resize();
    });
  }catch(err){clearTimeout(timeout);fail('MapLibre tidak dapat dimulakan: '+(err?.message||'ralat tidak diketahui'));return;}
  disposeActive=()=>{active=false;clearTimeout(timeout);cancelAnimationFrame(raf);try{map?.remove();}catch{}};
}
export function attachFlightVisuals(){if(window.__flightVisualBound)return;window.__flightVisualBound=true;document.addEventListener('click',async e=>{const b=e.target.closest('[data-flight-visual]');if(!b)return;const returning=!!b.closest('#return-flight-experience');const host=document.getElementById(returning?'return-flight-visual-host':'flight-visual-host');if(!host)return;const phase=returning?(document.querySelector('#return-flight-experience')?.dataset.phase||'CRUISE'):(document.querySelector('#flight-experience .flight-scene')?.getAttribute('data-phase')||'CRUISE');if(b.dataset.flightVisual==='3d')await openFlight3D(host,phase);else await openFlightMap(host,({TAKEOFF:.12,CRUISE:.52,DESCENT:.86,LANDED:1})[phase]??.52,returning);});}
