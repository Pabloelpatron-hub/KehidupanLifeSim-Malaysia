// Fasa 3: deterministic outbound flight lifecycle. Visual preview is CSS/SVG, not Three.js.
import {transitionTravel} from './travel-foundation.js';
import {nextDay} from './engine.js';
const PHASES=['TAKEOFF','CRUISE','DESCENT','LANDED'];
export function flightProgress(s){const t=s.travel,trip=t?.activeTrip;if(t?.returnJourney)return null;if(!trip||!['AT_AIRPORT','IN_FLIGHT'].includes(t.status))return null;return {trip,phase:trip.flightPhase||null,ready:!!trip.airportReady};}
export function startFlight(s){const p=flightProgress(s);if(!p||s.travel.status!=='AT_AIRPORT'||!p.ready||p.phase)throw Error('Selesaikan boarding sebelum memulakan penerbangan');if(s.day!==p.trip.departureDay)throw Error('Hari penerbangan tidak sepadan');if(!Number.isSafeInteger(p.trip.durationMinutes)||p.trip.durationMinutes<=0||p.trip.durationMinutes>1440)throw Error('Tempoh penerbangan tidak sah');transitionTravel(s,'IN_FLIGHT');s.travel.activeTrip.flightPhase='TAKEOFF';s.travel.activeTrip.departureClock={day:s.day,minute:s.hour*60,timezone:'Asia/Kuala_Lumpur'};return 'TAKEOFF';}
export function advanceFlight(s){const p=flightProgress(s);if(!p||s.travel.status!=='IN_FLIGHT'||!PHASES.includes(p.phase))throw Error('Penerbangan belum bermula');if(p.phase==='LANDED')throw Error('Pesawat sudah mendarat');const next=PHASES[PHASES.indexOf(p.phase)+1];s.travel.activeTrip.flightPhase=next;return next;}
export function arriveSeoul(s){const p=flightProgress(s);if(!p||s.travel.status!=='IN_FLIGHT'||p.phase!=='LANDED')throw Error('Pesawat belum mendarat');const id='arrival:'+p.trip.id;if(s.travel.processedEvents.includes(id))throw Error('Ketibaan sudah diproses');// Use the existing daily engine exactly once for each elapsed Malaysia calendar day.
 const departure=p.trip.departureClock;
 if(!departure||!Number.isSafeInteger(departure.day)||!Number.isSafeInteger(departure.minute))throw Error('Rekod masa berlepas tidak sah');
 const total=departure.minute+p.trip.durationMinutes;
 const expectedDay=departure.day+Math.floor(total/1440);
 if(s.day!==departure.day)throw Error('Jam permainan berubah ketika penerbangan; semak save sebelum ketibaan');
 while(s.day<expectedDay)nextDay(s);
 const minuteMY=total%1440;
 // Preserve the exact arrival minute in arrivalClock; the legacy global clock stores whole hours.
 s.hour=Math.floor(minuteMY/60);
 transitionTravel(s,'ABROAD',{location:{country:'KR',city:'Seoul',district:null,venue:'Incheon International Airport'}});
 if(s.travel.seoul)s.travel.seoul.entered=false;
 s.travel.activeTrip.arrivalDay=s.day;
 s.travel.activeTrip.arrivalClock={day:expectedDay,minuteMalaysia:minuteMY,minuteSeoul:(minuteMY+60)%1440,timezone:'Asia/Seoul'};
 s.travel.processedEvents.push(id);return id;}
export function flightPanel(s){const p=flightProgress(s);if(!p)return '';const active=s.travel.status==='IN_FLIGHT';return `<section class="card" id="flight-experience"><h3>AEROTRACE · KUL → ICN</h3><p>Tempoh penerbangan game: ${p.trip.durationMinutes} minit. Visual: 90–180 saat.</p>${active?'<p>Penerbangan aktif. Laluan dikunci mengikut tiket.</p><button class="btn" data-action="aerotrace-open">Lihat Flight Tracker</button>':p.ready?'<button class="btn" data-action="flight-start">Berlepas</button>':'<p>Selesaikan boarding dahulu.</p>'}</section>`;}
