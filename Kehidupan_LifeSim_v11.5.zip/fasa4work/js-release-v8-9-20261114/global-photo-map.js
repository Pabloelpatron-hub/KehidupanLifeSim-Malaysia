// Curated mapping from user-provided photo collages; unmatched offers intentionally have no image.
export const USER_LANDMARK_PHOTOS={
  "SIN": {
    "Jewel Changi Airport": "destination-assets/user-landmarks/m1-01-01.webp",
    "ArtScience Museum": "destination-assets/user-landmarks/m1-01-02.webp",
    "Gardens by the Bay": "destination-assets/user-landmarks/m2-01-02.webp",
    "Gardens by the Bay": "destination-assets/user-landmarks/m3-01-01.webp"
  },
  "BKK": {
    "Wat Arun": "destination-assets/user-landmarks/m2-01-03.webp",
    "Wat Phra Kaew": "destination-assets/user-landmarks/m2-01-04.webp",
    "Grand Palace": "destination-assets/user-landmarks/m3-01-04.webp",
    "Wat Pho": "destination-assets/user-landmarks/m1-01-03.webp"
  },
  "CGK": {
    "National Monument": "destination-assets/user-landmarks/m2-01-05.webp",
    "Istiqlal Mosque": "destination-assets/user-landmarks/m2-02-01.webp"
  },
  "MNL": {
    "Fort Santiago": "destination-assets/user-landmarks/m2-02-02.webp",
    "Rizal Park": "destination-assets/user-landmarks/m2-02-03.webp"
  },
  "SGN": {
    "Saigon Central Post Office": "destination-assets/user-landmarks/m2-02-04.webp",
    "Independence Palace": "destination-assets/user-landmarks/m2-02-05.webp"
  },
  "PNH": {
    "Royal Palace": "destination-assets/user-landmarks/m2-03-01.webp",
    "Independence Monument": "destination-assets/user-landmarks/m2-03-04.webp"
  },
  "VTE": {
    "Pha That Luang": "destination-assets/user-landmarks/m2-03-03.webp",
    "Patuxai": "destination-assets/user-landmarks/m3-03-03.webp"
  },
  "RGN": {
    "Shwedagon Pagoda": "destination-assets/user-landmarks/m2-03-05.webp"
  },
  "BWN": {
    "Omar Ali Saifuddien Mosque": "destination-assets/user-landmarks/m2-04-02.webp",
    "Jame' Asr Hassanil Bolkiah Mosque": "destination-assets/user-landmarks/m2-04-03.webp"
  },
  "ICN": {
    "Gyeongbokgung Palace": "destination-assets/user-landmarks/m3-04-04.webp",
    "N Seoul Tower": "destination-assets/user-landmarks/m3-04-05.webp"
  },
  "NRT": {
    "Tokyo Skytree": "destination-assets/user-landmarks/m2-05-01.webp",
    "Senso-ji Temple": "destination-assets/user-landmarks/m2-05-02.webp",
    "Tokyo Tower": "destination-assets/user-landmarks/m1-03-01.webp"
  },
  "PEK": {
    "Forbidden City": "destination-assets/user-landmarks/m2-05-03.webp",
    "Temple of Heaven": "destination-assets/user-landmarks/m2-05-04.webp"
  },
  "TPE": {
    "Taipei 101": "destination-assets/user-landmarks/m2-05-05.webp",
    "Chiang Kai-shek Memorial Hall": "destination-assets/user-landmarks/m2-06-01.webp"
  },
  "HKG": {
    "Victoria Harbour": "destination-assets/user-landmarks/m2-06-02.webp",
    "Tian Tan Buddha": "destination-assets/user-landmarks/m2-06-03.webp"
  },
  "DEL": {
    "India Gate": "destination-assets/user-landmarks/m2-06-04.webp",
    "Qutub Minar": "destination-assets/user-landmarks/m2-06-05.webp",
    "Red Fort": "destination-assets/user-landmarks/m1-03-09.webp",
    "Lotus Temple": "destination-assets/user-landmarks/m1-03-10.webp"
  },
  "DXB": {
    "Burj Khalifa": "destination-assets/user-landmarks/m1-04-09.webp",
    "Dubai Frame": "destination-assets/user-landmarks/m1-04-10.webp"
  },
  "DOH": {
    "National Museum of Qatar": "destination-assets/user-landmarks/m1-05-01.webp"
  },
  "IST": {
    "Galata Tower": "destination-assets/user-landmarks/m1-05-03.webp"
  },
  "LHR": {
    "Big Ben": "destination-assets/user-landmarks/m1-05-04.webp"
  },
  "CDG": {
    "Arc de Triomphe": "destination-assets/user-landmarks/m1-05-05.webp"
  },
  "FRA": {
    "Frankfurt Cathedral": "destination-assets/user-landmarks/m1-05-06.webp"
  },
  "SYD": {
    "Sydney Harbour Bridge": "destination-assets/user-landmarks/m1-05-08.webp"
  },
  "JFK": {
    "Empire State Building": "destination-assets/user-landmarks/m1-05-10.webp"
  }
};
const SEVEN_DESTINATION_PHOTOS = {
  "AKL": {
    "Auckland Harbour Bridge": "destination-assets/akl-user-attraction-01.webp",
    "One Tree Hill": "destination-assets/akl-user-attraction-02.webp",
    "Rangitoto Island": "destination-assets/akl-user-attraction-03.webp",
    "Wynyard Quarter": "destination-assets/akl-user-attraction-04.webp"
  },
  "AMS": {
    "Royal Palace Amsterdam": "destination-assets/ams-user-attraction-01.webp",
    "NEMO Science Museum": "destination-assets/ams-user-attraction-02.webp"
  },
  "CMB": {
    "Independence Memorial Hall": "destination-assets/cmb-user-attraction-01.webp",
    "Colombo Lotus Tower": "destination-assets/cmb-user-attraction-02.webp",
    "Mount Lavinia Beach": "destination-assets/cmb-user-attraction-03.webp"
  },
  "DAC": {
    "Shaheed Minar": "destination-assets/dac-user-attraction-01.webp",
    "Curzon Hall": "destination-assets/dac-user-attraction-02.webp",
    "Sadarghat": "destination-assets/dac-user-attraction-03.webp"
  },
  "JED": {
    "Al Rahma Mosque": "destination-assets/jed-user-attraction-01.webp",
    "Obhur Beach": "destination-assets/jed-user-attraction-02.webp"
  },
  "KTM": {
    "Kathmandu Durbar Square": "destination-assets/ktm-user-attraction-01.webp",
    "Bhaktapur Durbar Square": "destination-assets/ktm-user-attraction-02.webp"
  },
  "MLE": {
    "Grand Friday Mosque": "destination-assets/mle-user-attraction-01.webp",
    "Villingili Island": "destination-assets/mle-user-attraction-02.webp",
    "Rasfannu Beach": "destination-assets/mle-user-attraction-03.webp"
  }
};
export function photoForLandmark(code,name){return SEVEN_DESTINATION_PHOTOS[code]?.[name]||USER_LANDMARK_PHOTOS[code]?.[name]||null;}
