import {requireMalaysiaPresence} from './travel-foundation.js';
// CP03 limited vertical slice: one persistent developer NPC and an offline project-introduction storyline.
// This creates NO contractor project, tender award, financing, or money mutation.
import {registerNpcProfile,ensureWorldCore} from './world-core.js';
import {applyNpcAction,listNpcCommitments} from './world-actions.js';
import {offers,bid,activeCategories,GRADES} from './contractor.js';
export const PILOT_ID='NPC-BIZ-FARID-0001';
const PROJECT_ID='PILOT-INTRO-FARID-001';
export function pilotVenue(venues,city){return venues.find(v=>v.city===city&&v.type==='cowork') ?? venues.find(v=>v.city===city&&v.type==='cafe');}
export function ensurePilot(s,venues){
  const v=pilotVenue(venues,s.character.city); if(!v)return null;
  ensureWorldCore(s);
  registerNpcProfile(s,PILOT_ID,{fullName:'Farid Hakimi',honorific:"Dato' Seri",gender:'male',portraitId:'pilot-farid-placeholder',identityGroup:'malay',primaryClass:'business_tycoon',secondaryClasses:['orang_kenamaan','developer'],identityLocked:true});
  if(!s.npcs[PILOT_ID])s.npcs[PILOT_ID]={id:PILOT_ID,name:"Dato' Seri Farid Hakimi",age:55,city:v.city,venue:v.id,occupation:'Pemaju hartanah',personality:'professional',interest:'business',familiarity:0,trust:0,friendship:0,respect:0,affection:0,resentment:0,last:-1,met:s.day,memory:[],connections:[],known:{},portrait:1,available:true,importance:'significant'};
  // Venue assignment follows current city; stable NPC ID, identity, and history remain unchanged.
  s.npcs[PILOT_ID].venue=v.id;s.npcs[PILOT_ID].city=v.city;
  return v;
}
export function pilotStatus(s){const w=ensureWorldCore(s);return {met:w.events.some(e=>e.type==='NPC_ENCOUNTER'&&e.actorId===PILOT_ID),contact:s.contacts.includes(PILOT_ID),commitments:listNpcCommitments(s,PILOT_ID)};}
export function pilotMeet(s,venues){requireMalaysiaPresence(s,'Pertemuan NPC secara fizikal');const v=ensurePilot(s,venues);if(!v||s.currentVenue!==v.id)throw Error('Masuk lokasi pertemuan dahulu.');const result=applyNpcAction(s,{type:'NPC_ENCOUNTER',actionId:'pilot-meet-'+s.day,npcId:PILOT_ID,payload:{venueId:v.id}});const n=s.npcs[PILOT_ID];n.familiarity=Math.max(n.familiarity,16);n.trust=Math.max(n.trust,10);n.met=Math.min(n.met,s.day);n.memory.push({day:s.day,type:'pilot-meeting',text:'Bertemu di ruang kerja dan berbincang tentang pengalaman perniagaan.'});return result;}
export function pilotExchange(s){const n=s.npcs[PILOT_ID];if(!n||!pilotStatus(s).met)throw Error('Berkenalan dahulu.');if(!s.contacts.includes(PILOT_ID))s.contacts.push(PILOT_ID);n.phone='SIM-PILOT-FARID';n.familiarity=Math.max(n.familiarity,20);applyNpcAction(s,{type:'NPC_CONTACT_UNLOCK',actionId:'pilot-contact',npcId:PILOT_ID,payload:{method:'business-card'}});}
export function pilotIntroduction(s){if(!pilotStatus(s).contact)throw Error('Dapatkan nombor telefon dahulu.');const n=s.npcs[PILOT_ID];const c=pilotStatus(s).commitments.find(x=>x.id===PROJECT_ID);if(c)return c;
  applyNpcAction(s,{type:'NPC_COMMITMENT_CREATE',actionId:'pilot-project-introduction',npcId:PILOT_ID,payload:{commitmentId:PROJECT_ID,description:'Dato\' Seri Farid bersetuju mengatur perbincangan awal mengenai peluang projek. Ini bukan tawaran atau anugerah kontrak.',dueDay:s.day+14}});
  n.memory.push({day:s.day,type:'pilot-introduction',text:'Bersetuju mengatur perbincangan awal projek; tiada kontrak dianugerahkan.'});
  return pilotStatus(s).commitments.find(x=>x.id===PROJECT_ID);
}
export function pilotResolve(s,outcome){const c=pilotStatus(s).commitments.find(x=>x.id===PROJECT_ID);if(!c||c.status!=='open')throw Error('Tiada perbincangan aktif untuk diselesaikan.');if(!['fulfilled','cancelled'].includes(outcome))throw Error('Invalid outcome');applyNpcAction(s,{type:'NPC_COMMITMENT_RESOLVE',actionId:'pilot-project-'+outcome,npcId:PILOT_ID,payload:{commitmentId:PROJECT_ID,outcome}});s.npcs[PILOT_ID].memory.push({day:s.day,type:'pilot-followup',text:outcome==='fulfilled'?'Perbincangan awal selesai; sebarang kontrak memerlukan proses berasingan.':'Perbincangan awal dibatalkan.'});}

// CP03 contractor bridge: a real existing tender application, never an invented award.
export function pilotReferral(s){
 const c=s.contractor, b=c?.company;
 if(pilotStatus(s).commitments.find(x=>x.id===PROJECT_ID)?.status!=='fulfilled')throw Error('Selesaikan perbincangan awal dahulu.');
 if(!b||b.license!=='active')throw Error('Syarikat kontraktor perlu mempunyai lesen aktif.');
 if(b.blacklistedUntil>s.day)throw Error('Syarikat masih disekat daripada tender.');
 const ref=c.npcFaridReferral;
 if(ref && (c.tenderApplications||[]).some(a=>a.id===ref.applicationId))return ref;
 const categories=activeCategories(b);
 const eligible=offers(s).find(o=>!o.government&&categories.includes(o.category)&&b.grade>=o.grade&&o.value<=GRADES[b.grade].limit&&!(c.tenderApplications||[]).some(a=>a.offerId===o.id));
 if(!eligible)throw Error('Tiada tender komersial yang layak di papan tender minggu ini. Cuba minggu lain.');
 return {offerId:eligible.id,name:eligible.name,value:eligible.value,available:true};
}
export function pilotApplyReferral(s,margin=0){
 const r=pilotReferral(s);
 if(r.applicationId)return r;
 const a=bid(s,r.offerId,margin);
 s.contractor.npcFaridReferral={offerId:r.offerId,applicationId:a.id,npcId:PILOT_ID,day:s.day};
 s.npcs[PILOT_ID].memory.push({day:s.day,type:'contractor-referral',text:'Player memohon tender komersial '+a.offer.name+' melalui rujukan perbincangan; keputusan masih tertakluk kepada penilaian biasa.',applicationId:a.id});
 applyNpcAction(s,{type:'NPC_PROJECT_REFERRAL',actionId:'farid-referral-'+a.id,npcId:PILOT_ID,payload:{applicationId:a.id,offerId:a.offerId}});
 return s.contractor.npcFaridReferral;
}
export function pilotContractorOutcome(s){
 const ref=s.contractor?.npcFaridReferral;
 if(!ref)return null;
 const a=(s.contractor?.tenderApplications||[]).find(x=>x.id===ref.applicationId);
 return a?{applicationId:a.id,status:a.status,projectId:a.projectId||null,offerName:a.offer?.name||'',decisionDay:a.decisionDay}:null;
}
