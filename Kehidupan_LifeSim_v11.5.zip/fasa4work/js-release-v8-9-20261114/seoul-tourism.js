// Fasa 4 Seoul tourism starter. All prices are fictional in-game MYR sen.
export const SEOUL_PLACES=Object.freeze([
 {id:'gyeongbokgung',name:'Gyeongbokgung Palace',district:'Jongno-gu',costSen:1200,description:'Lawatan warisan dan istana'},
 {id:'myeongdong',name:'Myeongdong',district:'Jung-gu',costSen:0,description:'Jalan kaki di kawasan membeli-belah'},
 {id:'namsan',name:'N Seoul Tower (kawasan luar)',district:'Yongsan-gu',costSen:0,description:'Pemandangan bandar dari Namsan'},
 {id:'hongdae',name:'Hongdae',district:'Mapo-gu',costSen:0,description:'Jelajah kawasan seni dan budaya jalanan'},
 {id:'bukchon',name:'Bukchon Hanok Village',district:'Jongno-gu',costSen:0,description:'Jelajah kawasan rumah tradisional dengan hormat kepada penduduk'}
]);
export const SEOUL_HOTELS=Object.freeze([
 {id:'budget',name:'Seoul Budget Stay',district:'Jung-gu',nightSen:18000},
 {id:'midrange',name:'Seoul City Hotel',district:'Jung-gu',nightSen:38000},
 {id:'premium',name:'Seoul Premium Suites',district:'Gangnam-gu',nightSen:85000}
]);
export const SEOUL_TRANSPORT=Object.freeze([
 {id:'subway',name:'Seoul Subway',costSen:650,minutes:35,description:'Transit bandar menggunakan rangkaian metro'},
 {id:'bus',name:'Bas bandar',costSen:450,minutes:50,description:'Perjalanan bas tempatan'},
 {id:'taxi',name:'Teksi',costSen:4200,minutes:25,description:'Perjalanan terus ke destinasi'}
]);
export const SEOUL_FOOD=Object.freeze([
 {id:'streetfood',name:'Street food Seoul',costSen:1800,description:'Snek dan minuman'},
 {id:'casual',name:'Restoran tempatan',costSen:4200,description:'Hidangan lengkap'},
 {id:'cafe',name:'Kafe Seoul',costSen:2500,description:'Kopi dan makanan ringan'}
]);
const esc=x=>String(x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function ensureSeoul(s){
 if(!s.travel.seoul||typeof s.travel.seoul!=='object')s.travel.seoul={visits:[],hotel:null};
 const st=s.travel.seoul;
 if(!Array.isArray(st.visits))st.visits=[];
 if(!Array.isArray(st.hotelHistory))st.hotelHistory=[];
 // Settle expired stays once, retaining the historical record and original cost.
 if(st.hotel&&Number.isSafeInteger(st.hotel.checkoutDay)&&st.hotel.checkoutDay<=s.day){
  const stay=st.hotel;
  const record=[...st.hotelHistory].reverse().find(h=>h.tripId===stay.tripId&&h.checkinDay===stay.checkinDay&&h.id===stay.id&&h.status==='ACTIVE');
  if(record){record.status='COMPLETED';record.actualCheckoutDay=stay.checkoutDay;}
  st.hotel=null;
 }
 return st;
}
function requireSeoul(s){if(s.travel?.status!=='ABROAD'||s.travel.location?.country!=='KR'||s.travel.location?.city!=='Seoul')throw Error('Aktiviti ini hanya tersedia apabila berada di Seoul');}
export function visitSeoul(s,id){requireSeoul(s);const p=SEOUL_PLACES.find(x=>x.id===id);if(!p)throw Error('Lokasi pelancongan tidak sah');const st=ensureSeoul(s);const key=`${s.travel.activeTrip.id}:${s.day}:${id}`;if(st.visits.some(x=>x.key===key))throw Error('Lokasi ini sudah dilawati hari ini');st.visits.push({key,tripId:s.travel.activeTrip.id,day:s.day,placeId:id,costSen:p.costSen});s.travel.location={country:'KR',city:'Seoul',district:p.district,venue:p.name};return p;}
export function bookSeoulHotel(s,id,nights){requireSeoul(s);const h=SEOUL_HOTELS.find(x=>x.id===id);if(!h)throw Error('Hotel tidak sah');if(!Number.isSafeInteger(nights)||nights<1||nights>30)throw Error('Tempoh hotel mesti 1–30 malam');const st=ensureSeoul(s);if(st.hotel&&st.hotel.checkoutDay>s.day)throw Error('Tempahan hotel masih aktif');const costSen=h.nightSen*nights;st.hotel={id:h.id,name:h.name,tripId:s.travel.activeTrip.id,checkinDay:s.day,checkoutDay:s.day+nights,costSen,nights,status:'ACTIVE'};st.hotelHistory.push({...st.hotel});return {hotel:h,costSen};}

export function extendSeoulHotel(s,nights){
 requireSeoul(s);if(!Number.isSafeInteger(nights)||nights<1||nights>14)throw Error('Lanjutan mesti 1–14 malam');
 const st=ensureSeoul(s),stay=st.hotel;if(!stay||stay.checkoutDay<=s.day||stay.tripId!==s.travel.activeTrip.id)throw Error('Tiada penginapan aktif untuk dilanjutkan');
 const hotel=SEOUL_HOTELS.find(h=>h.id===stay.id);if(!hotel)throw Error('Rekod hotel tidak sah');
 const costSen=hotel.nightSen*nights;stay.checkoutDay+=nights;stay.nights=(stay.nights||stay.checkoutDay-stay.checkinDay-nights)+nights;stay.costSen+=costSen;
 const history=st.hotelHistory.findLast?.(h=>h.tripId===stay.tripId&&h.checkinDay===stay.checkinDay&&h.id===stay.id&&h.status==='ACTIVE');if(history)Object.assign(history,stay);
 return {hotel,costSen};
}
export function checkoutSeoulHotel(s){
 requireSeoul(s);const st=ensureSeoul(s),stay=st.hotel;
 if(!stay||stay.tripId!==s.travel.activeTrip.id)throw Error('Tiada tempahan hotel untuk daftar keluar');
 if(st.hotelHistory.length){const history=st.hotelHistory.findLast?.(h=>h.tripId===stay.tripId&&h.checkinDay===stay.checkinDay&&h.id===stay.id&&h.status==='ACTIVE');if(history){history.status='CHECKED_OUT';history.actualCheckoutDay=s.day;}}
 st.hotel=null;return stay;
}

export function travelSeoul(s,modeId,placeId){
 requireSeoul(s);const mode=SEOUL_TRANSPORT.find(x=>x.id===modeId);const place=SEOUL_PLACES.find(x=>x.id===placeId);
 if(!mode||!place)throw Error('Pilihan pengangkutan atau destinasi tidak sah');
 if(s.travel.location.venue===place.name)throw Error('Anda sudah berada di destinasi ini');
 const st=ensureSeoul(s);if(!Array.isArray(st.rides))st.rides=[];
 const ride={tripId:s.travel.activeTrip.id,day:s.day,modeId,placeId,costSen:mode.costSen,minutes:mode.minutes};
 st.rides.push(ride);s.travel.location={country:'KR',city:'Seoul',district:place.district,venue:place.name};return {mode,place,ride};
}
export function buySeoulMeal(s,foodId){
 requireSeoul(s);const food=SEOUL_FOOD.find(x=>x.id===foodId);if(!food)throw Error('Pilihan makanan tidak sah');
 const st=ensureSeoul(s);if(!Array.isArray(st.meals))st.meals=[];
 st.meals.push({tripId:s.travel.activeTrip.id,day:s.day,foodId,costSen:food.costSen,venue:s.travel.location.venue||'Seoul'});
 return food;
}
export function seoulTourismPanel(s){if(s.travel?.status!=='ABROAD'||s.travel.location?.city!=='Seoul')return '';const st=ensureSeoul(s);const tripId=s.travel.activeTrip?.id;const hotel=st.hotel;const hotelActive=hotel&&hotel.checkoutDay>s.day;return `<section class="card" id="seoul-tourism"><h3>🇰🇷 Seoul · Tourism & Stay</h3><p class="smalltext">Fasa 4 · Harga simulasi MYR, bukan harga sebenar. Aktiviti menggunakan 1 tindakan dan 1 jam game.</p><p><strong>Lokasi:</strong> ${esc(s.travel.location.venue||'Seoul')} · Hari ke-${s.day+1}</p><h4>Penginapan</h4>${hotel&&hotel.checkoutDay>s.day?`<p>🏨 ${esc(hotel.name)} · daftar keluar hari ke-${hotel.checkoutDay+1}</p>`:'<p>Belum ada penginapan aktif.</p>'}${hotelActive?`<p><button class="btn" data-action="seoul-hotel-extend" data-id="1">Lanjut 1 malam</button> <button class="btn" data-action="seoul-hotel-extend" data-id="3">Lanjut 3 malam</button> <button class="btn" data-action="seoul-hotel-checkout">Daftar keluar awal</button></p>`:''}<p class="smalltext">Rekod penginapan: ${st.hotelHistory.length} tempahan. Tempahan baharu tersedia selepas tamat tempoh atau daftar keluar.</p>${SEOUL_HOTELS.map(h=>`<p><strong>${esc(h.name)}</strong> · ${esc(h.district)} · RM ${(h.nightSen/100).toFixed(2)}/malam <button class="btn" data-action="seoul-hotel" data-id="${h.id}" ${hotelActive?'disabled':''}>${hotelActive?'Penginapan aktif':'Tempah 1 malam'}</button></p>`).join('')}<h4>Pengangkutan tempatan</h4><p class="smalltext">Pilih mod dan destinasi. Tambang simulasi ditolak daripada akaun utama; setiap perjalanan menggunakan satu tindakan.</p>${SEOUL_TRANSPORT.map(m=>`<details><summary>${esc(m.name)} · RM ${(m.costSen/100).toFixed(2)} · anggaran ${m.minutes} minit</summary><p class="smalltext">${esc(m.description)}</p>${SEOUL_PLACES.map(p=>`<button class="btn" data-action="seoul-transport" data-id="${m.id}|${p.id}" ${s.travel.location.venue===p.name?'disabled':''}>${esc(p.name)}</button> `).join('')}</details>`).join('')}<h4>Makan & minum</h4>${SEOUL_FOOD.map(f=>`<p>${esc(f.name)} · RM ${(f.costSen/100).toFixed(2)} <button class="btn" data-action="seoul-meal" data-id="${f.id}">Beli</button></p>`).join('')}<h4>Tempat menarik</h4>${SEOUL_PLACES.map(p=>{const visited=st.visits.some(v=>v.key===`${tripId}:${s.day}:${p.id}`);return `<p><strong>${esc(p.name)}</strong> · ${esc(p.district)}<br><span class="smalltext">${esc(p.description)} · ${p.costSen?'RM '+(p.costSen/100).toFixed(2):'Percuma'} (simulasi)</span><br><button class="btn" data-action="seoul-visit" data-id="${p.id}" ${visited?'disabled':''}>${visited?'Dilawati hari ini':'Lawat lokasi'}</button></p>`;}).join('')}<p class="smalltext">Rekod lawatan: ${st.visits.filter(v=>v.tripId===tripId).length} · Pengangkutan: ${(st.rides||[]).filter(v=>v.tripId===tripId).length} · Makanan: ${(st.meals||[]).filter(v=>v.tripId===tripId).length} · Tiket pulang diurus melalui panel Penerbangan Pulang.</p></section>`;}
