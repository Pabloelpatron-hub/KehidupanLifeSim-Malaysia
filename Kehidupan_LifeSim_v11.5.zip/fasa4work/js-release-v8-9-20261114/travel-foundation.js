// International Tourism Foundation v1. No booking, flight or location mutation is exposed yet.
export const TRAVEL_STATES=Object.freeze(['AT_HOME','BOOKED','AT_AIRPORT','IN_FLIGHT','ABROAD','RETURNING','RETURNED']);
export const PHYSICAL_CORE_ACTIONS=Object.freeze(['apply','acceptJob','work','clinic','travel','licence','vehicle','sellVehicle','property']);
const transitions={AT_HOME:['BOOKED'],BOOKED:['AT_AIRPORT','AT_HOME'],AT_AIRPORT:['IN_FLIGHT','BOOKED'],IN_FLIGHT:['ABROAD','RETURNED'],ABROAD:['RETURNING'],RETURNING:['AT_AIRPORT'],RETURNED:['AT_HOME','BOOKED']};
export function ensureTravel(s){
 if(!s.travel || typeof s.travel!=='object')s.travel={version:1,status:'AT_HOME',location:{country:'MY',cityId:s.character.city,district:null,venue:null},activeTrip:null,trips:[],processedEvents:[],returnJourney:false};
 return s.travel;
}
const safeText=value=>String(value??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const validLocation=loc=>loc&&typeof loc==='object'&&['MY','KR'].includes(loc.country)&&(loc.country!=='KR'||(typeof loc.city==='string'&&loc.city.length>0&&loc.city.length<=100));

export function currentLocation(s){const t=ensureTravel(s);return t.location;}
export function travelStatus(s){return ensureTravel(s).status;}
export function transitionTravel(s,next,{location,trip}={}){
 const current=ensureTravel(s);
 if(!transitions[current.status]?.includes(next))throw Error('Peralihan status perjalanan tidak sah');
 // Validate a candidate first: rejected transitions must never mutate the save.
 const t=structuredClone(current);
 if(next!=='AT_HOME'&&next!=='RETURNED'&&!trip&&!t.activeTrip)throw Error('Itinerary diperlukan');
 if(trip){if(!trip||typeof trip.id!=='string'||!trip.id.trim())throw Error('ID itinerary tidak sah');t.activeTrip=structuredClone(trip);}
 if(location){if(!validLocation(location))throw Error('Lokasi perjalanan tidak sah');t.location=structuredClone(location);}
 if(next==='RETURNED'&&!t.returnJourney)throw Error('Penerbangan pergi tidak boleh terus ditutup sebagai perjalanan pulang');
 if(next==='ABROAD'&&t.location.country!=='KR')throw Error('Ketibaan antarabangsa memerlukan lokasi luar negara');
 if(next==='RETURNING'&&t.location.country!=='KR')throw Error('Perjalanan pulang mesti bermula di luar negara');
 if(next==='RETURNING')t.returnJourney=true;
 if(next==='AT_HOME'&&t.status==='BOOKED')t.activeTrip=null;
 if(next==='AT_HOME'||next==='RETURNED'){
   t.location={country:'MY',cityId:s.character.city,district:null,venue:null};
   if(next==='RETURNED'&&t.activeTrip){if(!t.trips.some(x=>x.id===t.activeTrip.id))t.trips.push({...t.activeTrip,returnedDay:s.day});t.activeTrip=null;}
 }
 if(next==='AT_HOME'||next==='RETURNED')t.returnJourney=false;
 t.status=next;
 // Ensure a malformed intermediate state cannot be committed.
 validateTravel({...s,travel:t});
 s.travel=t;
 return t;
}
export function actionEligibility(s,{mode='REMOTE',country='MY',cityId=null,delegateAvailable=false}={}){
 const loc=currentLocation(s);
 if(mode==='REMOTE')return {allowed:true,reason:''};
 if(mode==='DELEGATED')return {allowed:!!delegateAvailable,reason:delegateAvailable?'':'Wakil yang sah diperlukan'};
 if(mode!=='PHYSICAL')return {allowed:false,reason:'Kategori tindakan tidak dikenali'};
 const allowed=loc.country===country&&(country!=='MY'||cityId===null||loc.cityId===cityId);
 return {allowed,reason:allowed?'':'Tindakan ini memerlukan kehadiran fizikal di lokasi berkenaan'};
}
export function validateTravel(s){const t=ensureTravel(s);if(t.returnJourney===undefined)t.returnJourney=false;
 if(typeof t.returnJourney!=='boolean')throw Error('Penanda perjalanan pulang tidak sah');
 if(t.version!==1||!TRAVEL_STATES.includes(t.status)||!t.location||!['MY','KR'].includes(t.location.country)||!Array.isArray(t.trips)||!Array.isArray(t.processedEvents))throw Error('Data perjalanan tidak sah');
 if(t.status==='AT_HOME'&&(t.location.country!=='MY'||t.location.cityId!==s.character.city||t.activeTrip!==null))throw Error('Lokasi rumah dan status travel tidak sepadan');
 if(!validLocation(t.location))throw Error('Lokasi perjalanan tidak sah');
 if(['ABROAD','RETURNING'].includes(t.status)&&t.location.country==='MY')throw Error('Lokasi luar negara tidak sah');
 if(t.status==='AT_HOME'&&t.activeTrip!==null)throw Error('Tempahan aktif pada status rumah');
 if(['BOOKED','AT_AIRPORT','IN_FLIGHT','ABROAD','RETURNING'].includes(t.status)&&!t.activeTrip)throw Error('Itinerary aktif diperlukan');
 if(t.status==='RETURNING'&&!t.returnJourney)throw Error('Penanda perjalanan pulang diperlukan');
 if(t.status==='RETURNED'&&t.location.country!=='MY')throw Error('Lokasi pulang tidak sah');
 if(t.status==='RETURNED'&&t.activeTrip!==null)throw Error('Perjalanan pulang belum ditutup');
 if(t.activeTrip!==null&&(typeof t.activeTrip!=='object'||typeof t.activeTrip.id!=='string'||!t.activeTrip.id))throw Error('Itinerary tidak sah');
 if(new Set(t.processedEvents).size!==t.processedEvents.length)throw Error('Event perjalanan berganda');return t;}
export function requireCoreActionLocation(s,type){if(PHYSICAL_CORE_ACTIONS.includes(type)){const result=actionEligibility(s,{mode:'PHYSICAL',country:'MY',cityId:s.character.city});if(!result.allowed)throw Error(result.reason+' — '+type);}}
export function travelPanel(s,cityName){const t=ensureTravel(s);const home=t.status==='AT_HOME';return `<section class="card" id="travel-foundation-status"><h3>International Travel & Tourism</h3><p class="smalltext">Fasa 1 — Travel Foundation</p><p><strong>Status:</strong> ${home?'Di Malaysia':t.status}</p><p><strong>Lokasi:</strong> ${safeText(home?cityName+', Malaysia':t.location.city||t.location.country)}</p><div class="smalltext">Sistem asas lokasi dan save tersedia. ${home?'<button class="btn" data-action="flight-book-open">Cari & tempah tiket KUL → Seoul</button>':'Tempahan disahkan. Proses airport akan tersedia dalam fasa berikutnya.'}</div></section>`;}

// Conservative UI policy: only actions whose physical presence is unambiguous.
// Remote management (restaurant, contractor, gang, banking, messaging) remains allowed.
export const PHYSICAL_UI_ACTIONS=Object.freeze([
 'venue','venue-activity','clinic','clinic-private','pilot-meet',
 'buy-property','buy-vehicle','vehicle-inspect','vehicle-service',
 'vehicle-jpj','vehicle-plate','vehicle-tradein'
]);
export const PHYSICAL_UI_FORMS=Object.freeze([
 'vehicle-cash','vehicle-loan-submit'
]);
export function physicalUiEligibility(s,kind,id){
 const physical=(kind==='action'?PHYSICAL_UI_ACTIONS:PHYSICAL_UI_FORMS).includes(id);
 return physical?actionEligibility(s,{mode:'PHYSICAL',country:'MY',cityId:s.character.city}):{allowed:true,reason:''};
}

// Domain-layer guard. Check before any mutation, including legacy direct calls.
export function isMalaysiaPresent(s){return currentLocation(s).country==='MY';}
export function requireMalaysiaPresence(s,label='Tindakan fizikal'){
 if(!isMalaysiaPresent(s))throw Error(label+' memerlukan kehadiran di Malaysia.');
}
