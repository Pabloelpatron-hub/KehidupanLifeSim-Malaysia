// Centralized, gesture-safe Web Audio feedback. No external audio assets required.
let context;
let lastClickAt=0;
let scene=null, sceneNodes=null, sceneSettings={enabled:true,volume:.35};
function stopScene(){if(!sceneNodes){scene=null;return;}const nodes=sceneNodes;sceneNodes=null;scene=null;try{const now=context.currentTime;nodes.gain.gain.cancelScheduledValues(now);nodes.gain.gain.setTargetAtTime(.00001,now,.18);setTimeout(()=>{try{nodes.source.stop();nodes.source.disconnect();nodes.filter.disconnect();nodes.gain.disconnect();nodes.low?.stop();nodes.low?.disconnect();}catch{}},900);}catch{}}
function startScene(kind){
 if(!context||context.state!=='running'||!sceneSettings.enabled||!(Number(sceneSettings.volume)>0))return;
 if(scene===kind&&sceneNodes)return;
 stopScene();if(!kind)return;
 // Original synthesized ambience: terminal air handling / distant concourse,
 // or modern commercial turbofan broadband airflow with low-frequency spool.
 const sampleRate=context.sampleRate,seconds=3,buffer=context.createBuffer(1,Math.floor(sampleRate*seconds),sampleRate),out=buffer.getChannelData(0);
 let smooth=0;for(let i=0;i<out.length;i++){const white=Math.random()*2-1;smooth=smooth*.94+white*.06;out[i]=kind==='airport'?smooth*.8+white*.075:smooth*.52+white*.30;}
 const source=context.createBufferSource();source.buffer=buffer;source.loop=true;
 const filter=context.createBiquadFilter();filter.type='lowpass';filter.frequency.value=kind==='airport'?900:2600;
 const gain=context.createGain();gain.gain.value=.00001;source.connect(filter);filter.connect(gain);gain.connect(context.destination);
 const target=Math.min(.23,Number(sceneSettings.volume)*(kind==='airport'?.13:.22));gain.gain.setTargetAtTime(target,context.currentTime,.45);
 let low=null;if(kind==='jet'){low=context.createOscillator();low.type='sawtooth';low.frequency.value=92;const lp=context.createBiquadFilter();lp.type='lowpass';lp.frequency.value=185;low.connect(lp);lp.connect(gain);low.start();}
 source.start();scene=kind;sceneNodes={source,filter,gain,low};
}
export function setAudioScene(kind,settings={enabled:true,volume:.35}){sceneSettings=settings||{enabled:false,volume:0};if(!sceneSettings.enabled||!(Number(sceneSettings.volume)>0)||document.hidden){stopScene();return;}if(!kind){stopScene();return;}if(context?.state==='running')startScene(kind);else{scene=kind;}}
export function refreshAudioScene(){if(document.hidden){stopScene();return;}const desired=scene||null;if(desired&&sceneSettings.enabled)startScene(desired);}

const labels={cash:'TRANSAKSI DIREKOD',message:'NOTIFIKASI',siren:'AMARAN',engine:'KENDERAAN',stamp:'REKOD DIKEMAS KINI',crime:'OPERASI',day:'HARI BAHARU',error:'TINDAKAN GAGAL',success:'BERJAYA',click:'PILIHAN'};
export function unlockAudio(){
 try{
  const C=window.AudioContext||window.webkitAudioContext;
  if(!C)return;
  context??=new C();
  if(context.state==='suspended')return context.resume().then(()=>refreshAudioScene()).catch(()=>{});
  refreshAudioScene();
 }catch(e){console.warn('Audio unavailable',e);}
}
export function feedback(kind='click',settings={enabled:true,volume:.35}){
 const el=document.getElementById('action-feedback');
 if(el&&kind!=='click'){
  el.textContent=labels[kind]||labels.click;el.dataset.kind=kind;
  el.classList.remove('play');void el.offsetWidth;el.classList.add('play');
 }
 if(!settings?.enabled||Number(settings.volume)<=0)return;
 // Avoid stacking click tones when a button also triggers an immediate result.
 if(kind==='click'){lastClickAt=performance.now();}
 try{
  const C=window.AudioContext||window.webkitAudioContext;if(!C)return;
  context??=new C();
  if(context.state==='suspended'){
   context.resume().then(()=>{if(context.state==='running')play(kind,settings);}).catch(e=>console.warn('Audio resume failed',e));
   return;
  }
  play(kind,settings);
 }catch(e){console.warn('Audio feedback failed',e);}
}
function play(kind,settings){
 const time=context.currentTime+.005,volume=Math.max(0,Math.min(1,Number(settings.volume)||0));
 const tone=(hz,delay,duration,type='sine',end=hz,level=.09)=>{
  const o=context.createOscillator(),g=context.createGain();o.type=type;
  o.frequency.setValueAtTime(Math.max(1,hz),time+delay);
  o.frequency.exponentialRampToValueAtTime(Math.max(1,end),time+delay+duration);
  g.gain.setValueAtTime(.0001,time+delay);
  g.gain.exponentialRampToValueAtTime(Math.max(.00011,level*volume),time+delay+.008);
  g.gain.exponentialRampToValueAtTime(.0001,time+delay+duration);
  o.connect(g);g.connect(context.destination);o.start(time+delay);o.stop(time+delay+duration+.015);
 };
 switch(kind){
 case 'dismiss':tone(390,0,.065,'sine',260,.035);break;
 case 'select':tone(630,0,.06,'sine',530,.045);break;
 case 'airport':tone(660,0,.10);tone(880,.12,.16);break;
 case 'cash':[880,1320,1760].forEach((f,i)=>tone(f,i*.065,.14));break;
 case 'message':tone(740,0,.11);tone(990,.12,.19);break;
 case 'siren':tone(440,0,.32,'sine',880);tone(880,.32,.32,'sine',440);break;
 case 'engine':tone(65,0,.38,'sawtooth',155,.045);break;
 case 'stamp':tone(170,0,.13,'triangle',45);break;
 case 'crime':tone(180,0,.18,'triangle',60);break;
 case 'day':tone(330,0,.19);tone(440,.16,.22);break;
 case 'error':tone(180,0,.17,'triangle',110);break;
 case 'success':tone(520,0,.09);tone(780,.09,.15);break;
 default:tone(490,0,.045,'sine',360,.045);
 }
}
