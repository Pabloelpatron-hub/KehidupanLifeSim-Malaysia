// Fasa 4: deterministic in-game KRW budgeting and shopping. Not a live FX quote.
export const KRW_PER_MYR=320;
export const SEOUL_SHOPS=Object.freeze([
 {id:'souvenir',name:'Cenderamata Seoul',priceKRW:12000,category:'Hadiah'},
 {id:'skincare',name:'Set penjagaan kulit Korea',priceKRW:35000,category:'Kecantikan'},
 {id:'fashion',name:'Pakaian butik Hongdae',priceKRW:58000,category:'Fesyen'},
 {id:'snacks',name:'Kotak snek Korea',priceKRW:18000,category:'Makanan'},
 {id:'craft',name:'Kraf tradisional',priceKRW:26000,category:'Budaya'}
]);
const esc=x=>String(x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const toMyrSen=krw=>Math.ceil(krw*100/KRW_PER_MYR);
export function ensureSeoulBudget(s){
 if(!s.travel?.seoul||typeof s.travel.seoul!=='object')s.travel.seoul={visits:[],hotel:null};
 const st=s.travel.seoul;
 if(!st.shopping||typeof st.shopping!=='object')st.shopping={purchases:[],budgetKRW:0};
 if(!Array.isArray(st.shopping.purchases))st.shopping.purchases=[];
 if(!Number.isSafeInteger(st.shopping.budgetKRW)||st.shopping.budgetKRW<0)st.shopping.budgetKRW=0;
 return st.shopping;
}
function requireSeoul(s){if(s.travel?.status!=='ABROAD'||s.travel.location?.country!=='KR'||s.travel.location?.city!=='Seoul'||!s.travel.activeTrip?.id)throw Error('Shopping hanya tersedia semasa berada di Seoul');}
export function setSeoulBudget(s,krw){requireSeoul(s);if(!Number.isSafeInteger(krw)||krw<0||krw>100000000)throw Error('Bajet KRW tidak sah');ensureSeoulBudget(s).budgetKRW=krw;return krw;}
export function buySeoulItem(s,id){requireSeoul(s);const item=SEOUL_SHOPS.find(x=>x.id===id);if(!item)throw Error('Barang tidak sah');const shopping=ensureSeoulBudget(s);const spent=shopping.purchases.filter(p=>p.tripId===s.travel.activeTrip.id).reduce((n,p)=>n+p.priceKRW,0);if(shopping.budgetKRW>0&&spent+item.priceKRW>shopping.budgetKRW)throw Error('Pembelian melebihi bajet KRW. Laraskan bajet dahulu.');const purchase={id:`${s.travel.activeTrip.id}:${s.day}:${shopping.purchases.length+1}`,tripId:s.travel.activeTrip.id,day:s.day,itemId:item.id,name:item.name,priceKRW:item.priceKRW,paidSen:toMyrSen(item.priceKRW)};shopping.purchases.push(purchase);return purchase;}
export function seoulShoppingPanel(s){if(s.travel?.status!=='ABROAD'||s.travel.location?.city!=='Seoul')return '';const sh=ensureSeoulBudget(s),trip=s.travel.activeTrip?.id;const purchases=sh.purchases.filter(p=>p.tripId===trip);const spent=purchases.reduce((n,p)=>n+p.priceKRW,0);const fmt=n=>Number(n).toLocaleString('en-US');return `<section class="card" id="seoul-shopping"><h3>🛍️ Shopping & Bajet KRW</h3><p class="smalltext">Kadar simulasi tetap: RM1 = ₩${KRW_PER_MYR}. Bayaran terus daripada akaun utama dalam MYR; KRW digunakan sebagai paparan harga dan had bajet. Tiada pertukaran tunai atau kadar FX sebenar.</p><p><strong>Bajet:</strong> ${sh.budgetKRW?`₩${fmt(sh.budgetKRW)}`:'Belum ditetapkan (tiada had)'} · <strong>Belanja:</strong> ₩${fmt(spent)} · <strong>Baki bajet:</strong> ${sh.budgetKRW?`₩${fmt(Math.max(0,sh.budgetKRW-spent))}`:'Tiada had'}</p><p><button class="btn" data-action="seoul-budget-open">Tetapkan bajet KRW</button></p><h4>Kedai & barangan</h4>${SEOUL_SHOPS.map(item=>`<p><strong>${esc(item.name)}</strong> · ${esc(item.category)} · ₩${fmt(item.priceKRW)} <span class="smalltext">(≈ RM ${(toMyrSen(item.priceKRW)/100).toFixed(2)})</span> <button class="btn" data-action="seoul-shop" data-id="${item.id}" ${sh.budgetKRW&&spent+item.priceKRW>sh.budgetKRW?'disabled':''}>Beli</button></p>`).join('')}<p class="smalltext">${purchases.length} pembelian dalam perjalanan ini. Semua pembelian disimpan dalam sejarah dan ledger bank.</p></section>`;}
