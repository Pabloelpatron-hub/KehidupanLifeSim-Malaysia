// Missed departure rebooking: retain original fare and charge a disclosed change fee.
export function missedFlightQuote(s,direction){
 const t=s.travel, trip=t?.activeTrip;
 const ret=direction==='return';
 const ticket=ret?trip?.returnFlight:trip;
 const eligible=ret?['ABROAD','RETURNING'].includes(t?.status):['BOOKED','AT_AIRPORT'].includes(t?.status);
 if(!eligible||!ticket||ticket.flightPhase)throw Error('Tiada tiket yang layak untuk dijadualkan semula');
 if(!(s.day>ticket.departureDay))throw Error('Penerbangan belum terlepas');
 const base=Number(ticket.paidSen);
 if(!Number.isSafeInteger(base)||base<0)throw Error('Nilai tiket tidak sah');
 return {feeSen:Math.max(2000,Math.ceil(base*0.15)),newDay:s.day+1,oldDay:ticket.departureDay};
}
export function rebookMissedFlight(s,direction){
 const q=missedFlightQuote(s,direction),t=s.travel,ret=direction==='return';
 const ticket=ret?t.activeTrip.returnFlight:t.activeTrip;
 if(ret&&t.seoul?.hotel&&t.seoul.hotel.checkoutDay>q.newDay)throw Error('Tempahan hotel bertindih dengan tarikh penerbangan baharu');
 if(!s.accounts?.main||s.accounts.main.balance<q.feeSen)throw Error('Baki bank tidak mencukupi untuk caj perubahan');
 const previous=Array.isArray(ticket.rebookHistory)?ticket.rebookHistory:[];
 ticket.rebookHistory=[...previous,{fromDay:q.oldDay,toDay:q.newDay,chargedDay:s.day,feeSen:q.feeSen}];
 ticket.departureDay=q.newDay;
 ticket.airportCompleted=[];ticket.airportReady=false;delete ticket.boardingDay;delete ticket.departureClock;delete ticket.flightPhase;
 if(!ret&&t.status==='AT_AIRPORT'){t.status='BOOKED';t.location={country:'MY',cityId:s.character.city,district:null,venue:null};}
 if(ret&&t.status==='RETURNING'){t.status='ABROAD';t.returnJourney=false;t.location={country:'KR',city:'Seoul',district:null,venue:null};}
 return q;
}
