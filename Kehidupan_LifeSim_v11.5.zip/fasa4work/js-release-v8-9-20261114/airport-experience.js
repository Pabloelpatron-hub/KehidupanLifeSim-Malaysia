// Fasa 2 airport workflow: deterministic, idempotent, no autonomous day advancement.
export const AIRPORT_STEPS=Object.freeze(['CHECK_IN','BAG_DROP','SECURITY','IMMIGRATION','GATE','BOARDING']);
export const AIRPORT_LABELS=Object.freeze({CHECK_IN:'Daftar masuk',BAG_DROP:'Serahan bagasi',SECURITY:'Pemeriksaan keselamatan',IMMIGRATION:'Imigresen',GATE:'Pengesahan pintu berlepas',BOARDING:'Boarding'});
export function airportProgress(s){
 const t=s.travel,trip=t?.activeTrip;
 if(t?.returnJourney)return null;
 if(!trip||!['BOOKED','AT_AIRPORT'].includes(t.status))return null;
 const completed=Array.isArray(trip.airportCompleted)?trip.airportCompleted:[];
 return {trip,completed,next:AIRPORT_STEPS.find(x=>!completed.includes(x))||null};
}
export function airportStep(s,step){
 const t=s.travel,p=airportProgress(s);
 if(!p)throw Error('Tiada tempahan penerbangan untuk proses airport');
 if(s.day<p.trip.departureDay)throw Error('Belum tiba hari penerbangan');
 if(s.day>p.trip.departureDay)throw Error('Penerbangan telah terlepas. Hubungi kaunter untuk tempahan baharu (belum tersedia).');
 if(!AIRPORT_STEPS.includes(step)||p.next!==step)throw Error('Selesaikan proses airport mengikut turutan');
 if(step==='BAG_DROP'&&p.trip.quote.checkedBags<0)throw Error('Maklumat bagasi tidak sah');
 if(step==='CHECK_IN'&&!['BOOKED','AT_AIRPORT'].includes(t.status))throw Error('Status check-in tidak sah');
 if(step!=='CHECK_IN'&&t.status!=='AT_AIRPORT')throw Error('Anda belum berada di airport');
 // Update only after all preconditions pass. Called inside app.mutate for rollback.
 const completed=[...p.completed,step];
 p.trip.airportCompleted=completed;
 if(step==='CHECK_IN'){t.status='AT_AIRPORT';t.location={country:'MY',cityId:s.character.city,district:null,venue:'KLIA Terminal'};}
 if(step==='BOARDING'){p.trip.airportReady=true;p.trip.boardingDay=s.day;}
 return {step,completed,ready:step==='BOARDING'};
}
export function airportPanel(s){
 const p=airportProgress(s);if(!p)return '';
 const esc=x=>String(x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const day=p.trip.departureDay+1;
 const steps=AIRPORT_STEPS.map(x=>`<li>${p.completed.includes(x)?'✓ ':''}${esc(AIRPORT_LABELS[x])}</li>`).join('');
 const ready=p.trip.airportReady;
 const missed=s.day>p.trip.departureDay;
 const action=p.next&&!missed&&s.day===p.trip.departureDay?`<button class="btn" data-action="airport-step" data-id="${p.next}">${esc(AIRPORT_LABELS[p.next])}</button>`:'';
 return `<section class="card"><h3>KLIA · Proses Airport</h3><p class="smalltext">E-tiket ${esc(p.trip.id)} · Berlepas hari ke-${day} · 09:00 MYT</p><ol>${steps}</ol>${ready?'<p><strong>Boarding selesai.</strong> Penerbangan 3D dan ketibaan akan diaktifkan dalam Fasa 3.</p>':s.day<p.trip.departureDay?'<p class="smalltext">Proses airport dibuka pada hari penerbangan.</p>':missed?'<p class="notice">Penerbangan terlepas. <button class="btn" data-action="flight-rebook">Jadual semula tiket</button></p>':action}</section>`;
}
