import {ensureInternationalWallet} from './international-wallet.js';
import {ensureTravel} from './travel-foundation.js';
import {ensureWorldCore} from './world-core.js';
import {cities} from './catalog.js';
export const salaryBands=[[1500,1800],[1900,2200],[2250,2800],[3300,5000],[5200,8000]];
export const qualifications=['SPM','Diploma','Ijazah Sarjana Muda','Sarjana','PhD'];
export const districts=['Kuala Lumpur','Petaling','Petaling','Klang','Petaling','Kinta','Timur Laut','Johor Bahru','Melaka Tengah','Seremban','Kota Kinabalu','Kuching','Kuantan','Kota Setar','Larut, Matang dan Selama','Kota Bharu','Kuala Terengganu','Kangar','Putrajaya','Labuan'];
export const defaultAppearance={gender:'Lelaki',ethnicity:'Melayu',religion:'Islam',skin:2,hair:2,hairColor:0,facial:0,hijab:0,hijabColor:0,face:0,eyes:0,photoPreset:0};
export function expandState(s){ensureTravel(s);ensureInternationalWallet(s);ensureWorldCore(s);s.actionsUsed??=0;s.actionLimit=10;s.character.appearance={...defaultAppearance,...s.character.appearance};s.character.district??=districts[s.character.city];s.character.neighbourhood??=cities[s.character.city]?.areas[0];s.audio??={enabled:true,volume:.35};s.crime??={heat:0,reputation:0,notoriety:0,cases:[],loot:[],attempts:[],mules:[],bankRestrictions:[],financeRestricted:false,agent:null,activeChallenge:null,detainedUntil:0,ended:false};s.gang??={membership:null,rank:0,merit:0,joined:0,factions:[],territories:[],initialised:false};return s;}
export function spendAction(s,allowDetained=false){if(s.justice?.prison)throw Error('Jalani hukuman dahulu.');expandState(s);if(!s.character.alive||s.crime.ended)throw Error('Kisah ini telah tamat. Eksport rekod atau mulakan kehidupan baharu.');if(s.actionsUsed>=10)throw Error('10 tindakan sudah digunakan. Pilih Hari seterusnya.');if(!allowDetained&&s.crime.detainedUntil>s.day)throw Error('Watak sedang ditahan. Urus kes atau tunggu hari seterusnya.');s.actionsUsed++;}
export function salaryFor(job,city){const [lo,hi]=salaryBands[job.qualification]||salaryBands[0];const loc=Math.min(1,Math.max(0,(cities[city].wage-.8)/.42));return Math.round((lo+(hi-lo)*Math.min(1,.25+loc*.45+(job.id%3)*.15))*100);}
