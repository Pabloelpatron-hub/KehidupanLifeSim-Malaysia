// Phase 2 universal airport domain: reusable for each paid FLEX flight leg.
// No browser/audio/finance mutations; integration must commit returned state via app.mutate.
import {GLOBAL_AIRPORTS} from './global-flight-network.js';
const clone=x=>structuredClone(x);
export const UNIVERSAL_AIRPORT_STEPS=Object.freeze(['CHECK_IN','BAG_DROP','SECURITY','IMMIGRATION','GATE','BOARDING']);
export const UNIVERSAL_ARRIVAL_STEPS=Object.freeze(['LANDING','IMMIGRATION_ARRIVAL','BAGGAGE_CLAIM','CUSTOMS','EXIT']);
function active(state){const j=state?.activeJourney,seg=j?.segments?.at(-1);if(!j||!seg)throw Error('Tiada segmen perjalanan aktif');return {j,seg};}
function legOf(seg){const i=seg.airport?.legIndex??0,leg=seg.legs?.[i];if(!leg||!GLOBAL_AIRPORTS[leg.from]||!GLOBAL_AIRPORTS[leg.to])throw Error('Segmen penerbangan tidak sah');return {leg,i};}
function guardDay(day,leg){if(!Number.isSafeInteger(day)||day<0)throw Error('Hari permainan tidak sah');if(day!==leg.departureDay)throw Error(day<leg.departureDay?'Belum tiba hari berlepas':'Penerbangan telah terlepas');}
export function getUniversalAirportView(state){const {j,seg}=active(state),{leg,i}=legOf(seg),a=seg.airport||{};return {journeyId:j.id,bookingId:seg.id,legIndex:i,legsTotal:seg.legs.length,origin:GLOBAL_AIRPORTS[leg.from],destination:GLOBAL_AIRPORTS[leg.to],departureDay:leg.departureDay,departureMinute:leg.departureMinute,status:a.status||'BOOKED',departureCompleted:[...(a.departureCompleted||[])],arrivalCompleted:[...(a.arrivalCompleted||[])],nextDeparture:UNIVERSAL_AIRPORT_STEPS.find(x=>!a.departureCompleted?.includes(x))||null,nextArrival:UNIVERSAL_ARRIVAL_STEPS.find(x=>!a.arrivalCompleted?.includes(x))||null,flightPhase:a.flightPhase||null};}
export function performUniversalDepartureStep(state,step,{day}={}){
 const next=clone(state),{seg}=active(next),{leg,i}=legOf(seg);guardDay(day,leg);
 if(!UNIVERSAL_AIRPORT_STEPS.includes(step))throw Error('Proses airport tidak dikenali');
 const a=seg.airport ||= {legIndex:i,status:'BOOKED',departureCompleted:[],arrivalCompleted:[],flightPhase:null};
 if(a.status!=='BOOKED'&&a.status!=='AT_AIRPORT')throw Error('Status airport tidak sah');
 const expected=UNIVERSAL_AIRPORT_STEPS[a.departureCompleted.length];if(step!==expected)throw Error('Proses airport mesti mengikut turutan dan tidak boleh berulang');
 a.departureCompleted.push(step);a.status='AT_AIRPORT';seg.status='AT_AIRPORT';next.activeJourney.status='AT_AIRPORT';
 if(step==='BOARDING'){a.status='READY_TO_FLY';seg.status='READY_TO_FLY';next.activeJourney.status='READY_TO_FLY';}
 return next;
}
export function startUniversalFlight(state,{day}={}){
 const next=clone(state),{seg}=active(next),{leg}=legOf(seg);guardDay(day,leg);const a=seg.airport;
 if(a?.status!=='READY_TO_FLY'||a.departureCompleted.length!==UNIVERSAL_AIRPORT_STEPS.length)throw Error('Boarding belum selesai');
 a.status='IN_FLIGHT';a.flightPhase='TAKEOFF';seg.status='IN_FLIGHT';next.activeJourney.status='IN_FLIGHT';return next;
}
export function advanceUniversalFlight(state){const next=clone(state),{seg}=active(next),a=seg.airport;
 const phases=['TAKEOFF','CRUISE','DESCENT','LANDED'];const idx=phases.indexOf(a?.flightPhase);
 if(a?.status!=='IN_FLIGHT'||idx<0||idx===phases.length-1)throw Error('Fasa penerbangan tidak sah');
 a.flightPhase=phases[idx+1];if(a.flightPhase==='LANDED')a.status='ARRIVAL';return next;
}
export function performUniversalArrivalStep(state,step){const next=clone(state),{j,seg}=active(next),{leg,i}=legOf(seg),a=seg.airport;
 if(a?.status!=='ARRIVAL'||a.flightPhase!=='LANDED')throw Error('Pesawat belum mendarat');
 const expected=UNIVERSAL_ARRIVAL_STEPS[a.arrivalCompleted.length];if(step!==expected)throw Error('Proses ketibaan mesti mengikut turutan dan tidak boleh berulang');
 a.arrivalCompleted.push(step);
 if(step==='EXIT'){
  j.currentAirport=leg.to;
  if(!j.visitedAirports.includes(leg.to))j.visitedAirports.push(leg.to);
  if(i+1<seg.legs.length){a.legIndex=i+1;a.status='BOOKED';a.departureCompleted=[];a.arrivalCompleted=[];a.flightPhase=null;seg.status='TRANSIT';j.status='TRANSIT';}
  else {seg.status='AT_DESTINATION';j.status='AT_DESTINATION';a.status='COMPLETE';if(leg.to==='KUL'){j.status='COMPLETED';next.history.push(j);next.activeJourney=null;}}
 }
 return next;
}
