// Phase 1 FLEX booking domain. Independent of legacy Seoul state until UI integration.
import {GLOBAL_AIRPORTS,GLOBAL_AIRLINES,GLOBAL_DIRECT_ROUTES,quoteGlobalItinerary} from './global-flight-network.js';
const MIN_CONNECTION_MINUTES=90;
const MINUTES_PER_DAY=1440;
function integer(v,name,min=0){if(!Number.isSafeInteger(v)||v<min)throw Error(`${name} tidak sah`);return v;}
function clone(v){return JSON.parse(JSON.stringify(v));}
export function buildGlobalFlightPlan(itinerary,{departureDay,departureMinute=540,connectionMinutes=120,bookingDay,passengers=1,seatClass='economy',checkedBags=0,airlineIds=[]}={}){
 integer(departureDay,'Hari berlepas',1);integer(bookingDay,'Hari tempahan',1);
 integer(departureMinute,'Minit berlepas');if(departureMinute>=MINUTES_PER_DAY)throw Error('Masa berlepas tidak sah');
 integer(connectionMinutes,'Masa transit',MIN_CONNECTION_MINUTES);
 const quote=quoteGlobalItinerary(itinerary,{departureDay,bookingDay,passengers,seatClass,checkedBags,airlineIds});
 let cursor=departureDay*MINUTES_PER_DAY+departureMinute;
 const legs=itinerary.legs.map((route,index)=>{
  const airlineId=quote.legs[index].airlineId;
  const durationMinutes=Math.max(45,Math.ceil(route.distanceKm/790*60+35));
  const departureAbsoluteMinute=cursor;
  const arrivalAbsoluteMinute=cursor+durationMinutes;
  cursor=arrivalAbsoluteMinute+connectionMinutes;
  return Object.freeze({index,from:route.from,to:route.to,routeId:route.id,airlineId,airlineName:GLOBAL_AIRLINES[airlineId].name,departureDay:Math.floor(departureAbsoluteMinute/MINUTES_PER_DAY),departureMinute:departureAbsoluteMinute%MINUTES_PER_DAY,arrivalDay:Math.floor(arrivalAbsoluteMinute/MINUTES_PER_DAY),arrivalMinute:arrivalAbsoluteMinute%MINUTES_PER_DAY,durationMinutes,departureAbsoluteMinute,arrivalAbsoluteMinute,simulated:true});
 });
 if(legs[0].departureDay<bookingDay)throw Error('Tarikh tempahan tidak sah');
 return Object.freeze({from:legs[0].from,to:legs.at(-1).to,legs,quote,connectionMinutes,simulated:true});
}
export function createGlobalJourneyState(previous=null){
 if(previous==null)return {version:1,activeJourney:null,history:[],bookingIds:[],paymentIds:[]};
 const state=clone(previous);
 if(state.version!==1||!Array.isArray(state.history)||!Array.isArray(state.bookingIds)||!Array.isArray(state.paymentIds))throw Error('Format global journey tidak sah');
 return state;
}
export function reserveGlobalItinerary(state,plan,{bookingId,paymentId,paymentSource,paidSen}={}){
 if(!state||state.version!==1)throw Error('Global journey tidak sah');
 if(typeof bookingId!=='string'||!bookingId.trim()||typeof paymentId!=='string'||!paymentId.trim()||typeof paymentSource!=='string'||!paymentSource.trim())throw Error('Rujukan bayaran tidak sah');
 integer(paidSen,'Amaun pembayaran',1);
 if(paidSen!==plan?.quote?.totalSen)throw Error('Amaun bayaran tidak sepadan dengan sebut harga');
 if(state.bookingIds.includes(bookingId)||state.paymentIds.includes(paymentId))throw Error('Tempahan atau pembayaran telah diproses');
 if(!plan?.legs?.length||!GLOBAL_AIRPORTS[plan.from]||!GLOBAL_AIRPORTS[plan.to])throw Error('Pelan penerbangan tidak sah');
 if(state.activeJourney&&state.activeJourney.status!=='AT_DESTINATION')throw Error('Selesaikan segmen perjalanan semasa');
 if(state.activeJourney&&state.activeJourney.currentAirport!==plan.from)throw Error('Airport berlepas tidak sepadan dengan lokasi pemain');
 if(!state.activeJourney&&plan.from!=='KUL')throw Error('Perjalanan pertama mesti bermula di KUL');
 const next=clone(state);
 const segment={id:bookingId,from:plan.from,to:plan.to,status:'BOOKED',legs:clone(plan.legs),quote:clone(plan.quote),payment:{id:paymentId,source:paymentSource,amountSen:paidSen,currency:'MYR',status:'PAID'}};
 if(!next.activeJourney)next.activeJourney={id:`journey-${bookingId}`,status:'BOOKED',currentAirport:'KUL',segments:[segment],visitedAirports:['KUL']};
 else {next.activeJourney.segments.push(segment);next.activeJourney.status='BOOKED';}
 next.bookingIds.push(bookingId);next.paymentIds.push(paymentId);
 return next;
}
// Payment is performed by the existing finance engine. This function only commits a
// validated PAID receipt; callers must never debit money inside a render handler twice.
export function commitPaidGlobalBooking(state,plan,receipt){return reserveGlobalItinerary(state,plan,receipt);}
export function advanceGlobalJourney(state,bookingId,event){
 const next=clone(state),j=next.activeJourney,seg=j?.segments?.at(-1);
 if(!seg||seg.id!==bookingId)throw Error('Segmen aktif tidak ditemui');
 const allowed={BOOKED:'AT_AIRPORT',AT_AIRPORT:'IN_FLIGHT',IN_FLIGHT:'ARRIVED',ARRIVED:'AT_DESTINATION'};
 if(allowed[seg.status]!==event)throw Error('Peralihan penerbangan tidak sah');
 seg.status=event;j.status=event;
 if(event==='AT_DESTINATION'){
  j.currentAirport=seg.to;
  if(!j.visitedAirports.includes(seg.to))j.visitedAirports.push(seg.to);
  if(seg.to==='KUL'){
   j.status='COMPLETED';next.history.push(j);next.activeJourney=null;
  }
 }
 return next;
}
export const GLOBAL_BOOKING_RULES=Object.freeze({minConnectionMinutes:MIN_CONNECTION_MINUTES,maxStops:2,paymentCurrency:'MYR',journeyMode:'FLEX'});

// Phase 5: non-mutating itinerary, payments and multi-city audit.
export function globalJourneyLedger(state){
 const journeys=[...(state?.history||[]),...(state?.activeJourney?[state.activeJourney]:[])];
 const segments=journeys.flatMap(j=>(j.segments||[]).map((seg,index)=>({journeyId:j.id,index:index+1,from:seg.from,to:seg.to,status:seg.status,bookingId:seg.id,paymentId:seg.payment?.id,paidSen:seg.payment?.amountSen||0,source:seg.payment?.source,legs:seg.legs?.length||0})));
 const seenBookings=new Set(),seenPayments=new Set();let totalPaidSen=0;
 for(const seg of segments){
  if(!GLOBAL_AIRPORTS[seg.from]||!GLOBAL_AIRPORTS[seg.to]||!seg.bookingId||!seg.paymentId||!Number.isSafeInteger(seg.paidSen)||seg.paidSen<=0)throw Error('Rekod perjalanan atau pembayaran rosak');
  if(seenBookings.has(seg.bookingId)||seenPayments.has(seg.paymentId))throw Error('Bayaran atau tiket berulang');
  seenBookings.add(seg.bookingId);seenPayments.add(seg.paymentId);totalPaidSen+=seg.paidSen;
  if(!Number.isSafeInteger(totalPaidSen))throw Error('Jumlah bayaran melebihi had');
 }
 return {segments,totalPaidSen,journeyCount:journeys.length,completedJourneys:state?.history?.length||0,activeAirport:state?.activeJourney?.currentAirport||'KUL'};
}
export function globalNextDeparture(state){
 const j=state?.activeJourney,seg=j?.segments?.at(-1);
 if(!seg||!['BOOKED','TRANSIT','AT_AIRPORT','READY_TO_FLY'].includes(j.status))return null;
 const leg=seg.legs?.[seg.airport?.legIndex??0];
 return leg?{bookingId:seg.id,from:leg.from,to:leg.to,departureDay:leg.departureDay,departureMinute:leg.departureMinute}:null;
}
