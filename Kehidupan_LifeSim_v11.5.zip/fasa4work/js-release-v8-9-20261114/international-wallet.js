// Persistent international travel wallet, denominated in MYR sen and integer foreign minor units.
// All bank movements use the game's balanced journal. Offline FX quotes are simulation rates.
import {account,transfer,post} from './finance.js';
const FX={KRW:320,JPY:34,SGD:.30,THB:7.8,AED:.84,GBP:.18,EUR:.20,USD:.23,AUD:.35,NZD:.39,IDR:3700,PHP:13.4,VND:5800,KHR:930,LAK:5000,MMK:480,BND:.30,CNY:1.65,TWD:7.2,HKD:1.78,INR:20,BDT:27,NPR:32,LKR:68,MVR:3.5,QAR:.84,SAR:.86,TRY:9};
const AIRPORT={ICN:'KRW',NRT:'JPY',SIN:'SGD',BKK:'THB',DXB:'AED',LHR:'GBP',CDG:'EUR',JFK:'USD',SYD:'AUD',AKL:'NZD',CGK:'IDR',MNL:'PHP',SGN:'VND',PNH:'KHR',VTE:'LAK',RGN:'MMK',BWN:'BND',PEK:'CNY',TPE:'TWD',HKG:'HKD',DEL:'INR',DAC:'BDT',KTM:'NPR',CMB:'LKR',MLE:'MVR',DOH:'QAR',JED:'SAR',IST:'TRY',FRA:'EUR',AMS:'EUR'};
const ZERO_DECIMAL=new Set(['KRW','JPY','IDR','VND','KHR','LAK']);
export const currencyDecimals=(currency)=>ZERO_DECIMAL.has(currency)?0:2;
export const currencyForAirport=code=>AIRPORT[code]||null;
export const fxCurrencies=Object.freeze({...AIRPORT});
export function ensureInternationalWallet(s){
 s.internationalWallet??={version:1,cash:{},history:[],processed:[]};
 const w=s.internationalWallet;
 w.cash??={};w.history??=[];w.processed??=[];
 if(!s.accounts.travelInternational)account(s,'travelInternational','International Travel Account','personal','asset',null);
 return w;
}
function validAmount(n){if(!Number.isSafeInteger(n)||n<=0)throw Error('Jumlah mesti integer positif');}
function journal(s,type,record){const w=ensureInternationalWallet(s);const id='iw-'+(++s.sequence);w.history.push({id,day:s.day,type,...record});return id;}
export function fundTravelAccount(s,source,amountSen){validAmount(amountSen);ensureInternationalWallet(s);const a=s.accounts[source];if(!a||a.kind!=='asset'||a.owner!=='personal'||a.status||source==='travelInternational'||source==='epf'||source.startsWith('fd-')||source.startsWith('bail-'))throw Error('Pilih akaun bank peribadi yang boleh digunakan');transfer(s,source,'travelInternational',amountSen,'International Travel Account funding','travel-funding');return journal(s,'FUND',{source,amountSen});}
export function fxQuote(s,currency,amountSen){validAmount(amountSen);ensureInternationalWallet(s);if(!FX[currency])throw Error('Mata wang tidak disokong');const spread=.015,fluctuation=1+((s.day%7)-3)*.001;const rate=Math.round(FX[currency]*(1-spread)*fluctuation*1000000)/1000000;const units=Math.floor(amountSen/100*rate*(ZERO_DECIMAL.has(currency)?1:100));if(units<=0)throw Error('Nilai terlalu kecil');return {currency,amountSen,rate,units,day:s.day,baseRate:FX[currency],spread,simulated:true};}
export function exchangeTravelCash(s,quote){const q=fxQuote(s,quote.currency,quote.amountSen);if(q.day!==quote.day||q.units!==quote.units||q.rate!==quote.rate||q.currency!==quote.currency||q.amountSen!==quote.amountSen)throw Error('Kadar pertukaran telah berubah; semak semula');const w=ensureInternationalWallet(s);if(s.accounts.travelInternational.balance<q.amountSen)throw Error('Travel Account tidak mencukupi');transfer(s,'travelInternational','world',q.amountSen,`FX MYR → ${q.currency} (${q.units} minor units)`,'travel-fx');w.cash[q.currency]=(w.cash[q.currency]||0)+q.units;journal(s,'FX',{...q,source:'travelInternational',settlementSen:q.amountSen});return q;}
export function spendForeignCash(s,currency,units,label){validAmount(units);const w=ensureInternationalWallet(s);if(!FX[currency])throw Error('Mata wang tidak disokong');if((w.cash[currency]||0)<units)throw Error(`International Currency Cash ${currency} tidak mencukupi`);w.cash[currency]-=units;journal(s,'SPEND',{currency,units,label});return units;}
export function refundForeignCash(s,currency,units,label){validAmount(units);const w=ensureInternationalWallet(s);if(!FX[currency])throw Error('Mata wang tidak disokong');w.cash[currency]=(w.cash[currency]||0)+units;journal(s,'REFUND',{currency,units,label});return units;}
export function validateInternationalWallet(s){const w=ensureInternationalWallet(s);if(w.version!==1||!Array.isArray(w.history)||!Array.isArray(w.processed)||Object.entries(w.cash).some(([k,v])=>!FX[k]||!Number.isSafeInteger(v)||v<0))throw Error('International wallet corrupted');return true;}
export function formatForeign(units,currency){const d=ZERO_DECIMAL.has(currency)?1:100;return new Intl.NumberFormat('en-US',{style:'currency',currency,minimumFractionDigits:d===1?0:2,maximumFractionDigits:d===1?0:2}).format(units/d);}
