// Curated hotel-name candidates for offline game. Names/availability and room types NOT live-verified.
export const HOTEL_CANDIDATES={
 "SIN": [
  "Raffles Singapore",
  "Marina Bay Sands",
  "The Fullerton Hotel Singapore",
  "Shangri-La Singapore",
  "Mandarin Oriental Singapore",
  "Pan Pacific Singapore",
  "Fairmont Singapore",
  "Conrad Singapore Marina Bay"
 ],
 "BKK": [
  "Mandarin Oriental Bangkok",
  "The Siam",
  "The Peninsula Bangkok",
  "Shangri-La Bangkok",
  "Banyan Tree Bangkok",
  "The Okura Prestige Bangkok",
  "Siam Kempinski Hotel Bangkok",
  "Anantara Siam Bangkok Hotel"
 ],
 "CGK": [
  "Hotel Indonesia Kempinski Jakarta",
  "Grand Hyatt Jakarta",
  "Mandarin Oriental Jakarta",
  "Shangri-La Jakarta",
  "The Ritz-Carlton Jakarta Pacific Place",
  "Fairmont Jakarta",
  "Hotel Mulia Senayan Jakarta",
  "Raffles Jakarta"
 ],
 "MNL": [
  "The Peninsula Manila",
  "Makati Shangri-La",
  "Fairmont Makati",
  "New World Makati Hotel",
  "The Manila Hotel",
  "Sofitel Philippine Plaza Manila",
  "Conrad Manila",
  "Grand Hyatt Manila"
 ],
 "SGN": [
  "Park Hyatt Saigon",
  "Hotel Majestic Saigon",
  "Caravelle Saigon",
  "The Reverie Saigon",
  "InterContinental Saigon",
  "Sheraton Saigon Grand Opera Hotel",
  "Rex Hotel Saigon",
  "Hotel Nikko Saigon"
 ],
 "PNH": [
  "Raffles Hotel Le Royal",
  "Sofitel Phnom Penh Phokeethra",
  "Rosewood Phnom Penh",
  "Hyatt Regency Phnom Penh",
  "Palace Gate Hotel & Resort",
  "SUN & MOON Urban Hotel",
  "Courtyard by Marriott Phnom Penh",
  "NagaWorld Hotel"
 ],
 "VTE": [
  "Lao Plaza Hotel",
  "Crowne Plaza Vientiane",
  "Settha Palace Hotel",
  "Green Park Boutique Hotel",
  "Salana Boutique Hotel",
  "Lao Poet Hotel",
  "Eastin Hotel Vientiane",
  "Muong Thanh Luxury Vientiane"
 ],
 "RGN": [
  "The Strand Yangon",
  "Pan Pacific Yangon",
  "Sule Shangri-La Yangon",
  "Novotel Yangon Max",
  "Melia Yangon",
  "Lotte Hotel Yangon",
  "Chatrium Hotel Royal Lake Yangon",
  "Sedona Hotel Yangon"
 ],
 "BWN": [
  "The Empire Brunei",
  "Radisson Hotel Brunei Darussalam",
  "The Brunei Hotel",
  "Badi’ah Hotel",
  "Mulia Hotel",
  "Higher Hotel",
  "Jubilee Hotel",
  "The Capital Residence Suites"
 ],
 "ICN": [
  "Four Seasons Hotel Seoul",
  "The Shilla Seoul",
  "Lotte Hotel Seoul",
  "Grand Hyatt Seoul",
  "Signiel Seoul",
  "The Westin Josun Seoul",
  "JW Marriott Dongdaemun Square Seoul",
  "Park Hyatt Seoul"
 ],
 "NRT": [
  "Park Hyatt Tokyo",
  "The Peninsula Tokyo",
  "Imperial Hotel Tokyo",
  "Aman Tokyo",
  "The Okura Tokyo",
  "Conrad Tokyo",
  "Shangri-La Tokyo",
  "Hotel New Otani Tokyo"
 ],
 "PEK": [
  "Waldorf Astoria Beijing",
  "The Peninsula Beijing",
  "Grand Hyatt Beijing",
  "Regent Beijing",
  "Four Seasons Hotel Beijing",
  "Park Plaza Beijing Wangfujing",
  "Rosewood Beijing",
  "The Opposite House"
 ],
 "TPE": [
  "Grand Hyatt Taipei",
  "Mandarin Oriental Taipei",
  "Regent Taipei",
  "W Taipei",
  "Palais de Chine Hotel",
  "Hotel Royal-Nikko Taipei",
  "Shangri-La Far Eastern Taipei",
  "Humble House Taipei"
 ],
 "HKG": [
  "The Peninsula Hong Kong",
  "The Ritz-Carlton Hong Kong",
  "Mandarin Oriental Hong Kong",
  "The Murray Hong Kong",
  "Four Seasons Hotel Hong Kong",
  "The Upper House",
  "The Landmark Mandarin Oriental",
  "K11 ARTUS"
 ],
 "DEL": [
  "The Imperial New Delhi",
  "The Leela Palace New Delhi",
  "Taj Mahal New Delhi",
  "The Oberoi New Delhi",
  "ITC Maurya New Delhi",
  "Shangri-La Eros New Delhi",
  "The Lalit New Delhi",
  "The Lodhi"
 ],
 "DAC": [
  "Pan Pacific Sonargaon Dhaka",
  "InterContinental Dhaka",
  "The Westin Dhaka",
  "Radisson Blu Dhaka Water Garden",
  "Le Méridien Dhaka",
  "Hotel Sarina Dhaka",
  "Amari Dhaka",
  "Renaissance Dhaka Gulshan Hotel"
 ],
 "KTM": [
  "Dwarika’s Hotel",
  "Hyatt Regency Kathmandu",
  "Kathmandu Marriott Hotel",
  "Hotel Yak & Yeti",
  "Soaltee Kathmandu",
  "Radisson Hotel Kathmandu",
  "Hotel Shanker",
  "Aloft Kathmandu Thamel"
 ],
 "CMB": [
  "Galle Face Hotel",
  "Shangri-La Colombo",
  "Cinnamon Grand Colombo",
  "The Kingsbury Colombo",
  "Hilton Colombo",
  "Taj Samudra Colombo",
  "Marino Beach Colombo",
  "Courtyard by Marriott Colombo"
 ],
 "MLE": [
  "JEN Maldives Malé by Shangri-La",
  "Samann Grand",
  "Hotel Octave",
  "The Somerset Hotel",
  "Maagiri Hotel",
  "Mookai Hotel",
  "Unima Grand",
  "Marukab Plaza"
 ],
 "DXB": [
  "Burj Al Arab Jumeirah",
  "Atlantis The Palm",
  "Armani Hotel Dubai",
  "Jumeirah Al Naseem",
  "Address Downtown",
  "Palace Downtown",
  "Atlantis The Royal",
  "One&Only Royal Mirage"
 ],
 "DOH": [
  "Mandarin Oriental Doha",
  "Four Seasons Hotel Doha",
  "The St. Regis Doha",
  "W Doha",
  "Marsa Malaz Kempinski",
  "The Ritz-Carlton Doha",
  "Park Hyatt Doha",
  "Banyan Tree Doha"
 ],
 "JED": [
  "Rosewood Jeddah",
  "Park Hyatt Jeddah",
  "Shangri-La Jeddah",
  "Jeddah Hilton",
  "InterContinental Jeddah",
  "The Ritz-Carlton Jeddah",
  "Assila a Luxury Collection Hotel Jeddah",
  "Mövenpick Hotel Jeddah"
 ],
 "IST": [
  "Çırağan Palace Kempinski Istanbul",
  "Four Seasons Hotel Istanbul at Sultanahmet",
  "The Peninsula Istanbul",
  "Pera Palace Hotel",
  "Raffles Istanbul",
  "Swissôtel The Bosphorus Istanbul",
  "The Ritz-Carlton Istanbul",
  "Shangri-La Bosphorus Istanbul"
 ],
 "LHR": [
  "The Savoy",
  "The Ritz London",
  "Claridge’s",
  "The Dorchester",
  "The Langham London",
  "The Connaught",
  "The Goring",
  "Shangri-La The Shard London"
 ],
 "CDG": [
  "The Ritz Paris",
  "Le Bristol Paris",
  "Hôtel de Crillon",
  "Four Seasons Hotel George V Paris",
  "Le Meurice",
  "Shangri-La Paris",
  "Mandarin Oriental Paris",
  "Hôtel Plaza Athénée"
 ],
 "FRA": [
  "Steigenberger Icon Frankfurter Hof",
  "JW Marriott Hotel Frankfurt",
  "Sofitel Frankfurt Opera",
  "Hilton Frankfurt City Centre",
  "The Westin Grand Frankfurt",
  "Roomers Frankfurt",
  "Meliá Frankfurt City",
  "Scandic Frankfurt Museumsufer"
 ],
 "AMS": [
  "Waldorf Astoria Amsterdam",
  "Conservatorium Hotel",
  "De L’Europe Amsterdam",
  "Pulitzer Amsterdam",
  "Hotel Okura Amsterdam",
  "Andaz Amsterdam Prinsengracht",
  "The Dylan Amsterdam",
  "Anantara Grand Hotel Krasnapolsky Amsterdam"
 ],
 "SYD": [
  "Park Hyatt Sydney",
  "Shangri-La Sydney",
  "Four Seasons Hotel Sydney",
  "The Langham Sydney",
  "InterContinental Sydney",
  "QT Sydney",
  "Capella Sydney",
  "Sofitel Sydney Darling Harbour"
 ],
 "AKL": [
  "Park Hyatt Auckland",
  "The Hotel Britomart",
  "Sofitel Auckland Viaduct Harbour",
  "Cordis Auckland",
  "Hilton Auckland",
  "The Grand by SkyCity",
  "QT Auckland",
  "M Social Auckland"
 ],
 "JFK": [
  "The Plaza New York",
  "The St. Regis New York",
  "The Peninsula New York",
  "The Carlyle",
  "The Pierre New York",
  "Mandarin Oriental New York",
  "The Langham New York Fifth Avenue",
  "The New York EDITION"
 ]
};
