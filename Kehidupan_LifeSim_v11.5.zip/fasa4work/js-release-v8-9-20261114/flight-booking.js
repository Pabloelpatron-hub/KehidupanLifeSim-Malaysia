// Phase 2 flight search and quote engine — simulated game data, no live airline feed.
// All monetary values are integer sen (MYR). This module does not debit accounts.
export const AIRPORTS=Object.freeze({
 KUL:Object.freeze({code:'KUL',city:'Kuala Lumpur',country:'MY',timezone:'Asia/Kuala_Lumpur'}),
 ICN:Object.freeze({code:'ICN',city:'Seoul',country:'KR',timezone:'Asia/Seoul'})
});
export const ROUTES=Object.freeze([
 Object.freeze({id:'KUL-ICN',from:'KUL',to:'ICN',durationMinutes:390,baseFareSen:145000}),
 Object.freeze({id:'ICN-KUL',from:'ICN',to:'KUL',durationMinutes:420,baseFareSen:132000})
]);
export const DIRECT_AIRLINES=Object.freeze([
 Object.freeze({id:'MH',name:'Malaysia Airlines',tier:1.15,classes:['economy','business'],aircraft:'Airbus A330-300'}),
 Object.freeze({id:'D7',name:'AirAsia X',tier:0.78,classes:['economy','business'],aircraft:'Airbus A330-300'}),
 Object.freeze({id:'KE',name:'Korean Air',tier:1.25,classes:['economy','business','first'],aircraft:'Boeing 777-300ER'}),
 Object.freeze({id:'OZ',name:'Asiana Airlines',tier:1.12,classes:['economy','business'],aircraft:'Airbus A350-900'})
]);
export function findFlights(from,to,departureDay){
 if(!Number.isSafeInteger(departureDay)||departureDay<0)throw Error('Hari penerbangan tidak sah');
 if(!AIRPORTS[from]||!AIRPORTS[to]||from===to)throw Error('Laluan penerbangan tidak sah');
 return ROUTES.filter(r=>r.from===from&&r.to===to).map(r=>({...r,departureDay,departureLocalHour:9}));
}
export function quoteFlight(flight,{passengers=1,checkedBags=0,seatClass='economy',airlineId='MH',bookingDay=null}={}){
 if(!flight||!ROUTES.some(r=>r.id===flight.id&&r.from===flight.from&&r.to===flight.to)||!Number.isSafeInteger(flight.departureDay)||flight.departureDay<0)throw Error('Penerbangan tidak sah');
 if(!Number.isSafeInteger(passengers)||passengers<1||passengers>6)throw Error('Bilangan penumpang tidak sah');
 if(!Number.isSafeInteger(checkedBags)||checkedBags<0||checkedBags>passengers*2)throw Error('Bilangan bagasi tidak sah');
 const airline=DIRECT_AIRLINES.find(a=>a.id===airlineId);
 if(!airline||!airline.classes.includes(seatClass))throw Error('Kelas tidak ditawarkan oleh airline ini');
 const route=ROUTES.find(r=>r.id===flight.id);
 const daysAhead=bookingDay===null?7:flight.departureDay-bookingDay;
 if(daysAhead<0)throw Error('Tarikh penerbangan telah berlalu');
 const leadFactor=daysAhead<=1?1.45:daysAhead<=2?1.3:daysAhead<=5?1.15:daysAhead<=9?1:0.9;
 const classFactor={economy:1,business:2.9,first:5.2}[seatClass];
 const base=Math.round(route.baseFareSen*passengers*airline.tier*classFactor*leadFactor);
 const bags=checkedBags*8500,taxes=passengers*12500;
 return Object.freeze({currency:'MYR',baseFareSen:base,baggageSen:bags,taxesSen:taxes,totalSen:base+bags+taxes,passengers,checkedBags,seatClass,airlineId,airlineName:airline.name,aircraft:airline.aircraft,routeId:route.id,departureDay:flight.departureDay,simulated:true});
}
// Booking is atomic when called inside app.mutate; no separate currency ledger.
export function bookFlight(s,selection){
 const {routeId,departureDay,passengers=1,checkedBags=0,seatClass='economy',airlineId='MH'}=selection||{};
 if(s.travel?.status!=='AT_HOME')throw Error('Selesaikan perjalanan aktif sebelum membuat tempahan baharu');
 const route=ROUTES.find(r=>r.id===routeId&&r.from==='KUL'&&r.to==='ICN');
 if(!route)throw Error('Tempahan awal hanya untuk laluan KUL ke Seoul');
 if(!Number.isSafeInteger(departureDay)||departureDay<s.day||departureDay>s.day+13)throw Error('Pilih tarikh dalam 14 hari bermula hari ini');
 const flight=findFlights(route.from,route.to,departureDay)[0];
 const quote=quoteFlight(flight,{passengers,checkedBags,seatClass,airlineId,bookingDay:s.day});
 if(!s.accounts?.main||s.accounts.main.balance<quote.totalSen)throw Error('Baki akaun utama tidak mencukupi');
 const bookingId='flight-'+(s.sequence+1);
 return {id:bookingId,routeId,from:route.from,to:route.to,departureDay,departureLocalHour:flight.departureLocalHour,durationMinutes:route.durationMinutes,quote,bookedDay:s.day,status:'CONFIRMED',paidSen:quote.totalSen,airlineId,airlineName:quote.airlineName,aircraft:quote.aircraft,flightNumber:airlineId+' '+String(100+departureDay%800),captain:['MH','D7'].includes(airlineId)?'Kapten Ahmad Hakimi':'Captain Daniel Park',firstOfficer:['MH','D7'].includes(airlineId)?'Pegawai Pertama Faris Iskandar':'First Officer James Kim'};
}
