# Global Travel Network — Phase 1 coding checkpoint

## Implemented
- 31-airport registry and currencies, separate from legacy Seoul module.
- Simulated airline registry with route-specific airline choices and cabin class restrictions.
- Directed network with 2-stop route search, preventing cycles.
- Fare quotation by distance, airline tier, booking lead time, class, baggage and taxes.
- Automated search across all 930 directed origin/destination pairs.

## Not yet integrated / not production ready
- Existing flight booking UI and legacy Seoul booking still use flight-booking.js.
- Global itinerary purchase/payment, save migration, airport transitions, connecting flight times, live schedules and destination content are NOT implemented.
- Route/airline pairings are illustrative game data, NOT a verified airline timetable; each pairing needs verification before final release. Prices are simulated, not actual market fares.
- No deployment. This checkpoint is only to preserve Phase 1 coding progress.

## Continued coding checkpoint (FLEX domain)
- Added global-journey-booking.js: dated flight legs, minimum 90-minute transit buffer, immutable fare quote references, FLEX journey segment history, paid receipt references, duplicate booking/payment ID rejection, and state transition guards.
- Added test-global-journey-booking.mjs: KUL -> ICN -> NRT -> KUL lifecycle and duplicate payment reference rejection.
- This module does not charge bank accounts. It accepts only a payment receipt from the existing finance engine. The finance integration and UI are still pending; therefore this is NOT an end-to-end payment test.
- Times are simulated abstract game-day minutes, not verified local-time flight schedules. Airline route mappings remain illustrative pending validation.

## Continued Phase 1 UI coding checkpoint
- Added non-destructive Global Flight Network search entry in International Travel when AT_HOME.
- Destination dropdown covers 30 international airports; 30-day date selection, class, passenger count, checked baggage, up to six simulated route quotations including airline and transit information.
- Legacy Seoul ticket checkout remains untouched to preserve current playable trip flow. Global checkout deliberately not enabled until the universal airport state and transaction mutation boundary are integrated; the global search screen explicitly labels simulated data.
- Validated global checkout unit script and JS syntax; this is not mobile-browser QA or final integration.

## Latest checkpoint: secure checkout guards
- Reconstructs fare and route from canonical registry at purchase time; rejects forged prices, invalid legs, loops and stale quotes before debit.
- Regression tests added; global checkout remains non-UI and not production ready.

## Checkout payment-source integrity checkpoint (2026-11-14)
- Explicit Malaysian bank account selection validated; chosen account alone is debited in returned state.
- Rejects invalid/prototype-like account identifiers before any mutation.
- Rejects duplicate booking/payment references against global payment receipt history as well as active FLEX journey.
- Added executable regression cases for selected bank, insufficient/missing bank, invalid account ID, historic duplicate receipts and immutable original state.
- All tests run using Node.js. This is still a domain-level checkout adapter, NOT yet connected to live game mutation/financial ledger or mobile UI. Do not deploy.
