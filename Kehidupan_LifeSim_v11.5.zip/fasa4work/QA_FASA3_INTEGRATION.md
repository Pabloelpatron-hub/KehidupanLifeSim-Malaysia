# Fasa 3 — Integration QA / Freeze Candidate

Baseline: Fasa 3 Flight Clock Dev (no deployment).

## Verified in Node
- Travel regressions CP4–CP8: pass.
- Flight search, payment, airport workflow: pass.
- Flight lifecycle + arrival idempotency: pass.
- NEW cross-midnight flight (departure day 11, 21:00 MYT, 390 min): arrival day 12, 03:30 MYT / 04:30 KST, display game hour 04:00; nextDay processed once; save serialize/deserialize and state validation pass.
- ZIP integrity: checked after packaging.

## Remaining limitations / release blockers
- Browser rendering of Three.js and MapLibre and iPhone Safari gestures/performance have NOT been verified.
- Third-party scripts and map tiles require internet; demotiles are not a production tile service.
- Route is illustrative and phase-based, not real-time position.
- Flight progression is manual phases, not elapsed-time animation of a complete 6h30 flight.
- Whole-hour main game clock rounds 03:30 to 04:00. Accurate minutes remain in travel arrival metadata.
- Full overnight flight regression for all possible game jobs, businesses, NPC and crime states not completed.
- Airport time usage, return flight, passports and cancellation/refunds remain incomplete.

This is a development/QA build, NOT a production-ready release. Netlify production unchanged.
