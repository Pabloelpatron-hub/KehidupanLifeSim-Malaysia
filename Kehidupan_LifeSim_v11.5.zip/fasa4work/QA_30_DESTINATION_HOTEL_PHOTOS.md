# Hotel image integration — 30 destinations

90 separate cropped WebP room illustrations from 3 user-provided 6×5 collages. One budget, standard, premium image for each destination. 8 hotel offers per destination select one of these by tier. These are **representative AI-generated room illustrations, not verified photographs of the named hotels**. No claim of authentic room imagery. All assets bundled locally for offline/iPhone Safari. No production deployment.

{
  "SIN": {
    "budget": "destination-assets/sin-hotel-budget.webp",
    "standard": "destination-assets/sin-hotel-standard.webp",
    "premium": "destination-assets/sin-hotel-premium.webp"
  },
  "BKK": {
    "budget": "destination-assets/bkk-hotel-budget.webp",
    "standard": "destination-assets/bkk-hotel-standard.webp",
    "premium": "destination-assets/bkk-hotel-premium.webp"
  },
  "CGK": {
    "budget": "destination-assets/cgk-hotel-budget.webp",
    "standard": "destination-assets/cgk-hotel-standard.webp",
    "premium": "destination-assets/cgk-hotel-premium.webp"
  },
  "MNL": {
    "budget": "destination-assets/mnl-hotel-budget.webp",
    "standard": "destination-assets/mnl-hotel-standard.webp",
    "premium": "destination-assets/mnl-hotel-premium.webp"
  },
  "SGN": {
    "budget": "destination-assets/sgn-hotel-budget.webp",
    "standard": "destination-assets/sgn-hotel-standard.webp",
    "premium": "destination-assets/sgn-hotel-premium.webp"
  },
  "PNH": {
    "budget": "destination-assets/pnh-hotel-budget.webp",
    "standard": "destination-assets/pnh-hotel-standard.webp",
    "premium": "destination-assets/pnh-hotel-premium.webp"
  },
  "VTE": {
    "budget": "destination-assets/vte-hotel-budget.webp",
    "standard": "destination-assets/vte-hotel-standard.webp",
    "premium": "destination-assets/vte-hotel-premium.webp"
  },
  "RGN": {
    "budget": "destination-assets/rgn-hotel-budget.webp",
    "standard": "destination-assets/rgn-hotel-standard.webp",
    "premium": "destination-assets/rgn-hotel-premium.webp"
  },
  "BWN": {
    "budget": "destination-assets/bwn-hotel-budget.webp",
    "standard": "destination-assets/bwn-hotel-standard.webp",
    "premium": "destination-assets/bwn-hotel-premium.webp"
  },
  "ICN": {
    "budget": "destination-assets/icn-hotel-budget.webp",
    "standard": "destination-assets/icn-hotel-standard.webp",
    "premium": "destination-assets/icn-hotel-premium.webp"
  },
  "NRT": {
    "budget": "destination-assets/nrt-hotel-budget.webp",
    "standard": "destination-assets/nrt-hotel-standard.webp",
    "premium": "destination-assets/nrt-hotel-premium.webp"
  },
  "PEK": {
    "budget": "destination-assets/pek-hotel-budget.webp",
    "standard": "destination-assets/pek-hotel-standard.webp",
    "premium": "destination-assets/pek-hotel-premium.webp"
  },
  "TPE": {
    "budget": "destination-assets/tpe-hotel-budget.webp",
    "standard": "destination-assets/tpe-hotel-standard.webp",
    "premium": "destination-assets/tpe-hotel-premium.webp"
  },
  "HKG": {
    "budget": "destination-assets/hkg-hotel-budget.webp",
    "standard": "destination-assets/hkg-hotel-standard.webp",
    "premium": "destination-assets/hkg-hotel-premium.webp"
  },
  "DEL": {
    "budget": "destination-assets/del-hotel-budget.webp",
    "standard": "destination-assets/del-hotel-standard.webp",
    "premium": "destination-assets/del-hotel-premium.webp"
  },
  "DAC": {
    "budget": "destination-assets/dac-hotel-budget.webp",
    "standard": "destination-assets/dac-hotel-standard.webp",
    "premium": "destination-assets/dac-hotel-premium.webp"
  },
  "KTM": {
    "budget": "destination-assets/ktm-hotel-budget.webp",
    "standard": "destination-assets/ktm-hotel-standard.webp",
    "premium": "destination-assets/ktm-hotel-premium.webp"
  },
  "CMB": {
    "budget": "destination-assets/cmb-hotel-budget.webp",
    "standard": "destination-assets/cmb-hotel-standard.webp",
    "premium": "destination-assets/cmb-hotel-premium.webp"
  },
  "MLE": {
    "budget": "destination-assets/mle-hotel-budget.webp",
    "standard": "destination-assets/mle-hotel-standard.webp",
    "premium": "destination-assets/mle-hotel-premium.webp"
  },
  "DXB": {
    "budget": "destination-assets/dxb-hotel-budget.webp",
    "standard": "destination-assets/dxb-hotel-standard.webp",
    "premium": "destination-assets/dxb-hotel-premium.webp"
  },
  "DOH": {
    "budget": "destination-assets/doh-hotel-budget.webp",
    "standard": "destination-assets/doh-hotel-standard.webp",
    "premium": "destination-assets/doh-hotel-premium.webp"
  },
  "JED": {
    "budget": "destination-assets/jed-hotel-budget.webp",
    "standard": "destination-assets/jed-hotel-standard.webp",
    "premium": "destination-assets/jed-hotel-premium.webp"
  },
  "IST": {
    "budget": "destination-assets/ist-hotel-budget.webp",
    "standard": "destination-assets/ist-hotel-standard.webp",
    "premium": "destination-assets/ist-hotel-premium.webp"
  },
  "LHR": {
    "budget": "destination-assets/lhr-hotel-budget.webp",
    "standard": "destination-assets/lhr-hotel-standard.webp",
    "premium": "destination-assets/lhr-hotel-premium.webp"
  },
  "CDG": {
    "budget": "destination-assets/cdg-hotel-budget.webp",
    "standard": "destination-assets/cdg-hotel-standard.webp",
    "premium": "destination-assets/cdg-hotel-premium.webp"
  },
  "FRA": {
    "budget": "destination-assets/fra-hotel-budget.webp",
    "standard": "destination-assets/fra-hotel-standard.webp",
    "premium": "destination-assets/fra-hotel-premium.webp"
  },
  "AMS": {
    "budget": "destination-assets/ams-hotel-budget.webp",
    "standard": "destination-assets/ams-hotel-standard.webp",
    "premium": "destination-assets/ams-hotel-premium.webp"
  },
  "SYD": {
    "budget": "destination-assets/syd-hotel-budget.webp",
    "standard": "destination-assets/syd-hotel-standard.webp",
    "premium": "destination-assets/syd-hotel-premium.webp"
  },
  "AKL": {
    "budget": "destination-assets/akl-hotel-budget.webp",
    "standard": "destination-assets/akl-hotel-standard.webp",
    "premium": "destination-assets/akl-hotel-premium.webp"
  },
  "JFK": {
    "budget": "destination-assets/jfk-hotel-budget.webp",
    "standard": "destination-assets/jfk-hotel-standard.webp",
    "premium": "destination-assets/jfk-hotel-premium.webp"
  }
}