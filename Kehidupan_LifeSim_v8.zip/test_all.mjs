globalThis.Image=class {set src(v){this._src=v;}get src(){return this._src;}};
await import('./test_capo_flow.mjs');
await import('./test_integration.mjs');
