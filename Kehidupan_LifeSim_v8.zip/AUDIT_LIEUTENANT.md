# Audit integrasi Lieutenant — 13 November 2026

Baseline: Kehidupan_LifeSim_Lieutenant_working_checkpoint.zip.

## Perubahan selepas audit
- `js/territory-world.js`: Semua racket berpengurus dalam negeri Lieutenant, termasuk rival, menggunakan transaksi hasil/kos mingguan yang sama. Kitaran bulanan lama melangkau racket negeri itu untuk mengelakkan pendapatan berganda. Negeri lain kekal pada model lama.
- `js/lieutenant.js`: Paparan keuntungan milik player menggunakan keuntungan mingguan direalisasikan selepas minggu pertama; sebelum itu menggunakan anggaran mingguan.
- Ujian automatik tambahan `test_integration.mjs` dan `test_all.mjs`.

## Ujian lulus
1. Perpindahan Soldier, pelantikan, tangkapan, pegawai menolak, pemangku, sabitan, pengganti tetap, pewarisan racket.
2. Pegawai IPK bersetuju, kos dalam julat, potongan Tabung Group sekali sahaja, percubaan caj kali kedua ditolak.
3. Pembebasan selepas reman dan pemulangan Soldier pemangku.
4. Kematian semasa reman direkodkan sebagai satu kes; penggantian tetap satu kali sahaja.
5. Recruitment tempatan selesai sekali sahaja.
6. Racket rival minimum RM8,500 seminggu, transaksi mingguan tepat sekali dan tiada transaksi bulanan berganda.
7. JSON round-trip mengekalkan ID kes, status pembayaran dan lejar.
8. Pemeriksaan sintaks semua fail JavaScript lulus.

## Batasan / belum disahkan
- Tiada ujian interaksi iPhone Safari atau browser end-to-end bagi popup, navigasi dan reka letak.
- Pengganti Sementara masih rank Soldier dalam roster; fungsi operasi Group yang memerlukan Caporegime aktif mungkin tidak membenarkan pemangku memimpin semua operasi. Perlu pembetulan/ujian gameplay khusus.
- Migrasi daripada save lama yang kompleks dan operasi Group yang sedang berlangsung belum diuji menyeluruh.
- Paparan Rekod PDRM ialah projection kepada kes Lieutenant, bukan kes `crime.cases` pemain; integriti UI perlu disahkan dalam pelayar.
- Semakan silang semua sistem game di luar expansion Lieutenant tidak dilakukan.

## Arahan keselamatan
Tiada deployment dibuat. Fail ZIP ini checkpoint audit, bukan final bebas bug.

## Semakan tambahan: Pengganti Sementara (13 Nov 2026)
- Punca: Group operasi menapis ketua mengikut rank 2, sedangkan pemangku kekal Soldier rank 1.
- Pembetulan: `groupOperationalCapos()` menghasilkan representasi operasi sementara berdasarkan kes reman aktif, `actingId`, dan `actingFor`; pangkat dan ID NPC asal tidak berubah.
- Pengiraan kekuatan, kesiapsiagaan, tugasan Soldier dan pilihan ketua operasi menggunakan ketua operasi berkesan. Pemangku tidak dikira sebagai Soldier tambahan dalam crew sendiri.
- Pengembalian Caporegime asal selepas pembebasan menamatkan pemangku secara automatik.
- `test_acting.mjs`: lulus reman tanpa pemangku, pelantikan, 4 Soldier boleh diketuai, pemilihan ketua operasi, kekuatan Group, dan pembebasan.
- Batasan: belum diuji secara interaktif pada Safari/iPhone; operasi yang sedang berjalan ketika pertukaran ketua masih perlu pengujian simulasi lanjutan.

## Semakan operasi sedang berjalan — tambahan
- `reconcileGroupOperations` menangguhkan operasi aktif jika ketua ditahan dan tiada pengganti operasi.
- Apabila Pengganti Sementara dilantik, operasi menukar ketua dalam team sedia ada tanpa menambah anggota atau menggandakan kos.
- Selepas pembebasan, operasi boleh kembali kepada Caporegime asal. Operasi yang sudah mencapai tarikh siap hanya diproses apabila ketua tersedia.
- `test_inflight.mjs` lulus: tangkapan → operasi tergantung → pemangku → ketua asal kembali → operasi diselesaikan sekali.
- Semua fail JS lulus pemeriksaan sintaks; `test_all.mjs`, `test_acting.mjs`, `test_inflight.mjs` lulus.

## Had pengesahan
- Ujian iPhone Safari sebenar tidak dapat dilakukan dalam persekitaran ini.
- Ujian ini bukan bukti bahawa semua laluan UI dan seluruh permainan bebas bug. Simulasi operasi aktif telah diuji dengan data kes terpilih, bukan setiap kemungkinan save lama.
