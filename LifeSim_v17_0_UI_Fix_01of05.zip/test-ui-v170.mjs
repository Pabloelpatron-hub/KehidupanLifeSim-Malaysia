import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
globalThis.Image=class{};
const base='./js-release-v8-9-20261114/';
const {initial,validate,serialize,deserialize}=await import(base+'state.js');
const {nextDay}=await import(base+'engine.js');
const {globalFlightChoices}=await import(base+'global-flight-checkout.js');
const {canonicalGlobalCheckout,canonicalGlobalNoShow,canonicalGlobalAirportAction}=await import(base+'canonical-global-actions.js');
const {syncGlobalFlightToTravel,bindGlobalJourney}=await import(base+'airport-merge-phase4.js');
const {expireMissedLegacyFlight}=await import(base+'airport-legacy-noshow.js');
const {transitionTravel}=await import(base+'travel-foundation.js');
const app=fs.readFileSync(new URL('app.js',new URL(base,import.meta.url)),'utf8');
let count=0;
for(const to of ['ICN','SIN','LHR']){
 const s=initial();s.day=672;
 const plan=globalFlightChoices(s,{from:'KUL',to,departureDay:673})[0];
 // Provide reconciled funds for every route, using the real ledger.
 const {income}=await import(base+'finance.js');income(s,'main',10000000,'Test funding','opening');
 canonicalGlobalCheckout(s,plan,{accountId:'main',bookingId:'test-'+to,paymentId:'pay-'+to});
 const balance=s.accounts.main.balance;
 nextDay(s);canonicalGlobalNoShow(s);expireMissedLegacyFlight(s);syncGlobalFlightToTravel(s);validate(s);
 assert.equal(s.day,673);assert.equal(s.travel.status,'BOOKED');
 const restored=deserialize(serialize(s));
 canonicalGlobalAirportAction(restored,'ENTER',{day:restored.day});assert.equal(restored.travel.status,'AT_AIRPORT');validate(restored);
 assert.ok(s.accounts.main.balance<=balance); // daily costs, no second ticket charge
 const payments=s.globalTravelPayments.length;
 nextDay(s);canonicalGlobalNoShow(s);expireMissedLegacyFlight(s);syncGlobalFlightToTravel(s);validate(s);
 assert.equal(s.travel.status,'AT_HOME');assert.equal(s.globalTravelPayments.length,payments);
 assert.equal(s.travel.trips.filter(t=>t.id==='test-'+to).length,1);count++;
}
// A missed legacy flight previously left an active ticket at home and failed validation.
const legacy=initial();legacy.day=672;transitionTravel(legacy,'BOOKED',{trip:{id:'legacy',from:'KUL',to:'ICN',departureDay:673}});
nextDay(legacy);validate(legacy);assert.equal(legacy.day,673);
nextDay(legacy);assert.equal(expireMissedLegacyFlight(legacy),true);validate(legacy);
assert.equal(legacy.travel.activeTrip,null);assert.equal(legacy.travel.location.cityId,0);
assert.equal(legacy.travel.trips.length,1);assert.equal(expireMissedLegacyFlight(legacy),false);
// Global no-show lifecycle is never touched by the legacy expiry function.
const global={day:674,travel:{status:'BOOKED',activeTrip:{source:'global-flight',departureDay:673}}};
assert.equal(expireMissedLegacyFlight(global),false);assert.equal(global.travel.status,'BOOKED');
// Test the real transaction boundary with failures before and after persistence.
const mutateSource=app.slice(app.indexOf('function mutate('),app.indexOf('\nfunction dialog('));
function transaction({renderFail=false,persistFail=false}={}){
 const ctx={s:initial(),structuredClone,console:{error(){}},operationalSnapshot:()=>({}),syncGlobalFlightToTravel,bindGlobalJourney,
 expandState:()=>{},spendAction:()=>{},scanOperationalAlerts:()=>{},applyComplianceEnforcement:()=>{},processComplianceInspections:()=>{},scanEnforcementWorkflow:()=>{},scanAdjudication:()=>{},processLoanApplications:()=>{},syncImportantNotices:()=>{},processVehicleApplications:()=>{},vehiclePeriodic:()=>{},prestigeScanMilestones:()=>{},validate,
 persist:()=>!persistFail,storageIssue:'storage test',prestigeEntries:()=>[],render:()=>{if(renderFail)throw Error('render test')},prestigeEnqueue:()=>{},feedback:()=>{},soundKind:'day',toast:()=>{},showOperationalPopup:()=>{},localStorage:{setItem(){}},showMandatoryCrewEvent:()=>{},unlockAudio:()=>{},setAudioScene:()=>{},document:{getElementById:()=>null},airportMode:()=>false,globalAirportActive:()=>false};
 vm.createContext(ctx);vm.runInContext(mutateSource,ctx);const prior=ctx.s.day;
 const ok=ctx.mutate(()=>nextDay(ctx.s));
 assert.equal(ctx.s.day,prior+(persistFail?0:1));assert.equal(ok,!persistFail);validate(ctx.s);
}
transaction();transaction({renderFail:true});transaction({persistFail:true});
// Actual image preprocessing preserves the full bounds for portrait and landscape input.
for(const [w,h] of [[400,1200],[1600,900]])for(const group of [false,true]){
 const draws=[],fills=[];let canvas;
 const ctx={URL:{createObjectURL:()=>'',revokeObjectURL:()=>{}},Image:class {naturalWidth=w;naturalHeight=h;set src(x){this.onload()}},document:{createElement(){canvas={getContext(){return {fillStyle:'',fillRect(...v){fills.push(v)},drawImage(...v){draws.push(v)}}},toDataURL:()=> 'data:image/webp;base64,AA=='};return canvas;}}};
 vm.createContext(ctx);const from=app.indexOf(group?'async function prepareGroupLogo(':'async function preparePlayerImage('),to=app.indexOf(group?"\ndocument.addEventListener('change'":'\nasync function prepareGroupLogo(',from);
 vm.runInContext(app.slice(from,to),ctx);await ctx[group?'prepareGroupLogo':'preparePlayerImage']({type:'image/png',size:100});
 assert.equal(draws[0].length,5);assert.equal(fills.length,1);const [,x,y,dw,dh]=draws[0];assert.ok(x>=0&&y>=0&&dw<=canvas.width&&dh<=canvas.height);assert.ok(Math.abs(dw/dh-w/h)<1e-9);
}
console.log('PASS v17.0: 3 routes day 673→674, reload/airport entry, no-show/ledger, legacy expiry, commit rollback, 4 image fit cases');
