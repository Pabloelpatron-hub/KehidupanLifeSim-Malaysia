# Objective 13 — Audio recovery implementation

Baseline: Objective 12 v16.6 (same source files confirmed against Part04 ZIP).

Changes:
- Web Audio: suspended/interrupted/closed handling, serialized recovery, bounded recreation and stalled-clock detection.
- Destination HTML Audio: foreground resume, freeze playback position during pagehide/hidden, new visits start at 0, existing track loop retained, stalled-media recovery.
- App pagehide: suspend instead of stopping destination visit.
- Existing theme, save data, gameplay and MP3 assets unchanged.

Validation: Node JavaScript syntax checks passed for all modified JS files. ZIP CRC/integrity and full inventory checks performed. Real iOS Safari lock/background playback and audible-output testing NOT performed here; platform audio unlock may still require the next trusted tap. No live deployment.
