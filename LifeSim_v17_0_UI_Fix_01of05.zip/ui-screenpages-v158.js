/* v15.8: page-specific structure, using original controls and existing gameplay DOM. */
(()=>{'use strict';
const app=document.getElementById('app');if(!app)return;
const groups={
 overview:'dashboard',life:'personal',career:'professional',explore:'discovery',phone:'social',journal:'personal',
 business:'operations',banking:'money',finance:'money',assets:'property',investments:'money',
 family:'social',connections:'social',health:'personal',government:'administration',economy:'administration',documents:'administration',settings:'administration',
 lieutenant:'underworld',crime:'underworld',gang:'underworld',police:'administration'};
const labels={dashboard:'RINGKASAN HARI INI',personal:'KEHIDUPAN PERIBADI',professional:'KERJAYA & PENDIDIKAN',discovery:'TEROKA DUNIA',social:'HUBUNGAN & KOMUNIKASI',operations:'PENGURUSAN PERNIAGAAN',money:'PUSAT KEWANGAN',property:'ASET & PEMILIKAN',administration:'REKOD & PENTADBIRAN',underworld:'DUNIA GELAP'};
const pageHints={business:'Pilih syarikat dan urus operasi',banking:'Akaun, pembayaran dan transaksi',finance:'Kedudukan kewangan dan kredit',assets:'Hartanah, kenderaan dan pemilikan',investments:'Portfolio dan prestasi pelaburan',career:'Pekerjaan, gaji dan kelayakan',health:'Kesihatan dan kesejahteraan',documents:'Dokumen dan rekod peribadi',government:'Perkhidmatan dan urusan rasmi',phone:'Mesej, panggilan dan kenalan',explore:'Lokasi, perkhidmatan dan aktiviti'};
function update(){
 const shell=app.querySelector(':scope > .shell');if(!shell)return;
 const content=shell.querySelector('.content');if(!content)return;
 const active=shell.querySelector('.sidebar .navitem.active');const page=active?.dataset.page;if(!page||!groups[page])return;
 if(content.dataset.ui158Page===page)return;
 content.dataset.ui158Page=page;content.dataset.ui158Group=groups[page];
 const head=content.querySelector(':scope > .pagehead');
 if(head){head.classList.add('ui158-pagehead');const eyebrow=head.querySelector('.eyebrow');if(eyebrow){eyebrow.textContent=labels[groups[page]];}
  const desc=head.querySelector('p');if(desc&&!desc.textContent.trim()&&pageHints[page])desc.textContent=pageHints[page];
 }
 // Apply layout classes to existing functional components; do not duplicate or reparent them.
 for(const panel of content.querySelectorAll('.card,.panel')){
  const title=panel.querySelector(':scope > h2,:scope > h3,:scope > .sectionhead h2,:scope > .sectionhead h3,:scope > .cardhead h2');
  if(title)panel.classList.add('ui158-titled-panel');
 }
 // The dashboard's statistics and actions are structurally different from finance ledgers.
 if(page==='overview'){
  content.querySelector('.stats')?.classList.add('ui158-dashboard-stats');
  content.querySelector('.quickgrid')?.classList.add('ui158-quick-actions');
 }
 if(['business','banking','finance','assets','investments'].includes(page)){
  for(const el of content.querySelectorAll('.stats,.grid2,.grid3,.grid4'))el.classList.add('ui158-data-grid');
 }
 if(['phone','family','connections'].includes(page)){
  for(const el of content.querySelectorAll('.tabs,.subtabs,.tabbar'))el.classList.add('ui158-social-tabs');
 }
 if(['government','documents','settings','police'].includes(page)){
  for(const el of content.querySelectorAll('form'))el.classList.add('ui158-admin-form');
 }
 // Context jump links are built only for sections with a native heading, and never change game state.
 const headings=[...content.querySelectorAll(':scope > section > h2,:scope > section > .sectionhead > h2,:scope > .card > h2,:scope > .card > .sectionhead > h2')]
  .filter(h=>h.textContent.trim()&&h.getBoundingClientRect!==undefined).slice(0,8);
 if(headings.length>=3&&head&&!content.querySelector('.ui158-section-index')){
  const nav=document.createElement('nav');nav.className='ui158-section-index';nav.setAttribute('aria-label','Pintasan seksyen');
  for(let i=0;i<headings.length;i++){
   const h=headings[i];const target=h.closest('section,.card');if(!target)continue;
   const id='ui158-'+page+'-'+i;target.id=target.id||id;
   const a=document.createElement('a');a.href='#'+target.id;a.textContent=h.textContent.trim().slice(0,42);
   a.addEventListener('click',event=>{event.preventDefault();target.scrollIntoView({behavior:'smooth',block:'start'});});nav.append(a);
  }
  if(nav.childElementCount>=3)head.after(nav);
 }
}
let pending=false;function schedule(){if(pending)return;pending=true;requestAnimationFrame(()=>{pending=false;update()})}
new MutationObserver(schedule).observe(app,{childList:true});schedule();
})();
