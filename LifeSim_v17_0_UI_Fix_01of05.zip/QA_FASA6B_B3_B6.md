# Fasa 6B — B3 hingga B6: airport, prosedur, AEROTRACE, transit

Baseline: Fasa 6B Integration Checkpoint. Production/Netlify tidak diubah.

## Perubahan
- B3/B4: Paparan airport Global kini memaparkan segmen aktif serta rangkaian laluan sambungan dalam panel Your Flight. Enam prosedur departure asal dikekalkan; pembacaan butiran segmen diambil daripada data canonical `s.travel.globalJourneyData`.
- B4: Menyekat tindakan ENTER airport berulang apabila segmen bukan lagi BOOKED.
- B5/B7 dependency: Memperbaiki pengawal input ketika landing Global. Status canonical masih `IN_FLIGHT` sepanjang lima prosedur arrival, jadi pengawal input terdahulu menolak klik `global-arrival-step`. Kini lima langkah arrival dibenarkan hanya jika view Global benar-benar `ARRIVAL`, sementara navigasi lain kekal disekat.
- B6: Memaparkan direct/transit dan segmen sambungan dalam airport; handoff transit sedia ada melalui `universal-airport.js` dikekalkan.

## Pengesahan
- 40/40 skrip Node lulus, termasuk satu ujian baharu untuk guard arrival dan paparan transit.
- Pemeriksaan sintaks `app.js` dan `canonical-global-actions.js` lulus.

## Had
- Ini pembaikan kod B3–B6, bukan bukti end-to-end Safari. Keseragaman visual penuh dan flow sebenar di iPhone belum diuji.
- Mekanisme AEROTRACE sedia ada dikekalkan, bukan ditulis semula.
