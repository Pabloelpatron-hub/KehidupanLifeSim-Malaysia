import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';
const src=fs.readFileSync('./js-release-v8-9-20261114/app.js','utf8');
const fn=src.match(/function commitImportedState\(imported,sidecars=null\)\{[\s\S]*?\n\}/)?.[0];assert.ok(fn);
const act=src.match(/function activateJsonMode\(\)\{[\s\S]*?\n\}/)?.[0];assert.ok(act);
function check(quota){const map=new Map([['kehidupan-auto','OLD']]);const c={window:{},s:{day:3},cp16Notes:{},cp17Followups:[],cp18Tags:{},favoriteContacts:new Set(),selectedContact:'x',selectedVenue:'x',relationshipSelected:'x',storageRecoveryRequired:true,storageError:true,storageIssue:'bad',jsonOnlyMode:false,jsonModeNotified:false,toast:()=>{},serialize:JSON.stringify,localStorage:{getItem:k=>map.get(k)??null,setItem(k,v){if(quota)throw Object.assign(new Error('full'),{name:'QuotaExceededError'});map.set(k,v)},removeItem:k=>map.delete(k)}};vm.createContext(c);vm.runInContext(act+'\n'+fn+'\nthis.commit=commitImportedState',c);const saved=c.commit({day:7});assert.equal(saved,!quota);assert.equal(c.s.day,7);assert.equal(c.storageRecoveryRequired,false);assert.equal(map.get('kehidupan-auto'),quota?'OLD':'{"day":7}');if(quota)assert.equal(c.jsonOnlyMode,true);}
check(false);check(true);
assert.ok(!src.includes('s=imported;storageRecoveryRequired=false;selectedContact=null;selectedVenue=null;persist()'));
assert.ok(!src.includes('if((processVehicleApplications(s)||vehiclePeriodic(s))&&!storageRecoveryRequired)persist()'));
console.log('PASS atomic import, quota JSON fallback, legacy import removal, render side effect removal');
