/* v15.7: structural enhancements to existing screen content, no state changes. */
(()=>{'use strict';
const app=document.getElementById('app');if(!app)return;
function enhance(){
 const content=app.querySelector(':scope > .shell > .content');if(!content||content.querySelector('.seoul-screen,.airport-screen'))return;
 // Move wide data tables into real horizontal-scroll regions, retaining table nodes and listeners.
 for(const table of content.querySelectorAll('table')){
  if(table.closest('.ui157-table-scroll,.seoul-screen,.airport-screen,[contenteditable]'))continue;
  const wrapper=document.createElement('div');wrapper.className='ui157-table-scroll';wrapper.tabIndex=0;wrapper.setAttribute('role','region');wrapper.setAttribute('aria-label','Jadual boleh ditatal secara mendatar');table.before(wrapper);wrapper.append(table);
 }
 // Expose native document section navigation with links to actual section headings.
 const nav=content.querySelector('.ui-context-nav');if(nav){nav.setAttribute('aria-label','Lompat ke seksyen halaman');nav.querySelectorAll('button[data-ui-context]').forEach(b=>b.setAttribute('aria-label','Pergi ke '+b.textContent.trim()));}
 // Make overflowed action groups scrollable without cloning or moving action buttons.
 for(const group of content.querySelectorAll('.tabs,.tabbar,.subtabs,.segmented,.pill-tabs')){
  if(group.dataset.ui157||group.closest('.seoul-screen,.airport-screen'))continue;
  group.dataset.ui157='1';group.classList.add('ui157-action-strip');
 }
 // Accessible expandable content: leave all existing details open/closed states intact.
 for(const details of content.querySelectorAll('details')){
  const summary=details.querySelector(':scope > summary');if(summary&&!summary.hasAttribute('aria-label'))summary.setAttribute('aria-label',summary.textContent.trim().slice(0,110)||'Buka bahagian');
 }
}
let queued=false;function schedule(){if(queued)return;queued=true;requestAnimationFrame(()=>{queued=false;enhance()})}
new MutationObserver(schedule).observe(app,{childList:true});schedule();
})();
