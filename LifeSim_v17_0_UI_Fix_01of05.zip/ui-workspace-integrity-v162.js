/* v16.2: safeguard transactional workspaces against hidden controls and stale state.
   Presentation-only: does not read or write simulation saves. */
(()=>{'use strict';
const app=document.getElementById('app');if(!app)return;
const sensitive=/bayar|pindah|transfer|transaksi|pengeluaran|deposit|pinjam|loan|bida|tender|kontrak|beli|jual|pembelian|jualan|permohonan|apply|checkout|tempahan|booking|daftar|hire|ambil pekerja/i;
let queued=false;
function reconcile(){queued=false;
 const shell=app.querySelector(':scope > .shell');const content=shell?.querySelector(':scope > .content');if(!content)return;
 const page=shell.querySelector('.sidebar .navitem.active')?.dataset.page||'';
 for(const panel of content.querySelectorAll(':scope > .ui159-workspace')){
  const fold=panel.querySelector(':scope > .ui159-fold');if(!fold)continue;
  const heading=panel.querySelector(':scope > .ui159-original-heading');
  // Transactional forms must never be silently hidden on initial visit.
  const title=(heading?.textContent||fold.textContent||'').trim();
  const hasTransactionForm=!!panel.querySelector('form input:not([type="hidden"]),form select,form textarea');
  const guarded=hasTransactionForm||sensitive.test(title);
  if(guarded&&!panel.dataset.ui162Reviewed){
   panel.dataset.ui162Reviewed='1';
   if(panel.classList.contains('ui159-closed'))fold.click();
  }
  // Original heading stays available to assistive technology.
  if(heading){if(!heading.id)heading.id='ui162-heading-'+page+'-'+[...content.children].indexOf(panel);fold.setAttribute('aria-describedby',heading.id)}
  // Hidden form controls should not retain keyboard focus.
  if(panel.classList.contains('ui159-closed')&&panel.contains(document.activeElement)&&document.activeElement!==fold)fold.click();
 }
}
function schedule(){if(queued)return;queued=true;requestAnimationFrame(reconcile)}
new MutationObserver(schedule).observe(app,{childList:true,subtree:true});
app.addEventListener('click',e=>{if(e.target.closest('.ui159-fold,.ui160-workspace-tools'))schedule()},true);
schedule();
})();
