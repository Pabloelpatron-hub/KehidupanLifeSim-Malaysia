/* v15.6: mobile navigation interaction upgrade; simulation controls are untouched. */
(()=>{'use strict';
const app=document.getElementById('app');if(!app)return;
let previousFocus=null;
const mobile=()=>window.matchMedia('(max-width: 820px)').matches;
function setup(){
 const shell=app.querySelector(':scope > .shell');if(!shell)return;
 const sidebar=shell.querySelector('.sidebar'),top=shell.querySelector('.topbar');if(!sidebar||!top)return;
 if(shell.dataset.ui156==='1')return;shell.dataset.ui156='1';
 const toggle=document.createElement('button');toggle.type='button';toggle.className='ui156-menu-toggle';toggle.setAttribute('aria-label','Buka menu halaman');toggle.setAttribute('aria-expanded','false');toggle.textContent='☰ Menu';
 const backdrop=document.createElement('button');backdrop.type='button';backdrop.className='ui156-backdrop';backdrop.setAttribute('aria-label','Tutup menu');backdrop.hidden=true;
 top.prepend(toggle);shell.append(backdrop);
 const close=()=>{shell.classList.remove('ui156-menu-open');toggle.setAttribute('aria-expanded','false');toggle.setAttribute('aria-label','Buka menu halaman');backdrop.hidden=true;sidebar.removeAttribute('role');sidebar.removeAttribute('aria-modal');if(previousFocus?.isConnected)previousFocus.focus({preventScroll:true});previousFocus=null;};
 const open=()=>{if(!mobile())return;previousFocus=document.activeElement;shell.classList.add('ui156-menu-open');toggle.setAttribute('aria-expanded','true');toggle.setAttribute('aria-label','Tutup menu halaman');backdrop.hidden=false;sidebar.setAttribute('role','dialog');sidebar.setAttribute('aria-modal','true');(sidebar.querySelector('button:not([disabled])')||sidebar)?.focus?.({preventScroll:true});};
 toggle.addEventListener('click',()=>shell.classList.contains('ui156-menu-open')?close():open());backdrop.addEventListener('click',close);
 sidebar.addEventListener('click',e=>{if(e.target.closest('button[data-page],button.navitem'))close()});
 shell.addEventListener('keydown',e=>{if(!shell.classList.contains('ui156-menu-open'))return;if(e.key==='Escape'){e.preventDefault();close();return;}if(e.key!=='Tab')return;const focusable=[...sidebar.querySelectorAll('button:not([disabled]):not([hidden]),input:not([disabled]),a[href]')].filter(el=>el.getClientRects().length);if(!focusable.length)return;const first=focusable[0],last=focusable[focusable.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}});
 const mq=window.matchMedia('(max-width: 820px)');mq.addEventListener?.('change',()=>{if(!mq.matches)close()});
 }
 new MutationObserver(setup).observe(app,{childList:true});setup();
})();
