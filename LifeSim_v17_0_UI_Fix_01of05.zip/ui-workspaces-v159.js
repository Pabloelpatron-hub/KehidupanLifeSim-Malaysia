/* v15.9: actual in-page workspace folding, without cloning gameplay nodes. */
(()=>{'use strict';
const app=document.getElementById('app');if(!app)return;
const supported=new Set(['business','banking','finance','assets','investments','government','documents','career']);
const KEY='kehidupan-ui-workspace-v159';
// Do not fold critical workflows: hiding active transaction forms is unsafe.
const critical=/bayar|pindah|transfer|transaksi|pengeluaran|deposit|pinjam|loan|bida|tender|kontrak|beli|jual|pembelian|jualan|permohonan|apply|checkout|tempahan|booking|daftar|hire|ambil pekerja/i;
let saved={};try{saved=JSON.parse(sessionStorage.getItem(KEY)||'{}')||{}}catch{}
function enhance(){
 const shell=app.querySelector(':scope > .shell');const content=shell?.querySelector(':scope > .content');
 const page=shell?.querySelector('.sidebar .navitem.active')?.dataset.page;
 if(!content||!supported.has(page)||content.querySelector('.seoul-screen,.airport-screen'))return;
 // Only the page's own top-level cards are eligible, never nested gameplay widgets.
 const cards=[...content.children].filter(el=>el.matches('section,.card,.panel'));
 let n=0;
 for(const card of cards){
  if(card.dataset.ui159==='1'||card.matches('[hidden],.modal')||card.closest('dialog'))continue;
  const head=[...card.children].find(el=>el.matches('h2,h3,.sectionhead,.cardhead'));
  const rest=[...card.children].filter(el=>el!==head);
  if(!head||rest.length<2||card.querySelector(':scope > details'))continue;
  const title=(head.textContent||'').replace(/\s+/g,' ').trim().slice(0,90);
  if(!title||title.length>90)continue;
  // Critical workflows remain fully visible; preserve their original heading and DOM.
  if(critical.test(title)||card.querySelector('form input:not([type="hidden"]),form select,form textarea,[aria-invalid="true"]'))continue;
  const key=page+':'+title;const index=n++;
  card.dataset.ui159='1';card.classList.add('ui159-workspace');
  const btn=document.createElement('button');btn.type='button';btn.className='ui159-fold';
  btn.setAttribute('aria-label','Buka atau tutup '+title);
  const text=document.createElement('span');text.textContent=title;
  const mark=document.createElement('span');mark.className='ui159-chevron';mark.setAttribute('aria-hidden','true');mark.textContent='⌄';btn.append(text,mark);
  // The original heading stays in the DOM, but is visually hidden to prevent duplicate labels.
  head.classList.add('ui159-original-heading');head.before(btn);
  const set=(closed)=>{card.classList.toggle('ui159-closed',closed);btn.setAttribute('aria-expanded',String(!closed));saved[key]=closed;try{sessionStorage.setItem(KEY,JSON.stringify(saved))}catch{}};
  set(typeof saved[key]==='boolean'?saved[key]:index>1);
  btn.addEventListener('click',()=>set(!card.classList.contains('ui159-closed')));
 }
}
let queued=false;function schedule(){if(queued)return;queued=true;requestAnimationFrame(()=>{queued=false;enhance()})}
new MutationObserver(schedule).observe(app,{childList:true});schedule();
})();
