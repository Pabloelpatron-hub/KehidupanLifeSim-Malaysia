import assert from 'node:assert/strict';
import {GLOBAL_AIRPORTS,searchGlobalRoutes,isPlausibleItinerary} from './js-release-v8-9-20261114/global-flight-network.js';
import {globalFlightChoices} from './js-release-v8-9-20261114/global-flight-checkout.js';
const cases=[['ICN','CGK'],['DEL','IST'],['SIN','PNH'],['BWN','AKL'],['KUL','JFK'],['PNH','CDG']];
for(const [a,b] of cases){const routes=searchGlobalRoutes(a,b,{maxOptions:50});assert(routes.length,`${a}-${b} missing`);for(const r of routes){assert(isPlausibleItinerary(a,b,r.legs));assert.equal(r.legs.at(-1).to,b);assert(r.stops<=2);}}
assert(searchGlobalRoutes('ICN','CGK').some(r=>r.stops===0));
assert(searchGlobalRoutes('DEL','IST').some(r=>r.stops===0));
assert(searchGlobalRoutes('SIN','PNH').some(r=>r.stops===0));
assert(!searchGlobalRoutes('ICN','CGK').some(r=>r.legs.some(l=>l.to==='NRT')));
assert(!searchGlobalRoutes('DEL','IST').some(r=>r.legs.some(l=>l.to==='KUL')));
for(const a of Object.keys(GLOBAL_AIRPORTS))for(const b of Object.keys(GLOBAL_AIRPORTS)){if(a===b)continue;assert(searchGlobalRoutes(a,b,{maxOptions:8}).length,`${a}-${b} missing`);}
console.log('PASS geography, direct/connection and all 930 ordered airport pairs');
