/* Presentation-only enhancements for objectives 8–10. */
(()=>{'use strict';const app=document.getElementById('app');if(!app)return;
const historyTerms=/transaksi|transaction|account activity|bank statement|hasil terkini|berita.*bawah tanah|rekod keputusan|projek.*perkembangan|laporan tugas|benang cerita|sejarah|jurnal|aktiviti akaun|activity|ledger|riwayat|log peristiwa|kronologi|life lately|keputusan terkini|lejar|journal|underworld.*news|recent.*(?:activity|results|outcomes)/i;
const statusMap=[[/^(operating|active|aktif|valid|approved|completed|beroperasi|selesai|diluluskan)$/i,'good'],[/^(not operating|inactive|tidak aktif|expired|rejected|failed|tamat tempoh|suspended|closed|dibatalkan|ditolak|digantung)$/i,'bad'],[/^(pending|processing|under review|menunggu|dalam proses|tertangguh)$/i,'warn'],[/^(ongoing|in progress|scheduled|berjalan|sedang berjalan|dijadualkan)$/i,'info']];
function markStatus(el){if(el.dataset.uiStatus)return;const t=(el.textContent||'').trim();for(const [re,kind] of statusMap){if(re.test(t)){el.classList.add('ui-status-'+kind);el.dataset.uiStatus=kind;return;}}}
function enhance(){const shell=app.querySelector('.shell');if(!shell||app.querySelector('.airport-screen,.seoul-screen,.global-city,.dx-root'))return;
 const nav=shell.querySelector('.bottomnav');if(nav&&!nav.querySelector('[data-ui-next-day]')){const b=document.createElement('button');b.type='button';b.dataset.uiNextDay='1';b.className='ui-next-day';b.innerHTML='<span aria-hidden="true">➜</span><span>Hari +1</span>';b.dataset.action='next';nav.append(b);}
 const top=shell.querySelector('.topbar');if(top){top.classList.add('ui-modern-topbar');const menu=top.querySelector('.mobile-menu');if(menu)menu.setAttribute('aria-label','Buka menu navigasi');}
 if(nav&&nav.querySelector('[data-ui-next-day]'))app.querySelectorAll('.pagehead button[data-action="next"]').forEach(b=>b.classList.add('ui-delegated-next'));
 const content=shell.querySelector('.content');if(content){for(const n of content.querySelectorAll(':scope > .notice'))if(/Mod JSON aktif/i.test(n.textContent||''))n.classList.add('ui-json-dashboard-duplicate');}
 // Accordion: preserve the original buttons and listeners; only move navigation children.
 for(const node of app.querySelectorAll('section,div,nav')){if(node.dataset.uiSections==='1'||node.closest('.ui-section-accordion'))continue;const children=[...node.children];const heading=children.find(c=>c.children.length===0&&/^Seksyen Halaman$/i.test((c.textContent||'').trim()));if(!heading||children.length<2||children.length>18)continue;const choices=children.filter(c=>c!==heading&&(c.matches('button,[data-page]')||c.querySelector('button,[data-page]')));if(!choices.length)continue;node.dataset.uiSections='1';node.classList.add('ui-section-accordion');const trigger=document.createElement('button');trigger.type='button';trigger.className='ui-section-trigger';trigger.textContent='Seksyen Halaman';trigger.setAttribute('aria-expanded','false');const panel=document.createElement('div');panel.className='ui-section-panel';panel.hidden=true;choices.forEach(c=>panel.append(c));heading.replaceWith(trigger);trigger.after(panel);trigger.addEventListener('click',()=>{panel.hidden=!panel.hidden;trigger.setAttribute('aria-expanded',String(!panel.hidden));});}
 // Explicit badges and business accordion status text.
 for(const el of app.querySelectorAll('.badge,.pill,.status,.status-pill,.tag,.business-subtitle')){if(el.classList.contains('business-subtitle')){const text=el.textContent||'';const match=text.match(/(?:^|\s·\s)(Not Operating|Operating|Suspended|Closed|Active|Inactive|Pending|Processing|Approved|Rejected|Completed|Expired|Aktif|Tidak Aktif|Dalam Proses|Menunggu|Diluluskan|Ditolak|Selesai|Tamat Tempoh)\s*$/i);if(match&&!el.querySelector('.ui-status-inline')){const value=match[1];const prefix=text.slice(0,match.index)+text.slice(match.index).replace(match[0],'');el.textContent=prefix.replace(/\s*·\s*$/,'');const badge=document.createElement('span');badge.className='ui-status-inline';badge.textContent=value;el.append(' · ',badge);markStatus(badge);}}else markStatus(el);}
 // Bound each record run after its own heading. Leave headings and forms outside.
 const headingSelector='h2,h3,h4,summary,.cardhead,.ui159-original-heading';
 function scrollable(node,label){
  if(node.closest('.ui-history-scroll'))return;
  node.classList.add('ui-history-scroll');node.tabIndex=0;
  node.setAttribute('role','region');node.setAttribute('aria-label',label+' — skrol rekod');
 }
 for(const table of content?.querySelectorAll('.tablewrap')||[]){
  if(table.querySelectorAll('tbody tr').length>=6)scrollable(table,'Jadual rekod');
 }
 for(const h of content?.querySelectorAll(headingSelector)||[]){
  if(h.closest('.ui-history-scroll')||!historyTerms.test(h.textContent||''))continue;
  let anchor=h.closest('.cardhead,.ui159-original-heading')||h;
  let node=anchor.nextElementSibling,run=[];
  const flush=()=>{if(run.length>=6){const wrap=document.createElement('div');run[0].before(wrap);run.forEach(x=>wrap.append(x));scrollable(wrap,h.textContent.trim());}run=[];};
  while(node){const next=node.nextElementSibling;
   if(node.matches(headingSelector+',form,.inline-actions,.modalactions,.ui-history-scroll')){flush();break;}
   if(node.matches('.tablewrap,ul,ol,.history,.history-list,.transaction-list,.activity-list,.journal-list,.log-list,.entries,.records,.statement-list,.ledger-list,.event-log,.timeline-list,.timeline,.stack')){
    flush();if(node.children.length>=6||node.querySelectorAll('tbody tr').length>=6)scrollable(node,h.textContent.trim());break;
   }
   if(node.matches('p,article,details,.metricblock,.card,.record,.entry,.history-entry,.transaction-row,.activity-row,.timeline-row')&&!node.querySelector('form,input,textarea,select'))run.push(node);
   else {flush();break;}
   node=next;
  }
  flush();
 }

}
let scheduled=false;const obs=new MutationObserver(()=>{if(scheduled)return;scheduled=true;requestAnimationFrame(()=>{scheduled=false;obs.disconnect();try{enhance()}finally{obs.observe(app,{childList:true,subtree:true});}})});enhance();obs.observe(app,{childList:true,subtree:true});
})();
