# Developer UI Studio v2 — Enhanced checkpoint (NOT complete production release)

Baseline: v16.9 UI Studio checkpoint. Existing gameplay and media retained. No production deployment.

## Access
Open with `?ui-studio=1`. Existing `?ui-editor=1` remains separate.

## Added in this build
- Advanced Layout Tools in the UI Studio panel
- Touch/pointer drag to swap visual order of **siblings in the same container**, with CSS `order` rules; left/right alternative buttons
- Smart Grid controls for 1–6 equal-width columns (content may still need manual adaptation)
- Text mode controls: auto-wrap, one-line and word-stacked text for plain text leaf elements
- Additional undo/redo, JSON export/import, local draft and reset for advanced rules
- Core v2 capabilities from previous checkpoint remain available

## Limitations — read before using
- Drag does NOT support moving items between containers, freeform layout, animated snapping guides, or stable reorder of arbitrary dynamic lists. It applies CSS rules only.
- Global semantic template registry, universal popup-state editor, full accessibility audit, automated one-tap repair and safe publishing are NOT implemented.
- Advanced changes and base Studio changes are stored/exported separately. Back up BOTH JSON files.
- Text stacking modifies visible plain-text DOM only; avoid elements containing nested markup. The original text is restored on reapply, but third-party rerenders may overwrite the change.
- Selector stability on dynamically created/reordered lists remains a known limitation.
- LocalStorage may fail with QuotaExceededError; JSON exports are essential.
- JavaScript syntax checks only. Full Safari interactive/regression testing has NOT been completed.

Do not deploy to production until staging and gameplay/save regression tests pass.
