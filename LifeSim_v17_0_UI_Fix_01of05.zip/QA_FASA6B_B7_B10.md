# Fasa 6B — B7 hingga B10

Baseline: B3–B6 Airport & Transit Patch. Netlify production tidak disentuh.

- B7: Mesej selepas arrival EXIT membezakan transit dan ketibaan akhir; lima prosedur asal kekal.
- B8: Sekat butang return Legacy Seoul untuk Global traveler supaya tidak mewujudkan tiket bertindih. Tunjukkan No-Show / tiada refund / tiket sambungan ditutup dalam panel perjalanan.
- B9: Papan airport Global tidak lagi memaparkan jadual penerbangan rekaan yang sama di semua airport; memaparkan penerbangan pemain yang berasal daripada segmen tiket aktif.
- B10: Masa pendaratan Global memerlukan `durationMinutes` integer positif daripada tiket; durasi sifar atau rosak ditolak, bukannya mengubah masa permainan secara senyap. Animasi AEROTRACE tidak digunakan sebagai durasi in-game.

Pengesahan Safari sebenar dan ujian gameplay penuh 30 destinasi perlu dibuat dalam Fasa 6C.
