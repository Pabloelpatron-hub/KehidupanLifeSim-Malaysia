# Objective 12 — Appearance Themes

Baseline: Objective 11 fixed build.

Implemented:
- Legacy Accent Color dropdown removed from Command Hub appearance settings; old accent preference discarded.
- Velocity Acid (default), Obsidian Gold, Sage Mist selectable instantly.
- Both dark themes use pure #000000 as the main base-game background.
- Theme picker, text-size selector (85/92/100/110/120%), and Favourite Bottom Bar retained in Command Hub.
- Appearance preferences stored in localStorage and embedded as `state.uiAppearance` on game save/export; import restores them when present. Old saves without `uiAppearance` continue to work.
- Theme CSS scoped away from Airport and international destination screenpages.

Automated checks: JS syntax and ZIP integrity. Browser/iPhone Safari visual QA and exhaustive gameplay regression not verified. CSS specificity may require module-by-module refinements on older inline-styled panels.

Extraction: unzip all 5 parts into the SAME folder, preserving directory structure. Do not upload each ZIP as a separate site. No production deployment.
