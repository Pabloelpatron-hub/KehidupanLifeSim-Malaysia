KEHIDUPAN — UI FIX v17.0
Baseline: semua 7 ZIP LayoutPolish Followup yang dilampirkan.

PILIH SATU CARA:
1. ZIP FULL: ekstrak satu fail FULL sahaja.
2. ZIP 5 PART: ekstrak SEMUA 01of05 hingga 05of05 ke FOLDER YANG SAMA.
   Ini ZIP berasingan dengan fail berbeza, bukan arkib .z01.
   Pastikan index.html dan folder assets berada di akar folder gabungan.
   Jangan jalankan atau upload hanya Part 1 kerana aset lain akan hilang.

Gunakan folder gabungan sebagai build lengkap pada hosting game anda.
Tiada deployment/live publish dibuat dalam tugas ini.
Eksport JSON daripada versi lama dahulu. Import JSON dalam versi baharu
untuk sambung progress. Jangan mulakan kehidupan baharu untuk migrasi.
Format save dan ID akaun/tiket/kenderaan/NPC tidak ditukar.

Ringkasan pembaikan dan batas ujian: QA_UI_FIX_v17_0.md.
