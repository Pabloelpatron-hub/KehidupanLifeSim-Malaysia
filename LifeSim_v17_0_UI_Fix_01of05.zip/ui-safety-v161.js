/* v16.1: keep legacy gameplay controls reachable inside redesigned workspaces. */
(()=>{'use strict';
const app=document.getElementById('app');if(!app)return;
const rootSelector='.ui159-workspace';
function reveal(node){
 const panel=node?.closest?.(rootSelector);
 if(!panel||!panel.classList.contains('ui159-closed'))return;
 const toggle=panel.querySelector(':scope > .ui159-fold');
 if(toggle){toggle.click();}else panel.classList.remove('ui159-closed');
}
// Native browser validation can focus controls hidden by the new workspace layout.
app.addEventListener('invalid',e=>reveal(e.target),true);
app.addEventListener('focusin',e=>reveal(e.target),true);
// Game-generated alerts, status text, or errors inside collapsed panels must be visible.
const alertSelector='[role="alert"],.error,.field-error,.validation-error,[aria-invalid="true"]';
let scheduled=false;
function check(){
 scheduled=false;
 const shell=app.querySelector(':scope > .shell');
 const content=shell?.querySelector(':scope > .content');if(!content)return;
 for(const panel of content.querySelectorAll('.ui159-workspace.ui159-closed')){
  const active=document.activeElement;
  if(active&&panel.contains(active)&&active!==panel.querySelector(':scope > .ui159-fold')){reveal(active);continue;}
  // Only reveal newly inserted live errors, not static explanatory text.
  for(const el of panel.querySelectorAll(alertSelector)){
   if(el.matches('[aria-invalid="true"]')||((el.getAttribute('role')==='alert'||el.matches('.error,.field-error,.validation-error'))&&el.textContent.trim())){
    reveal(el);break;
   }
  }
 }
}
function schedule(){if(scheduled)return;scheduled=true;requestAnimationFrame(check)}
new MutationObserver(schedule).observe(app,{childList:true,subtree:true,attributes:true,attributeFilter:['aria-invalid','role','class']});
app.addEventListener('click',e=>{if(e.target.closest('.ui159-fold,.ui160-workspace-tools'))schedule()},true);
schedule();
})();
