# Fasa 6A — A5, A6, A7 implementation

Baseline: Kehidupan_LifeSim_Fasa6A_A2_A4_Core_Transition_Update.zip.

## A5 — Global gameplay action routing
- Added `canonical-global-actions.js` as a single command boundary for entering airport, departure steps, arrival steps, takeoff, checkout, no-show and landing.
- `app.js` routes those Global actions through the command boundary; canonical data commits to `s.travel.globalJourneyData` and `syncGlobalFlightToTravel` updates the active trip/status.
- Existing pure Universal Airport functions are reused; no UI/asset overhaul.
- `global-flight-checkout.js` now records the paid itinerary under travel while keeping a return-only `globalJourney` compatibility property for older callers.

## A6 — Compatibility
- `globalJourney` remains a non-enumerable compatibility accessor for existing UI and destination modules; it is not independently serialized.
- Historical Global itinerary remains in `s.travel.globalJourneyData`, and `s.travel.activeTrip`/`s.travel.status` remain the travel/location authority.
- **Limitation:** this is a canonical command/storage boundary, not complete removal of all old Global representation. Some legacy UI/domain readers still use the compatibility accessor. Full UI unification belongs to Fasa 6B.

## A7 — Old save migration
- Legacy `globalJourney` is migrated into `s.travel.globalJourneyData` on import.
- If both exist and differ, the canonical data is preserved and the old value copied to `s.travel.globalJourneyLegacyBackup` with a conflict record.
- Existing legacy activeTrip collision protection is retained.

## Verification
- Node syntax checks passed for edited modules.
- New `test-fasa6a-a5-a7.mjs` passed: canonical airport steps, save serialization/import and conflicting old save backup.
- Existing `test-global-flight-checkout.mjs` passed.
- Other regression tests and actual iPhone Safari have NOT been fully validated. A previous standalone unified-landing test uses a data-URL import that cannot resolve a relative module; that test harness needs adjustment before its result is meaningful.

No production deployment performed.
