# Tier 5 Prestige transaction flow QA — P14

## Confirmed source-based flows
- Successful `mutate` commits state to storage before newly created prestige achievements enter the cinematic queue.
- Failed mutation rolls state back; no prestige event is enqueued.
- Achievement keys prevent repeat awards for the same category.
- Gold purchase >= RM500,000 uses 50,000,000 sen.
- Gold holdings >= RM1m uses 100,000,000 sen market buyback value.
- Net worth >= RM10m uses 1,000,000,000 sen.
- First Class purchase and boarding have distinct achievement keys and cinematic themes.
- Executive Suite achievement follows successful hotel booking payment (`roomId=suite`).
- Vehicle luxury award occurs only at successful JPJ transfer, for both cash and financed paths. Fixed a premature award on cash payment in P13.
- Michelin is keyed to in-game award identity per branch.
- Modal queue waits for existing dialog to close.

## Executed validation
- Existing regression suite plus new component/threshold/queue/integration test: 46/46 pass.
- `node --check` app.js passed.
- ZIP integrity checked.

## Not proven by this QA
- Real browser click-through from fresh game to every qualifying transaction, including save/reload and old save import.
- Real iPhone Safari interactions, animations and airport visual layout.
- Therefore this build is a transaction-flow QA checkpoint, not a certified end-to-end production-final release.
