import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {VEHICLE_GALLERY} from './js-release-v8-9-20261114/vehicle-gallery-registry.js';
import {carCatalog} from './js-release-v8-9-20261114/vehicle-market-cp1.js';
import {vehicleImagePath,vehicleImageMarkup} from './js-release-v8-9-20261114/vehicle-images.js';
const root=path.dirname(fileURLToPath(import.meta.url));
assert.equal(carCatalog.length,150);
assert.equal(Object.keys(VEHICLE_GALLERY).length,150);
let four=0;
for(const car of carCatalog){const views=VEHICLE_GALLERY[car.id];assert.ok(views?.front,car.id+' missing front');assert.equal(vehicleImagePath(car.id),views.front,car.id+' cannot render front image');assert.ok(vehicleImageMarkup(car.id,car.name,'MISSING').includes('<img'),car.id+' incorrectly renders placeholder');for(const file of Object.values(views))assert.ok(fs.existsSync(path.join(root,'js-release-v8-9-20261114',file)),car.id+' missing '+file);if(['Bentley','Rolls-Royce','Ferrari','Lamborghini','Aston Martin'].includes(car.brand)){assert.equal(Object.keys(views).length,4,car.name);four++;}}
assert.equal(four,21);
console.log('Car gallery: 150/150 car entries, 21/21 luxury 4-view galleries, all asset paths verified.');

for(const id of ['cp1-001','cp1-121','cp1-125'])assert.ok(vehicleImagePath(id),id+' regression');
assert.equal(vehicleImagePath('unknown-car'),null);
