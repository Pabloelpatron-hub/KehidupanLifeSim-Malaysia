import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const app=readFileSync(new URL('./'+process.env.APP_PATH,import.meta.url),'utf8');
assert.match(app,/gv\?\.status==='ARRIVAL'&&\['global-arrival-step','close'\]/);
assert.match(app,/Transit \/ Sambungan/);
assert.match(app,/getUniversalAirportView\(s\.travel\.globalJourneyData\)/);
console.log('B3-B6 arrival UI guard and transit leg display: PASS');
