# UI Overhaul P5 — Popup audit and scoped presentation
Baseline: Kehidupan_LifeSim_v12.5_UI_Overhaul_P4.zip

## Verified source findings
- Main `dialog()` in `js-release-v8-9-20261114/app.js` already detects police-related content and inserts `assets/logos/pdrm.webp` when not already present.
- Existing `#modal` is reused for multiple workflows; it contains event-handler wiring and character-specific classes.
- Restaurant confirmations additionally use `.restaurant-confirm-dialog`, a separate implementation.
- Michelin and luxury restaurant events have dedicated paths and must not be normalized into routine popup styling.

## Implemented
- Added read-only popup presentation classification by title for the existing `#modal`.
- Added short entrance motion only for standard modal presentations; preserves contents, logos, images, button handlers, transaction logic.
- Skips custom animation on luxury/character/Michelin popup classes; respects `prefers-reduced-motion`.
- No generic emoji or fabricated official logo.
- No automatic new official logo assignment (requires validated asset mapping).

## Remaining
- Exhaustive event-by-event registry with stable event IDs and visual assets.
- Tier 3–5 bespoke storyboard upgrades after per-event verification.
- iPhone Safari interactive verification and transaction/save regression.
