# Developer UI Studio v2 — Integrity extension (staging build)

This is NOT a completed production release. Built on v16.9 UI Studio v2 Enhanced.

## Implemented
- Template styling only through stable reusable classes or data-ui-component/data-component/data-testid attributes; no positional selector fallback in this extension.
- CSS template rules apply to future matching DOM elements through browser CSS, subject to stable markup and selector specificity.
- Visual snap-target outline preview, **not** true drag-and-drop snapping or cross-container rearrangement.
- Inert cloned popup/component preview (not a comprehensive state simulator).
- Separate staging JSON export/import, basic validation, undo/redo and draft rollback.
- Production publish deliberately disabled. No credentials or game-state writes.

## Not implemented / not verified
- Full smart snapping with drag placement, sibling resize and collision solver.
- Semantic registry coverage for every dynamic game component (requires per-component source markup audit/refactor).
- Comprehensive popup state editor (normal/error/loading/disabled) and editing those states.
- Secure GitHub publishing (requires external authenticated deployment service and staging workflow).
- Safari interactive tests, full game/save regression tests, staging deployment.

## Access
Use ?ui-studio=1 in a TEST deployment. In Studio, pick an element, then use the Global Templates panel. Export three separate drafts if used: Studio base, Plus, Integrity. Existing v2 drafts are not automatically consolidated.

## QA
JavaScript syntax validated with node --check; ZIP archive integrity and file inventory validated. No claim of production readiness.
