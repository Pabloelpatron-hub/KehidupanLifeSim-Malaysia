// Airport merge, phase 1 only. No checkout, airport routing or flight transitions here.
// Preserve legacy gameplay until later phases explicitly switch to the unified engine.
const copy=x=>JSON.parse(JSON.stringify(x));
const obj=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
const text=x=>typeof x==='string'&&x.trim().length>0;
const validLeg=x=>obj(x)&&text(x.from)&&text(x.to)&&Number.isSafeInteger(x.departureDay)&&x.departureDay>=0;
function globalCandidate(s){
 const g=s.globalJourney;
 if(!obj(g)||!obj(g.activeJourney))return null;
 const j=g.activeJourney;
 if(!Array.isArray(j.segments)||!j.segments.length)return null;
 const segments=[];
 for(const booking of j.segments){
  if(!obj(booking)||!text(booking.id)||!Array.isArray(booking.legs)||!booking.legs.length||!booking.legs.every(validLeg))return null;
  segments.push(...booking.legs.map((leg,i)=>({
   id:`${booking.id}:leg:${i}`,bookingId:booking.id,from:leg.from,to:leg.to,
   departureDay:leg.departureDay,departureMinute:leg.departureMinute??540,
   arrivalDay:leg.arrivalDay??null,arrivalMinute:leg.arrivalMinute??null,
   durationMinutes:leg.durationMinutes??null,airlineId:leg.airlineId??null,
   status:booking.status||'BOOKED',departureSteps:[],arrivalSteps:[],
   source:'global-flight',sourceLegIndex:i
  })));
 }
 return {id:j.id||`migrated-${j.segments[0].id}`,from:segments[0].from,to:segments.at(-1).to,
  departureDay:segments[0].departureDay,segments,activeSegmentIndex:0,
  source:'global-flight',migrationOnly:true};
}
function legacySegment(trip){
 return {id:`${trip.id}:leg:0`,bookingId:trip.id,from:trip.from||'KUL',to:trip.to||'ICN',
  departureDay:trip.departureDay??null,departureMinute:trip.departureMinute??null,
  status:'LEGACY',source:'legacy-kul-icn',departureSteps:copy(trip.departureSteps||trip.airportSteps||[]),
  arrivalSteps:copy(trip.arrivalSteps||[])};
}
export function prepareTravelPhase1(s){
 if(!obj(s)||!obj(s.travel))return {status:'no-travel'};
 const t=s.travel;
 // This metadata is additive and deliberately does not change the legacy travel status.
 const m=obj(t.airportMergePhase1)?t.airportMergePhase1:{version:1,conflicts:[],stagedGlobalTrip:null};
 m.version=1;
 if(!Array.isArray(m.conflicts))m.conflicts=[];
 const trip=obj(t.activeTrip)&&text(t.activeTrip.id)?t.activeTrip:null;
 if(trip){
  if(!Array.isArray(trip.segments)||!trip.segments.length){
   trip.segments=[legacySegment(trip)];trip.activeSegmentIndex=0;
  }else if(!Number.isInteger(trip.activeSegmentIndex)||trip.activeSegmentIndex<0||trip.activeSegmentIndex>=trip.segments.length){
   // Do not overwrite unknown segment progress: record a recoverable warning.
   if(!m.conflicts.some(x=>x.code==='INVALID_LEGACY_SEGMENT_INDEX'))m.conflicts.push({code:'INVALID_LEGACY_SEGMENT_INDEX',tripId:trip.id});
  }
 }
 const candidate=globalCandidate(s);
 if(candidate){
  // A global ticket is staged, not activated, until booking/airport phases are merged.
  // Never overwrite a valid legacy active trip or discard the original global state.
  if(!m.stagedGlobalTrip||!(m.stagedGlobalTrip.id===candidate.id||m.stagedGlobalTrip.id===s.globalJourney?.activeJourney?.segments?.at(-1)?.id))m.stagedGlobalTrip=candidate;
  if(trip&&trip.id!==candidate.id&&!m.conflicts.some(x=>x.code==='DUAL_ACTIVE_JOURNEY'&&x.globalTripId===candidate.id))
   m.conflicts.push({code:'DUAL_ACTIVE_JOURNEY',legacyTripId:trip.id,globalTripId:candidate.id});
 }else if(obj(s.globalJourney?.activeJourney)&&!m.conflicts.some(x=>x.code==='UNREADABLE_GLOBAL_JOURNEY')){
  m.conflicts.push({code:'UNREADABLE_GLOBAL_JOURNEY'});
 }
 t.airportMergePhase1=m;
 return {status:trip?'legacy-preserved':candidate?'global-staged':'ready',segments:trip?.segments?.length||0,conflicts:m.conflicts.length};
}
