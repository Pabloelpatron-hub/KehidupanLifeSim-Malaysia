// Centralized, gesture-safe Web Audio feedback. No external audio assets required.
let context;
let lastClickAt=0;
let desiredScene=null;
let scene=null, sceneNodes=null, sceneSettings={enabled:true,volume:.35};
function stopScene(){if(!sceneNodes){scene=null;return;}const nodes=sceneNodes;sceneNodes=null;scene=null;try{const now=context.currentTime;nodes.gain.gain.cancelScheduledValues(now);nodes.gain.gain.setTargetAtTime(.00001,now,.18);setTimeout(()=>{try{nodes.source.stop();nodes.source.disconnect();nodes.filter.disconnect();nodes.gain.disconnect();nodes.low?.stop();nodes.low?.disconnect();}catch{}},900);}catch{}}
function startScene(kind){
 if(!context||context.state!=='running'||!sceneSettings.enabled||!(Number(sceneSettings.volume)>0))return;
 if(scene===kind&&sceneNodes)return;
 stopScene();if(!kind)return;
 // Original synthesized ambience: terminal air handling / distant concourse,
 // or modern commercial turbofan broadband airflow with low-frequency spool.
 const sampleRate=context.sampleRate,seconds=3,buffer=context.createBuffer(1,Math.floor(sampleRate*seconds),sampleRate),out=buffer.getChannelData(0);
 let smooth=0;for(let i=0;i<out.length;i++){const white=Math.random()*2-1;smooth=smooth*.94+white*.06;out[i]=kind==='airport'?smooth*.8+white*.075:smooth*.52+white*.30;}
 const source=context.createBufferSource();source.buffer=buffer;source.loop=true;
 const filter=context.createBiquadFilter();filter.type='lowpass';filter.frequency.value=kind==='airport'?900:2600;
 const gain=context.createGain();gain.gain.value=.00001;source.connect(filter);filter.connect(gain);gain.connect(context.destination);
 const target=Math.min(.23,Number(sceneSettings.volume)*(kind==='airport'?.13:.22));gain.gain.setTargetAtTime(target,context.currentTime,.45);
 let low=null;if(kind==='jet'){low=context.createOscillator();low.type='sawtooth';low.frequency.value=92;const lp=context.createBiquadFilter();lp.type='lowpass';lp.frequency.value=185;low.connect(lp);lp.connect(gain);low.start();}
 source.start();scene=kind;sceneNodes={source,filter,gain,low};
}
export function setAudioScene(kind,settings={enabled:true,volume:.35}){
 desiredScene=kind||null;sceneSettings=settings||{enabled:false,volume:0};
 if(!sceneSettings.enabled||!(Number(sceneSettings.volume)>0)||document.hidden||!desiredScene){stopScene();return;}
 if(context?.state==='running')startScene(desiredScene);
 else stopScene();
}
export function refreshAudioScene(){
 if(document.hidden||!desiredScene||!sceneSettings.enabled||!(Number(sceneSettings.volume)>0)){stopScene();return;}
 if(context?.state==='running')startScene(desiredScene);
}

const labels={cash:'TRANSAKSI DIREKOD',message:'NOTIFIKASI',siren:'AMARAN',engine:'KENDERAAN',stamp:'REKOD DIKEMAS KINI',crime:'OPERASI',day:'HARI BAHARU',error:'TINDAKAN GAGAL',success:'BERJAYA',click:'PILIHAN'};
// Audio lifecycle coordinator. Recover only desired ambience; never replay old effects.
let recoveryPromise=null, lastRecoveryAt=0, contextGeneration=0;
let audioClockValue=0,audioClockChecked=0,audioClockRetries=0;
function replaceContext(){
 const old=context;context=undefined;contextGeneration++;
 // Discard all nodes belonging to the old context before creating new ones.
 sceneNodes=null;scene=null;
 try{old?.close?.().catch?.(()=>{});}catch(_){}
 const C=window.AudioContext||window.webkitAudioContext;
 if(C)context=new C();
}
async function recoverContext(force=false){
 if(document.hidden)return false;
 const C=window.AudioContext||window.webkitAudioContext;if(!C)return false;
 try{
  if(!context||context.state==='closed')replaceContext();
  if(context?.state==='running'&&!force){refreshAudioScene();return true;}
  if(context?.state==='running'&&force)replaceContext();
  const current=context;
  // iOS reports both suspended and interrupted. A resume may need a gesture.
  if(current?.state==='suspended'||current?.state==='interrupted'){
   await Promise.race([current.resume(),new Promise(resolve=>setTimeout(resolve,1200))]);
  }
  if(current!==context)return context?.state==='running';
  if(context?.state==='running'){refreshAudioScene();return true;}
  if(force){replaceContext();if(context?.state!=='running')await Promise.race([context.resume(),new Promise(resolve=>setTimeout(resolve,1200))]);}
  if(context?.state==='running'){refreshAudioScene();return true;}
 }catch(e){if(force){try{replaceContext();if(context?.state==='running'){refreshAudioScene();return true;}}catch(_){}}}
 return false;
}
export function unlockAudio(force=false){
 if(document.hidden)return Promise.resolve(false);
 if(recoveryPromise)return recoveryPromise;
 recoveryPromise=recoverContext(force).finally(()=>{recoveryPromise=null;});
 return recoveryPromise;
}
export function feedback(kind='click',settings={enabled:true,volume:.35}){
 const el=document.getElementById('action-feedback');
 if(el&&kind!=='click'){
  el.textContent=labels[kind]||labels.click;el.dataset.kind=kind;
  el.classList.remove('play');void el.offsetWidth;el.classList.add('play');
 }
 if(!settings?.enabled||Number(settings.volume)<=0)return;
 // Avoid stacking click tones when a button also triggers an immediate result.
 if(kind==='click'){lastClickAt=performance.now();}
 try{
  const C=window.AudioContext||window.webkitAudioContext;if(!C)return;
  context??=new C();
  if(context.state!=='running'){
   unlockAudio().then(ok=>{if(ok&&context?.state==='running'&&!document.hidden)play(kind,settings);}).catch(()=>{});
   return;
  }
  play(kind,settings);
 }catch(e){console.warn('Audio feedback failed',e);}
}
function play(kind,settings){
 const time=context.currentTime+.005,volume=Math.max(0,Math.min(1,Number(settings.volume)||0));
 const tone=(hz,delay,duration,type='sine',end=hz,level=.09)=>{
  const o=context.createOscillator(),g=context.createGain();o.type=type;
  o.frequency.setValueAtTime(Math.max(1,hz),time+delay);
  o.frequency.exponentialRampToValueAtTime(Math.max(1,end),time+delay+duration);
  g.gain.setValueAtTime(.0001,time+delay);
  g.gain.exponentialRampToValueAtTime(Math.max(.00011,level*volume),time+delay+.008);
  g.gain.exponentialRampToValueAtTime(.0001,time+delay+duration);
  o.connect(g);g.connect(context.destination);o.start(time+delay);o.stop(time+delay+duration+.015);
 };
 switch(kind){
 case 'dismiss':tone(390,0,.065,'sine',260,.035);break;
 case 'select':tone(630,0,.06,'sine',530,.045);break;
 case 'airport':tone(660,0,.10);tone(880,.12,.16);break;
 case 'cash':[880,1320,1760].forEach((f,i)=>tone(f,i*.065,.14));break;
 case 'message':tone(740,0,.11);tone(990,.12,.19);break;
 case 'siren':tone(440,0,.32,'sine',880);tone(880,.32,.32,'sine',440);break;
 case 'engine':tone(65,0,.38,'sawtooth',155,.045);break;
 case 'stamp':tone(170,0,.13,'triangle',45);break;
 case 'crime':tone(180,0,.18,'triangle',60);break;
 case 'day':tone(330,0,.19);tone(440,.16,.22);break;
 case 'error':tone(180,0,.17,'triangle',110);break;
 case 'success':tone(520,0,.09);tone(780,.09,.15);break;
 default:tone(490,0,.045,'sine',360,.045);
 }
}

// iOS Safari may suspend the AudioContext when switching apps or answering calls.
// Recovery is attempted on foreground and on the next trusted user gesture.
function recoverGlobalAudio(){if(document.hidden)return;const now=Date.now();if(now-lastRecoveryAt<350)return;lastRecoveryAt=now;unlockAudio().then(ok=>{if(!ok&&desiredScene)setTimeout(()=>{if(!document.hidden)unlockAudio(true);},750);}).catch(()=>{});}
document.addEventListener('visibilitychange',()=>{if(document.hidden)stopScene();else recoverGlobalAudio();});
window.addEventListener('pageshow',recoverGlobalAudio);
window.addEventListener('pagehide',stopScene);
window.addEventListener('focus',recoverGlobalAudio);
for(const type of ['pointerdown','touchstart','keydown'])document.addEventListener(type,recoverGlobalAudio,{capture:true,passive:true});

// Detect a WebKit context whose state is "running" but clock has stopped.
// Check only in the foreground, with bounded retries to avoid repeated resets.
setInterval(()=>{
 if(document.hidden||!context||context.state!=='running'){audioClockChecked=0;return;}
 const now=Date.now(),clock=context.currentTime;
 if(!audioClockChecked){audioClockChecked=now;audioClockValue=clock;return;}
 if(clock>audioClockValue+.02){audioClockValue=clock;audioClockChecked=now;audioClockRetries=0;return;}
 if(now-audioClockChecked>6500&&audioClockRetries<2){
  audioClockChecked=now;audioClockRetries++;unlockAudio(true).catch(()=>{});
 }
},3000);
