// Fasa 6A A5: Global airport actions commit through the canonical travel owner.
// Universal-airport functions remain pure calculators, not a second state machine.
import {bindGlobalJourney,syncGlobalFlightToTravel,completeUnifiedFlightLanding} from './airport-merge-phase4.js';
import {expireMissedGlobalFlight} from './airport-merge-phase5.js';
import {getUniversalAirportView,performUniversalDepartureStep,performUniversalArrivalStep,startUniversalFlight,advanceUniversalFlight} from './universal-airport.js';
import {checkoutGlobalFlight} from './global-flight-checkout.js';
import {createGlobalJourneyState} from './global-journey-booking.js';

export function canonicalGlobalView(s){
 bindGlobalJourney(s);
 return getUniversalAirportView(s.travel.globalJourneyData);
}
export function canonicalGlobalAirportAction(s,action,{step,day}={}){
 bindGlobalJourney(s);
 const t=s.travel,journey=t.globalJourneyData;
 if(!journey?.activeJourney)throw Error('Tiada perjalanan aktif');
 if(t.activeTrip?.source!=='global-flight')throw Error('Perjalanan aktif tidak sepadan dengan tiket Global');
 const view=getUniversalAirportView(journey);
 if(t.activeTrip.id!==view.bookingId)throw Error('ID tiket tidak sepadan');
 let next;
 if(action==='ENTER'){
  if(day!==view.departureDay||view.status!=='BOOKED'||!['BOOKED','TRANSIT'].includes(journey.activeJourney.status))throw Error('Airport hanya boleh dimasuki pada hari penerbangan');
  next=structuredClone(journey);
  const j=next.activeJourney,seg=j.segments.at(-1);
  seg.airport ||= {legIndex:view.legIndex,status:'BOOKED',departureCompleted:[],arrivalCompleted:[],flightPhase:null};
  seg.airport.status='AT_AIRPORT';seg.status='AT_AIRPORT';j.status='AT_AIRPORT';
 }else if(action==='DEPARTURE')next=performUniversalDepartureStep(journey,step,{day});
 else if(action==='ARRIVAL')next=performUniversalArrivalStep(journey,step);
 else if(action==='START')next=startUniversalFlight(journey,{day});
 else if(action==='ADVANCE')next=advanceUniversalFlight(journey);
 else throw Error('Tindakan airport tidak dikenali');
 t.globalJourneyData=next;
 syncGlobalFlightToTravel(s);
 return true;
}
export function canonicalGlobalCheckout(s,plan,{accountId,bookingId,paymentId}={}){
 bindGlobalJourney(s);
 // Atomic checkout calculates on a copy; commit only after finance + itinerary succeed.
 const candidate=checkoutGlobalFlight(s,plan,{accountId,bookingId,paymentId});
 const nextJourney=createGlobalJourneyState(candidate.travel?.globalJourneyData||candidate.globalJourney);
 s.accounts=candidate.accounts;s.ledger=candidate.ledger;s.sequence=candidate.sequence;
 s.globalTravelPayments=candidate.globalTravelPayments;
 s.travel.globalJourneyData=nextJourney;
 syncGlobalFlightToTravel(s);
 if(s.travel.activeTrip?.id!==bookingId)throw Error('Tempahan tidak berjaya disatukan');
 return true;
}

// All Global no-show and landing actions use the same travel commit boundary.
export function canonicalGlobalNoShow(s){
 bindGlobalJourney(s);
 const changed=expireMissedGlobalFlight(s);
 if(changed)syncGlobalFlightToTravel(s);
 return changed;
}
export function canonicalGlobalLanding(s){
 bindGlobalJourney(s);
 return completeUnifiedFlightLanding(s,{kind:'global',advanceGlobal:advanceUniversalFlight});
}
