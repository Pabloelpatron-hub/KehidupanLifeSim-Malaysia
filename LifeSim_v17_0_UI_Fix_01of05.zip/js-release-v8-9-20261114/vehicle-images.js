import {VEHICLE_GALLERY} from './vehicle-gallery-registry.js';
// Objective 12: local photo registry. All 30 uploaded photos assigned to distinct IDs.
export const PHOTO_PATHS = Object.freeze({
  'cp1-001': 'assets/vehicles/cars/cp1-001.webp',
  'cp1-002': 'assets/vehicles/cars/cp1-002.webp',
  'cp1-003': 'assets/vehicles/cars/cp1-003.webp',
  'cp1-005': 'assets/vehicles/cars/cp1-005.webp',
  'cp1-006': 'assets/vehicles/cars/cp1-006.webp',
  'cp1-007': 'assets/vehicles/cars/cp1-007.webp',
  'cp1-013': 'assets/vehicles/cars/cp1-013.webp',
  'cp1-014': 'assets/vehicles/cars/cp1-014.webp',
  'cp1-015': 'assets/vehicles/cars/cp1-015.webp',
  'cp1-017': 'assets/vehicles/cars/cp1-017.webp',
  'cp1-016': 'assets/vehicles/cars/cp1-016.webp',
  'cp1-020': 'assets/vehicles/cars/cp1-020.webp',
  'cp1-019': 'assets/vehicles/cars/cp1-019.webp',
  'cp1-023': 'assets/vehicles/cars/cp1-023.webp',
  'cp1-057': 'assets/vehicles/cars/cp1-057.webp',
  'cp1-059': 'assets/vehicles/cars/cp1-059.webp',
  'cp1-058': 'assets/vehicles/cars/cp1-058.webp',
  'cp1-060': 'assets/vehicles/cars/cp1-060.webp',
  'cp1-079': 'assets/vehicles/cars/cp1-079.webp',
  'cp1-080': 'assets/vehicles/cars/cp1-080.webp',
  'cp1-081': 'assets/vehicles/cars/cp1-081.webp',
  'cp1-082': 'assets/vehicles/cars/cp1-082.webp',
  'cp1-086': 'assets/vehicles/cars/cp1-086.webp',
  'cp1-087': 'assets/vehicles/cars/cp1-087.webp',
  'cp1-146': 'assets/vehicles/cars/cp1-146.webp',
  'cp1-088': 'assets/vehicles/cars/cp1-088.webp',
  'cp1-089': 'assets/vehicles/cars/cp1-089.webp',
  'cp1-091': 'assets/vehicles/cars/cp1-091.webp',
  'cp1-093': 'assets/vehicles/cars/cp1-093.webp',
  'cp1-094': 'assets/vehicles/cars/cp1-094.webp',
});
export function vehicleImagePath(vehicleId){
  if(typeof vehicleId!=='string')return null;
  return VEHICLE_GALLERY[vehicleId]?.front||PHOTO_PATHS[vehicleId]||null;
}
export function vehicleImageMarkup(vehicleId,alt,placeholderMarkup){
  const path=vehicleImagePath(vehicleId);
  if(!path)return placeholderMarkup;
  const safeAlt=String(alt||'Kenderaan').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  return `<div class="vehicle-photo-frame vehicle-gallery-trigger" data-car-gallery="${vehicleId}" role="button" tabindex="0" title="Lihat galeri gambar"><img src="${path}" alt="${safeAlt}" loading="lazy" decoding="async" onerror="this.hidden=true;this.parentElement.classList.add('vehicle-photo-error')"><span class="vehicle-photo-fallback">Foto belum tersedia</span></div>`;
}
export function catalogVehicleId(owned,catalog){
  const direct=[owned?.vehicleId,owned?.catalogId,owned?.modelId,owned?.sourceVehicleId,owned?.id];
  for(const id of direct)if(catalog.some(v=>v.id===id))return id;
  const name=String(owned?.name||'').trim().toLowerCase(),year=Number(owned?.year);
  if(!name)return null;
  const matches=catalog.filter(v=>v.name.toLowerCase()===name&&Number(v.year)===year);
  return matches.length===1?matches[0].id:null;
}

// Gallery UI: isolated from gameplay state; no writes to save or accounts.
let activeCar=null,activeIndex=0;
const order=['front','side','rear','interior'];
const labels={front:'Front View',side:'Side View',rear:'Rear View',interior:'Interior View'};
function galleryItems(id){const entry=VEHICLE_GALLERY[id]||{};return order.filter(k=>entry[k]).map(k=>({key:k,path:entry[k]}));}
function galleryEsc(s){return String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function paintGallery(){const el=document.getElementById('car-gallery-overlay');if(!el||!activeCar)return;const items=galleryItems(activeCar),item=items[activeIndex];if(!item)return;
 const carName=el.dataset.carName||'Kereta';el.querySelector('[data-gallery-photo]').src=item.path;el.querySelector('[data-gallery-photo]').alt=carName+' — '+labels[item.key];el.querySelector('[data-gallery-count]').textContent=labels[item.key]+' · '+(activeIndex+1)+'/'+items.length;el.querySelector('[data-gallery-prev]').hidden=items.length<2;el.querySelector('[data-gallery-next]').hidden=items.length<2;}
function openGallery(id,name){if(!galleryItems(id).length)return;closeGallery();activeCar=id;activeIndex=0;const el=document.createElement('div');el.id='car-gallery-overlay';el.dataset.carName=name||'Kereta';el.className='car-gallery-overlay';el.setAttribute('role','dialog');el.setAttribute('aria-modal','true');el.setAttribute('aria-label','Galeri '+(name||'kereta'));
 el.innerHTML=`<div class="car-gallery-panel"><div class="car-gallery-head"><strong>${galleryEsc(name||'Galeri kereta')}</strong><button type="button" data-gallery-close aria-label="Tutup galeri">✕</button></div><div class="car-gallery-stage"><button type="button" data-gallery-prev aria-label="Gambar sebelumnya">‹</button><img data-gallery-photo draggable="false" alt=""><button type="button" data-gallery-next aria-label="Gambar seterusnya">›</button></div><div class="car-gallery-counter" data-gallery-count></div><p class="car-gallery-hint">Swipe kiri atau kanan untuk lihat sudut lain.</p></div>`;
 document.body.appendChild(el);paintGallery();}
function closeGallery(){document.getElementById('car-gallery-overlay')?.remove();activeCar=null;}
function shiftGallery(delta){const items=galleryItems(activeCar);if(!items.length)return;activeIndex=(activeIndex+delta+items.length)%items.length;paintGallery();}
if(typeof document!=='undefined'){
 document.addEventListener('click',e=>{const overlay=document.getElementById('car-gallery-overlay');if(overlay){if(e.target===overlay||e.target.closest('[data-gallery-close]')){e.preventDefault();e.stopPropagation();closeGallery();return;}if(e.target.closest('[data-gallery-prev]')){e.preventDefault();e.stopPropagation();shiftGallery(-1);return;}if(e.target.closest('[data-gallery-next]')){e.preventDefault();e.stopPropagation();shiftGallery(1);return;}}
 const trigger=e.target.closest('[data-car-gallery]');if(trigger){e.preventDefault();e.stopPropagation();openGallery(trigger.dataset.carGallery,trigger.dataset.carName||trigger.querySelector('img')?.alt||'Kereta');}},true);
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&activeCar){closeGallery();return;}if(activeCar&&e.key==='ArrowLeft')shiftGallery(-1);if(activeCar&&e.key==='ArrowRight')shiftGallery(1);const t=e.target.closest?.('[data-car-gallery]');if(t&&(e.key==='Enter'||e.key===' ')){e.preventDefault();openGallery(t.dataset.carGallery,t.dataset.carName||'Kereta');}});
 let startX=0;document.addEventListener('touchstart',e=>{if(activeCar&&e.target.closest('#car-gallery-overlay'))startX=e.changedTouches[0].screenX;},{passive:true});document.addEventListener('touchend',e=>{if(activeCar&&e.target.closest('#car-gallery-overlay')){const d=e.changedTouches[0].screenX-startX;if(Math.abs(d)>45)shiftGallery(d<0?1:-1);}},{passive:true});
}
