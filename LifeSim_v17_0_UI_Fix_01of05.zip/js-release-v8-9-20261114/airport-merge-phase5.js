// Phase 5: idempotent no-show lifecycle and transaction consistency checks.
// Legacy s.travel tickets are preserved; only global-flight bookings are handled here.
const terminal=new Set(['AT_DESTINATION','COMPLETED','NO_SHOW','MISSED','CANCELLED']);
export function phase5FlightDeadline(state){
 const j=state?.globalJourney?.activeJourney,seg=j?.segments?.at(-1);
 if(!j||!seg||terminal.has(j.status))return null;
 const a=seg.airport||{},idx=a.legIndex||0,leg=seg.legs?.[idx];
 if(!leg||['IN_FLIGHT','ARRIVAL','READY_TO_FLY','AT_AIRPORT'].includes(a.status))return null;
 if(!['BOOKED','TRANSIT'].includes(j.status)&&!['BOOKED','TRANSIT'].includes(seg.status))return null;
 return {journey:j,segment:seg,leg,index:idx};
}
export function expireMissedGlobalFlight(state){
 const item=phase5FlightDeadline(state);if(!item)return false;
 const {journey:j,segment:seg,leg,index}=item;
 if(state.day<leg.departureDay)return false;
 if(state.day===leg.departureDay && Number(state.hour||0)*60<=leg.departureMinute)return false;
 const key=seg.id+':leg:'+index+':no-show';
 state.travel ||= {};state.travel.airportMergePhase5 ||= {events:[]};
 const events=state.travel.airportMergePhase5.events;
 if(events.includes(key))return false;
 events.push(key);
 seg.airport ||= {legIndex:index,departureCompleted:[],arrivalCompleted:[]};
 seg.airport.status='NO_SHOW';seg.status='NO_SHOW';j.status='NO_SHOW';
 seg.missedFlight={legIndex:index,from:leg.from,to:leg.to,departureDay:leg.departureDay,departureMinute:leg.departureMinute,recordedDay:state.day,reason:index?'MISSED_CONNECTION':'MISSED_DEPARTURE',refundSen:0};
 for(let i=index+1;i<seg.legs.length;i++){
  seg.legs[i].status='CLOSED_NO_SHOW';
 }
 state.travel.airportMergePhase5.lastNoShow={key,bookingId:seg.id,...seg.missedFlight};
 const trip=state.travel.activeTrip;
 if(trip?.source==='global-flight'&&(trip.id===seg.id||trip.id===j.id)){
  trip.globalStatus='NO_SHOW';trip.status='NO_SHOW';
  if(Array.isArray(trip.segments))for(let i=index;i<trip.segments.length;i++)trip.segments[i].status=i===index?'NO_SHOW':'CLOSED_NO_SHOW';
 }
 return true;
}
export function phase5PaymentIntegrity(state,bookingId,paymentId){
 if(!bookingId||!paymentId)throw Error('ID pembayaran tidak sah');
 if(state.globalJourney?.bookingIds?.includes(bookingId)||state.globalJourney?.paymentIds?.includes(paymentId))throw Error('Tempahan atau pembayaran telah diproses');
 const payments=state.globalTravelPayments||[];
 if(payments.some(p=>p.id===paymentId||p.bookingId===bookingId))throw Error('Tempahan atau pembayaran sudah wujud');
 if(state.documents?.some(d=>d.bookingId===bookingId))throw Error('E-tiket sudah wujud');
 const j=state.globalJourney?.activeJourney;
 if(j?.segments?.some(seg=>seg.id===bookingId)||state.travel?.activeTrip?.id===bookingId)throw Error('Tiket sudah ditempah');
 return true;
}
