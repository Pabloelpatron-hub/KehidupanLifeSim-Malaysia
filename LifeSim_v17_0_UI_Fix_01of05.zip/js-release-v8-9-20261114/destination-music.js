// 30 licensed local MP3 tracks; one persistent HTMLMediaElement (no generated oscillator music).
// iOS can interrupt audio during calls/background. Resume is best effort and never bypasses Safari policies.
const tracks={"SIN":{"asset":"assets/audio/destinations/singapore.mp3","title":"Airport Lounge","creator":"Kevin MacLeod"},"BKK":{"asset":"assets/audio/destinations/bangkok.mp3","title":"Dream Culture","creator":"Kevin MacLeod"},"CGK":{"asset":"assets/audio/destinations/jakarta.mp3","title":"Mystic Force","creator":"Kevin MacLeod"},"MNL":{"asset":"assets/audio/destinations/manila.mp3","title":"Carefree","creator":"Kevin MacLeod"},"SGN":{"asset":"assets/audio/destinations/ho-chi-minh-city.mp3","title":"Easy Lemon","creator":"Kevin MacLeod"},"PNH":{"asset":"assets/audio/destinations/phnom-penh.mp3","title":"Nightdreams","creator":"Kevin MacLeod"},"VTE":{"asset":"assets/audio/destinations/vientiane.mp3","title":"Healing","creator":"Kevin MacLeod"},"RGN":{"asset":"assets/audio/destinations/yangon.mp3","title":"Enchanted Journey","creator":"Kevin MacLeod"},"BWN":{"asset":"assets/audio/destinations/bandar-seri-begawan.mp3","title":"Water Lily","creator":"Kevin MacLeod"},"ICN":{"asset":"assets/audio/destinations/seoul.mp3","title":"Reawakening","creator":"Kevin MacLeod"},"NRT":{"asset":"assets/audio/destinations/tokyo.mp3","title":"Ishikari Lore","creator":"Kevin MacLeod"},"PEK":{"asset":"assets/audio/destinations/beijing.mp3","title":"Shenyang","creator":"Kevin MacLeod"},"TPE":{"asset":"assets/audio/destinations/taipei.mp3","title":"Cattails","creator":"Kevin MacLeod"},"HKG":{"asset":"assets/audio/destinations/hong-kong.mp3","title":"Night on the Docks - Sax","creator":"Kevin MacLeod"},"DEL":{"asset":"assets/audio/destinations/new-delhi.mp3","title":"Jalandhar","creator":"Kevin MacLeod"},"DAC":{"asset":"assets/audio/destinations/dhaka.mp3","title":"Dhaka","creator":"Kevin MacLeod"},"CMB":{"asset":"assets/audio/destinations/colombo.mp3","title":"Vadodora Chill Mix","creator":"Kevin MacLeod"},"KTM":{"asset":"assets/audio/destinations/kathmandu.mp3","title":"That Zen Moment","creator":"Kevin MacLeod"},"MLE":{"asset":"assets/audio/destinations/male.mp3","title":"Bossa Antigua","creator":"Kevin MacLeod"},"DXB":{"asset":"assets/audio/destinations/dubai.mp3","title":"Ibn Al-Noor","creator":"Kevin MacLeod"},"DOH":{"asset":"assets/audio/destinations/doha.mp3","title":"Desert City","creator":"Kevin MacLeod"},"JED":{"asset":"assets/audio/destinations/jeddah.mp3","title":"Tabuk","creator":"Kevin MacLeod"},"IST":{"asset":"assets/audio/destinations/istanbul.mp3","title":"Mystery Bazaar","creator":"Kevin MacLeod"},"LHR":{"asset":"assets/audio/destinations/london.mp3","title":"Almost New","creator":"Kevin MacLeod"},"CDG":{"asset":"assets/audio/destinations/paris.mp3","title":"Duet Musette","creator":"Kevin MacLeod"},"FRA":{"asset":"assets/audio/destinations/frankfurt.mp3","title":"Prelude in C (BWV 846)","creator":"Kevin MacLeod"},"AMS":{"asset":"assets/audio/destinations/amsterdam.mp3","title":"Backbay Lounge","creator":"Kevin MacLeod"},"JFK":{"asset":"assets/audio/destinations/new-york.mp3","title":"Night in Venice","creator":"Kevin MacLeod"},"SYD":{"asset":"assets/audio/destinations/sydney.mp3","title":"Clear Air","creator":"Kevin MacLeod"},"AKL":{"asset":"assets/audio/destinations/auckland.mp3","title":"Windswept","creator":"Kevin MacLeod"}};
// One HTMLMediaElement, one active visit. Background pauses freeze playback position.
const audio=new Audio();audio.preload='auto';audio.loop=true;audio.playsInline=true;
let activeCode=null,enabled=true,volume=.32,pendingResume=false,lastAttempt=0;
let suspendedByPage=false, resumePosition=0, playbackToken=0, recoveryInFlight=false;
let lastProgressAt=0,lastProgressPosition=0,lastRecoveryAt=0;
function applyVolume(){audio.volume=Math.max(0,Math.min(1,volume));}
function position(){return Number.isFinite(audio.currentTime)?Math.max(0,audio.currentTime):resumePosition;}
function rememberPosition(){if(activeCode)resumePosition=position();}
function seekPosition(value){
 if(!Number.isFinite(value)||value<=0)return;
 try{if(Number.isFinite(audio.duration)&&audio.duration>0)audio.currentTime=Math.min(value,Math.max(0,audio.duration-.05));else audio.currentTime=value;}catch(_){}
}
function loadTrack(code){
 playbackToken++;audio.pause();audio.removeAttribute('src');audio.load();
 activeCode=code;resumePosition=0;lastProgressPosition=0;lastProgressAt=Date.now();
 suspendedByPage=false;pendingResume=true;lastAttempt=0;
 audio.src=new URL(tracks[code].asset,document.baseURI).href;
 audio.load();
}
function start(force=false){
 if(!activeCode||!enabled||volume<=0||document.hidden)return;
 if(recoveryInFlight)return;
 const now=Date.now();if(now-lastAttempt<(force?200:450))return;
 if(!audio.paused&&!pendingResume&&!force)return;
 lastAttempt=now;
 const token=playbackToken;
 if(suspendedByPage){seekPosition(resumePosition);suspendedByPage=false;}
 let result;
 try{result=audio.play();}catch(_){pendingResume=true;return;}
 if(result?.then){result.then(()=>{if(token===playbackToken){pendingResume=false;lastProgressAt=Date.now();lastProgressPosition=position();}}).catch(()=>{if(token===playbackToken)pendingResume=true;});}
}
export function playDestinationMusic(code,opts={}){
 if(!tracks[code]||opts.enabled===false){stopDestinationMusic();return;}
 enabled=true;volume=Math.max(0,Math.min(1,Number(opts.volume??.32)||0));applyVolume();
 if(activeCode!==code)loadTrack(code);
 if(!document.hidden&&volume>0)start();
 else if(volume<=0){rememberPosition();audio.pause();}
}
export function stopDestinationMusic(){
 playbackToken++;audio.pause();activeCode=null;pendingResume=false;suspendedByPage=false;
 resumePosition=0;lastProgressPosition=0;audio.removeAttribute('src');audio.load();
}
export function suspendDestinationMusic(){
 if(!activeCode)return;
 rememberPosition();suspendedByPage=true;audio.pause();pendingResume=true;
}
export function setDestinationMusicVolume(v){
 volume=Math.max(0,Math.min(1,Number(v)||0));applyVolume();
 if(volume<=0){rememberPosition();audio.pause();}else if(activeCode&&!document.hidden)start();
}
export function resumeDestinationMusic(){
 if(!activeCode||!enabled||document.hidden||volume<=0)return;
 if(suspendedByPage)seekPosition(resumePosition);
 start();
}
export function destinationMusicStatus(){return {code:activeCode,playing:!!activeCode&&!audio.paused&&!document.hidden,blocked:pendingResume,position:position()};}
export const destinationMusicCount=Object.keys(tracks).length;
// Safari can report paused=false while its media clock has stopped. Detect this
// conservatively; avoid restarts during buffering, loading and a normal loop.
function checkStalled(){
 if(!activeCode||!enabled||volume<=0||document.hidden||suspendedByPage||audio.paused)return;
 const now=Date.now(),current=position();
 if(Math.abs(current-lastProgressPosition)>.12||current<lastProgressPosition-.5){lastProgressPosition=current;lastProgressAt=now;return;}
 if(audio.readyState<2||audio.seeking||now-lastProgressAt<9000||now-lastRecoveryAt<10000)return;
 lastRecoveryAt=now;recoverStalled();
}
async function recoverStalled(){
 if(recoveryInFlight||!activeCode||document.hidden)return;
 recoveryInFlight=true;const token=playbackToken,code=activeCode,saved=position();
 try{
  audio.pause();pendingResume=true;
  // Recreate media pipeline only after confirmed stall, without changing visit.
  audio.load();
  await new Promise(resolve=>{if(audio.readyState>=1)return resolve();const finish=()=>{audio.removeEventListener('loadedmetadata',finish);resolve();};audio.addEventListener('loadedmetadata',finish,{once:true});setTimeout(finish,1200);});
  if(token!==playbackToken||code!==activeCode||document.hidden)return;
  seekPosition(saved);resumePosition=saved;
 }finally{recoveryInFlight=false;lastProgressAt=Date.now();lastProgressPosition=position();if(token===playbackToken&&!document.hidden)start(true);}
}
const stallTimer=setInterval(checkStalled,3000);
audio.addEventListener('timeupdate',()=>{if(!document.hidden){lastProgressPosition=position();lastProgressAt=Date.now();resumePosition=position();}});
audio.addEventListener('playing',()=>{pendingResume=false;lastProgressAt=Date.now();lastProgressPosition=position();});
audio.addEventListener('ended',()=>{if(activeCode&&!document.hidden&&enabled)start(true);});
audio.addEventListener('error',()=>{if(activeCode){pendingResume=true;console.warn('Destination MP3 error',activeCode,audio.error?.code);}});
document.addEventListener('visibilitychange',()=>{if(document.hidden)suspendDestinationMusic();else resumeDestinationMusic();});
window.addEventListener('pagehide',suspendDestinationMusic);
window.addEventListener('pageshow',resumeDestinationMusic);
window.addEventListener('focus',resumeDestinationMusic);
for(const type of ['pointerdown','touchstart','keydown'])document.addEventListener(type,resumeDestinationMusic,{capture:true,passive:true});
