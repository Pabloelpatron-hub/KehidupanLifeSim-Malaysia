// Airport Merge Phase 5: legacy KUL–ICN no-show is irreversible.
// Preserve paid tickets and history; do not debit, refund or reschedule.
export function expireMissedLegacyFlight(s){
 const t=s?.travel, trip=t?.activeTrip;
 if(!t||!trip||trip.source==='global-flight'||!Number.isInteger(s.day))return false;
 let changed=false;
 t.processedEvents=Array.isArray(t.processedEvents)?t.processedEvents:[];
 function expire(ticket,kind){
  if(!ticket||!Number.isInteger(ticket.departureDay)||s.day<=ticket.departureDay||ticket.flightPhase||ticket.status==='NO_SHOW')return false;
  const key='legacy-no-show:'+String(ticket.id||trip.id||kind)+':'+kind+':'+ticket.departureDay;
  if(t.processedEvents.includes(key))return false;
  ticket.status='NO_SHOW';ticket.noShowDay=s.day;ticket.noShowReason='MISSED_DEPARTURE';ticket.refundSen=0;
  t.processedEvents.push(key);
  t.noShowHistory=Array.isArray(t.noShowHistory)?t.noShowHistory:[];
  if(!t.noShowHistory.some(x=>x.eventKey===key))t.noShowHistory.push({eventKey:key,ticketId:ticket.id||trip.id,kind,departureDay:ticket.departureDay,detectedDay:s.day,refundSen:0});
  return true;
 }
 if(['BOOKED','AT_AIRPORT'].includes(t.status)&&expire(trip,'outbound')){
  t.trips ||= [];if(!t.trips.some(x=>x.id===trip.id))t.trips.push({...trip,closedDay:s.day});
  t.activeTrip=null;t.returnJourney=false;t.status='AT_HOME';t.location={country:'MY',cityId:s.character?.city??t.location?.cityId??null,district:null,venue:null};changed=true;
 }
 if(['ABROAD','RETURNING'].includes(t.status)&&expire(trip.returnFlight,'return')){
  t.status='ABROAD';t.returnJourney=false;changed=true;
 }
 return changed;
}
