// Fasa 6A: one persisted owner for the Global itinerary.
// The historical globalJourney property is a non-persisted compatibility view.
// Older JSON saves are migrated without deleting the original itinerary until accepted.
export function bindGlobalJourney(state){
 if(!state||typeof state!=='object')throw Error('State perjalanan tidak sah');
 state.travel ||= {};
 const descriptor=Object.getOwnPropertyDescriptor(state,'globalJourney');
 if(descriptor?.get&&descriptor?.set)return state.travel.globalJourneyData;
 const old=state.globalJourney;
 if(old&&typeof old==='object'){
  if(!state.travel.globalJourneyData)state.travel.globalJourneyData=old;
  else if(JSON.stringify(old)!==JSON.stringify(state.travel.globalJourneyData)){
   state.travel.airportMergePhase1 ||= {version:1,conflicts:[],stagedGlobalTrip:null};
   const conflicts=state.travel.airportMergePhase1.conflicts ||= [];
   if(!conflicts.some(x=>x.code==='GLOBAL_SAVE_DIVERGENCE')){state.travel.globalJourneyLegacyBackup=structuredClone(old);conflicts.push({code:'GLOBAL_SAVE_DIVERGENCE',resolution:'CANONICAL_PRESERVED',backup:'travel.globalJourneyLegacyBackup'});}
  }
 }
 Object.defineProperty(state,'globalJourney',{configurable:true,enumerable:false,
  get(){return this.travel?.globalJourneyData;},
  set(value){this.travel ||= {};this.travel.globalJourneyData=value;}
 });
 return state.travel.globalJourneyData;
}
export function globalJourneyFromTravel(state){bindGlobalJourney(state);return state.travel.globalJourneyData;}
