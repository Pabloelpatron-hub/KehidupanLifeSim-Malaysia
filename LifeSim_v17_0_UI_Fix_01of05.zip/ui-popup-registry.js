/* P5: presentation metadata only; never alters gameplay actions, rewards, or logos. */
(()=>{'use strict';
const modal=document.getElementById('modal');if(!modal)return;
const protectedClasses=['luxury-restaurant-modal','character-modal','michelin-modal'];
const profiles=[
 {id:'pdrm',pattern:/\b(PDRM|polis|reman|tangkapan|balai|IPD|IPK)\b/i,tier:2},
 {id:'institution',pattern:/\b(JPJ|CIDB|LHDN|KWSP|PERKESO|mahkamah|kastam|imigresen)\b/i,tier:2},
 {id:'prestige',pattern:/\b(Michelin|anugerah prestij)\b/i,tier:5},
 {id:'milestone',pattern:/\b(kenaikan pangkat|pencapaian|anugerah)\b/i,tier:3},
 {id:'crisis',pattern:/\b(kecemasan|krisis|serbuan)\b/i,tier:4}
];
function classify(){
 if(!modal.open)return;
 const title=modal.querySelector('h2')?.textContent||'';
 const profile=profiles.find(p=>p.pattern.test(title))||{id:'standard',tier:1};
 modal.dataset.uiPopupProfile=profile.id;
 modal.dataset.uiPopupTier=String(profile.tier);
 const protectedEvent=protectedClasses.some(c=>modal.classList.contains(c))||/michelin/i.test(title);
 modal.classList.toggle('ui-popup-standard-motion',!protectedEvent);
 // Preserve every existing image, portrait, SVG, logo, and event handler.
}
new MutationObserver(classify).observe(modal,{attributes:true,attributeFilter:['open','class'],childList:true});
})();
