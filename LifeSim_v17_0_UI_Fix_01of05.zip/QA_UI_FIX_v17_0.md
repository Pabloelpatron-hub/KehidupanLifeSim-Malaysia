# Kehidupan — UI Fix v17.0

## Perubahan

- CSS base game: butang fleksibel sebaris di sebelah kanan apabila ruang cukup, balut ke baris baharu apabila sempit; padding, jarak teks/tajuk/butang, serta pembalutan perkataan panjang.
- Logo institusi: buang plat cerah CSS yang membentuk kotak di belakang PDRM; kekalkan aset logo asal dan nisbahnya. Saiz logo Group dan logo bank dikawal.
- Gambar pemain dan logo Group baharu: muat keseluruhan gambar secara berkadar, bukan potong tengah. Ruang kosong dan piksel lutsinar diratakan kepada hitam. Paparan gambar menggunakan contain dengan latar hitam.
- Gambar dalam save lama yang sudah dipotong tidak boleh dipulihkan daripada piksel yang dibuang. Upload semula gambar asal untuk mendapat framing penuh.
- Senarai panjang: tambah sokongan tajuk kecil h4, cardhead, jadual berbungkus, kad jurnal dan projek dalam details. Senarai sekurang-kurangnya enam rekod menjadi panel skrol dengan had tinggi, fokus papan kekunci dan label aksesibiliti. Borang dan tajuk kekal di luar panel. Had rekod terkini asal tidak diubah; tiada data sejarah dipadam.
- Hari +1 pada navigasi mudah alih menghantar tindakan next secara terus, tanpa bergantung pada butang tajuk halaman lain.
- Transaksi: kegagalan paparan selepas autosave berjaya tidak lagi mengembalikan state dalam memori kepada hari sebelumnya. Kegagalan sebelum penyimpanan tetap rollback. Mesej membezakan tindakan yang sudah disimpan daripada paparan yang gagal.
- Tiket legacy terlepas: arkib tiket sekali sahaja, kosongkan activeTrip, kekalkan ID bandar 0 yang sah. Sebelum ini state AT_HOME masih mempunyai tiket aktif dan gagal validasi.
- Pemproses no-show legacy tidak lagi menyentuh tiket global; tiket global melalui lifecycle canonical sendiri.

## Perlindungan skop

UI dan aset destinasi, airport dan AEROTRACE tidak diedit. Perubahan perjalanan ialah pembaikan lifecycle tiket di atas, bukan reka bentuk screenpage. Tiada pertukaran harga, inventori, gaji, baki atau kandungan game secara pukal. Semua 1,501 fail baseline dikekalkan; fail ujian tertentu mendapat mock window yang diperlukan oleh kod UI semasa.

## Ujian

- 50 skrip ujian lulus menggunakan Node. Meliputi checkout, debit sekali, akaun pembayaran, perjalanan transit/pulang, ketibaan melintasi tengah malam, no-show, import/export, fallback storan, integrasi destinasi dan ujian sedia ada lain.
- Ujian baharu: tiga laluan KUL–ICN/SIN/LHR, hari dalaman 672 → 673 (paparan Hari 673 → 674), tiket kekal BOOKED, serialize/deserialize, masuk airport pada hari tiket, no-show dan ledger. Tiket legacy diuji pada peralihan hari yang sama.
- Ujian transaksi memasukkan kegagalan paparan selepas simpan dan kegagalan simpan sebelum commit; kedua-duanya mengekalkan state yang sepatutnya.
- Empat kes pemprosesan gambar diuji: portrait/landscape untuk foto pemain dan logo Group, tanpa pemotongan dan dengan isian latar hitam.
- Audit destinasi sedia ada: 30 destinasi, 240 hotel, 450 aktiviti, 450 pilihan makan, 600 pilihan membeli-belah dan 90 pengangkutan; tiada foto hilang atau ID pendua dalam audit tersebut.
- Semakan sintaks JavaScript dan import relatif dijalankan. Integriti CRC ZIP dan kesetaraan fail FULL/5-part disemak semasa pembungkusan.

## Batas pengesahan

Tiada JSON save pemain disertakan. Masalah tepat hari tersekat dalam save pengguna tidak berjaya dihasilkan semula pada fixture baharu; senario Hari 673 → 674 lulus. Pembetulan yang disertakan menangani pepijat lifecycle, butang dan rollback yang dikenal pasti, tetapi bukan jaminan semua punca dalam save tertentu sudah hilang.

Ujian ini bukan ujian Safari/iPhone sebenar. Chromium automatik gagal dilancarkan akibat sekatan proses/socket; pelayar tersedia tidak dapat membuka server tempatan, dan polisi pelayar menyekat URL fail tempatan. Oleh itu UI responsif dan pemotongan imej tidak disahkan secara visual dalam pelayar. Ujian imej menggunakan mock canvas untuk mengesahkan koordinat/nisbah; ujian media dalam Node menggunakan mock API pelayar dan bukan pengesahan bunyi boleh didengar.

Untuk menghasilkan semula suite: jalankan setiap test*.mjs di akar projek dan js-release-v8-9-20261114 dengan Node dari akar projek, gunakan --import ./qa-browser-shim.mjs dan APP_PATH=js-release-v8-9-20261114/app.js.
