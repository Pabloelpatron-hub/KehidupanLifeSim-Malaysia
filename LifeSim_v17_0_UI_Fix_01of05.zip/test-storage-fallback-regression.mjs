import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const src=fs.readFileSync('./js-release-v8-9-20261114/app.js','utf8');
const declaration=src.match(/let jsonOnlyMode=false,jsonModeNotified=false;/)?.[0];
assert.ok(declaration,'Fallback state must be declared');
const activate=src.match(/function activateJsonMode\(\)\{[\s\S]*?\n\}/)?.[0];
assert.ok(activate,'JSON fallback helper missing');
const persist=src.match(/function persist\(\)\{[\s\S]*?\n\}/)?.[0];
assert.ok(persist,'Persist implementation missing');
function run(quota){
 const store=new Map();let calls=0;const messages=[];
 const context={window:{},s:{day:672},storageRecoveryRequired:false,storageError:false,storageIssue:'',serialize:JSON.stringify,
  localStorage:{setItem(k,v){calls++;if(quota)throw Object.assign(new Error('quota'),{name:'QuotaExceededError'});store.set(k,v)},getItem:k=>store.get(k)},toast:(v)=>messages.push(v)};
 vm.createContext(context);vm.runInContext(declaration+'\n'+activate+'\n'+persist+'\nthis.save=persist;this.state=()=>({jsonOnlyMode,jsonModeNotified,storageError,storageIssue});',context);
 assert.equal(context.save(),true);assert.equal(context.state().jsonOnlyMode,quota);
 assert.equal(context.save(),true);assert.equal(calls,quota?1:2);
 if(quota)assert.equal(messages.length,1);
}
run(false);run(true);
assert.match(src,/Mod JSON aktif:<\/strong> Autosave Safari tidak tersedia/);
console.log('PASS normal storage, quota fallback, single notification, persistent warning');
