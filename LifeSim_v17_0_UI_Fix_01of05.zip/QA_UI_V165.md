# UI v16.5 — transaction safety patch

Baseline: v16.4 core and assets.

The v15.9 generic workspace wrapper could collapse top-level panels with transaction forms. v16.2 subsequently reopened some panels after the fact. v16.5 prevents these critical panels from being folded in the first place. It preserves original headings, DOM and event handlers. This is a targeted conflict fix, **not** a full ScreenPage overhaul or verified Safari release.

Validation: JS syntax and ZIP integrity; no end-to-end Safari/gameplay claims.
