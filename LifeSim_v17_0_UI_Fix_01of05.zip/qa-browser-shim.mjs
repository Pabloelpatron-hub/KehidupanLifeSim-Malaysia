globalThis.Image=class{};
globalThis.Audio=class {addEventListener(){} removeEventListener(){} pause(){} load(){} play(){return Promise.resolve()}};
globalThis.document={hidden:false,addEventListener(){}};
globalThis.window={addEventListener(){}};
const nativeInterval=globalThis.setInterval;
globalThis.setInterval=(...args)=>{const timer=nativeInterval(...args);timer.unref();return timer};
