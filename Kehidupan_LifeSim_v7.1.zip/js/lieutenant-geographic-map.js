import {geography} from './geography.js';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const geoByState=new Map();
for(const f of geography){const state=f.properties?.state;if(!geoByState.has(state))geoByState.set(state,[]);geoByState.get(state).push(f);}
function rings(geometry){if(!geometry)return [];if(geometry.type==='Polygon')return geometry.coordinates||[];if(geometry.type==='MultiPolygon')return (geometry.coordinates||[]).flatMap(poly=>poly);return [];}
function bounds(features){let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;for(const f of features)for(const ring of rings(f.geometry))for(const pt of ring){if(!Number.isFinite(pt[0])||!Number.isFinite(pt[1]))continue;minX=Math.min(minX,pt[0]);maxX=Math.max(maxX,pt[0]);minY=Math.min(minY,pt[1]);maxY=Math.max(maxY,pt[1]);}return {minX,minY,maxX,maxY};}
function pathFor(f,project){return rings(f.geometry).map(ring=>{if(ring.length<3)return '';const stride=Math.max(1,Math.floor(ring.length/240));const pts=ring.filter((_,i)=>i%stride===0||i===ring.length-1);return pts.map((p,i)=>(i?'L':'M')+project(p).join(' ')).join(' ')+' Z';}).join(' ');}
export function lieutenantGeographicMap(state,districts,selected,score,claims){const features=geoByState.get(state)||[];if(!features.length)return '<p class="muted">Sempadan geografi belum tersedia untuk negeri ini. Gunakan senarai daerah di bawah.</p>';
 const b=bounds(features);if(!Number.isFinite(b.minX))return '<p class="muted">Data sempadan negeri tidak lengkap.</p>';
 const W=760,H=490,pad=18,dx=Math.max(.001,b.maxX-b.minX),dy=Math.max(.001,b.maxY-b.minY);const scale=Math.min((W-pad*2)/dx,(H-pad*2)/dy),offsetX=(W-dx*scale)/2,offsetY=(H-dy*scale)/2;
 const project=p=>[(offsetX+(p[0]-b.minX)*scale).toFixed(1),(H-offsetY-(p[1]-b.minY)*scale).toFixed(1)];
 const byName=new Map(districts.map(d=>[d.name.toLowerCase(),d]));
 const kl=state==='W.P. Kuala Lumpur';
 const paths=features.map(f=>{const d=byName.get(String(f.properties.district).toLowerCase());const active=d?.id===selected?.id;const owned=d&&claims[d.id]?.status==='dikuasai';const ratio=d?Math.round(score(d).ratio*100):0;const name=esc(f.properties.district);const shape=pathFor(f,project);return `<path d="${shape}" class="lt-geo-district ${active?'lt-geo-active':''} ${owned?'lt-geo-owned':''}" ${d?`data-action="lt-district" data-id="${esc(d.id)}" role="button" tabindex="0" aria-label="Pilih ${name}, ${ratio}% racket stabil"`:'aria-hidden="true"'}><title>${name}${d?' · '+ratio+'% racket stabil':''}</title></path>`;}).join('');
 return `<div class="lt-geographic-wrap"><svg class="lt-geographic-map" viewBox="0 0 ${W} ${H}" role="group" aria-label="Peta sempadan geografi ${esc(state)}; pilih daerah pada peta" preserveAspectRatio="xMidYMid meet">${paths}</svg><p class="muted">Sempadan geografi daripada dataset permainan. ${kl?'Kuala Lumpur mempunyai satu bentuk geografi asas; 18 zon gameplay tidak mempunyai sempadan rasmi dalam dataset, jadi pilih zon melalui senarai interaktif di bawah.':'Tekan daerah pada peta atau pilih melalui senarai di bawah.'}</p></div>`;
}
