import {lieutenantGeographicMap,lieutenantDistrictAtlas} from './lieutenant-geographic-map.js';
import {quote} from './territory-world.js';
import {spend} from './finance.js';
import {random} from './state.js';
import {btn,esc} from './ui.js';
const money=n=>'RM '+(n/100).toLocaleString('en-MY',{minimumFractionDigits:2,maximumFractionDigits:2});
const clamp=(x,max=100)=>Math.max(0,Math.min(max,x));
const hash=t=>[...t].reduce((a,c)=>(a*31+c.charCodeAt(0))>>>0,7);
// Per-racket project briefs: each port uses its own vocabulary and event context.
const RACKET_BRIEFS=[
 {match:/judi|gambl|casino|bet|slot|bookie/i,tag:'Meja judi',guard:'Jaga pintu dan meja besar',expand:'Tambah meja dan ruang pemain VIP',welfare:'Jaga kepala meja dan orang lama',problem:'Pemain besar mula tarik muka; kepala meja minta keputusan sebelum port jadi kecoh.'},
 {match:/ktv|karaoke|night|club|hiburan|pub|bar/i,tag:'Kelab / KTV',guard:'Jaga pintu dan bilik VIP',expand:'Buka bilik VIP dan tarik regular',welfare:'Jaga promoter dan orang floor',problem:'Promoter besar tarik diri; booking VIP mula lari ke kelab sebelah.'},
 {match:/ah.long|pinjam|loan|hutang|kredit/i,tag:'Buku hutang',guard:'Kuatkan keselamatan pejabat',expand:'Tambah modal pusingan buku hutang',welfare:'Jaga orang yang urus akaun',problem:'Banyak akaun tertunggak serentak; orang kanan minta arahan tentang risiko modal.'},
 {match:/seludup|smug|kontraban|rokok|gudang|warehouse/i,tag:'Gudang / bekalan',guard:'Kuatkan kawalan gudang',expand:'Besarkan ruang simpanan dan bekalan',welfare:'Jaga orang gudang dan penghantar',problem:'Bekalan tersangkut dan ruang simpanan makin sempit; orang gudang tunggu keputusan.'},
 {match:/dadah|drug|narko|syabu|ganja/i,tag:'Rangkaian berisiko tinggi',guard:'Perketat keselamatan premis',expand:'Susun semula kapasiti operasi',welfare:'Redakan ketegangan orang bawahan',problem:'Orang bawahan mula bercakaran dan tekanan siasatan meningkat.'},
 {match:/protect|perlindung|kawasan|extort/i,tag:'Kawasan jagaan',guard:'Kuatkan keselamatan kawasan',expand:'Luaskan liputan perniagaan',welfare:'Jaga hubungan orang lapangan',problem:'Peniaga mula buat aduan dan geng sebelah pertikai pengaruh kawasan.'},
];
export function ltRacketBrief(racket){return RACKET_BRIEFS.find(x=>x.match.test(String(racket||'')))||{tag:'Port tempatan',guard:'Kuatkan orang jaga port',expand:'Besarkan port dan tarik pelanggan',welfare:'Jaga orang kanan',problem:'Orang kanan lapor port mula panas; keputusan boss diperlukan.'};}
export function ltState(s){const l=s.gang.life;l.lt??={projects:[],incidents:[],police:{},lastDay:-1,selectedDistrict:l.lieutenantDistrictId||l.district};if(!l.lt.police||typeof l.lt.police!=='object'||Array.isArray(l.lt.police))l.lt.police={};if(!Array.isArray(l.lt.projects))l.lt.projects=[];if(!Array.isArray(l.lt.incidents))l.lt.incidents=[];if(!l.lt.districtClaims||typeof l.lt.districtClaims!=='object'||Array.isArray(l.lt.districtClaims))l.lt.districtClaims={};l.lt.stateClaim??={status:'belum dicabar',lastAttempt:-999};l.lt.lastPowerTick??=-1;if(!Array.isArray(l.lt.capoCrises))l.lt.capoCrises=[];l.lt.policeTickDay??=-1;return l.lt;}
export function ltZones(s,d){return (Array.isArray(s.gang.territories)?s.gang.territories:[]).filter(z=>z&&z.districtId===d?.id);}
export function ltStable(z){return !!z&&z.status==='Aktif'&&Number(z.control)>=60&&Number(z.security)>=45&&z.policy!=='rehat';}
export function ltDistrictScore(s,d){const zones=ltZones(s,d),mine=zones.filter(z=>z.owner===s.gang.membership&&ltStable(z)).length;return {total:zones.length,mine,ratio:zones.length?mine/zones.length:0,dominant:zones.length>0&&mine/zones.length>=.5&&Number.isFinite(Number(d.stability))&&Number(d.stability)>=55};}
export function ltPower(s,owner,d){const g=(Array.isArray(s.gang.factions)?s.gang.factions:[]).find(f=>f&&f.id===owner);if(!owner||!g||!d)return 0;const zones=ltZones(s,d).filter(z=>z.owner===owner),active=(Array.isArray(g.people)?g.people:[]).filter(p=>p.status==='Aktif');const balance=Number(s.accounts?.[owner]?.balance);const funds=Number.isFinite(balance)?Math.max(0,balance):0;const safe=(v,defaultValue=0)=>{const n=Number(v);return Number.isFinite(n)?Math.max(0,n):defaultValue;};const troop=Math.min(250,active.length*8),cash=Math.min(200,funds/150000),territory=Math.min(200,zones.reduce((v,z)=>v+safe(z.control)*.5+safe(z.security)*.25,0)),loyalty=active.length?active.reduce((v,p)=>v+safe(p.loyalty,50),0)/active.length:0,discipline=Math.min(150,loyalty*1.5),experience=Math.min(100,safe(g.might)*1.2),stability=Math.min(100,safe(d.stability));return clamp(Math.round(troop+cash+territory+discipline+experience+stability),1000);}
// Live district intelligence uses the same strength calculation as dominance challenges.
// No extra saved score: a rival's losses and recovery are reflected immediately.
// Actionable, read-only district progress: a racket only counts when fully stable.
export function ltDistrictProgress(s,d){
 if(!d)return {total:0,required:0,stable:0,owned:0,unstableOwned:0,remaining:0,stability:0,ready:false};
 const zones=ltZones(s,d),owned=zones.filter(z=>z.owner===s.gang.membership),stable=owned.filter(ltStable).length;
 const required=Math.ceil(zones.length/2),stability=Number(d.stability)||0;
 return {total:zones.length,required,stable,owned:owned.length,unstableOwned:owned.length-stable,remaining:Math.max(0,required-stable),stability,ready:zones.length>0&&stable>=required&&stability>=55};
}
export function ltDistrictRivals(s,d){
 if(!d)return [];
 const zones=ltZones(s,d),counts=new Map();
 for(const z of zones){
  if(!z.owner)continue;
  const item=counts.get(z.owner)||{owner:z.owner,rackets:0,stable:0};
  item.rackets++;if(ltStable(z))item.stable++;
  counts.set(z.owner,item);
 }
 return [...counts.values()].map(x=>({
  ...x,name:(Array.isArray(s.gang.factions)?s.gang.factions:[]).find(f=>f&&f.id===x.owner)?.name||'Organisasi tidak diketahui',
  power:ltPower(s,x.owner,d),share:zones.length?Math.round(x.rackets/zones.length*100):0
 })).sort((a,b)=>b.power-a.power||b.rackets-a.rackets);
}
export function ltAction(s,type,id,choice){if(s.gang.rank!==3)throw Error('Hanya Lieutenant.');const l=s.gang.life,t=ltState(s);ltPoliceDay(s,t,false);const g=s.gang.factions.find(g=>g.id===s.gang.membership);if(!g)throw Error('Organisasi pemain tidak ditemui.');const z=s.gang.territories.find(z=>z.id===id),d=z&&s.gang.world?.districts[z.districtId];if(t.capoCrises.some(e=>!e.resolved)&&type!=='capo-crisis')throw Error('Selesaikan dahulu krisis penahanan Caporegime sebelum memberi arahan Lieutenant lain.');
 // Lieutenant operations are server-logic guarded by the permanently selected state.
 if(['project','claim','contest','policy'].includes(type)&&(!z||!d||d.state!==l.lieutenantState))throw Error('Port bukan dalam negeri jagaan Lieutenant.');
 if(type==='capo-crisis'){const [eventId,decision]=id.split('::'),event=t.capoCrises.find(e=>e.id===eventId&&!e.resolved);if(!event||!['lawyer','acting','wait'].includes(decision))throw Error('Krisis Caporegime sudah diselesaikan.');const cap=(g.people||[]).find(p=>p.id===event.person);if(!cap)throw Error('Caporegime tidak ditemui.');if(decision==='lawyer'){const cost=18000000;spend(s,g.id,cost,'Khidmat guaman Caporegime','lt-capo-legal');g.expenses+=cost;cap.legalSupportDay=s.day;cap.loyalty=clamp((cap.loyalty||50)+8);}if(decision==='acting'){if(cap.actingId)throw Error('Pemangku Caporegime sudah dilantik.');const acting=g.people.find(p=>p.rank===1&&p.status==='Aktif'&&!p.actingFor&&p.district===cap.district);if(!acting)throw Error('Tiada Soldier aktif dalam daerah untuk pemangku. Pilih bantuan guaman atau tunggu.');cap.actingId=acting.id;acting.actingFor=cap.id;acting.loyalty=clamp((acting.loyalty||50)+5);}if(decision==='wait'){cap.resentment=clamp((cap.resentment||0)+12);}event.resolved=true;event.choice=decision;event.resolvedDay=s.day;t.incidents.unshift({id:'lt-event-'+ ++s.sequence,day:s.day,kind:'capo',text:'Keputusan untuk '+cap.name+' direkodkan: '+({lawyer:'bantuan guaman',acting:'pemangku sementara',wait:'tunggu perkembangan'}[decision])+'.'});return;}
 if(type==='police'){const [key,act]=String(id||'').split('::'),p=t.police[key];if(!p||!['recruit','meet','resolve'].includes(act))throw Error('Kenalan polis tidak sah.');
 // A legacy or forged officer record must never be actionable outside this Lieutenant's state.
 // Match the canonical directory key, institutional capacity and geographical scope.
 const [level,scope,slotText,...extra]=String(key).split(':');
 const slot=Number(slotText),maxSlots={Balai:1,IPD:4,IPK:6};
 const validDistricts=Object.values(s.gang.world?.districts||{}).filter(d=>d&&d.state===l.lieutenantState);
 const validScope=level==='IPK'?scope===l.lieutenantState:validDistricts.some(d=>d.id===scope);
 if(extra.length||!Object.hasOwn(maxSlots,level)||!Number.isInteger(slot)||slot<0||slot>=maxSlots[level]||!validScope||!ltValidPoliceRecord(key,p,ltCanonicalPoliceKeys(s)))throw Error('Pegawai bukan dalam direktori negeri Lieutenant yang sah.');if(act==='recruit'){if(p.connected)throw Error('Pegawai ini sudah menjadi kenalan.');if(p.disconnectedDay===s.day)throw Error('Hubungan baru sahaja diputuskan. Tunggu hari berikutnya.');const max={Balai:1,IPD:4,IPK:6}[p.level];const used=new Set(Object.values(t.police).filter(x=>x.level===p.level&&x.scope===p.scope&&x.connected).map(x=>x.id)).size;if(used>=max)throw Error('Had kenalan institusi sudah penuh.');const cost=p.level==='IPK'?25000000:p.level==='IPD'?12000000:5000000;spend(s,'wallet',cost,'Hubungan baharu '+p.level,'lt-network-intro');p.connected=true;p.connectedDay=s.day;p.relationship=clamp(p.relationship+4);p.suspicion=clamp(p.suspicion+4);t.incidents.unshift({id:'lt-event-'+ ++s.sequence,day:s.day,kind:'police',text:'Hubungan dengan '+p.name+' bermula. Risiko pendedahan rangkaian meningkat.'});return;}if(!p.connected)throw Error('Pegawai belum menjadi kenalan.');if(act==='meet'){if(p.lastMeeting===s.day)throw Error('Sudah berjumpa hari ini.');const cost=p.level==='IPK'?9000000:p.level==='IPD'?4500000:1800000;spend(s,'wallet',cost,'Urus rangkaian '+p.level,'lt-network');p.lastMeeting=s.day;p.relationship=clamp(p.relationship+5);p.trust=clamp(p.trust+3);p.suspicion=clamp(p.suspicion+2);p.pressure=clamp(p.pressure+Math.floor(random(s)*9));t.incidents.unshift({id:'lt-event-'+ ++s.sequence,day:s.day,kind:'police',text:'Pertemuan '+p.name+' selesai. Hubungan berubah; tekanan institusi kekal berisiko.'});}else{if(p.pressure<75)throw Error('Tiada krisis hubungan untuk diselesaikan.');p.connected=false;p.disconnectedDay=s.day;p.relationship=clamp(p.relationship-12);p.trust=clamp(p.trust-8);p.suspicion=clamp(p.suspicion-8);p.lastMeeting=s.day;t.incidents.unshift({id:'lt-event-'+ ++s.sequence,day:s.day,kind:'police',text:'Hubungan dengan '+p.name+' diputuskan akibat tekanan atasan. Slot kenalan kembali kosong.'});}return;}
 if(type==='district-challenge'||type==='state-challenge'){
   const districts=Object.values(s.gang.world?.districts||{}).filter(x=>x.state===l.lieutenantState);
   if(!districts.length)throw Error('Negeri belum mempunyai daerah permainan.');const target=type==='district-challenge'?districts.find(x=>x.id===id):null;
   if(type==='district-challenge'&&!target)throw Error('Daerah di luar negeri jagaan.');if(target&&!ltZones(s,target).length)throw Error('Daerah belum mempunyai racket untuk dicabar.');
   const eligible=districts.filter(x=>ltDistrictScore(s,x).dominant&&Number(x.stability)>=55&&t.districtClaims[x.id]?.status==='dikuasai').length;
   if(type==='state-challenge'&&t.stateClaim.status==='dikuasai')throw Error('Negeri sudah dikuasai.');
   if(type==='district-challenge'&&t.districtClaims[id]?.status==='dikuasai')throw Error('Daerah sudah dikuasai.');
   const prior=type==='district-challenge'?t.districtClaims[id]:t.stateClaim;
   if(s.day-(prior?.lastAttempt??-999)<21)throw Error('Tunggu 21 hari sebelum mencabar lagi.');
   const ratio=type==='district-challenge'?(ltDistrictScore(s,target).dominant?ltDistrictScore(s,target).ratio:0):(districts.length?eligible/districts.length:0);
   const ready=type==='district-challenge'?ratio>=.5:ratio>.5;if(type==='state-challenge'&&eligible===0)throw Error('Kuasai sekurang-kurangnya satu daerah sebelum mencabar dominasi negeri.');
   const cost=type==='district-challenge'?Math.round(25000000*(target.factor||1)*(ready?1:2.5)):Math.round(180000000*(ready?1:3));
   spend(s,g.id,cost,'Cabaran dominasi '+(target?.name||l.lieutenantState),'lt-dominance');g.expenses+=cost;
   const myPower=type==='district-challenge'?ltPower(s,g.id,target):Math.round(districts.reduce((n,x)=>n+ltPower(s,g.id,x),0)/Math.max(1,districts.length));
   const rivals=type==='district-challenge'?ltZones(s,target):districts.flatMap(x=>ltZones(s,x));
   const rivalCounts={};for(const zone of rivals)if(zone.owner&&zone.owner!==g.id)rivalCounts[zone.owner]=(rivalCounts[zone.owner]||0)+1;
   const rival=Object.keys(rivalCounts).sort((a,b)=>rivalCounts[b]-rivalCounts[a])[0];
   const enemyPower=type==='district-challenge'?ltPower(s,rival,target):Math.round(districts.reduce((n,x)=>{const owners=[...new Set(ltZones(s,x).map(z=>z.owner).filter(o=>o&&o!==g.id))];return n+Math.max(0,...owners.map(o=>ltPower(s,o,x)));},0)/Math.max(1,districts.length));
   const chance=clamp((ready?24:2)+(myPower-enemyPower)*.065+(ready?ratio*28:0),ready?78:9)/100;
   const win=random(s)<chance;
   const record={status:win?'dikuasai':'gagal',lastAttempt:s.day,challenger:g.id,enemy:rival||null,cost,chance,myPower,enemyPower};
   if(type==='district-challenge'){t.districtClaims[id]=record;target.heat=clamp(target.heat+18);target.stability=clamp(target.stability-(win?6:15));}
   else{t.stateClaim=record;for(const x of districts){x.heat=clamp(x.heat+8);x.stability=clamp(x.stability-4);}}
   s.crime.heat=clamp(s.crime.heat+(win?7:13));
   t.incidents.unshift({id:'lt-event-'+ ++s.sequence,day:s.day,kind:'dominance',text:(win?'Pengaruh berjaya ditegakkan di ':'Cabaran pengaruh gagal di ')+(target?.name||l.lieutenantState)+'. Modal '+money(cost)+' hangus; kekuatan '+myPower+' lawan '+enemyPower+'.'});
   return;
 }
 if(!['police','project-decision','capo-crisis'].includes(type)&&(!z||!d||d.state!==l.lieutenantState))throw Error('Racket bukan dalam negeri jagaan anda.');
 if(type==='project-decision'){const [projectId,decision]=id.split('::'),p=t.projects.find(p=>p.id===projectId);if(!p||p.status!=='decision'||!['continue','investigate','stop'].includes(decision))throw Error('Keputusan projek tidak sah.');const projectZone=s.gang.territories.find(z=>z.id===p.zone);if(!projectZone||projectZone.owner!==g.id||s.gang.world?.districts[projectZone.districtId]?.state!==l.lieutenantState)throw Error('Projek bukan dalam wilayah jagaan.');if(decision==='stop'){p.status='cancelled';p.resolved=s.day;}else{if(decision==='investigate'){const cost=Math.round(p.cost*.15);spend(s,g.id,cost,'Siasat masalah port','lt-project-followup');g.expenses+=cost;p.finish=s.day+7;p.bonus=.15;}else{p.finish=s.day+3;p.bonus=-.1;}p.status='active';p.phase=2;}return;}
 if(type==='project'){if(z.owner!==g.id)throw Error('Racket bukan milik geng.');if(t.projects.some(p=>p.zone===id&&['active','decision'].includes(p.status)))throw Error('Projek masih berjalan.');const costs={guard:{minor:2500000,medium:6500000,major:12000000},expand:{minor:6000000,medium:16000000,major:35000000},welfare:{minor:1500000,medium:4000000,major:8000000}};const kind=choice.split(':')[0],tier=choice.split(':')[1]||'medium',price=costs[kind]?.[tier==='major'?'major':tier==='minor'?'minor':'medium'];if(!price)throw Error('Projek tidak sah.');spend(s,g.id,price,'Projek Lieutenant '+kind+' · '+z.name,'lt-project');g.expenses+=price;t.projects.unshift({id:'lt-project-'+ ++s.sequence,zone:id,kind,tier,racket:z.racket,brief:ltRacketBrief(z.racket)[kind],cost:price,started:s.day,finish:s.day+(tier==='major'?28:tier==='medium'?14:7),status:'active',phase:0});return;}
 if(type==='claim'){if(z.owner)throw Error('Racket sudah mempunyai pemilik.');const cost=Math.max(z.price,10000000);spend(s,g.id,cost,'Buka port '+z.name,'lt-claim');g.expenses+=cost;z.owner=g.id;z.control=50;z.security=45;z.status='Pemulihan';z.ltStabilizeDay=s.day+21;return;}
 if(type==='contest'){if(!z.owner||z.owner===g.id)throw Error('Racket lawan diperlukan.');const cost=Math.max(15000000,Math.round(z.price*.2));spend(s,g.id,cost,'Pertikaian wilayah '+z.name,'lt-contest');g.expenses+=cost;const own=ltPower(s,g.id,d),enemy=ltPower(s,z.owner,d),ds=ltDistrictScore(s,d);const chance=clamp(3+(own-enemy)*.045+(ds.ratio>=.5?16:0)-d.heat*.08,35)/100;const win=random(s)<chance;z.control=clamp(z.control+(win?-14:10));d.heat=clamp(d.heat+18);d.stability=clamp(d.stability-12);s.crime.heat=clamp(s.crime.heat+8);if(win&&z.control<=20){z.owner=g.id;z.manager=null;z.control=35;z.security=35;z.status='Pemulihan';z.ltStabilizeDay=s.day+35;}else if(win)z.status='Dipertikai';t.incidents.unshift({id:'lt-event-'+ ++s.sequence,day:s.day,zone:id,kind:'contest',win,cost,own,enemy});return;}
 if(type==='policy'){if(z.owner!==g.id||!['stabil','agresif','rehat'].includes(choice))throw Error('Polisi tidak sah.');z.policy=choice;return;}
 throw Error('Tindakan tidak sah.');}
export function ltDay(s){if(s.gang.rank!==3)return;const t=ltState(s);if(t.lastDay===s.day)return;t.lastDay=s.day;if(t.incidents.length>200)t.incidents.length=200;for(const p of t.projects){if(!p||!['active','decision'].includes(p.status))continue;const z=s.gang.territories.find(z=>z.id===p.zone);if(!z||z.owner!==s.gang.membership||s.gang.world?.districts[z.districtId]?.state!==s.gang.life.lieutenantState){p.status='cancelled';p.resolved=s.day;t.incidents.unshift({id:'lt-event-'+ ++s.sequence,day:s.day,kind:'project',text:'Projek '+(p.brief||p.kind)+' terhenti kerana port tidak lagi dalam jagaan geng.'});continue;}if(p.status==='decision'||p.finish>s.day)continue;if(p.phase===0&&random(s)<.42){p.status='decision';p.phase=1;t.incidents.unshift({id:'lt-event-'+ ++s.sequence,day:s.day,kind:'project',text:ltRacketBrief(p.racket).problem});continue;}const good=random(s)<(.72+(p.bonus||0));if(p.kind==='guard'){z.security=clamp(z.security+(good?22:10));z.control=clamp(z.control+8);}if(p.kind==='expand'){z.base=Math.round(z.base*(good?1.25:1.08));z.fixedCost=Math.round((z.fixedCost||0)*1.10);}if(p.kind==='welfare'){const g=s.gang.factions.find(g=>g&&g.id===z.owner),cap=g?.people?.find(c=>c&&c.id===z.manager);if(cap){cap.loyalty=clamp(cap.loyalty+(good?20:10));cap.resentment=clamp(cap.resentment-12);}}p.status=good?'completed':'partial';t.incidents.unshift({id:'lt-event-'+ ++s.sequence,day:s.day,zone:p.zone,kind:'project',good});}
 ltPoliceDay(s,t);
 const own=s.gang.factions.find(f=>f.id===s.gang.membership);for(const cap of (Array.isArray(own?.people)?own.people:[])){if(!cap)continue;if(cap.rank===2&&cap.status==='Ditahan'&&Number.isFinite(cap.returnDay)&&cap.returnDay<=s.day&&!t.capoCrises.some(e=>e.person===cap.id&&!e.resolved)){cap.status='Aktif';if(cap.actingId){const deputy=own?.people?.find(p=>p&&p.id===cap.actingId);if(deputy&&deputy.actingFor===cap.id)delete deputy.actingFor;delete cap.actingId;}delete cap.returnDay;t.incidents.unshift({id:'lt-event-'+ ++s.sequence,day:s.day,kind:'capo',text:cap.name+' kembali selepas tempoh tahanan. Status pengurusan port dipulihkan.'});}}
 // Perubahan pengaruh rival berkala; kekuatan tidak statik dan tidak berubah tanpa sebab.
 if(s.day>0&&s.day%7===0&&t.lastPowerTick!==s.day){t.lastPowerTick=s.day;
  const ds=Object.values(s.gang.world?.districts||{}).filter(d=>d.state===s.gang.life.lieutenantState);
  // Operasi penguatkuasaan memberi kesan sebenar pada port pemain, bukan sekadar Heat.
  // Diproses sekali setiap tujuh hari melalui lastPowerTick, bukan ketika halaman dibuka.
  for(const d of ds){
   if(!(Number(d.operationUntil)>s.day))continue;
   const affected=ltZones(s,d).filter(z=>z.owner===s.gang.membership&&z.status==='Aktif');
   if(!affected.length)continue;
   let impacted=0;
   for(const z of affected){
    const loss=2+Math.floor(random(s)*5);
    z.control=clamp(z.control-loss);
    z.security=clamp(z.security-2);
    impacted++;
   }
   d.stability=clamp((d.stability||0)-Math.min(6,2+Math.floor(impacted/3)));
   t.incidents.unshift({id:'lt-event-'+ ++s.sequence,day:s.day,kind:'enforcement',text:'Operasi penguatkuasaan masih aktif di '+d.name+'. '+impacted+' port geng terjejas; kawalan dan kestabilan daerah merosot.'});
  }
  for(const d of ds){for(const z of ltZones(s,d)){
   if(!z.owner||z.owner===s.gang.membership)continue;
   const cause=random(s);const shift=cause<.20?-7:cause<.43?-3:cause<.68?0:cause<.88?3:6;
   z.control=clamp(z.control+shift);
   if(Math.abs(shift)>=6)t.incidents.unshift({id:'lt-event-'+ ++s.sequence,day:s.day,zone:z.id,kind:'rival',text:(shift>0?'Geng lawan tambah pengaruh di ':'Geng lawan mula hilang pengaruh di ')+z.name+'. Kawalan berubah '+shift+' mata.'});
   if(d.operationUntil>s.day)z.security=clamp(z.security-2);
   else if(random(s)<.15)z.security=clamp(z.security+2);
  }}
  for(const [id,claim] of Object.entries(t.districtClaims))if(claim.status==='dikuasai'){
   const d=s.gang.world?.districts[id];if(d&&(!ltDistrictScore(s,d).dominant||Number(d.stability)<55)){
    claim.status='dipertikai';claim.disputedSince=s.day;claim.stableSince=null;t.incidents.unshift({id:'lt-event-'+ ++s.sequence,day:s.day,kind:'dominance',text:'Pengaruh di '+d.name+' mula goyah. Stabilkan semula racket untuk pulihkan dominasi.'});
   }
  }
  // A disputed district can be restored only after two full weekly cycles of stable racket control.
  for(const [id,claim] of Object.entries(t.districtClaims))if(claim.status==='dipertikai'){
   const d=s.gang.world?.districts[id];if(!d)continue;
   if(ltDistrictScore(s,d).dominant&&Number(d.stability)>=55){
    if(!Number.isFinite(claim.stableSince))claim.stableSince=s.day;
    if(s.day-claim.stableSince>=14){claim.status='dikuasai';claim.restoredDay=s.day;claim.stableSince=null;t.incidents.unshift({id:'lt-event-'+ ++s.sequence,day:s.day,kind:'dominance',text:'Pengaruh di '+d.name+' kembali kukuh selepas dua minggu racket stabil.'});}
   }else claim.stableSince=null;
  }
  // State-level recovery requires sustained majority for 14 days, not an instant flip.
  const secureDistricts=ds.filter(d=>t.districtClaims[d.id]?.status==='dikuasai'&&ltDistrictScore(s,d).dominant&&Number(d.stability)>=55).length;
  const hasStateMajority=ds.length>0&&secureDistricts>ds.length/2;
  if(t.stateClaim.status==='dipertikai'){
   if(hasStateMajority){
    if(!Number.isFinite(t.stateClaim.stableSince))t.stateClaim.stableSince=s.day;
    if(s.day-t.stateClaim.stableSince>=14){
     t.stateClaim.status='dikuasai';t.stateClaim.restoredDay=s.day;t.stateClaim.stableSince=null;
     t.incidents.unshift({id:'lt-event-'+ ++s.sequence,day:s.day,kind:'dominance',text:'Dominasi negeri kembali kukuh selepas majoriti daerah kekal stabil selama 14 hari.'});
    }
   }else t.stateClaim.stableSince=null;
  }
  if(t.stateClaim.status==='dikuasai'&&!hasStateMajority){
   t.stateClaim.status='dipertikai';t.stateClaim.disputedSince=s.day;t.stateClaim.stableSince=null;
   t.incidents.unshift({id:'lt-event-'+ ++s.sequence,day:s.day,kind:'dominance',text:'Dominasi negeri mula dipertikai kerana majoriti daerah tidak lagi stabil.'});
  }
 }
 t.incidents=t.incidents.slice(0,200);
 for(const z of s.gang.territories){if(z.status==='Pemulihan'&&z.ltStabilizeDay&&s.day>=z.ltStabilizeDay){const district=s.gang.world?.districts[z.districtId];if(z.owner===s.gang.membership&&district?.state===s.gang.life.lieutenantState){z.status='Aktif';z.control=clamp(z.control+15);z.security=clamp(z.security+10);delete z.ltStabilizeDay;}else{delete z.ltStabilizeDay;}}}
}

// A high-pressure officer can turn against the group. The group's current
// exposure influences that event, but contacts never confer legal immunity.
// Keep the weekly chance bounded to avoid runaway raid loops.
export function ltPoliceOperationChance(s,t,ds,p){
 const pressure=clamp(Number(p.pressure)||0);
 if(!p.connected||pressure<75)return 0;
 const suspicion=clamp(Number(p.suspicion)||0);
 const authority=clamp(Number(p.authority)||0);
 const exposure=ltLegalExposure(s,t,ds).score;
 // A district officer responds primarily to the conditions in that district.
 // State HQ has a broader mandate, so it uses the statewide exposure.
 const local=ds.find(d=>d.id===p.scope);
 const localHeat=local?clamp(Number(local.heat)||0):exposure;
 const localOperation=local&&Number(local.operationUntil)>s.day?12:0;
 const effectiveExposure=p.level==='IPK'?exposure:Math.round(exposure*.45+localHeat*.55)+localOperation;
 const base=.10+(pressure-75)*.009+suspicion*.0012+authority*.0006;
 return Math.min(.60,Math.max(.03,base+Math.min(100,effectiveExposure)*.0015));
}

// One canonical roster is shared by simulation and network scoring. Imported
// duplicate, foreign-state and malformed officer entries remain in saves but
// cannot trigger raids or inflate the institutional network.
export function ltCanonicalPoliceKeys(s){
 const state=s.gang?.life?.lieutenantState;
 const districts=Object.values(s.gang?.world?.districts||{}).filter(d=>d&&d.state===state);
 const keys=new Set();
 for(const d of districts){keys.add('Balai:'+d.id+':0');for(let i=0;i<4;i++)keys.add('IPD:'+d.id+':'+i);}
 if(state)for(let i=0;i<6;i++)keys.add('IPK:'+state+':'+i);
 return keys;
}
export function ltValidPoliceRecord(key,p,keys){
 if(!keys.has(key)||!p||typeof p!=='object'||p.id!==key)return false;
 const parts=key.split(':');
 return parts.length===3&&p.level===parts[0]&&p.scope===parts[1];
}
function ltPoliceDay(s,t,simulate=true){const l=s.gang.life,ds=Object.values(s.gang.world?.districts||{}).filter(d=>d.state===l.lieutenantState);for(const d of [...ds,{id:l.lieutenantState,_stateHQ:true}]){for(const [level,n] of (d._stateHQ?[['IPK',6]]:[['Balai',1],['IPD',4]])){const root=d.id;for(let i=0;i<n;i++){const key=level+':'+root+':'+i;if(!t.police[key]){const h=hash(key);t.police[key]={id:key,name:['Inspektor','ASP','DSP','Supt','ACP'][h%5]+' '+['Azlan','Ravi','Lim','Faizal','Kumar','Tan'][h%6],level,scope:root,relationship:20+h%28,trust:15+h%25,authority:level==='IPK'?80+i*3:level==='IPD'?52+i*5:28,suspicion:10+h%20,pressure:20+h%25,connected:false,lastMeeting:-1};}}}}
// Normalize legacy/imported police records even on read-only page visits.
// No RNG or weekly event is triggered by this normalization.
for(const [key,p] of Object.entries(t.police)){if(!p||typeof p!=='object'||Array.isArray(p)){delete t.police[key];continue;}for(const field of ['relationship','trust','authority','suspicion','pressure'])p[field]=clamp(Number.isFinite(Number(p[field]))?Number(p[field]):0);p.connected=p.connected===true;}
if(!simulate||s.day===0||s.day%7!==0||t.policeTickDay===s.day)return;t.policeTickDay=s.day;const canonical=ltCanonicalPoliceKeys(s);for(const [key,p] of Object.entries(t.police)){if(!ltValidPoliceRecord(key,p,canonical))continue;p.pressure=clamp(p.pressure+Math.floor(random(s)*19)-8);if(p.connected&&p.pressure>=75&&s.day-(Number.isFinite(p.lastOperationDay)?p.lastOperationDay:-999)>=7&&random(s)<ltPoliceOperationChance(s,t,ds,p)){const scoped=ds.find(d=>p.scope===d.id);const eligible=ds.filter(d=>!(Number(d.operationUntil)>s.day));const weighted=eligible.flatMap(d=>Array.from({length:1+Math.floor(Math.max(0,Number(d.heat)||0)/25)},()=>d));const target=scoped||(p.level==='IPK'&&weighted.length?weighted[Math.floor(random(s)*weighted.length)]:null);if(target&&!(Number(target.operationUntil)>s.day)){p.relationship=clamp(p.relationship-15);p.trust=clamp(p.trust-12);p.lastOperationDay=s.day;target.heat=clamp(target.heat+12);target.operationUntil=Math.max(target.operationUntil||0,s.day+7);const own=s.gang.factions.find(f=>f.id===s.gang.membership);const affected=own?.people.filter(c=>c.rank===2&&c.status==='Aktif'&&(c.district===target.name||c.district===target.id))||[];if(affected.length&&random(s)<.25){const cap=affected[Math.floor(random(s)*affected.length)];if(!t.capoCrises.some(e=>e.person===cap.id&&(!e.resolved||cap.status==='Ditahan'))){cap.status='Ditahan';cap.detainedDay=s.day;cap.returnDay=s.day+14+Math.floor(random(s)*22);t.capoCrises.push({id:'lt-capo-'+ ++s.sequence,person:cap.id,district:target.id,day:s.day,resolved:false});}}t.incidents.unshift({id:'lt-event-'+ ++s.sequence,day:s.day,kind:'police',text:p.name+' terlibat dalam operasi penguatkuasaan di '+target.name+'. Hubungan lama tidak menjamin perlindungan.'});}}else if(p.pressure<55)p.suspicion=clamp(p.suspicion-1);}}

// The network score measures both quality and institutional coverage. A single
// well-connected officer cannot produce a near-perfect statewide network.
export function ltPoliceNetwork(s,t,ds){
 // Only the canonical institution slots count: legacy duplicate/foreign records
 // remain in the save but cannot inflate network strength beyond slot capacity.
 const state=s.gang.life.lieutenantState;
 const valid=ltCanonicalPoliceKeys(s);
 const contacts=Object.entries(t.police||{}).filter(([key,p])=>p?.connected===true&&ltValidPoliceRecord(key,p,valid)).map(([,p])=>p);
 const quality=p=>clamp((Number(p.relationship)||0)*.28+(Number(p.trust)||0)*.27+(Number(p.authority)||0)*.20+(100-(Number(p.suspicion)||0))*.10+(100-(Number(p.pressure)||0))*.15,100);
 const districtCount=ds.length;
 const balaiSlots=districtCount;
 const ipdSlots=districtCount*4;
 const ipkSlots=6;
 const group=(level,slots)=>{
  const members=contacts.filter(p=>p.level===level&&(level==='IPK'||ds.some(d=>d.id===p.scope)));
  const covered=members.length;
  return slots>0?members.reduce((n,p)=>n+quality(p),0)/(slots*100):0;
 };
 const coverage=group('Balai',balaiSlots)*.20+group('IPD',ipdSlots)*.35+group('IPK',ipkSlots)*.45;
 const critical=contacts.filter(p=>p.pressure>=75).length;
 return {contacts,critical,score:clamp(Math.round(coverage*1000),1000)};
}
// Exposure is distinct from police contacts: a strong network cannot erase an active case.
// Keep this derived from world state rather than persisting a second mutable counter.
export function ltLegalExposure(s,t,ds){
 const own=s.gang.membership;
 const zones=ds.flatMap(d=>ltZones(s,d)).filter(z=>z.owner===own);
 const heat=ds.length?ds.reduce((sum,d)=>sum+clamp(Number(d.heat)||0),0)/ds.length:0;
 const activeOperations=ds.filter(d=>Number(d.operationUntil)>s.day).length;
 const unstable=zones.length?zones.filter(z=>!ltStable(z)).length/zones.length:0;
 const crises=(Array.isArray(t.capoCrises)?t.capoCrises:[]).filter(e=>e&&!e.resolved).length;
 const exposure=clamp(Math.round(heat*.55+unstable*25+Math.min(25,activeOperations*8)+Math.min(20,crises*10)));
 return {score:exposure,activeOperations,unstableRackets:zones.filter(z=>!ltStable(z)).length,totalRackets:zones.length};
}
export function lieutenantView(s){if(s.gang.rank!==3)return '<section class="card"><h2>Lieutenant</h2><p>Hanya tersedia pada pangkat Lieutenant.</p></section>';const l=s.gang.life,t=ltState(s);ltPoliceDay(s,t,false);const g=s.gang.factions.find(g=>g.id===s.gang.membership),ds=Object.values(s.gang.world?.districts||{}).filter(d=>d.state===l.lieutenantState);const selected=ds.find(d=>d.id===t.selectedDistrict)||ds.find(d=>d.name===l.district)||ds[0];const score=selected&&ltDistrictScore(s,selected);const operationActive=selected&&Number(selected.operationUntil)>s.day;const dominated=ds.filter(d=>ltDistrictScore(s,d).dominant).length;const claimed=ds.filter(d=>t.districtClaims[d.id]?.status==='dikuasai'&&ltDistrictScore(s,d).dominant&&Number(d.stability)>=55).length;const stateReady=ds.length>0&&claimed>ds.length/2;const reports=l.lieutenantLedger||[];const validScopes=new Set(ds.map(d=>d.id).concat(l.lieutenantState));const candidates=Object.values(t.police).filter(p=>p&&validScopes.has(p.scope)&&(p.level!=='IPK'||p.scope===l.lieutenantState));const policeNetwork=ltPoliceNetwork(s,t,ds);const cops=policeNetwork.contacts;const critical=policeNetwork.critical;const scopedContacts={Balai:cops.filter(p=>p.level==='Balai'&&p.scope===selected?.id).length,IPD:cops.filter(p=>p.level==='IPD'&&p.scope===selected?.id).length,IPK:cops.filter(p=>p.level==='IPK').length};const network=policeNetwork.score;const legalExposure=ltLegalExposure(s,t,ds);return `<div class="pagehead"><div><div class="eyebrow">PUSAT KUASA // LIEUTENANT</div><h1>Lieutenant · ${esc(l.lieutenantState||'Negeri belum ditetapkan')}</h1><p>Negeri kekal · ${ds.length} daerah · ${dominated} daerah cukup racket · ${claimed} daerah dikuasai · ${stateReady?'Kelayakan cabaran negeri dipenuhi':'Belum cukup dominasi negeri'} · ${g?.name||''}</p></div></div><section class="card"><h2>Peta Negeri & Daerah</h2><p>Pilih daerah untuk melihat semua port dan kuasa lawan. Kuasa hanya dalam negeri ini.</p><div class="lt-state-map" role="group" aria-label="Peta strategik daerah negeri">${lieutenantGeographicMap(l.lieutenantState,ds,selected,d=>ltDistrictScore(s,d),t.districtClaims)}<div class="lt-map-grid">${ds.map(d=>{const q=ltDistrictScore(s,d),claim=t.districtClaims[d.id]?.status||'belum dicabar',active=d.id===selected?.id;return `<button type="button" class="lt-map-tile ${active?'lt-map-selected':''} ${claim==='dikuasai'?'lt-map-owned':''}" aria-pressed="${active?'true':'false'}" data-action="lt-district" data-id="${esc(d.id)}" title="${esc(d.name)}: ${Math.round(q.ratio*100)}% racket stabil, Heat ${Math.round(d.heat||0)}%"><span class="lt-map-name">${esc(d.name)}</span><span class="lt-map-stats">${Math.round(q.ratio*100)}% port · ${Math.round(d.heat||0)}% Heat</span><span class="lt-map-status">${esc(claim)}</span></button>`}).join('')}</div><p class="muted">Senarai zon interaktif melengkapkan peta geografi; bagi KL, zon gameplay bukan sempadan pentadbiran rasmi. Pilih daerah untuk membuka portfolio racket di bawah.</p></div><details class="lt-district-picker"><summary>Tukar daerah · ${esc(selected?.name||'Tiada daerah')} (${ds.length} pilihan)</summary><div class="inline-actions">${ds.map(d=>btn(d.name+' · '+Math.round(ltDistrictScore(s,d).ratio*100)+'%','lt-district',d.id,d.id===selected?.id?'':'outline')).join('')}</div></details>${selected?lieutenantDistrictAtlas(l.lieutenantState,selected,s):''}<h3>${esc(selected?.name||'Tiada daerah')}</h3><p>Racket stabil ${score?.mine||0}/${score?.total||0} · Heat ${Math.round(selected?.heat||0)}% · Kestabilan ${Math.round(selected?.stability||0)}% · ${score?.dominant?'Syarat racket cukup':'Syarat racket belum cukup'}</p>${selected?(()=>{const p=ltDistrictProgress(s,selected);return `<details class="lt-district-progress"><summary>Perjalanan kuasai daerah · ${p.stable}/${p.required} port stabil ${p.ready?'· Layak':'· Belum layak'}</summary><p>Port milik geng: ${p.owned}/${p.total}. Port sendiri yang belum stabil: ${p.unstableOwned}. Lagi ${p.remaining} port stabil diperlukan untuk mencapai sekurang-kurangnya separuh racket daerah.</p><p>Kestabilan daerah: ${Math.round(p.stability)}/100 (minimum 55). ${p.ready?'Syarat asas dipenuhi; kejayaan cabaran masih bergantung pada kekuatan geng dan lawan.':'Kukuhkan port dan kestabilan daerah untuk meningkatkan peluang cabaran.'}</p></details>`})():''}<details class="lt-rival-intel"><summary>Risikan kekuatan geng · ${selected?ltDistrictRivals(s,selected).length:0} organisasi</summary><p class="muted">Skor 0–1000 dikira daripada anggota, kewangan, racket, kesetiaan dan kestabilan semasa. Nilai berubah mengikut simulasi; bukan ramalan pasti menang.</p>${selected?ltDistrictRivals(s,selected).map(r=>`<p><strong>${esc(r.name)}</strong> · ${r.power}/1000 kekuatan · ${r.rackets} port (${r.stable} stabil) · ${r.share}% kawasan ${r.owner===g?.id?'· Geng sendiri':''}</p>`).join('')||'<p>Belum ada organisasi menguasai racket daerah ini.</p>':'<p>Tiada daerah dipilih.</p>'}</details>${operationActive?`<div class="notice red"><strong>Operasi penguatkuasaan sedang berlangsung</strong><p>Port di daerah ini boleh kehilangan kawalan dan kestabilan pada kitaran mingguan. Dijangka berakhir selepas hari ${Math.round(selected.operationUntil)+1}.</p></div>`:''}<p>Status kuasa daerah: ${esc(t.districtClaims[selected?.id]?.status||'belum dicabar')} · Cabaran memerlukan modal besar, dengan cooldown 21 hari.</p>${selected?btn('Cabar dominasi daerah','lt-district-challenge',selected.id,'outline'):''}<p>Dominasi negeri: ${claimed}/${ds.length} daerah dikuasai · ${esc(t.stateClaim.status)} ${stateReady?'· Syarat majoriti dipenuhi':'· Cabaran awal sangat sukar'}${t.stateClaim.status==='dipertikai'&&Number.isFinite(t.stateClaim.stableSince)?' · Pemulihan '+Math.min(14,Math.max(0,s.day-t.stateClaim.stableSince))+'/14 hari':''}</p>${ds.length?btn('Cabar dominasi negeri','lt-state-challenge',l.lieutenantState,'outline'):''}<div class="territory-grid">${selected?ltZones(s,selected).map(z=>{const own=z.owner===g?.id,other=s.gang.factions.find(f=>f.id===z.owner),q=z.worldManaged&&z.owner?quote(s,z):null;return `<div class="territory"><h3>${esc(z.name)}</h3><p>${esc(z.racket)} · ${esc(other?.name||'Kosong')} · ${esc(z.status)}</p><p>Kawalan ${Math.round(z.control)} · Keselamatan ${Math.round(z.security)} · Unjuran ${money(q?.profit||0)}/bulan</p><p>${z.owner?'Kekuatan pihak '+ltPower(s,z.owner,selected)+'/1000':'Racket belum berpenghuni'}</p><div class="inline-actions">${!z.owner?btn('Buka port · '+money(Math.max(z.price,10000000)),'lt-claim',z.id):own?btn('Urus port','lt-project',z.id):btn('Cabar racket · modal besar','lt-contest',z.id,'danger')}</div></div>`}).join(''):''}</div></section><section class="card"><h2>Caporegime bawah jagaan</h2><p>Bekas Soldier yang masih dalam daerah asal boleh dinaikkan pangkat.</p>${(Array.isArray(g?.people)?g.people:[]).filter(p=>p&&p.rank===1&&p.parent==='player'&&p.status==='Aktif').map(p=>`<p>${esc(p.name)} · Loyalty ${p.loyalty}% · ${esc(p.district||'')}${p.district===l.district?btn('Naikkan Caporegime','gl-promoteSoldier',p.id):' · Kekal di daerah asal'}</p>`).join('')||'<p>Tiada Soldier layak.</p>'}</section><section class="card"><h2>Lejar mingguan & bulanan</h2><p>35–40% daripada untung semasa setiap Caporegime, mengikut kesetiaan. Bayaran setiap 7 hari, tertakluk baki tabung geng.</p>${reports.slice(0,16).map(r=>`<details><summary>Hari ${r.day+1} · Minggu ${r.week+1} · ${money(r.net)}</summary>${r.rows.map(a=>`<p>${esc(s.gang.territories.find(z=>z.id===a.zone)?.name||a.zone)} · Untung ${money(a.profit)} · ${(a.rate*100).toFixed(2)}% · Diterima ${money(a.amount)}${a.unpaid?' · Tidak dibayar '+money(a.unpaid):''}</p>`).join('')}</details>`).join('')||'<p>Lejar pertama selepas kitaran 7 hari.</p>'}<h3>Lejar bulanan (30 hari permainan)</h3>${Object.entries(reports.reduce((a,r)=>{const month=Math.floor(r.day/30)+1;(a[month]??=[]).push(r);return a;},{})).sort((a,b)=>Number(b[0])-Number(a[0])).slice(0,12).map(([month,rows])=>`<details><summary>Bulan ${month} · ${rows.length} pembayaran · ${money(rows.reduce((n,r)=>n+(r.net||0),0))}</summary><p>Jumlah keuntungan Caporegime: ${money(rows.reduce((n,r)=>n+(r.rows||[]).reduce((v,x)=>v+(x.profit||0),0),0))}</p><p>Jumlah diterima: ${money(rows.reduce((n,r)=>n+(r.net||0),0))}</p><p>Belum dibayar: ${money(rows.reduce((n,r)=>n+(r.rows||[]).reduce((v,x)=>v+(x.unpaid||0),0),0))}</p></details>`).join('')||'<p>Belum ada transaksi bulanan.</p>'}</section><section class="card"><h2>Projek & perkembangan</h2>${t.projects.slice(0,12).map(p=>`<p>${esc(p.brief||p.kind)} · ${esc(s.gang.territories.find(z=>z.id===p.zone)?.name||'')} · ${money(p.cost)} · ${p.status} · Tamat hari ${p.finish+1}</p>`).join('')||'<p>Belum ada projek.</p>'}${t.incidents.slice(0,12).map(e=>`<p>Hari ${e.day+1} · ${esc(e.kind)} · ${esc(e.text|| (e.good===false||e.win===false?'Ada komplikasi':'Perkembangan direkodkan'))}</p>`).join('')}</section><section class="card"><h2>Rangkaian polis · Balai / IPD / IPK</h2><p>Indeks rangkaian ${network}/1000 · Pendedahan undang-undang ${legalExposure.score}% · ${legalExposure.activeOperations} operasi aktif · ${legalExposure.unstableRackets}/${legalExposure.totalRackets} port tidak stabil · ${critical} pegawai pada tekanan kritikal · ${cops.length} kenalan aktif daripada ${candidates.length} pegawai tersedia. Balai daerah ${scopedContacts.Balai}/1 · IPD daerah ${scopedContacts.IPD}/4 · IPK negeri ${scopedContacts.IPK}/6. Indeks mengambil kira kualiti dan liputan semua institusi negeri; bukan jaminan kebal daripada undang-undang.</p><p>Relationship, Trust, Authority, Suspicion dan Pressure berubah mengikut simulasi. Pressure 75 ke atas boleh menyebabkan pegawai berpaling dan operasi penguatkuasaan.</p>${['Balai','IPD','IPK'].map(level=>{const group=candidates.filter(p=>p.level===level&&(level==='IPK'||p.scope===selected?.id)).sort((a,b)=>Number(b.connected)-Number(a.connected)||Number(b.pressure)-Number(a.pressure));return `<details class="lt-police-group"><summary>${level} · ${group.filter(p=>p.connected).length}/${group.length} kenalan · ${group.filter(p=>p.connected&&p.pressure>=75).length} kritikal</summary>${group.map(p=>`<details><summary>${esc(p.name)} · ${esc(p.level)} · Pressure ${p.pressure}% ${p.pressure>=75?'· AMARAN KRITIKAL':''} · ${p.connected?'Kenalan':'Belum dikenali'}</summary><p>Hubungan ${p.relationship} · Trust ${p.trust} · Authority ${p.authority} · Suspicion ${p.suspicion} · Pressure ${p.pressure}</p>${p.connected?btn('Jumpa pegawai · kos tinggi','lt-police',p.id+'::meet','outline'):btn('Bina kenalan · kos pengenalan','lt-police',p.id+'::recruit','outline')}${p.connected&&p.pressure>=75?btn('Putuskan urusan berisiko','lt-police',p.id+'::resolve','outline'):''}</details>`).join('')}</details>`}).join('')}</section><section class="card"><h2>Krisis Caporegime</h2>${t.capoCrises.filter(e=>e&&!e.resolved).map(e=>{const cap=g?.people?.find(p=>p&&p.id===e.person);return `<div class="notice red"><strong>${esc(cap?.name||'Caporegime')} ditahan</strong><p>Operasi di ${esc(s.gang.world?.districts[e.district]?.name||'daerah')} terjejas. Keputusan diperlukan sebelum meneruskan permainan.</p><div class="inline-actions">${btn('Khidmat guaman · RM180,000','lt-capo-crisis',e.id+'::lawyer')}${btn('Lantik pemangku sementara','lt-capo-crisis',e.id+'::acting','outline')}${btn('Tunggu perkembangan','lt-capo-crisis',e.id+'::wait','outline')}</div></div>`}).join('')||'<p>Tiada krisis penahanan terbuka.</p>'}</section><section class="card"><h2>Arahan projek tertangguh</h2>${t.projects.filter(p=>p&&p.status==='decision').map(p=>`<p>${esc(s.gang.territories.find(z=>z.id===p.zone)?.name||'Port')} · ${esc(ltRacketBrief(p.racket).problem)}</p><div class="inline-actions">${btn('Teruskan','lt-project-decision',p.id+'::continue')}${btn('Siasat lagi · tambah kos 15%','lt-project-decision',p.id+'::investigate','outline')}${btn('Batalkan','lt-project-decision',p.id+'::stop','danger')}</div>`).join('')||'<p>Tiada arahan tergantung.</p>'}</section>`;}
