import assert from 'node:assert/strict';
import {GLOBAL_AIRPORTS} from './js-release-v8-9-20261114/global-flight-network.js';
import {globalFlightChoices} from './js-release-v8-9-20261114/global-flight-checkout.js';
const state={day:673};let count=0,classes=0;
for(const from of Object.keys(GLOBAL_AIRPORTS))for(const to of Object.keys(GLOBAL_AIRPORTS)){
 if(from===to)continue;
 let has=false;
 for(const seatClass of ['economy','business','first']){
  const found=globalFlightChoices(state,{from,to,departureDay:680,seatClass,maxOptions:6});
  for(const p of found){assert.equal(p.from,from);assert.equal(p.to,to);assert.equal(p.quote.seatClass,seatClass);assert(p.legs.length<=3);has=true;classes++;}
 }
 assert(has,`${from}-${to} no flights`);count++;
}
assert(globalFlightChoices(state,{from:'KUL',to:'IST',departureDay:680,seatClass:'first'}).length>0);
console.log(`PASS ${count} airport pairs, ${classes} class-aware flight plans, Istanbul First Class connecting option`);
