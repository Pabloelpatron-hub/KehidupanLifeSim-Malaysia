import {geography} from './geography.js';
import {policeDirectory} from './police-directory.js';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const geoByState=new Map();
for(const f of geography){const state=f.properties?.state;if(!geoByState.has(state))geoByState.set(state,[]);geoByState.get(state).push(f);}
function rings(geometry){if(!geometry)return [];if(geometry.type==='Polygon')return geometry.coordinates||[];if(geometry.type==='MultiPolygon')return (geometry.coordinates||[]).flatMap(poly=>poly);return [];}
function bounds(features){let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;for(const f of features)for(const ring of rings(f.geometry))for(const pt of ring){if(!Number.isFinite(pt[0])||!Number.isFinite(pt[1]))continue;minX=Math.min(minX,pt[0]);maxX=Math.max(maxX,pt[0]);minY=Math.min(minY,pt[1]);maxY=Math.max(maxY,pt[1]);}return {minX,minY,maxX,maxY};}
function pathFor(f,project){return rings(f.geometry).map(ring=>{if(ring.length<3)return '';const stride=Math.max(1,Math.floor(ring.length/240));const pts=ring.filter((_,i)=>i%stride===0||i===ring.length-1);return pts.map((p,i)=>(i?'L':'M')+project(p).join(' ')).join(' ')+' Z';}).join(' ');}
export function lieutenantGeographicMap(state,districts,selected,score,claims){const features=geoByState.get(state)||[];if(!features.length)return '<p class="muted">Sempadan geografi belum tersedia untuk negeri ini. Gunakan senarai daerah di bawah.</p>';
 const b=bounds(features);if(!Number.isFinite(b.minX))return '<p class="muted">Data sempadan negeri tidak lengkap.</p>';
 const W=760,H=490,pad=18,dx=Math.max(.001,b.maxX-b.minX),dy=Math.max(.001,b.maxY-b.minY);const scale=Math.min((W-pad*2)/dx,(H-pad*2)/dy),offsetX=(W-dx*scale)/2,offsetY=(H-dy*scale)/2;
 const project=p=>[(offsetX+(p[0]-b.minX)*scale).toFixed(1),(H-offsetY-(p[1]-b.minY)*scale).toFixed(1)];
 const byName=new Map(districts.map(d=>[d.name.toLowerCase(),d]));
 const kl=state==='W.P. Kuala Lumpur';
 const paths=features.map(f=>{const d=byName.get(String(f.properties.district).toLowerCase());const active=d?.id===selected?.id;const owned=d&&claims[d.id]?.status==='dikuasai';const ratio=d?Math.round(score(d).ratio*100):0;const name=esc(f.properties.district);const shape=pathFor(f,project);return `<path d="${shape}" class="lt-geo-district ${active?'lt-geo-active':''} ${owned?'lt-geo-owned':''}" ${d?`data-action="lt-district" data-id="${esc(d.id)}" role="button" tabindex="0" aria-label="Pilih ${name}, ${ratio}% racket stabil"`:'aria-hidden="true"'}><title>${name}${d?' · '+ratio+'% racket stabil':''}</title></path>`;}).join('');
 return `<div class="lt-geographic-wrap"><svg class="lt-geographic-map" viewBox="0 0 ${W} ${H}" role="group" aria-label="Peta sempadan geografi ${esc(state)}; pilih daerah pada peta" preserveAspectRatio="xMidYMid meet">${paths}</svg><p class="muted">Sempadan geografi daripada dataset permainan. ${kl?'Kuala Lumpur mempunyai satu bentuk geografi asas; 18 zon gameplay tidak mempunyai sempadan rasmi dalam dataset, jadi pilih zon melalui senarai interaktif di bawah.':'Tekan daerah pada peta atau pilih melalui senarai di bawah.'}</p></div>`;
}

// District drill-down: retains actual administrative district polygon; no fabricated mukim boundaries.
// Compact playable atlas: real district outline, game-world area/racket markers.
// Markers are schematic within the real polygon until verified coordinates exist.
function pointInPolygon(pt,g){for(const ring of rings(g)){let inside=false;for(let i=0,j=ring.length-1;i<ring.length;j=i++){const x=ring[i][0],y=ring[i][1],xx=ring[j][0],yy=ring[j][1];if((y>pt[1])!==(yy>pt[1])&&pt[0]<(xx-x)*(pt[1]-y)/(yy-y)+x)inside=!inside;}if(inside)return true;}return false;}
function markerPoints(f,count){const b=bounds([f]),pts=[];for(let iy=1;iy<=17;iy++)for(let ix=1;ix<=23;ix++){const x=b.minX+(b.maxX-b.minX)*ix/24,y=b.minY+(b.maxY-b.minY)*iy/18;if(pointInPolygon([x,y],f.geometry))pts.push([x,y]);}if(!pts.length)return [];const chosen=[];for(let k=0;k<count;k++){const i=Math.min(pts.length-1,Math.floor((k+.5)*pts.length/count));chosen.push(pts[i]);}return chosen;}
export function lieutenantDistrictAtlas(state,district,world){
 if(!district)return '';
 const f=(geoByState.get(state)||[]).find(x=>String(x.properties?.district||'').toLowerCase()===String(district.name||'').toLowerCase());
 const zones=(world?.gang?.territories||[]).filter(z=>z.districtId===district.id);
 const entries=policeDirectory.filter(p=>p.state===state);
 const norm=x=>String(x||'').toLowerCase().replace(/[^a-z0-9]/g,'');
 const matches=entries.filter(p=>norm(p.name)===norm(district.name));
 const stations=[...new Set(matches.flatMap(p=>p.stations||[]))].filter(x=>/^Balai Polis /i.test(x));
 // Use locality names from the official police directory when present. A station name
 // is evidence of a real place, NOT evidence of its geographic coordinates or boundary.
 const localityNames=stations.map(n=>n.replace(/^Balai Polis /i,'').trim()).filter(n=>n&&!/^(trafik|lokap)/i.test(n));
 // Prefer 3–4 areas, and respect the 2–5 racket target whenever the
 // existing persistent racket count makes that mathematically possible.
 const feasible=[3,4].filter(n=>zones.length>=2*n&&zones.length<=5*n);
 const areaCount=feasible.length?(feasible.includes(3)?3:4):(zones.length>15?4:3);
 const areaNames=Array.from({length:areaCount},(_,i)=>localityNames[i]||`${district.name} · Kawasan operasi ${i+1}`);
 // Allocate existing rackets as evenly as possible; never fabricate new rackets or
 // silently alter persistent ownership, income, or gameplay state.
 const groups=areaNames.map(name=>({name,zones:[]}));
 zones.forEach((z,i)=>groups[i%areaCount].zones.push(z));
 const localitySource=localityNames.length?'Nama lokasi daripada direktori PDRM; kedudukan penanda masih simulasi.':'Nama kawasan operasi sementara; lokasi geografi belum disahkan.';
 const unassigned=groups.flatMap(g=>g.zones).length!==zones.length;
 const countsVerified=groups.every(g=>g.zones.length>=2&&g.zones.length<=5)&&!unassigned;
 let map='<p class="muted">Sempadan geografi daerah belum tersedia dalam dataset.</p>';
 if(f){const bb=bounds([f]),W=720,H=460,pad=26,dx=Math.max(.001,bb.maxX-bb.minX),dy=Math.max(.001,bb.maxY-bb.minY),scale=Math.min((W-pad*2)/dx,(H-pad*2)/dy),ox=(W-dx*scale)/2,oy=(H-dy*scale)/2;
 const proj=p=>[ox+(p[0]-bb.minX)*scale,H-oy-(p[1]-bb.minY)*scale];
 const centers=markerPoints(f,areaCount);
 const marks=centers.map((c,i)=>{const [x,y]=proj(c);return `<g class="lt-area-pin" data-area="${i}" tabindex="0" role="button" aria-label="Lihat kawasan ${esc(groups[i].name)}"><circle cx="${x}" cy="${y}" r="15"/><text x="${x}" y="${y+4}" text-anchor="middle">${i+1}</text></g>`;}).join('');
 const racketMarks=groups.map((g,i)=>g.zones.map((z,j)=>{const base=centers[i];if(!base)return '';const [cx,cy]=proj(base),angle=j*2.39996,rad=28+13*Math.sqrt(j);const x=Math.max(16,Math.min(W-16,cx+Math.cos(angle)*rad)),y=Math.max(16,Math.min(H-16,cy+Math.sin(angle)*rad));return `<g class="lt-racket-pin" data-racket-pin="${esc(z.id)}" data-area="${i}" tabindex="0" role="button" aria-label="Racket ${esc(z.name)}"><circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="8" fill="#f6c65e" stroke="#252525" stroke-width="1.5"/><title>${esc(z.name)} · ${esc(z.racket||'Racket')}</title></g>`;}).join('')).join('');
 map=`<div class="lt-map-controls"><button type="button" data-map-zoom="in">+ Zoom</button><button type="button" data-map-zoom="out">− Zoom</button><button type="button" data-map-zoom="reset">Reset</button></div><div class="lt-map-viewport"><svg viewBox="0 0 ${W} ${H}" class="lt-geographic-map lt-play-map" role="group" aria-label="Peta geografi ${esc(district.name)}"><g class="lt-map-camera"><path d="${pathFor(f,p=>proj(p).map(v=>v.toFixed(1)))}" fill="#23594e" stroke="#d3e7d8" stroke-width="2"/>${marks}${racketMarks}</g></svg></div>`;
 }
 const cards=groups.map((g,i)=>`<section class="lt-area-card" data-area-panel="${i}" ${i?'hidden':''}><h4>${esc(g.name)} · ${g.zones.length} racket</h4><p class="muted">${esc(localitySource)} ${g.zones.length<2?'Belum cukup 2 racket sedia ada di kawasan ini.':''}</p>${g.zones.map(z=>`<div class="lt-racket-row"><strong>${esc(z.name)}</strong><span>${esc(z.racket||'Racket')} · ${esc(z.status||'')} · Kawalan ${Math.round(z.control||0)}%</span><button type="button" class="lt-racket-select" data-racket="${esc(z.id)}">Lihat tindakan</button></div>`).join('')||'<p>Tiada racket dalam kawasan ini.</p>'}</section>`).join('');
 return `<div class="lt-atlas" id="lt-atlas-detail"><div class="lt-atlas-head"><strong>Peta Interaktif · ${esc(district.name)}</strong><span>${esc(state)}</span></div>${map}<p class="muted">Tekan penanda kawasan pada peta, kemudian pilih racket. Seret untuk bergerak; cubit dua jari untuk zoom, atau gunakan butang. Sempadan daerah daripada dataset game; penanda operasi masih anggaran. ${countsVerified?'Setiap kawasan mempunyai 2–5 racket sedia ada.':'Bilangan racket sedia ada tidak membolehkan semua kawasan mencapai 2–5; tiada racket rekaan ditambah.'}</p><div class="lt-area-tabs">${groups.map((g,i)=>`<button type="button" class="lt-area-tab" data-area="${i}">${esc(g.name)}</button>`).join('')}</div>${cards}<div class="lt-racket-popup" hidden aria-live="polite"></div><details><summary>IPD dan balai · direktori rujukan</summary>${matches.map(p=>`<p>IPD ${esc(p.name)} · <a href="${esc(p.url)}" target="_blank" rel="noopener">PDRM</a></p>`).join('')||'<p>Padanan IPD belum disahkan.</p>'}<p>${stations.map(esc).join(' · ')||'Tiada balai dipadankan.'}</p></details></div>`;
}
// Map camera state is scoped to each atlas SVG, so a newly rendered district starts clean.
function mapCamera(svg){
 const camera=svg?.querySelector('.lt-map-camera');if(!camera)return null;
 const state=svg.__ltCamera||(svg.__ltCamera={zoom:1,x:0,y:0,pointers:new Map(),lastDistance:0,lastCenter:null});
 const paint=()=>{camera.setAttribute('transform',`translate(${state.x+360*(1-state.zoom)} ${state.y+230*(1-state.zoom)}) scale(${state.zoom})`);svg.dataset.zoom=String(state.zoom);};
 const scaleAt=(factor,clientX,clientY)=>{const rect=svg.getBoundingClientRect(),px=(clientX-rect.left)/rect.width*720,py=(clientY-rect.top)/rect.height*460,old=state.zoom,next=Math.max(1,Math.min(6,old*factor));const k=next/old;state.x=px-360*(1-next)-(px-360*(1-old)-state.x)*k;state.y=py-230*(1-next)-(py-230*(1-old)-state.y)*k;state.zoom=next;if(next===1){state.x=0;state.y=0;}paint();};
 return {state,paint,scaleAt};
}
if(typeof document!=='undefined'){
 document.addEventListener('pointerdown',e=>{const svg=e.target.closest?.('.lt-play-map');if(!svg)return;const cam=mapCamera(svg);if(!cam)return;cam.state.pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});svg.setPointerCapture?.(e.pointerId);});
 document.addEventListener('pointermove',e=>{const svg=e.target.closest?.('.lt-play-map')||(e.target.closest?.('.lt-atlas')?.querySelector('.lt-play-map'));if(!svg)return;const cam=mapCamera(svg),s=cam?.state;if(!s?.pointers.has(e.pointerId))return;const old=s.pointers.get(e.pointerId);if(Math.hypot(e.clientX-old.x,e.clientY-old.y)>5)svg.__ltDragged=true;s.pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});const pts=[...s.pointers.values()];if(pts.length>=2){const a=pts[0],b=pts[1],dist=Math.hypot(a.x-b.x,a.y-b.y);if(s.lastDistance>0)cam.scaleAt(dist/s.lastDistance,(a.x+b.x)/2,(a.y+b.y)/2);s.lastDistance=dist;}else if(s.zoom>1){const rect=svg.getBoundingClientRect();s.x+=(e.clientX-old.x)/rect.width*720;s.y+=(e.clientY-old.y)/rect.height*460;cam.paint();}});
 const endPointer=e=>{const svg=e.target.closest?.('.lt-play-map')||(e.target.closest?.('.lt-atlas')?.querySelector('.lt-play-map'));const s=svg?.__ltCamera;if(s){s.pointers.delete(e.pointerId);s.lastDistance=0;}};
 document.addEventListener('pointerup',endPointer);document.addEventListener('pointercancel',endPointer);
 document.addEventListener('wheel',e=>{const svg=e.target.closest?.('.lt-play-map');if(!svg)return;e.preventDefault();mapCamera(svg)?.scaleAt(e.deltaY<0?1.18:1/1.18,e.clientX,e.clientY);},{passive:false});
 document.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target.closest?.('.lt-area-pin,.lt-racket-pin')){e.preventDefault();e.target.dispatchEvent(new MouseEvent('click',{bubbles:true}));}});
 document.addEventListener('click',e=>{
  const atlas=e.target.closest?.('.lt-atlas');if(!atlas)return;
  if(atlas.querySelector('.lt-play-map')?.__ltDragged){atlas.querySelector('.lt-play-map').__ltDragged=false;return;}
  const pin=e.target.closest('[data-racket-pin]');if(pin){const panel=atlas.querySelector(`[data-area-panel="${pin.dataset.area}"]`);atlas.querySelectorAll('[data-area-panel]').forEach(p=>p.hidden=p!==panel);const button=[...(panel?.querySelectorAll('.lt-racket-select')||[])].find(b=>b.dataset.racket===pin.dataset.racketPin);button?.click();return;}
  const area=e.target.closest('[data-area]');if(area){const n=area.dataset.area;atlas.querySelectorAll('[data-area-panel]').forEach(p=>p.hidden=p.dataset.areaPanel!==n);atlas.querySelectorAll('.lt-area-tab').forEach(b=>b.classList.toggle('active',b.dataset.area===n));return;}
  const zoom=e.target.closest('[data-map-zoom]');if(zoom){const svg=atlas.querySelector('.lt-play-map'),cam=mapCamera(svg);if(!cam)return;if(zoom.dataset.mapZoom==='reset'){cam.state.zoom=1;cam.state.x=0;cam.state.y=0;cam.paint();}else{const r=svg.getBoundingClientRect();cam.scaleAt(zoom.dataset.mapZoom==='in'?1.35:1/1.35,r.left+r.width/2,r.top+r.height/2);}return;}
  const rack=e.target.closest('.lt-racket-select');if(rack){const z=[...document.querySelectorAll('.territory-grid .territory')].find(el=>el.querySelector(`[data-id="${CSS.escape(rack.dataset.racket)}"]`));const pop=atlas.querySelector('.lt-racket-popup');pop.hidden=false;pop.replaceChildren();const h=document.createElement('strong');h.textContent=rack.closest('.lt-racket-row')?.querySelector('strong')?.textContent||'Racket';pop.append(h);const p=document.createElement('p');p.textContent='Tindakan sebenar menggunakan sistem Lieutenant sedia ada.';pop.append(p);if(z){const buttons=z.querySelectorAll('button[data-action]');buttons.forEach(b=>{const copy=document.createElement('button');copy.type='button';copy.textContent=b.textContent;copy.addEventListener('click',()=>b.click());pop.append(copy);});}else{const p2=document.createElement('p');p2.textContent='Pilih racket melalui portfolio di bawah jika tindakan belum tersedia.';pop.append(p2);}pop.scrollIntoView({block:'nearest'});}
 });
}
