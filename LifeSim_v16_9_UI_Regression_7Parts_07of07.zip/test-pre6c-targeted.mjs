import assert from 'node:assert/strict';
import {initial,serialize,deserialize} from './js-release-v8-9-20261114/state.js';
import {directFlights,GLOBAL_AIRPORTS} from './js-release-v8-9-20261114/global-flight-network.js';
import {buildGlobalFlightPlan,reserveGlobalItinerary,createGlobalJourneyState} from './js-release-v8-9-20261114/global-journey-booking.js';
import {bindGlobalJourney,syncGlobalFlightToTravel} from './js-release-v8-9-20261114/airport-merge-phase4.js';
import {canonicalGlobalAirportAction,canonicalGlobalLanding} from './js-release-v8-9-20261114/canonical-global-actions.js';
import {UNIVERSAL_AIRPORT_STEPS,UNIVERSAL_ARRIVAL_STEPS} from './js-release-v8-9-20261114/universal-airport.js';
const results=[];
function create(airports,id){const s=initial(); const legs=airports.slice(1).map((a,i)=>directFlights(airports[i],a)[0]);assert(legs.every(Boolean)); const plan=buildGlobalFlightPlan({legs},{departureDay:20,bookingDay:10});s.travel.globalJourneyData=reserveGlobalItinerary(createGlobalJourneyState(),plan,{bookingId:id,paymentId:'pay-'+id,paymentSource:'bank',paidSen:plan.quote.totalSen});bindGlobalJourney(s);syncGlobalFlightToTravel(s);return {s,plan};}
function depart(s,day){s.day=day;canonicalGlobalAirportAction(s,'ENTER',{day});for(const step of UNIVERSAL_AIRPORT_STEPS)canonicalGlobalAirportAction(s,'DEPARTURE',{step,day});canonicalGlobalAirportAction(s,'START',{day});}
function arrive(s){for(const step of UNIVERSAL_ARRIVAL_STEPS)canonicalGlobalAirportAction(s,'ARRIVAL',{step});}
for(const [name,airports] of [['KUL-ICN',['KUL','ICN']],['KUL-LHR',['KUL','LHR']],['KUL-DOH-LHR',['KUL','DOH','LHR']]]){
 try {const {s,plan}=create(airports,'test-'+name);assert.equal(s.travel.activeTrip.segments.length,plan.legs.length);for(let i=0;i<plan.legs.length;i++){depart(s,plan.legs[i].departureDay);assert.equal(canonicalGlobalLanding(s),true);assert.equal(canonicalGlobalLanding(s),false);arrive(s);if(i<plan.legs.length-1){assert.equal(s.travel.activeTrip.activeSegmentIndex,i+1);const loaded=deserialize(serialize(s));assert.equal(loaded.travel.activeTrip.activeSegmentIndex,i+1);assert.equal(loaded.travel.globalJourneyData.activeJourney.currentAirport,airports[i+1]);}}assert.equal(s.travel.location.country,GLOBAL_AIRPORTS[airports.at(-1)].country);results.push({name,status:'PASS',details:s.travel.status});}
 catch(e){results.push({name,status:'FAIL',details:e.stack?.split('\n').slice(0,3).join(' | ')||String(e)});}
}
for(const r of results)console.log(`${r.status} ${r.name}: ${r.details}`);
if(results.some(x=>x.status==='FAIL'))process.exitCode=1;
import {canonicalGlobalNoShow} from './js-release-v8-9-20261114/canonical-global-actions.js';
try {const {s,plan}=create(['KUL','DOH','LHR'],'missed-connection');depart(s,plan.legs[0].departureDay);canonicalGlobalLanding(s);arrive(s);s.day=plan.legs[1].departureDay+1;s.hour=12;assert.equal(canonicalGlobalNoShow(s),true);assert.equal(canonicalGlobalNoShow(s),false);assert.equal(s.travel.globalJourneyData.activeJourney.segments.at(-1).missedFlight.reason,'MISSED_CONNECTION');assert.equal(s.travel.globalJourneyData.activeJourney.segments.at(-1).legs[1].status,'CLOSED_NO_SHOW'===s.travel.globalJourneyData.activeJourney.segments.at(-1).legs[1].status?'CLOSED_NO_SHOW':undefined);console.log('PASS missed connection idempotent');}catch(e){console.log('FAIL missed connection:',e.stack);process.exitCode=1;}
import {searchGlobalRoutes} from './js-release-v8-9-20261114/global-flight-network.js';
let checked=0;for(const airport of Object.keys(GLOBAL_AIRPORTS).filter(x=>x!=='KUL')){const options=searchGlobalRoutes('KUL',airport,{maxStops:2,maxOptions:200});assert(options.length,`No route to ${airport}`);const route=options[0];const {s}=create([route.legs[0].from,...route.legs.map(x=>x.to)],'dest-'+airport);assert.equal(s.travel.activeTrip.to,airport);checked++;}console.log(`PASS ${checked} destinations route and canonical booking state`);
