/* v16.3: prevent unsafe folding of active controls, without touching game state. */
(()=>{'use strict';
const app=document.getElementById('app');if(!app)return;
const interactive='input:not([type="hidden"]),select,textarea,[contenteditable="true"]';
let pending=false;
function fix(){pending=false;
 const content=app.querySelector(':scope > .shell > .content');if(!content)return;
 for(const card of content.querySelectorAll(':scope > .ui159-workspace')){
  const fold=card.querySelector(':scope > .ui159-fold');if(!fold)continue;
  const heading=card.querySelector(':scope > .ui159-original-heading');
  // A form must be discoverable without relying on hidden CSS or a title keyword.
  const controls=[...card.querySelectorAll(interactive)].filter(el=>!el.disabled&&!el.closest('dialog,[hidden]'));
  const active=card.contains(document.activeElement)&&document.activeElement!==fold;
  const invalid=controls.some(el=>el.matches(':invalid,[aria-invalid="true"]'));
  if((active||invalid)&&card.classList.contains('ui159-closed'))fold.click();
  // No duplicated spoken label: fold button already announces the original heading.
  if(heading){fold.removeAttribute('aria-describedby');if(!fold.getAttribute('aria-label'))fold.setAttribute('aria-label',heading.textContent.trim());}
  if(!card.id)card.id='ui163-panel-'+[...card.parentElement.children].indexOf(card);
  fold.setAttribute('aria-controls',card.id);
 }
}
function schedule(){if(pending)return;pending=true;requestAnimationFrame(fix)}
new MutationObserver(schedule).observe(app,{childList:true,subtree:true});
app.addEventListener('focusin',schedule,true);app.addEventListener('invalid',schedule,true);
schedule();
})();
