import {commitGlobalTravelState} from './travel-foundation.js';
// Fasa 6A: one persisted owner for the Global itinerary.
// The historical globalJourney property is a non-persisted compatibility view.
// Older JSON saves are migrated without deleting the original itinerary until accepted.
export function bindGlobalJourney(state){
 if(!state||typeof state!=='object')throw Error('State perjalanan tidak sah');
 state.travel ||= {};
 const descriptor=Object.getOwnPropertyDescriptor(state,'globalJourney');
 if(descriptor?.get&&descriptor?.set)return state.travel.globalJourneyData;
 const old=state.globalJourney;
 if(old&&typeof old==='object'){
  if(!state.travel.globalJourneyData)state.travel.globalJourneyData=old;
  else if(JSON.stringify(old)!==JSON.stringify(state.travel.globalJourneyData)){
   state.travel.airportMergePhase1 ||= {version:1,conflicts:[],stagedGlobalTrip:null};
   const conflicts=state.travel.airportMergePhase1.conflicts ||= [];
   if(!conflicts.some(x=>x.code==='GLOBAL_SAVE_DIVERGENCE')){
    state.travel.globalJourneyLegacyBackup=structuredClone(old);
    conflicts.push({code:'GLOBAL_SAVE_DIVERGENCE',resolution:'CANONICAL_PRESERVED',backup:'travel.globalJourneyLegacyBackup'});
   }
  }
 }
 Object.defineProperty(state,'globalJourney',{configurable:true,enumerable:false,
  get(){return this.travel?.globalJourneyData;},
  set(value){this.travel ||= {};this.travel.globalJourneyData=value;}
 });
 return state.travel.globalJourneyData;
}
export function globalJourneyFromTravel(state){bindGlobalJourney(state);return state.travel.globalJourneyData;}

// Phase 4: reversible global-flight adapter to the original travel activeTrip.
// Does not mutate legacy KUL-ICN trips. Preserve globalJourney for legacy saves until final cutover.
const AIRPORT_COUNTRY=Object.freeze({KUL:'MY',SIN:'SG',BKK:'TH',CGK:'ID',MNL:'PH',SGN:'VN',PNH:'KH',VTE:'LA',RGN:'MM',BWN:'BN',ICN:'KR',NRT:'JP',PEK:'CN',TPE:'TW',HKG:'HK',DEL:'IN',DAC:'BD',KTM:'NP',CMB:'LK',MLE:'MV',DXB:'AE',DOH:'QA',JED:'SA',IST:'TR',LHR:'GB',CDG:'FR',FRA:'DE',AMS:'NL',SYD:'AU',AKL:'NZ',JFK:'US'});
const clone=x=>structuredClone(x);
const DEPARTURE=['CHECK_IN','BAG_DROP','SECURITY','IMMIGRATION','GATE','BOARDING'];
const ARRIVAL=['DISEMBARK','IMMIGRATION','BAGGAGE','CUSTOMS','CLEARANCE'];
const GLOBAL_ARRIVAL=['LANDING','IMMIGRATION_ARRIVAL','BAGGAGE_CLAIM','CUSTOMS','EXIT'];
const isObj=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
export function syncGlobalFlightToTravel(s){
 bindGlobalJourney(s);
 const j=s.globalJourney?.activeJourney;
 // Completed return flights are moved to history by the airport domain.
 // The canonical travel state must be closed even when activeJourney is null.
 if(!j){
  const last=s.globalJourney?.history?.at(-1);
  const completed=last?.segments?.at(-1);
  const t=s.travel;
  if(last?.status==='COMPLETED'&&completed?.id&&t?.activeTrip?.source==='global-flight'&&t.activeTrip.id===completed.id){
   commitGlobalTravelState(s,{status:'RETURNED',trip:t.activeTrip,closedDay:s.day});
   return true;
  }
  return false;
 }
 if(!Array.isArray(j.segments)||!j.segments.length)return false;
 const booking=j.segments.at(-1),legs=booking?.legs;
 if(!Array.isArray(legs)||!legs.length)return false;
 s.travel ||= {};
 const t=s.travel;
 const original=t.activeTrip;
 // Never overwrite an unrelated active original ticket.
 if(original&&original.source!=='global-flight'&&original.id!==booking.id){
  t.airportMergePhase1 ||= {version:1,conflicts:[],stagedGlobalTrip:null};
  t.airportMergePhase1.conflicts ||= [];
  if(!t.airportMergePhase1.conflicts.some(c=>c.code==='PHASE4_ACTIVE_TRIP_COLLISION'&&c.globalTripId===booking.id))
   t.airportMergePhase1.conflicts.push({code:'PHASE4_ACTIVE_TRIP_COLLISION',legacyTripId:original.id,globalTripId:booking.id});
  return false;
 }
 const idx=Math.max(0,Math.min(legs.length-1,booking.airport?.legIndex??0));
 const prev=isObj(original)?original:{};
 const segments=legs.map((leg,i)=>{
  const existing=prev.segments?.find(x=>x.id===`${booking.id}:leg:${i}`)||{};
  const active=i===idx,airport=active?booking.airport||{}:{};
  return {...existing,id:`${booking.id}:leg:${i}`,bookingId:booking.id,
   from:leg.from,to:leg.to,departureDay:leg.departureDay,departureMinute:leg.departureMinute,
   arrivalDay:leg.arrivalDay,arrivalMinute:leg.arrivalMinute,durationMinutes:leg.durationMinutes,
   airlineId:leg.airlineId,airlineName:leg.airlineName,flightNumber:leg.flightNumber,
   aircraft:leg.aircraft,captain:leg.captain,firstOfficer:leg.firstOfficer,
   departureSteps:active?[...(airport.departureCompleted||[])]:existing.departureSteps||[],
   arrivalSteps:active?(airport.arrivalCompleted||[]).map(x=>ARRIVAL[GLOBAL_ARRIVAL.indexOf(x)]).filter(Boolean):existing.arrivalSteps||[],
   status:active?airport.status||booking.status:existing.status||'BOOKED',source:'global-flight'};
 });
 // Save completed segments when moving to next leg, without discarding old progress.
 if(idx>0)for(let i=0;i<idx;i++){
  segments[i].status='COMPLETE';segments[i].departureSteps=[...DEPARTURE];segments[i].arrivalSteps=[...ARRIVAL];
 }
 t.activeTrip={...prev,id:booking.id,source:'global-flight',from:legs[0].from,to:legs.at(-1).to,
  departureDay:legs[0].departureDay,segments,activeSegmentIndex:idx,
  airportCompleted:[...(booking.airport?.departureCompleted||[])],
  arrivalCompleted:(booking.airport?.arrivalCompleted||[]).map(x=>ARRIVAL[GLOBAL_ARRIVAL.indexOf(x)]).filter(Boolean),
  globalJourneyId:j.id,globalStatus:j.status,
  // All direct and connecting legs share the same canonical segment array.
  // Legacy global airport data is retained solely for compatibility.
  isTransit:legs.length>1,segmentCount:legs.length};
 // One canonical status commit. The historical itinerary is a compatibility
 // payload for Global airport UI; it must not independently determine game location.
 const gs=j.status;
 const statusMap={BOOKED:'BOOKED',AT_AIRPORT:'AT_AIRPORT',READY_TO_FLY:'AT_AIRPORT',
  IN_FLIGHT:'IN_FLIGHT',TRANSIT:'TRANSIT',AT_DESTINATION:'ABROAD',
  NO_SHOW:'AT_HOME',MISSED:'AT_HOME',COMPLETED:'RETURNED'};
 let status=statusMap[gs];
 if(booking.airport?.status==='ARRIVAL')status='IN_FLIGHT';
 if(status){
  let location=t.location;
  const airportCode=(gs==='AT_DESTINATION'||gs==='TRANSIT'||gs==='BOOKED')?(j.currentAirport||legs[idx]?.from):
   (idx>0&&['BOOKED','AT_AIRPORT','READY_TO_FLY','IN_FLIGHT'].includes(gs)?legs[idx].from:null);
  if(airportCode&&airportCode!=='KUL')location={country:AIRPORT_COUNTRY[airportCode]||'KR',city:airportCode,airport:airportCode};
  if(gs==='BOOKED'&&airportCode&&airportCode!=='KUL')status='ABROAD';
  if(gs==='NO_SHOW'||gs==='MISSED'){
   if(j.currentAirport&&j.currentAirport!=='KUL'){
    // Missed onward leg: player remains abroad, but the itinerary is closed.
    // Keep the ticket as a historical record, not an active flight.
    status='ABROAD';location={country:AIRPORT_COUNTRY[j.currentAirport]||'KR',city:j.currentAirport,airport:j.currentAirport};
    t.activeTrip.status='NO_SHOW';
   }else status='AT_HOME';
  }
  if(gs==='COMPLETED')status='RETURNED';
  commitGlobalTravelState(s,{status,trip:t.activeTrip,location,closedDay:s.day});
 }
 t.airportMergePhase1 ||= {version:1,conflicts:[],stagedGlobalTrip:null};
 t.airportMergePhase1.phase4SyncedBookingId=booking.id;
 return true;
}
export function completeGlobalFlightLanding(s,advance){
 bindGlobalJourney(s);
 const j=s.globalJourney?.activeJourney,booking=j?.segments?.at(-1);
 if(!booking)throw Error('Tiada penerbangan aktif');
 const idx=booking.airport?.legIndex||0,leg=booking.legs?.[idx];
 if(!leg||booking.airport?.status!=='IN_FLIGHT')throw Error('Penerbangan tidak aktif');
 const key=`${booking.id}:leg:${idx}:landed`;
 s.travel ||= {};s.travel.airportMergePhase4 ||= {landings:[]};
 const events=s.travel.airportMergePhase4.landings;
 if(events.includes(key))return false;
 for(let i=0;i<3;i++)s.travel.globalJourneyData=advance(s.travel.globalJourneyData);
 events.push(key);
 // Clock advances by elapsed flight time, once. Arrival clock is expressed in the game's
 // day/hour fields; minute remainder is recorded without changing global clock semantics.
 const duration=Number(leg.durationMinutes);
 if(!Number.isSafeInteger(duration)||duration<=0)throw Error('Tempoh penerbangan dalam tiket tidak sah');
 const current=Math.max(0,Number(s.hour)||0)*60;
 const total=current+duration;
 s.day+=Math.floor(total/1440);
 s.hour=Math.floor((total%1440)/60);
 s.travel.airportMergePhase4.lastFlight={key,durationMinutes:duration,minuteRemainder:total%60,
  from:leg.from,to:leg.to,landedGameDay:s.day,landedHour:s.hour};
 syncGlobalFlightToTravel(s);
 return true;
}

// Phase 6: one idempotent landing entry point for both legacy and global flights.
// The two ticket formats remain readable for backwards-compatible saves.
export function completeUnifiedFlightLanding(state,{kind,advanceGlobal,finishLegacyReturn,finishLegacyOutbound}={}){
 state.travel ||= {};
 state.travel.processedEvents ||= [];
 if(kind==='global'){
  const j=state.globalJourney?.activeJourney;
  const b=j?.segments?.at(-1);
  const idx=b?.airport?.legIndex||0;
  if(!b||b.airport?.status!=='IN_FLIGHT')return false;
  const key=`landing:global:${b.id}:${idx}`;
  if(state.travel.processedEvents.includes(key))return false;
  if(!completeGlobalFlightLanding(state,advanceGlobal))return false;
  state.travel.processedEvents.push(key);
  return true;
 }
 if(kind!=='legacy')throw Error('Jenis penerbangan tidak sah');
 const trip=state.travel.activeTrip;
 if(state.travel.status!=='IN_FLIGHT'||!trip)return false;
 const returning=!!state.travel.returnJourney;
 const ticket=returning?trip.returnFlight:trip;
 if(!ticket||ticket.aerotraceCompleted)return false;
 const key=`landing:legacy:${trip.id}:${returning?'return':'outbound'}`;
 if(state.travel.processedEvents.includes(key))return false;
 const previous=ticket.aerotraceCompleted;
 ticket.aerotraceCompleted=true;
 try{
  ticket.flightPhase='LANDED';
  if(returning)finishLegacyReturn(state);else finishLegacyOutbound(state);
  state.travel.processedEvents.push(key);
  return true;
 }catch(error){ticket.aerotraceCompleted=previous;throw error;}
}
