import assert from 'node:assert/strict';
import {syncGlobalFlightToTravel,bindGlobalJourney} from './airport-merge-phase4.js';
import {validateTravel} from './travel-foundation.js';
const make=(codes,status='BOOKED',idx=0)=>{
 const legs=codes.slice(0,-1).map((from,i)=>({from,to:codes[i+1],departureDay:i+1,departureMinute:600,durationMinutes:120}));
 const booking={id:'flex-1',legs,airport:{legIndex:idx,status:status==='AT_DESTINATION'?'COMPLETE':status,departureCompleted:[],arrivalCompleted:[]}};
 const j={id:'journey-1',status,currentAirport:status==='TRANSIT'?codes[idx]:status==='AT_DESTINATION'?codes.at(-1):codes[0],segments:[booking]};
 return {day:1,hour:10,character:{city:'Kuala Lumpur'},travel:{version:1,status:'AT_HOME',location:{country:'MY',cityId:'Kuala Lumpur'},activeTrip:null,trips:[],processedEvents:[],returnJourney:false},globalJourney:{activeJourney:j,history:[]}};
};
{
 const s=make(['KUL','ICN']);assert.equal(syncGlobalFlightToTravel(s),true);assert.equal(s.travel.status,'BOOKED');assert.equal(s.travel.activeTrip.segments.length,1);assert.equal(s.travel.activeTrip.isTransit,false);assert.equal(Object.keys(s).includes('globalJourney'),false);validateTravel(s);
}
{
 const s=make(['KUL','DOH','LHR'],'TRANSIT',1);assert.equal(syncGlobalFlightToTravel(s),true);assert.equal(s.travel.status,'TRANSIT');assert.equal(s.travel.activeTrip.activeSegmentIndex,1);assert.equal(s.travel.activeTrip.segments[0].status,'COMPLETE');assert.equal(s.travel.activeTrip.segments[1].from,'DOH');assert.equal(s.travel.location.country,'QA');assert.equal(s.travel.activeTrip.isTransit,true);validateTravel(s);
 s.globalJourney.activeJourney.status='AT_AIRPORT';s.globalJourney.activeJourney.segments[0].airport.status='AT_AIRPORT';syncGlobalFlightToTravel(s);assert.equal(s.travel.status,'AT_AIRPORT');assert.equal(s.travel.location.country,'QA');validateTravel(s);
}
{
 const s=make(['KUL','ICN'],'AT_DESTINATION');syncGlobalFlightToTravel(s);assert.equal(s.travel.status,'ABROAD');assert.equal(s.travel.location.country,'KR');validateTravel(s);
}
{
 const s=make(['KUL','DOH','KUL'],'TRANSIT',1);syncGlobalFlightToTravel(s);const booking=s.globalJourney.activeJourney.segments[0];s.globalJourney.history.push({...s.globalJourney.activeJourney,status:'COMPLETED'});s.globalJourney.activeJourney=null;assert.equal(syncGlobalFlightToTravel(s),true);assert.equal(s.travel.status,'RETURNED');assert.equal(s.travel.activeTrip,null);assert.equal(s.travel.trips.length,1);assert.equal(syncGlobalFlightToTravel(s),false);validateTravel(s);
}
{
 const s=make(['KUL','ICN']);s.travel.activeTrip={id:'legacy',source:'legacy'};assert.equal(syncGlobalFlightToTravel(s),false);assert.equal(s.travel.activeTrip.id,'legacy');
}
console.log('PASS A2/A3/A4: canonical storage, direct, transit, transitions, arrival, return, idempotency, collision');
