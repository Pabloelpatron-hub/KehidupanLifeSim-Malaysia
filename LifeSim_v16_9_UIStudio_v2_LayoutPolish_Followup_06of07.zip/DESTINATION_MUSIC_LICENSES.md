# Destination Music Licenses

Baseline: Kehidupan_LifeSim_v12.1.zip. Verification date: 15 November 2026.

All 30 tracks are external recordings published by Kevin MacLeod on Incompetech. Each individual source page was opened in Cloud Browser and displayed the track-specific attribution with Creative Commons Attribution 4.0. The official license permits commercial use, adaptation and redistribution, including bundling in this game, provided attribution is retained.

License: https://creativecommons.org/licenses/by/4.0/
Licensor licensing information: https://incompetech.com/music/royalty-free/licenses/

Required attribution appears in Music Credits inside each destination page and below. Keep these credits and links when redistributing the game. No endorsement by the creator is implied. Do not impose additional restrictions on these CC BY recordings.

Modifications: full-length recordings transcoded to stereo MP3, 44.1 kHz, 160 kbps; loudness adjusted to a background listening target. No excerpts, generated replacements or added melodies. Original titles retained.

Selection follows the user’s relaxed destination-vibe requirement. These are atmosphere choices, not a claim that every recording is an authentic local tradition. Instrument/mood selection was based on the composer’s catalogue. No claim is made that all recordings were personally auditioned.

| Destination | Track | Creator / recording | Composition | Source | Exact license | Bundling permission |
|---|---|---|---|---|---|---|
| Singapore | Airport Lounge | Kevin MacLeod | Kevin MacLeod | [Original source](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100806) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Yes, with attribution retained |
| Bangkok | Dream Culture | Kevin MacLeod | Kevin MacLeod | [Original source](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1300046) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Yes, with attribution retained |
| Jakarta | Mystic Force | Kevin MacLeod | Kevin MacLeod | [Original source](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1500060) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Yes, with attribution retained |
| Manila | Carefree | Kevin MacLeod | Kevin MacLeod | [Original source](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1400037) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Yes, with attribution retained |
| Ho Chi Minh City | Easy Lemon | Kevin MacLeod | Kevin MacLeod | [Original source](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1200076) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Yes, with attribution retained |
| Phnom Penh | Nightdreams | Kevin MacLeod | Kevin MacLeod | [Original source](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1700054) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Yes, with attribution retained |
| Vientiane | Healing | Kevin MacLeod | Kevin MacLeod | [Original source](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1200048) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Yes, with attribution retained |
| Yangon | Enchanted Journey | Kevin MacLeod | Kevin MacLeod | [Original source](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100799) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Yes, with attribution retained |
| Bandar Seri Begawan | Water Lily | Kevin MacLeod | Kevin MacLeod | [Original source](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1400035) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Yes, with attribution retained |
| Seoul | Reawakening | Kevin MacLeod | Kevin MacLeod | [Original source](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1400017) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Yes, with attribution retained |
| Tokyo | Ishikari Lore | Kevin MacLeod | Kevin MacLeod | [Original source](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100192) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Yes, with attribution retained |
| Beijing | Shenyang | Kevin MacLeod | Kevin MacLeod | [Original source](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1600066) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Yes, with attribution retained |
| Taipei | Cattails | Kevin MacLeod | Kevin MacLeod | [Original source](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100743) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Yes, with attribution retained |
| Hong Kong | Night on the Docks - Sax | Kevin MacLeod | Kevin MacLeod | [Original source](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100137) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Yes, with attribution retained |
| New Delhi | Jalandhar | Kevin MacLeod | Kevin MacLeod | [Original source](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1400018) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Yes, with attribution retained |
| Dhaka | Dhaka | Kevin MacLeod | Kevin MacLeod | [Original source](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1400003) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Yes, with attribution retained |
| Colombo | Vadodora Chill Mix | Kevin MacLeod | Kevin MacLeod | [Original source](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1400050) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Yes, with attribution retained |
| Kathmandu | That Zen Moment | Kevin MacLeod | Kevin MacLeod | [Original source](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN2400001) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Yes, with attribution retained |
| Malé | Bossa Antigua | Kevin MacLeod | Kevin MacLeod | [Original source](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1700069) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Yes, with attribution retained |
| Dubai | Ibn Al-Noor | Kevin MacLeod | Kevin MacLeod | [Original source](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100706) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Yes, with attribution retained |
| Doha | Desert City | Kevin MacLeod | Kevin MacLeod | [Original source](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100564) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Yes, with attribution retained |
| Jeddah | Tabuk | Kevin MacLeod | Kevin MacLeod | [Original source](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100818) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Yes, with attribution retained |
| Istanbul | Mystery Bazaar | Kevin MacLeod | Kevin MacLeod | [Original source](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1700005) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Yes, with attribution retained |
| London | Almost New | Kevin MacLeod | Kevin MacLeod | [Original source](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1800008) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Yes, with attribution retained |
| Paris | Duet Musette | Kevin MacLeod | Kevin MacLeod | [Original source](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100250) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Yes, with attribution retained |
| Frankfurt | Prelude in C (BWV 846) | Kevin MacLeod | Johann Sebastian Bach | [Original source](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100689) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Yes, with attribution retained |
| Amsterdam | Backbay Lounge | Kevin MacLeod | Kevin MacLeod | [Original source](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1700068) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Yes, with attribution retained |
| New York | Night in Venice | Kevin MacLeod | Kevin MacLeod | [Original source](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1900056) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Yes, with attribution retained |
| Sydney | Clear Air | Kevin MacLeod | Kevin MacLeod | [Original source](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100626) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Yes, with attribution retained |
| Auckland | Windswept | Kevin MacLeod | Kevin MacLeod | [Original source](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100757) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Yes, with attribution retained |

## Complete attribution and destination mapping

### Singapore (SIN)

"Airport Lounge" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100806
ISRC: USUAN1100806
File: `assets/audio/destinations/singapore.mp3`
Duration: 307.70 seconds. Full decode: PASS.
SHA-256: `811613a70c09a8e31de3f08484dd8858257e35797ddcc109a655a24d6242f84a`
Vibe: Lounge metropolitan yang ringan; piano elektrik, vibraphone dan bass.

### Bangkok (BKK)

"Dream Culture" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1300046
ISRC: USUAN1300046
File: `assets/audio/destinations/bangkok.mp3`
Duration: 214.39 seconds. Full decode: PASS.
SHA-256: `6f7b7d6bc7381c0d7c76eb601e5c494f29ad9658683e057b05779e0b3920ab18`
Vibe: Piano berirama dan perkusi santai untuk suasana bandar, kafe dan sungai.

### Jakarta (CGK)

"Mystic Force" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1500060
ISRC: USUAN1500060
File: `assets/audio/destinations/jakarta.mp3`
Duration: 223.82 seconds. Full decode: PASS.
SHA-256: `da5faae88c65a09a97aa87b1cd0e904061b54e0dc960dc54a3e61c6890a94919`
Vibe: Warna gamelan dalam susunan sinematik kontemporari.

### Manila (MNL)

"Carefree" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1400037
ISRC: USUAN1400037
File: `assets/audio/destinations/manila.mp3`
Duration: 205.17 seconds. Full decode: PASS.
SHA-256: `fbc14a3c6126844e545a55d2e54e9581819d00460ceaae49036acfc85ab0cbd5`
Vibe: Petikan gitar dan ukulele ceria untuk suasana bandar kepulauan.

### Ho Chi Minh City (SGN)

"Easy Lemon" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1200076
ISRC: USUAN1200076
File: `assets/audio/destinations/ho-chi-minh-city.mp3`
Duration: 126.41 seconds. Full decode: PASS.
SHA-256: `74cb41abf1cba7c714990c47374408563e084c88e68aaa35ceb59d471f7d08ad`
Vibe: Gitar, marimba dan celesta yang hangat untuk suasana kafe bandar.

### Phnom Penh (PNH)

"Nightdreams" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1700054
ISRC: USUAN1700054
File: `assets/audio/destinations/phnom-penh.mp3`
Duration: 395.65 seconds. Full decode: PASS.
SHA-256: `a50e91ac698fe78a0f86bf6d370bd8e831ebd95152695e3ef97ba6c2b0ddc38f`
Vibe: Melodi hang drum dan perkusi perlahan untuk suasana warisan dan sungai.

### Vientiane (VTE)

"Healing" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1200048
ISRC: USUAN1200048
File: `assets/audio/destinations/vientiane.mp3`
Duration: 520.10 seconds. Full decode: PASS.
SHA-256: `a4ddb6c9f8e32a47ed5fe30fd418b0858fbcb910c7255e11c6ac505c151dc922`
Vibe: Flute pentatonik dan gitar yang tenang untuk suasana santai tepi Mekong.

### Yangon (RGN)

"Enchanted Journey" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100799
ISRC: USUAN1100799
File: `assets/audio/destinations/yangon.mp3`
Duration: 269.58 seconds. Full decode: PASS.
SHA-256: `466c7d5c8fa26ddfc3d678e2e4c76a040b247ce3e2f66f012b6e57ae452638c7`
Vibe: Solo harp lembut untuk suasana bandar warisan; bukan rakaman saung tradisional.

### Bandar Seri Begawan (BWN)

"Water Lily" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1400035
ISRC: USUAN1400035
File: `assets/audio/destinations/bandar-seri-begawan.mp3`
Duration: 144.09 seconds. Full decode: PASS.
SHA-256: `adbac181594ecda30cd6ae0c6b84d3027ff604e68dc6380a8966366d999c4bb1`
Vibe: Piano dan cello yang halus untuk suasana bandar air yang tenang.

### Seoul (ICN)

"Reawakening" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1400017
ISRC: USUAN1400017
File: `assets/audio/destinations/seoul.mp3`
Duration: 214.10 seconds. Full decode: PASS.
SHA-256: `6772d7b1277896b297e1fd7048c93dc69713dc8f3413eee3919212d135b1bbdf`
Vibe: Piano dan cello romantik, sesuai dengan suasana sinematik bandar moden.

### Tokyo (NRT)

"Ishikari Lore" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100192
ISRC: USUAN1100192
File: `assets/audio/destinations/tokyo.mp3`
Duration: 164.10 seconds. Full decode: PASS.
SHA-256: `dea25bbeef2bc6f87072b65af84bd328845417bc6d864dd05d4aae2212a5baa0`
Vibe: Koto, flute dan perkusi berpengaruh Jepun.

### Beijing (PEK)

"Shenyang" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1600066
ISRC: USUAN1600066
File: `assets/audio/destinations/beijing.mp3`
Duration: 151.48 seconds. Full decode: PASS.
SHA-256: `5e4890ba3ae7f1eb42851de8ceac07b647771d3b44da5f7acea18508c320943d`
Vibe: Erhu, pipa dan yangqin dalam susunan berpengaruh muzik Cina.

### Taipei (TPE)

"Cattails" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100743
ISRC: USUAN1100743
File: `assets/audio/destinations/taipei.mp3`
Duration: 159.06 seconds. Full decode: PASS.
SHA-256: `7a889858216cf58a79c749d79a0991e2e15d6443a544b2bb7cc199eae423705c`
Vibe: Erhu bersama gitar dan accordion dalam fusion akustik lembut.

### Hong Kong (HKG)

"Night on the Docks - Sax" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100137
ISRC: USUAN1100137
File: `assets/audio/destinations/hong-kong.mp3`
Duration: 174.08 seconds. Full decode: PASS.
SHA-256: `6c59ea7c8af3acb351c09b3c08f723d59b6a4ba70d358cb17943e8b4584fc1eb`
Vibe: Sax tenor dan piano elektrik untuk suasana pelabuhan serta malam metropolitan.

### New Delhi (DEL)

"Jalandhar" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1400018
ISRC: USUAN1400018
File: `assets/audio/destinations/new-delhi.mp3`
Duration: 248.97 seconds. Full decode: PASS.
SHA-256: `66cd3e4be21e996a5ce92e0e7ed1f810fd4b66c39014e4db967cdde0d1e3a358`
Vibe: Sitar, bass dan perkusi berpengaruh India.

### Dhaka (DAC)

"Dhaka" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1400003
ISRC: USUAN1400003
File: `assets/audio/destinations/dhaka.mp3`
Duration: 248.27 seconds. Full decode: PASS.
SHA-256: `ee2f5afa078df195c285f7cc5ed667e602a3a61fcc9b67325a549dd6d7252ee7`
Vibe: Sarod dan dilruba untuk suasana melodi Asia Selatan.

### Colombo (CMB)

"Vadodora Chill Mix" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1400050
ISRC: USUAN1400050
File: `assets/audio/destinations/colombo.mp3`
Duration: 222.77 seconds. Full decode: PASS.
SHA-256: `46ed98bde9db9455004f96e355b2c21e33592fdec3b50a4be32ceac8236cad0a`
Vibe: Fusion Asia Selatan dengan sitar, bansuri dan perkusi; bukan tradisi Sri Lanka asli.

### Kathmandu (KTM)

"That Zen Moment" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN2400001
ISRC: USUAN2400001
File: `assets/audio/destinations/kathmandu.mp3`
Duration: 601.84 seconds. Full decode: PASS.
SHA-256: `e92ce6edf7fbb45153ec0f344c31739efb57f40109683fb21520103d34ac823a`
Vibe: Tongue drum dan strings meditatif untuk suasana gunung yang tenang.

### Malé (MLE)

"Bossa Antigua" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1700069
ISRC: USUAN1700069
File: `assets/audio/destinations/male.mp3`
Duration: 283.38 seconds. Full decode: PASS.
SHA-256: `f9faee3dec47a9180fc4d8d5bf80247d8d2acb605b7ce66fb4e85f6aff31473c`
Vibe: Gitar dan jazz santai untuk percutian pulau serta pesisir.

### Dubai (DXB)

"Ibn Al-Noor" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100706
ISRC: USUAN1100706
File: `assets/audio/destinations/dubai.mp3`
Duration: 218.28 seconds. Full decode: PASS.
SHA-256: `310f9503948bdd008efbdd717e88a424b2e8b174b342445b31f9822192d906cc`
Vibe: Susunan strings dan perkusi sinematik berpengaruh Arab.

### Doha (DOH)

"Desert City" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100564
ISRC: USUAN1100564
File: `assets/audio/destinations/doha.mp3`
Duration: 89.39 seconds. Full decode: PASS.
SHA-256: `bd5472d2d00fc06f9fa7ed5ad873f0a9e084e216ba1e71f1a81bad95ca0211b4`
Vibe: Dulcimer dan perkusi Timur Tengah yang santai.

### Jeddah (JED)

"Tabuk" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100818
ISRC: USUAN1100818
File: `assets/audio/destinations/jeddah.mp3`
Duration: 158.59 seconds. Full decode: PASS.
SHA-256: `e19db8ba82016e710a90937352d3aa87ffc3fab88493a0e8b0663252c41dd4a2`
Vibe: Flute, strings dan perkusi berpengaruh Timur Tengah.

### Istanbul (IST)

"Mystery Bazaar" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1700005
ISRC: USUAN1700005
File: `assets/audio/destinations/istanbul.mp3`
Duration: 158.48 seconds. Full decode: PASS.
SHA-256: `8ebf71ada44cc04d35a089437918d5e81f4c248e8b76f1ccf1f75fa458f62871`
Vibe: Santur, strings dan perkusi untuk suasana bazar bersejarah.

### London (LHR)

"Almost New" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1800008
ISRC: USUAN1800008
File: `assets/audio/destinations/london.mp3`
Duration: 202.58 seconds. Full decode: PASS.
SHA-256: `da1ab4b512610b0e93c92889bcf87b8c3cdfecd50fa22370a9e7bf3bc7d58316`
Vibe: Piano dan bass yang elegan untuk suasana taman dan bandar British.

### Paris (CDG)

"Duet Musette" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100250
ISRC: USUAN1100250
File: `assets/audio/destinations/paris.mp3`
Duration: 140.09 seconds. Full decode: PASS.
SHA-256: `2767d29b5fbb836592e904f21379deff4630185ad912e420fde477668e4f9778`
Vibe: Duet accordion dan violin untuk suasana kafe Eropah.

### Frankfurt (FRA)

"Prelude in C (BWV 846)" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100689
ISRC: USUAN1100689
File: `assets/audio/destinations/frankfurt.mp3`
Duration: 178.73 seconds. Full decode: PASS.
SHA-256: `1166c731cc882dea5d01b066b0f1ceb2e6bc43ecdb41a7c207bfe36e8073f2d9`
Vibe: Prelude Bach pada piano, sesuai dengan pengaruh klasik Jerman.

### Amsterdam (AMS)

"Backbay Lounge" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1700068
ISRC: USUAN1700068
File: `assets/audio/destinations/amsterdam.mp3`
Duration: 266.58 seconds. Full decode: PASS.
SHA-256: `719758028fc4407f4cba611fb4e686664782055b77c1ffcddf89ff5a64349bcf`
Vibe: Jazz gitar dan piano yang santai untuk suasana kafe terusan.

### New York (JFK)

"Night in Venice" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1900056
ISRC: USUAN1900056
File: `assets/audio/destinations/new-york.mp3`
Duration: 218.17 seconds. Full decode: PASS.
SHA-256: `90b60764ea6f3b3fc16049cc24a4b35ed77865d1969fb156df958eddee108907`
Vibe: Jazz alto sax, piano, bass dan drums untuk suasana malam bandar.

### Sydney (SYD)

"Clear Air" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100626
ISRC: USUAN1100626
File: `assets/audio/destinations/sydney.mp3`
Duration: 183.82 seconds. Full decode: PASS.
SHA-256: `ecf49d095c062c50afd7546285f9ec9525e7f306143980e044d0fc0bd3e22605`
Vibe: Gitar akustik dan piano hangat untuk suasana pesisir.

### Auckland (AKL)

"Windswept" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100757
ISRC: USUAN1100757
File: `assets/audio/destinations/auckland.mp3`
Duration: 208.38 seconds. Full decode: PASS.
SHA-256: `c8ba60f916377072143ae3853ced2ea4a597d74fd25927f033ac7bd2d13c00a1`
Vibe: Gitar dan strings tenang untuk suasana alam serta pelabuhan; tiada dakwaan muzik Māori.
