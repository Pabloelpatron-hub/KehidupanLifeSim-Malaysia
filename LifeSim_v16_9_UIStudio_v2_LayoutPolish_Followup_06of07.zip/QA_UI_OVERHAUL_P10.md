# P10 Prestige checkpoint
Baseline: P9.
Added first successful First Class ticket purchase achievement to legacy and global flight checkout paths. Added cash-only luxury vehicle purchase achievement at >= RM1,000,000 (price is in sen). Achievement recording occurs inside successful game mutation; no new financial charges.
Preserved airport styling and gallery from P7-P9.
44 existing automated tests passed. JavaScript syntax checked. Dedicated end-to-end first-class and vehicle transaction tests NOT yet run; Safari visual tests NOT run.
Still pending: boarding achievement, Executive Suite, Michelin unique restaurant award, luxury vehicle purchases via financed route after approval, and full per-event cinematic popups. This is not final.
