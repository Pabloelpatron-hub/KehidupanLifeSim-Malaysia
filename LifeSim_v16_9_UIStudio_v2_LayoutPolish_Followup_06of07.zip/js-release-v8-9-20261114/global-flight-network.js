// Global Travel Network V1 / Phase 1: standalone route search & fare quote.
// Simulated airline offerings, NOT a live schedule. No money is debited here.
const rows=[
['KUL','Kuala Lumpur','MY','MYR'],['SIN','Singapore','SG','SGD'],['BKK','Bangkok','TH','THB'],['CGK','Jakarta','ID','IDR'],['MNL','Manila','PH','PHP'],['SGN','Ho Chi Minh City','VN','VND'],['PNH','Phnom Penh','KH','KHR'],['VTE','Vientiane','LA','LAK'],['RGN','Yangon','MM','MMK'],['BWN','Bandar Seri Begawan','BN','BND'],['ICN','Seoul','KR','KRW'],['NRT','Tokyo','JP','JPY'],['PEK','Beijing','CN','CNY'],['TPE','Taipei','TW','TWD'],['HKG','Hong Kong','HK','HKD'],['DEL','New Delhi','IN','INR'],['DAC','Dhaka','BD','BDT'],['KTM','Kathmandu','NP','NPR'],['CMB','Colombo','LK','LKR'],['MLE','Malé','MV','MVR'],['DXB','Dubai','AE','AED'],['DOH','Doha','QA','QAR'],['JED','Jeddah','SA','SAR'],['IST','Istanbul','TR','TRY'],['LHR','London','GB','GBP'],['CDG','Paris','FR','EUR'],['FRA','Frankfurt','DE','EUR'],['AMS','Amsterdam','NL','EUR'],['SYD','Sydney','AU','AUD'],['AKL','Auckland','NZ','NZD'],['JFK','New York','US','USD']];
export const GLOBAL_AIRPORTS=Object.freeze(Object.fromEntries(rows.map(([code,city,country,currency])=>[code,Object.freeze({code,city,country,currency})])));
const airlines=[['MH','Malaysia Airlines',1.13,['economy','business']],['AK','AirAsia',0.76,['economy']],['D7','AirAsia X',0.82,['economy','business']],['SQ','Singapore Airlines',1.3,['economy','business','first']],['TR','Scoot',0.82,['economy']],['TG','Thai Airways',1.13,['economy','business']],['GA','Garuda Indonesia',1.12,['economy','business']],['BI','Royal Brunei Airlines',1.06,['economy','business']],['VN','Vietnam Airlines',1.04,['economy','business']],['PR','Philippine Airlines',1.08,['economy','business']],['KE','Korean Air',1.25,['economy','business']],['OZ','Asiana Airlines',1.16,['economy','business']],['JL','Japan Airlines',1.24,['economy','business']],['NH','ANA',1.27,['economy','business']],['CX','Cathay Pacific',1.22,['economy','business']],['BR','EVA Air',1.18,['economy','business']],['CI','China Airlines',1.1,['economy','business']],['CA','Air China',1.07,['economy','business']],['AI','Air India',1.03,['economy','business']],['BG','Biman Bangladesh Airlines',0.99,['economy','business']],['UL','SriLankan Airlines',1.02,['economy','business']],['EK','Emirates',1.35,['economy','business','first']],['QR','Qatar Airways',1.31,['economy','business']],['SV','Saudia',1.08,['economy','business']],['TK','Turkish Airlines',1.2,['economy','business']],['BA','British Airways',1.25,['economy','business']],['AF','Air France',1.23,['economy','business']],['LH','Lufthansa',1.24,['economy','business']],['KL','KLM',1.22,['economy','business']],['QF','Qantas',1.25,['economy','business']],['NZ','Air New Zealand',1.19,['economy','business']],['UA','United Airlines',1.21,['economy','business']],['DL','Delta Air Lines',1.21,['economy','business']]];
export const GLOBAL_AIRLINES=Object.freeze(Object.fromEntries(airlines.map(([id,name,tier,classes])=>[id,Object.freeze({id,name,tier,classes:Object.freeze(classes)})])));
const edges=[];
function add(a,b,ids,km){if(!GLOBAL_AIRPORTS[a]||!GLOBAL_AIRPORTS[b])throw Error('Airport registry mismatch');for(const [from,to] of [[a,b],[b,a]])edges.push(Object.freeze({id:`${from}-${to}`,from,to,airlines:Object.freeze(ids.split(' ')),distanceKm:km}));}
// Representative game network: do not interpret as verified operating schedules.
for(const [to,ids,km] of [
['SIN','MH AK SQ TR',300],['BKK','MH AK TG',1210],['CGK','MH AK GA',1130],['MNL','MH AK PR',2470],['SGN','MH AK VN',1050],['PNH','AK MH',1030],['VTE','AK',1660],['RGN','MH',1620],['BWN','MH BI AK',1490],['ICN','MH D7 KE OZ',4610],['NRT','MH D7 JL NH',5400],['PEK','MH CA',4350],['TPE','MH D7 CI BR',3220],['HKG','MH AK CX',2530],['DEL','MH AK AI',3870],['DAC','MH BG',2640],['KTM','MH',3270],['CMB','MH UL AK',2460],['MLE','MH AK',3120],['DXB','EK',5550],['DOH','QR MH',5920],['JED','MH SV',7070],['IST','TK MH',8310],['LHR','MH BA',10600],['CDG','MH AF',10400],['FRA','LH MH',9990],['AMS','KL MH',10200],['SYD','MH D7 QF',6580],['AKL','MH NZ',8750]])add('KUL',to,ids,km);
for(const [to,ids,km] of [['BKK','SQ TG TR',1430],['CGK','SQ TR GA',880],['MNL','SQ TR PR',2380],['SGN','SQ TR VN',1090],['ICN','SQ KE OZ TR',4660],['NRT','SQ JL NH TR',5350],['PEK','SQ CA',4470],['TPE','SQ BR CI TR',3230],['HKG','SQ CX TR',2570],['DEL','SQ AI',4150],['CMB','SQ UL',2750],['MLE','SQ',3400],['DXB','SQ EK',5850],['DOH','QR',6210],['IST','SQ TK',8700],['LHR','SQ BA',10850],['CDG','SQ AF',10700],['FRA','SQ LH',10300],['AMS','SQ KL',10500],['SYD','SQ QF TR',6300],['AKL','SQ NZ',8400],['JFK','SQ',15300]])add('SIN',to,ids,km);
for(const [a,b,ids,km] of [['DOH','JFK','QR',10700],['DXB','JFK','EK',11000],['IST','JFK','TK',8020],['LHR','JFK','BA',5550],['CDG','JFK','AF DL',5830],['FRA','JFK','LH UA',6200],['AMS','JFK','KL DL',5850],['NRT','JFK','JL NH UA',10800],['ICN','JFK','KE',11050],['HKG','JFK','CX',12900],['SYD','AKL','QF NZ',2160],['DOH','LHR','QR BA',5250],['DXB','LHR','EK BA',5500],['IST','LHR','TK BA',2500],['NRT','ICN','KE OZ JL NH',1260],['HKG','TPE','CX BR CI',800],['BKK','SGN','TG VN',750],['BKK','PNH','TG',540],['BKK','RGN','TG',580],['BKK','VTE','TG',520],['DEL','KTM','AI',820],['CMB','MLE','UL',770],['DXB','DOH','EK QR',380],['DXB','IST','EK',3000],['DOH','JED','QR SV',1320],['IST','CDG','TK AF',2250],['FRA','AMS','LH KL',360]])add(a,b,ids,km);
// Additional plausible simulated direct links (not claims about live schedules).
add('DEL','IST','AI TK',4550);
add('ICN','CGK','KE GA',5300);
// Direct routes are finalized after geographic augmentation below.

const AIRPORT_COORDS={"KUL":[101.7072,2.7456],"SIN":[103.9915,1.3644],"BKK":[100.7501,13.69],"CGK":[106.6559,-6.1256],"MNL":[121.0198,14.5086],"SGN":[106.652,10.819],"PNH":[104.844,11.547],"VTE":[102.563,17.988],"RGN":[96.133,16.907],"BWN":[114.928,4.944],"ICN":[126.4505,37.4602],"NRT":[140.3929,35.772],"PEK":[116.603,40.08],"TPE":[121.233,25.08],"HKG":[113.915,22.308],"DEL":[77.1,28.556],"DAC":[90.397,23.843],"KTM":[85.359,27.697],"CMB":[79.884,7.181],"MLE":[73.529,4.192],"DXB":[55.364,25.253],"DOH":[51.608,25.273],"JED":[39.156,21.68],"IST":[28.814,40.976],"LHR":[-0.4543,51.47],"CDG":[2.548,49.01],"FRA":[8.57,50.033],"AMS":[4.764,52.309],"SYD":[151.177,-33.946],"AKL":[174.785,-37.008],"JFK":[-73.779,40.641]};
// Additional simulated regional services: only short, geographically sensible hops.
// Airlines are assigned by their home airport/country or an existing endpoint service.
const HOME_AIRLINES={MY:['MH','AK'],SG:['SQ','TR'],TH:['TG'],ID:['GA'],PH:['PR'],VN:['VN'],BN:['BI'],KR:['KE','OZ'],JP:['JL','NH'],CN:['CA'],TW:['BR','CI'],HK:['CX'],IN:['AI'],BD:['BG'],LK:['UL'],AE:['EK'],QA:['QR'],SA:['SV'],TR:['TK'],GB:['BA'],FR:['AF'],DE:['LH'],NL:['KL'],AU:['QF'],NZ:['NZ'],US:['UA','DL']};
const EXISTING_PAIRS=new Set(edges.map(e=>e.id));
function registerRegionalLinks(){
 const codes=Object.keys(GLOBAL_AIRPORTS);
 for(let i=0;i<codes.length;i++)for(let j=i+1;j<codes.length;j++){
  const a=codes[i],b=codes[j],km=greatCircleKm(a,b);
  if(km>4500||km<100||EXISTING_PAIRS.has(`${a}-${b}`))continue;
  const ids=[...(HOME_AIRLINES[GLOBAL_AIRPORTS[a].country]||[]),...(HOME_AIRLINES[GLOBAL_AIRPORTS[b].country]||[])];
  if(!ids.length)ids.push('TG');
  add(a,b,[...new Set(ids)].join(' '),Math.round(km));
  EXISTING_PAIRS.add(`${a}-${b}`);EXISTING_PAIRS.add(`${b}-${a}`);
 }
}
function greatCircleKm(a,b){const p=AIRPORT_COORDS[a],q=AIRPORT_COORDS[b];if(!p||!q)return Infinity;const rad=Math.PI/180;const dLat=(q[1]-p[1])*rad,dLon=(q[0]-p[0])*rad;const h=Math.sin(dLat/2)**2+Math.cos(p[1]*rad)*Math.cos(q[1]*rad)*Math.sin(dLon/2)**2;return 12742*Math.asin(Math.min(1,Math.sqrt(h)));}
registerRegionalLinks();
// Cross-region hub corridors support geographically sensible long-haul connections.
for(const [a,b,ids] of [
 ['BWN','SYD','BI'],['PEK','AMS','CA'],['PEK','JFK','CA'],['AKL','JFK','NZ'],['DOH','CDG','QR'],['DOH','FRA','QR'],['DOH','AMS','QR'],['DXB','CDG','EK'],['DXB','FRA','EK'],['DXB','AMS','EK'],['CGK','SYD','QF'],['BKK','SYD','QF'],['MNL','SYD','QF'],['SGN','SYD','QF'],['ICN','SYD','KE'],['NRT','SYD','QF'],['BKK','DOH','QR'],['BKK','DXB','EK'],['BKK','JED','SV'],['BKK','IST','TK'],
 ['ICN','DOH','QR'],['ICN','DXB','EK'],['NRT','DOH','QR'],['NRT','DXB','EK'],
 ['DEL','DOH','QR'],['DEL','DXB','EK'],['DEL','JED','SV'],
 ['SYD','DOH','QR'],['SYD','DXB','EK'],['AKL','DOH','QR'],['AKL','DXB','EK'],
 ['PEK','DOH','QR'],['HKG','DOH','QR'],['MNL','DOH','QR'],['CGK','DOH','QR'],
 ['CMB','DOH','QR'],['DAC','DOH','QR'],['JED','LHR','SV'],['JED','CDG','SV'],
 ['IST','DEL','TK'],['IST','ICN','TK'],['IST','NRT','TK'],['IST','SYD','TK'],
 ['LHR','SYD','QF'],['LHR','AKL','NZ'],['LHR','ICN','BA'],['CDG','ICN','AF'],
 ['FRA','ICN','LH'],['AMS','ICN','KL'],['LHR','DEL','BA'],['FRA','DEL','LH']
]){if(!EXISTING_PAIRS.has(`${a}-${b}`)){add(a,b,ids,Math.round(greatCircleKm(a,b)));EXISTING_PAIRS.add(`${a}-${b}`);EXISTING_PAIRS.add(`${b}-${a}`);}}
export const GLOBAL_DIRECT_ROUTES=Object.freeze(edges);
// Keep transit corridors geographically plausible; avoid backward detours.
export function isPlausibleItinerary(from,to,legs){
 if(!legs.length||legs[0].from!==from||legs.at(-1).to!==to)return false;
 if(legs.some((leg,i)=>i&&legs[i-1].to!==leg.from))return false;
 if(legs.length===1)return true;
 const direct=greatCircleKm(from,to);
 if(!Number.isFinite(direct)||direct<2200)return false;
 const distance=legs.reduce((sum,leg)=>sum+greatCircleKm(leg.from,leg.to),0);
 const ratio=distance/direct;
 if(ratio>(direct<4500?1.18:direct<8000?1.28:1.38))return false;
 // Transit airports should advance toward destination rather than double back.
 for(let i=0;i<legs.length-1;i++){
  const stop=legs[i].to;
  if(greatCircleKm(stop,to)>direct*0.94)return false;
  if(greatCircleKm(from,stop)<250||greatCircleKm(stop,to)<250)return false;
 }
 return true;
}

const ROUTES_BY_FROM=Object.groupBy?Object.groupBy(GLOBAL_DIRECT_ROUTES,r=>r.from):Object.fromEntries(Object.keys(GLOBAL_AIRPORTS).map(a=>[a,GLOBAL_DIRECT_ROUTES.filter(r=>r.from===a)]));
export function directFlights(from,to){return (ROUTES_BY_FROM[from]||[]).filter(r=>r.to===to);}
export function searchGlobalRoutes(from,to,{maxStops=2,maxOptions=8}={}){
 if(!GLOBAL_AIRPORTS[from]||!GLOBAL_AIRPORTS[to]||from===to)throw Error('Airport tidak sah');
 if(!Number.isInteger(maxStops)||maxStops<0||maxStops>2)throw Error('Had transit tidak sah');
 const queue=[{at:from,legs:[],visited:new Set([from])}],found=[];
 while(queue.length){const cur=queue.shift();if(cur.at===to){if(isPlausibleItinerary(from,to,cur.legs))found.push({legs:cur.legs,stops:cur.legs.length-1,distanceKm:cur.legs.reduce((n,r)=>n+r.distanceKm,0)});continue;}if(cur.legs.length>maxStops)continue;
 for(const leg of ROUTES_BY_FROM[cur.at]||[]){if(cur.visited.has(leg.to))continue;queue.push({at:leg.to,legs:[...cur.legs,leg],visited:new Set([...cur.visited,leg.to])});}}
 return found.sort((a,b)=>a.stops-b.stops||a.distanceKm-b.distanceKm).slice(0,maxOptions);
}
export function quoteGlobalItinerary(itinerary,{departureDay,bookingDay,passengers=1,seatClass='economy',checkedBags=0,airlineIds=[]}={}){
 if(!itinerary?.legs?.length||!Number.isSafeInteger(departureDay)||!Number.isSafeInteger(bookingDay)||departureDay<bookingDay||departureDay>bookingDay+365)throw Error('Tarikh atau itinerary tidak sah');
 if(!Number.isInteger(passengers)||passengers<1||passengers>6||!Number.isInteger(checkedBags)||checkedBags<0||checkedBags>passengers*2)throw Error('Penumpang atau bagasi tidak sah');
 const factor=departureDay-bookingDay<=1?1.45:departureDay-bookingDay<=2?1.3:departureDay-bookingDay<=5?1.15:departureDay-bookingDay<=9?1:0.9;
 const classFactor={economy:1,business:2.9,first:5.2}[seatClass];if(!classFactor)throw Error('Kelas tidak sah');
 const legs=itinerary.legs.map((leg,i)=>{if(!GLOBAL_DIRECT_ROUTES.includes(leg))throw Error('Laluan tidak berdaftar');if(i&&itinerary.legs[i-1].to!==leg.from)throw Error('Segmen tidak bersambung');const id=airlineIds[i]||leg.airlines[0],airline=GLOBAL_AIRLINES[id];if(!leg.airlines.includes(id)||!airline?.classes.includes(seatClass))throw Error('Airline atau kelas tidak tersedia untuk laluan');const baseFareSen=Math.round((Math.max(100,leg.distanceKm)*21+24000)*airline.tier*classFactor*factor*passengers);return {routeId:leg.id,airlineId:id,airlineName:airline.name,baseFareSen};});
 const baggageSen=checkedBags*8500*legs.length,taxesSen=12500*passengers*legs.length,totalSen=legs.reduce((n,l)=>n+l.baseFareSen,0)+baggageSen+taxesSen;
 return Object.freeze({currency:'MYR',legs,totalSen,baggageSen,taxesSen,departureDay,bookingDay,passengers,seatClass,checkedBags,simulated:true});
}
