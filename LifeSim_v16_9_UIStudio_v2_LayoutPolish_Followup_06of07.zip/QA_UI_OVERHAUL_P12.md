# Prestige P12 checkpoint

Baseline: P11. No production deployment.

Changes:
- Luxury vehicle prestige achievement now records on successful JPJ ownership-transfer completion for financed purchases (and retains the existing cash-purchase achievement). Only car catalog entries qualify, price >= RM1m (100,000,000 sen). The same ID prevents repeat awards.
- First Class boarding now calls the existing `prestigeCelebration` helper, which attempts to show a prestige modal after first successful boarding, if no other modal is open.
- Removed redundant Prestige Gallery display from Investments; Gallery remains in Kehidupan Saya.
- Minor scoped gallery CSS improvements and reduced-motion consideration.

QA:
- 44 existing automated regression tests passed.
- 10 static source-integration assertions passed (not runtime end-to-end simulations).
- `node --check` passed.
- ZIP CRC integrity verified.

Limitations / pending:
- Full distinct First Class purchase vs boarding cinematic design is not finished.
- All other Tier 5 categories do not yet have reliable full-screen cinematic modals.
- `prestigeCelebration` only shows when another modal is not open, so the event may be recorded without an immediate celebration.
- No browser/iPhone Safari end-to-end transaction testing.
- Save migration and backward compatibility need dedicated tests.
- P12 is a checkpoint, not a completed Tier 5 expansion.
