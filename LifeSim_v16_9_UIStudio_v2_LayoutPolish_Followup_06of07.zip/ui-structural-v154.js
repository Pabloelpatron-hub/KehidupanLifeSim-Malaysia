/* v15.4 structural shell redesign: progressive enhancement, never touches simulation state. */
(()=>{'use strict';
const KEY='kehidupan-ui-v154-nav';
let collapsed={};try{collapsed=JSON.parse(localStorage.getItem(KEY)||'{}')||{}}catch{}
const labels={'YOUR WORLD':'KEHIDUPAN','BUILD YOUR FUTURE':'KERJAYA & KEWANGAN','LIFE ADMIN':'PENGURUSAN & DUNIA'};
function init(){
 const shell=document.querySelector('#app > .shell');if(!shell||shell.dataset.ui154==='1')return;
 shell.dataset.ui154='1';const sidebar=shell.querySelector('.sidebar'),top=shell.querySelector('.topbar'),content=shell.querySelector('.content');if(!sidebar||!top||!content)return;
 // Navigation groups are rebuilt from existing nodes, preserving their data-page and handlers.
 const headings=[...sidebar.querySelectorAll(':scope > .navlabel')];
 headings.forEach((heading,i)=>{
  const group=document.createElement('div');group.className='ui154-navgroup';group.dataset.group=String(i);
  const trigger=document.createElement('button');trigger.type='button';trigger.className='ui154-group-trigger';trigger.setAttribute('aria-expanded','true');trigger.innerHTML='<span>'+ (labels[heading.textContent.trim()]||heading.textContent.trim()) +'</span><span aria-hidden="true">⌄</span>';
  const items=document.createElement('div');items.className='ui154-group-items';
  let sibling=heading.nextElementSibling;while(sibling&&!sibling.matches('.navlabel,.sidebar-foot')){const next=sibling.nextElementSibling;items.appendChild(sibling);sibling=next;}
  heading.replaceWith(group);group.append(trigger,items);
  const active=!!items.querySelector('.navitem.active');const shut=collapsed[i]===true&&!active;
  function toggle(closed){items.hidden=closed;trigger.setAttribute('aria-expanded',String(!closed));group.classList.toggle('is-collapsed',closed);collapsed[i]=closed;try{localStorage.setItem(KEY,JSON.stringify(collapsed))}catch{}}
  toggle(shut);trigger.addEventListener('click',()=>toggle(!items.hidden));
 });
 // Contextual screen masthead: replace the old generic breadcrumb with the active destination.
 const active=sidebar.querySelector('.navitem.active');const title=active?.textContent?.replace(/\s+/g,' ').trim()||'Kehidupan';
 const crumb=top.querySelector('.breadcrumb');if(crumb){crumb.classList.add('ui154-breadcrumb');crumb.innerHTML='';const eyebrow=document.createElement('span');eyebrow.className='ui154-breadcrumb-label';eyebrow.textContent='KEHIDUPAN / SCREENPAGE';const value=document.createElement('strong');value.textContent=title;crumb.append(eyebrow,value);}
 // Mobile overview of the current screen; does not clone or move gameplay controls.
 const mast=document.createElement('div');mast.className='ui154-mast';mast.setAttribute('aria-label','Halaman semasa');
 const meta=document.createElement('div');meta.className='ui154-mast-meta';meta.textContent='RUANG PERMAINAN';
 const h=document.createElement('div');h.className='ui154-mast-title';h.textContent=title;
 const hint=document.createElement('div');hint.className='ui154-mast-hint';hint.textContent='Urus kehidupan dan keputusan anda';
 mast.append(meta,h,hint);
 const first=content.firstElementChild; if(first)content.insertBefore(mast,first);else content.append(mast);
 // Keep existing page heading accessible, without adding redundant duplicate mastheads.
 if(content.querySelector('.pagehead h1'))mast.classList.add('ui154-mast-compact');
 const bottom=shell.querySelector('.bottomnav');if(bottom){bottom.setAttribute('aria-label','Navigasi utama');bottom.querySelectorAll('button[data-page]').forEach(b=>{b.setAttribute('aria-current',b.classList.contains('active')?'page':'false')})}
}
const app=document.getElementById('app');if(!app)return;
new MutationObserver(init).observe(app,{childList:true});init();
})();
