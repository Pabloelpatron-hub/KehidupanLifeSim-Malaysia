/* v16.0: repair old/new UI interactions without changing simulation state. */
(()=>{'use strict';
const app=document.getElementById('app');if(!app)return;
const workspacePages=new Set(['business','banking','finance','assets','investments','government','documents','career']);
const labelMap={business:'Perniagaan',banking:'Perbankan',finance:'Kewangan',assets:'Aset',investments:'Pelaburan',government:'Kerajaan',documents:'Dokumen',career:'Kerjaya'};
let lastContent=null,lastPage='',pending=false;
const visible=(el)=>!!(el&&el.isConnected&&!el.closest('[hidden],dialog:not([open]),.modal:not([open])'));
function openFold(card){if(!card?.classList.contains('ui159-closed'))return;const button=card.querySelector(':scope > .ui159-fold');if(button)button.click();else{card.classList.remove('ui159-closed');}}
function setup(){
 const shell=app.querySelector(':scope > .shell');if(!shell)return;
 const content=shell.querySelector(':scope > .content');const sidebar=shell.querySelector('.sidebar');
 const page=sidebar?.querySelector('.navitem.active')?.dataset.page;
 if(!content||!page)return;
 // A changed content node is a real page transition, not a CSS-only state change.
 if(content!==lastContent||page!==lastPage){lastContent=content;lastPage=page;}
 // Navigation shortcut from v15.8 must open collapsed v15.9 sections before scrolling.
 const nav=content.querySelector('.ui158-section-index');
 if(nav&&!nav.dataset.ui160){nav.dataset.ui160='1';nav.addEventListener('click',event=>{
  const a=event.target.closest('a[href^="#"]');if(!a)return;
  let target;try{target=content.querySelector('#'+CSS.escape(decodeURIComponent(a.getAttribute('href').slice(1))))}catch{return}
  if(!target)return;openFold(target.closest('.ui159-workspace'));
  // Existing v15.8 listener runs in the same event; defer scroll until CSS reflects expansion.
  requestAnimationFrame(()=>target.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'}));
 });}
 if(!workspacePages.has(page)||content.querySelector('.seoul-screen,.airport-screen,.destination-experience'))return;
 let bar=content.querySelector(':scope > .ui160-workspace-tools');
 const panels=[...content.children].filter(el=>el.classList.contains('ui159-workspace')&&visible(el));
 if(panels.length<2){bar?.remove();return;}
 if(!bar){
  bar=document.createElement('div');bar.className='ui160-workspace-tools';bar.setAttribute('role','group');bar.setAttribute('aria-label','Kawalan ruang kerja');
  const title=document.createElement('span');title.className='ui160-workspace-label';title.textContent=labelMap[page]||'Ruang kerja';
  const actions=document.createElement('div');actions.className='ui160-workspace-actions';
  const expand=document.createElement('button');expand.type='button';expand.textContent='Buka semua';expand.dataset.action='expand';
  const collapse=document.createElement('button');collapse.type='button';collapse.textContent='Ringkaskan';collapse.dataset.action='collapse';
  actions.append(expand,collapse);bar.append(title,actions);
  const first=panels[0];first.before(bar);
  bar.addEventListener('click',event=>{
   const action=event.target.closest('button[data-action]')?.dataset.action;if(!action)return;
   const cards=[...content.children].filter(el=>el.classList.contains('ui159-workspace'));
   for(const card of cards){const closed=card.classList.contains('ui159-closed');if(action==='expand'&&closed)openFold(card);if(action==='collapse'&&!closed&&card!==cards[0])card.querySelector(':scope > .ui159-fold')?.click();}
  });
 }
 // Re-attach if a page rerender moved or replaced the panels.
 if(bar.nextElementSibling!==panels[0])panels[0].before(bar);
 // Announce the page's collapsed state without adding duplicated headings.
 const collapsed=panels.filter(el=>el.classList.contains('ui159-closed')).length;
 bar.setAttribute('aria-label',`${labelMap[page]||'Ruang kerja'}: ${panels.length-collapsed} daripada ${panels.length} panel dibuka`);
 // Old v15.9 headings are visually hidden. Give each toggle a relationship to its original heading.
 for(const [i,card] of panels.entries()){
  const btn=card.querySelector(':scope > .ui159-fold');const heading=card.querySelector(':scope > .ui159-original-heading');
  if(!btn||!heading)continue;
  if(!heading.id)heading.id=`ui160-heading-${page}-${i}`;
  btn.setAttribute('aria-describedby',heading.id);
 }
}
function schedule(){if(pending)return;pending=true;requestAnimationFrame(()=>{pending=false;setup()})}
new MutationObserver(schedule).observe(app,{childList:true,subtree:false});
// Content is replaced by the game engine, so watch shell-level structural changes too.
new MutationObserver(schedule).observe(app,{childList:true,subtree:true});
setup();
})();
