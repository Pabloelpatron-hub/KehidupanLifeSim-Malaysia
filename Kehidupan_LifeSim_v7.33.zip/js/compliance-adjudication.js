// Fictional procedural layer: not a real-world summons or a prediction of a court outcome.
import {complianceFindings,COMPLIANCE_RULES} from './compliance-penalties.js';
import {spend} from './finance.js';
const num=n=>Number.isFinite(n)&&n>=0;
export function ensureAdjudication(s){s.complianceAdjudication??={cases:[],seen:{}};const d=s.complianceAdjudication;d.cases??=[];d.seen??={};s.operationalAlerts??={seen:{},queue:[]};s.notices??=[];return d;}
function announce(s,key,title,text){const d=ensureAdjudication(s);if(d.seen[key])return;d.seen[key]=s.day+1;s.notices.unshift({day:s.day,title,text});s.operationalAlerts.queue??=[];s.operationalAlerts.queue.push({key:'adjudication:'+key,day:s.day,title,text,kind:'warning'});s.operationalAlerts.queue=s.operationalAlerts.queue.slice(-80);s.notices=s.notices.slice(0,100);}
function record(s,c,type,detail){c.events.push({day:s.day,type,detail});}
export function adjudicationCases(s){return ensureAdjudication(s).cases.slice().reverse();}
export function reportObservedOffence(s,rule,subject,reference=''){const d=ensureAdjudication(s),r=COMPLIANCE_RULES[rule];if(!r)throw Error('Kategori kesalahan tidak diketahui');const key=`observed:${rule}:${reference||subject}:${s.day}`;if(d.cases.some(c=>c.id===key))return null;const c={id:key,rule,agency:r.agency,subject,reference,day:s.day,status:'investigation',evidence:'Aktiviti dikesan dalam simulasi; belum diputuskan bersalah',evidenceType:'observed-activity',evidenceDay:s.day,deadline:s.day+7,events:[],fineRM:0};record(s,c,'observed','Pemeriksaan aktiviti');d.cases.push(c);announce(s,key+':opened',`PEMERIKSAAN ${r.agency}`,`${subject}: aktiviti memerlukan dokumen sah. Kes dalam siasatan, belum ada sabitan.`);return c;}
export function scanAdjudication(s){const d=ensureAdjudication(s),findings=complianceFindings(s);for(const c of d.cases){if(['closed','withdrawn','paid','court-final'].includes(c.status))continue;
 if(c.status==='investigation'&&s.day>c.deadline){c.status='notice';c.deadline=s.day+7;record(s,c,'notice','Notis memberi peluang membetulkan atau mencabar kes');announce(s,c.id+':notice','NOTIS SIASATAN — '+c.agency,`${c.subject}: tindakan diperlukan sebelum Hari ${c.deadline+1}.`);}
 else if(c.status==='notice'&&s.day>c.deadline){c.status='hearing';c.deadline=s.day+14;record(s,c,'hearing','Kes disenaraikan untuk pendengaran simulasi');announce(s,c.id+':hearing','PENDENGARAN KES — '+c.agency,`${c.subject}: pilih pembelaan atau akui fakta kes dalam Urusan Kerajaan.`);}
 else if(c.status==='appeal-pending'&&s.day>=c.deadline){c.status='appeal-ready';record(s,c,'appeal-ready','Keputusan rayuan boleh dimuktamadkan');announce(s,c.id+':appeal-ready','KEPUTUSAN RAYUAN TERSEDIA',`${c.subject}: semak keputusan rayuan dalam Urusan Kerajaan.`);}
 if(c.status==='investigation'&&!c.reference&&['ssm','premises','food'].includes(c.rule)&&!findings.some(f=>f.rule===c.rule&&f.name===c.subject)){c.status='closed';record(s,c,'remedied','Pematuhan dipulihkan; tiada keputusan mahkamah');announce(s,c.id+':closed','KES PEMATUHAN DITUTUP',`${c.subject}: isu diselesaikan sebelum tindakan lanjut.`);}
 }d.cases=d.cases.slice(-250);return d.cases;}
export function offenceRemedied(s,c){
 const b=(s.businesses||[]).find(x=>x.id===c.reference||x.name===c.subject);
 if(c.rule==='ssm')return !!b&&b.structure==='enterprise'&&b.registeredUntil>=s.day;
 if(c.rule==='premises')return !!b&&b.licenceUntil>=s.day;
 if(c.rule==='food')return (s.documents||[]).some(d=>d.business===(b?.id||c.reference?.split(':')[0])&&/food premises|pendaftaran premis makanan/i.test([d.type,d.title].join(' '))&&(d.expires??d.expiryDay??d.validUntil)>=s.day);
 if(c.rule==='cidb')return s.contractor?.company?.license==='active';
 if(['roadtax','motorInsurance'].includes(c.rule)){
  const id=(c.reference||'').split(':')[1],v=(s.vehicles||[]).find(x=>x.id===id||x.name===c.subject);
  return !!v&&(c.rule==='roadtax'?v.renew:v.insuranceExpiry)>=s.day;
 }
 if(c.rule==='driving')return !!s.licence&&s.licence.expires>=s.day;
 return false;
}
export function adjudicationAction(s,id,action){const d=ensureAdjudication(s),c=d.cases.find(x=>x.id===id);if(!c)throw Error('Kes tidak ditemui');const r=COMPLIANCE_RULES[c.rule];const closed=['closed','withdrawn','paid','court-final'];if(closed.includes(c.status))throw Error('Kes sudah dimuktamadkan');
 if(action==='contest'){if(!['investigation','notice','hearing'].includes(c.status))throw Error('Tidak boleh mencabar pada tahap ini');c.status='hearing';c.deadline=s.day+14;record(s,c,'contest','Pemain mempertikaikan dakwaan');announce(s,c.id+':contest','PENDENGARAN DIJADUALKAN',`${c.subject}: kes dipertikaikan. Tiada denda dikenakan sehingga keputusan.`);return 'Pendengaran simulasi dijadualkan';}
 if(action==='remedy'){if(!['investigation','notice','hearing'].includes(c.status))throw Error('Keputusan kes telah direkodkan; gunakan saluran rayuan atau penyelesaian.');if(!offenceRemedied(s,c))throw Error('Dokumen masih tidak sah atau belum didaftarkan. Perbaharui dahulu.');c.status='closed';record(s,c,'remedied','Pembetulan disahkan');announce(s,c.id+':remedied','KES DITUTUP',`${c.subject}: pembetulan disahkan.`);return 'Kes ditutup selepas pembetulan';}
 if(action==='hearing'){if(c.status!=='hearing')throw Error('Kes belum pada peringkat pendengaran');const max=num(r.maximumRM)?r.maximumRM:null;const min=num(r.minimumRM)?r.minimumRM:0;
 // Deterministic simulated hearing, no invented real compound rate; an explicit fictional award.
 const proven=c.evidenceType==='observed-activity'&&Number.isInteger(c.evidenceDay)&&c.evidenceDay<=s.day&&!!COMPLIANCE_RULES[c.rule];
 if(!proven){c.status='withdrawn';c.fineRM=0;record(s,c,'dismissed','Bukti simulasi tidak mencukupi');announce(s,c.id+':dismissed','KES DIGUGURKAN',`${c.subject}: bukti tidak mencukupi.`);return 'Kes digugurkan';}
 c.status='judgment';c.fineRM=max===null?0:Math.min(max,Math.max(min,Math.round((min+(max-min)*0.12)/10)*10));c.judgmentDay=s.day;c.appealUntil=s.day+14;record(s,c,'judgment','Keputusan simulasi; denda belum dibayar');announce(s,c.id+':judgment','KEPUTUSAN KES',`${c.subject}: keputusan simulasi. ${max===null?'Tiada jumlah denda ditentukan kerana peraturan PBT khusus belum dipilih.':'Denda simulasi RM'+c.fineRM+'.'} Rayuan sehingga Hari ${c.appealUntil+1}.`);return 'Keputusan simulasi direkodkan';}
 if(action==='appeal'){if(c.status!=='judgment'||s.day>c.appealUntil)throw Error('Tempoh rayuan tidak tersedia');c.status='appeal-pending';c.deadline=s.day+7;record(s,c,'appeal','Rayuan difailkan');announce(s,c.id+':appeal','RAYUAN DIDAFTARKAN',`${c.subject}: keputusan rayuan tersedia selepas 7 hari permainan.`);return 'Rayuan diterima untuk semakan';}
 if(action==='appeal-decision'){if(c.status!=='appeal-ready')throw Error('Keputusan rayuan belum tersedia');
 // A review of recorded evidence, not a random chance to reverse a court finding.
 const evidenceValid=c.evidenceType==='observed-activity'&&Number.isInteger(c.evidenceDay)&&c.evidenceDay<=c.judgmentDay;
 if(!evidenceValid){c.fineRM=0;c.status='withdrawn';record(s,c,'appeal-allowed','Keputusan diketepikan: bukti aktiviti tidak mencukupi');}
 else{c.status='judgment';c.appealUntil=s.day;record(s,c,'appeal-dismissed','Bukti aktiviti yang direkodkan kekal; keputusan dikekalkan');}
 announce(s,c.id+':appeal-result','KEPUTUSAN RAYUAN',`${c.subject}: ${c.status==='withdrawn'?'Kes diketepikan':'Denda simulasi kekal RM'+c.fineRM}.`);return 'Keputusan rayuan direkodkan';}
 if(action==='finalize'){if(c.status!=='judgment'||c.fineRM!==0)throw Error('Kes masih mempunyai amaun atau belum diputuskan');c.status='court-final';record(s,c,'finalized','Keputusan tanpa amaun direkodkan');announce(s,c.id+':finalized','KES DIMUKTAMADKAN',`${c.subject}: keputusan tanpa bayaran dimuktamadkan.`);return 'Kes dimuktamadkan tanpa bayaran';}
 if(action==='pay'){if(c.status!=='judgment')throw Error('Tiada denda boleh dibayar');if(!c.fineRM)throw Error('Tiada jumlah denda ditetapkan; semak peraturan agensi');const account=s.accounts?.main;if(!account||account.balance<c.fineRM*100)throw Error('Baki akaun utama tidak mencukupi');spend(s,'main',c.fineRM*100,'Bayaran penalti simulasi: '+c.agency+' · '+c.subject,'compliance-penalty');c.status='paid';c.paidDay=s.day;record(s,c,'payment',`RM${c.fineRM} dibayar`);announce(s,c.id+':paid','DENDA SIMULASI DIBAYAR',`${c.subject}: RM${c.fineRM} telah ditolak daripada akaun utama.`);return 'Bayaran denda simulasi berjaya';}
 throw Error('Tindakan tidak dikenali');}
