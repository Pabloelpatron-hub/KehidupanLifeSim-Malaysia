import assert from 'node:assert/strict';
import {npcPortraitAsset,portraitCoverage} from './npc-portraits-cp12.js';
assert.equal(portraitCoverage().ready,300);
assert.equal(portraitCoverage().finalQA,0);
assert.equal(npcPortraitAsset('npc-cp04-001'),'assets/npc-portraits/npc-cp04-001.webp');
assert.equal(npcPortraitAsset('npc-cp04-300'),'assets/npc-portraits/npc-cp04-300.webp');
assert.equal(npcPortraitAsset('npc-cp04-301'),null);
console.log('CP12 illustrated asset registry OK');
