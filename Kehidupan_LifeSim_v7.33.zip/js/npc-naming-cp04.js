import {bossName} from './gang-boss-profiles.js';
// CP04: additive, deterministic identity and title presentation.
// Identity group is character metadata, never inferred from a portrait.
export const NPC_CLASSES = Object.freeze([
 'orang_kenamaan','politician','business_tycoon','business_owner','broker',
 'investor','gang_supreme_boss','gang_superior','gang_subordinate','rival',
 'fixer','police_officer','police_member','government_officer','legal_professional',
 'banker','contractor','skilled_professional','social_contact','community_figure'
]);
const TITLES = Object.freeze({malay:'Ayah',indian:'Don',chinese:'Taiko'});
const PREFIX = /^(?:(?:Ayah|Don|Taiko|Dato' Seri|Dato'|Tan Sri)\s+)+/i;
const HONORIFIC = /^(?:Dato' Seri|Dato'|Tan Sri)\s+/i;
export function npcIdentityGroup(person){
  const explicit=String(person?.identityGroup||'').toLowerCase();
  return Object.hasOwn(TITLES,explicit)?explicit:null;
}
export function gangDisplayName(person){
  if(!person)return '';
  const original=String(person.fullName||person.name||'').trim();
  const name=original.replace(PREFIX,'').trim();
  if(Number(person.rank)===3){
    const title=TITLES[npcIdentityGroup(person)];
    return title?`${title} ${name}`:original;
  }
  if(Number(person.rank)===5){return bossName(person);}
  if(false && Number(person.rank)===5 && (person.isSupremeBoss===true || person.primaryClass==='gang_supreme_boss')){
    const title=String(person.honorific||'').trim()||"Dato'";
    return `${title} ${name}`;
  }
  return original;
}
export function validateNpcIdentity(profile){
  if(!profile||typeof profile!=='object')throw Error('NPC identity required');
  if(profile.primaryClass && !NPC_CLASSES.includes(profile.primaryClass))throw Error('Unknown NPC class');
  if(profile.secondaryClasses && (!Array.isArray(profile.secondaryClasses)||profile.secondaryClasses.some(c=>!NPC_CLASSES.includes(c))))throw Error('Unknown secondary class');
  if(profile.identityGroup && !['malay','indian','chinese','other'].includes(profile.identityGroup))throw Error('Invalid identity group');
  if(profile.primaryClass==='gang_supreme_boss' && !profile.honorific && !HONORIFIC.test(profile.fullName||''))throw Error('Supreme gang boss requires honorific');
  return true;
}
