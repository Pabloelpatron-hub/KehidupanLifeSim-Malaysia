// NPC Expansion v2.0, Phase 02: canonical roster identity access and integrity.
// This is an additive adapter. Never changes stable IDs or rewrites existing save fields.
import {getNpcProfile,rosterDisplayName,rosterAcquaintances} from './npc-roster-cp04.js';
export const NPC_IDENTITY_SCHEMA_VERSION=2;
export function canonicalNpcIdentity(state,id){
 const live=state?.npcs?.[id]||null,profile=getNpcProfile(id);
 if(!live&&!profile)return null;
 const base=profile||live;
 return Object.freeze({id,fullName:profile?.fullName||live?.name||'',displayName:profile?rosterDisplayName(profile):(live?.displayName||live?.name||''),primaryClass:profile?.primaryClass||live?.primaryClass||null,occupation:profile?.occupation||live?.occupation||'',identityGroup:profile?.identityGroup||live?.identityGroup||null,city:profile?.city||live?.city||null,rank:profile?.rank??live?.rank??null,portraitId:profile?.portraitId||live?.portraitId||null,acquaintances:profile?rosterAcquaintances(id):Array.isArray(live?.acquaintances)?live.acquaintances:[]});
}
export function reconcileNpcIdentity(state,id){
 const n=state?.npcs?.[id],p=getNpcProfile(id);if(!n||!p)return false;
 // Update canonical metadata only; preserve player-specific NPC state and historical name.
 let changed=false;
 const fields={displayName:rosterDisplayName(p),primaryClass:p.primaryClass,identityGroup:p.identityGroup,occupation:p.occupation,portraitId:p.portraitId,portraitStatus:p.portraitStatus};
 for(const [k,v] of Object.entries(fields)){if(n[k]!==v){n[k]=v;changed=true;}}
 if(!Array.isArray(n.acquaintances)){n.acquaintances=rosterAcquaintances(id);changed=true;}
 return changed;
}
export function auditNpcIdentityState(state){
 const issues=[],ids=new Set(Object.keys(state?.npcs||{}));
 for(const [id,n] of Object.entries(state?.npcs||{})){
  if(!n||n.id!==id)issues.push({id,code:'ID_MISMATCH'});
  if(getNpcProfile(id)&&n.primaryClass&&n.primaryClass!==getNpcProfile(id).primaryClass)issues.push({id,code:'CLASS_MISMATCH'});
  for(const a of n?.acquaintances||[])if(!getNpcProfile(a.npcId)&&!ids.has(a.npcId))issues.push({id,code:'ORPHAN_ACQUAINTANCE',target:a.npcId});
 }
 const graph=state?.livingWorld?.socialLinks||{};
 for(const [id,edges] of Object.entries(graph)){
  if(!ids.has(id))issues.push({id,code:'ORPHAN_GRAPH_SOURCE'});
  for(const target of Object.keys(edges||{}))if(!ids.has(target))issues.push({id,code:'ORPHAN_GRAPH_TARGET',target});
 }
 return {ok:issues.length===0,issues,activeNpcCount:ids.size};
}

// Phase 02: explicit, conservative authority boundaries. These describe possible
// institutional domains, NEVER permissions to mutate game state or grant rewards.
const NPC_AUTHORITY_DOMAINS=Object.freeze({
 politician:['public_advocacy'],orang_kenamaan:['community_referral'],community_figure:['community_referral'],
 government_officer:['administrative_guidance'],police_officer:['law_enforcement_guidance'],police_member:['law_enforcement_guidance'],
 banker:['banking_guidance'],legal_professional:['legal_guidance'],contractor:['construction_guidance'],
 business_tycoon:['business_referral'],business_owner:['business_referral'],broker:['business_referral'],
 investor:['investment_guidance'],gang_supreme_boss:['organization_guidance'],gang_superior:['organization_guidance'],
 gang_subordinate:[],fixer:['social_referral'],social_contact:[]
});
export function npcAuthorityProfile(state,id){
 const identity=canonicalNpcIdentity(state,id);if(!identity)return null;
 const role=identity.primaryClass;
 return Object.freeze({id,role,rank:identity.rank,domains:Object.freeze([...(NPC_AUTHORITY_DOMAINS[role]||[])]),
  canAuthorizeTransactions:false,canGrantEmployment:false,canApproveGovernmentAction:false});
}
export function npcHasAdvisoryDomain(state,id,domain){return !!npcAuthorityProfile(state,id)?.domains.includes(domain);}
// Existing edges are directional. Do not infer reciprocal friendship, family or
// authority links, and do not fabricate an organization from class/occupation.
export function npcSocialGraphSnapshot(state,id){
 if(!canonicalNpcIdentity(state,id))return null;
 const graph=state?.livingWorld?.socialLinks||{};
 const outgoing=Object.entries(graph[id]||{}).filter(([target])=>!!canonicalNpcIdentity(state,target)).map(([target,edge])=>({npcId:target,kind:edge?.kind||'unknown',strength:edge?.strength??null}));
 const incoming=Object.entries(graph).filter(([source,edges])=>source!==id&&edges&&Object.prototype.hasOwnProperty.call(edges,id)&&canonicalNpcIdentity(state,source)).map(([source,edges])=>({npcId:source,kind:edges[id]?.kind||'unknown',strength:edges[id]?.strength??null}));
 return {id,outgoing,incoming};
}
export function auditNpcSocietyState(state){
 const base=auditNpcIdentityState(state),issues=[...base.issues],graph=state?.livingWorld?.socialLinks||{};
 for(const [source,edges] of Object.entries(graph))for(const [target,edge] of Object.entries(edges||{})){
  if(source===target)issues.push({id:source,code:'SELF_SOCIAL_LINK'});
  if(!['professional','family','friend','rival','authority'].includes(edge?.kind))issues.push({id:source,target,code:'INVALID_RELATION_KIND'});
  if(!Number.isFinite(edge?.strength)||edge.strength<0||edge.strength>100)issues.push({id:source,target,code:'INVALID_RELATION_STRENGTH'});
 }
 return {ok:issues.length===0,issues,activeNpcCount:base.activeNpcCount};
}
