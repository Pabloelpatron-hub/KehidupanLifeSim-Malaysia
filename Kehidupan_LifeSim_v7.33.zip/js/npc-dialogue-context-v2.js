// Offline, bounded dialogue topic context. Stored under livingWorld; no private facts inferred.
import {ensureWorldCore} from './world-core.js';
const clean=x=>String(x||'').toLowerCase().normalize('NFKC').replace(/[^\p{L}\p{N}\s]/gu,' ').replace(/\s+/g,' ').trim();
const patterns=[['employment',/\b(kerja|keje|kije|keja|job|vacancy|vacancies|jawatan|interview|temuduga|temu duga|resume|cv|gaji|referral|rujukan|employment|apply|mohon)\b/],['introduction',/\b(kenalan|kenalkan|perkenalkan|contact|nombor|number|intro|introduce|kawan)\b/],['business',/\b(bisnes|business|niaga|supplier|pembekal|projek|kontrak|tender|project|contract|vendor)\b/],['property',/\b(rumah|sewa|hartanah|property|shoplot|rent|rental|house)\b/],['health',/\b(doktor|doctor|klinik|clinic|sihat|kesihatan|sakit|demam|hospital)\b/],['meeting',/\b(jumpa|lepak|kopi|coffee|meet|dinner|appointment|temujanji)\b/]];
export function npcMessageTopic(text){
 const q=clean(text);
 // Explicit corrections must supersede a topic mentioned only to reject it.
 // Example: 'bukan pasal kerja, saya nak tanya rumah sewa'.
 const redirect=q.match(/\b(?:tapi|tetapi|cuma|hanya|sebaliknya|instead|actually|sebenarnya)\b\s+(.+)$/);
 if(redirect&&/\b(?:tak|tidak|bukan|jangan|dont|no|taknak|xnak|x|takmahu)\b/.test(q.slice(0,redirect.index))){return patterns.find(([,re])=>re.test(redirect[1]))?.[0]||null;}
 const correction=q.match(/\b(?:bukan|bukannya|not|instead of)\s+(?:pasal|tentang|about)?\s*.+?\b(?:tapi|tetapi|sebaliknya|instead|actually|sebenarnya)\b\s*(.+)$/);
 if(correction){const selected=patterns.find(([,re])=>re.test(correction[1]));if(selected)return selected[0];}
 return patterns.find(([,re])=>re.test(q))?.[0]||null;
}
export function npcDialogueState(s,id){const w=ensureWorldCore(s);w.npcDialogue??={};return w.npcDialogue[id]??={topic:null,lastDay:-1,turns:0};}
export function npcDialogueReply(s,id,text){const q=clean(text),state=npcDialogueState(s,id);
 const explicit=npcMessageTopic(q),follow=/^(apa maksud|maksud|mcmne|macam mana|camne|camana|kenapa|why|how|jelaskan|explain|boleh explain|yg mana|yang mana|boleh cerita|cerita lagi|sambung|pastu|lepas tu|then|contoh|contohnya)\b/.test(q);
 const validDay=Number.isFinite(state.lastDay)&&Number.isFinite(s.day)&&s.day>=state.lastDay&&s.day-state.lastDay<=7;
 const topic=explicit||(follow&&validDay?state.topic:null);
 const responses={employment:'Tentang kerja tadi, bidang dan pengalaman awak macam mana? Saya boleh kongsi maklumat, tetapi permohonan dan keputusan majikan tetap diperlukan.',introduction:'Tentang kenalan tadi, perkenalan perlu persetujuan orang itu dahulu. Saya tak boleh kongsi nombor tanpa izin.',business:'Tentang urusan bisnes tadi, kita kena jelas skop, kos, risiko dan tanggungjawab sebelum buat keputusan.',property:'Tentang hartanah tadi, semak lokasi, kos, deposit dan kelayakan dahulu sebelum buat keputusan.',health:'Tentang kesihatan tadi, lebih baik dapatkan pemeriksaan profesional untuk penilaian yang tepat.',meeting:'Tentang rancangan jumpa tadi, kita perlu sahkan masa dan kesediaan kedua-dua pihak dahulu.'};
 if(explicit){state.topic=explicit;state.lastDay=s.day;state.turns=Math.min(100,state.turns+1);return null;}
 if(follow&&topic){state.lastDay=s.day;state.turns=Math.min(100,state.turns+1);return responses[topic]||null;}
 return null;
}
// Conservative clarification for messages whose reference cannot be grounded.
// Never infer an action, authority or referral from an ambiguous utterance.
export function npcNeedsClarification(s,id,text){
 const q=clean(text),st=npcDialogueState(s,id);
 const vague=/^(?:yang mana|yg mana|mcmne tu|macam mana tu|camne tu|boleh explain|explain sikit|apa maksud|maksudnya|itu macam mana|tu macam mana)\??$/.test(q);
 if(!vague||npcMessageTopic(q))return null;
 const valid=Number.isFinite(st.lastDay)&&Number.isFinite(s.day)&&s.day>=st.lastDay&&s.day-st.lastDay<=7&&!!st.topic;
 return valid?null:'Awak maksudkan perkara yang mana? Boleh jelaskan sedikit supaya saya tak tersalah faham?';
}
