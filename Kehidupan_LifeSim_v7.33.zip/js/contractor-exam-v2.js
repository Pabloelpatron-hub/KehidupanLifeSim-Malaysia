// Fictional competency assessment: five questions per category, 80% pass.
export const BANK={
B:[
['For a reinforced concrete beam, why is development length checked at supports?',['To transfer reinforcement force into concrete through bond','To determine paint coverage','To eliminate cover blocks','To reduce curing duration'],0],
['Cube results at 28 days are below specified characteristic strength. Best first response?',['Immediately conceal results','Review sampling, testing and structural assessment with engineer','Add water to remaining mix','Assume all results are invalid'],1],
['A temporary formwork system is modified on site. Which control is most critical?',['Supervisor verbal approval alone','Design check and approval of revised temporary works','Increase concrete pour rate','Remove all bracing for access'],1],
['A BQ item is measured in m³ for in-situ concrete. What is normally measured?',['Net volume to measurement rules','Weight of cement bags only','Area of formwork','Labour man-days'],0],
['Why must waterproofing substrate moisture and surface preparation be checked?',['To prevent adhesion and membrane failures','To shorten defect liability automatically','To waive manufacturer warranty','To replace flood testing'],0]],
CE:[
['Field density tests consistently fail compaction specification. What should follow?',['Cover with next layer','Investigate moisture/lift thickness and recompact then retest','Increase traffic immediately','Delete failed results'],1],
['Excavation near a known high-pressure water main requires what?',['Verified utility location, permit and protection plan','Only a wider bucket','Work at night without notice','Assume drawings are exact'],0],
['What is the principal purpose of a silt trap during earthworks?',['Intercept sediment-laden runoff before discharge','Increase asphalt strength','Replace slope stability assessment','Raise groundwater'],0],
['An embankment shows progressive tension cracks after rain. Appropriate action?',['Restrict access and seek geotechnical assessment','Add heavy loads at crest','Ignore until final handover','Remove monitoring markers'],0],
['Road pavement design subgrade CBR is lower than assumed. What should be reviewed?',['Pavement thickness and ground improvement requirements','Street lighting colour','Road markings only','Contractor company logo'],0]],
ME:[
['Before energising a new LV distribution board, which tests are relevant?',['Insulation resistance, earth continuity and protective devices','Only paint thickness','Only lighting lux readings','No tests if supplier is known'],0],
['A protective device trips repeatedly under normal load. Best approach?',['Investigate load, fault and protection coordination','Install oversized fuse without design','Bypass earth conductor','Tape breaker in ON position'],0],
['For chilled-water piping, why conduct pressure testing before insulation?',['To detect leakage while joints are accessible','To measure paint shade','To replace flushing','To avoid commissioning'],0],
['In a confined plant room, what is essential before hot works?',['Permit, fire controls and atmosphere assessment as applicable','Only a warning sign','Switch off emergency exits','Remove extinguishers'],0],
['What does selectivity in electrical protection aim to achieve?',['Isolate the faulted section while maintaining healthy supply','Trip all feeders simultaneously','Eliminate earthing','Increase cable temperature'],0]],
F:[
['What differentiates condition-based maintenance from fixed-interval maintenance?',['Intervention based on measured asset condition','No asset register required','Repairs only after total failure','All tasks on same date'],0],
['An AHU vibration trend rises sharply. Appropriate first step?',['Inspect safely, analyse cause and plan corrective action','Disable alarms permanently','Increase fan speed','Ignore until annual audit'],0],
['For critical equipment, what does MTTR measure?',['Mean time to repair','Mean time to revenue','Maximum tariff to replace','Minimum test temperature'],0],
['Repeated lift breakdowns after contractor service indicate what management need?',['Review failure history, service quality and root cause','Erase downtime logs','Cancel all inspections','Increase passenger load'],0],
['Which record best supports planned preventive maintenance audit?',['Asset ID, task schedule, completion evidence and findings','Only monthly utility bill','Only staff attendance','Only equipment purchase brochure'],0]]
};
export const PASS_MARK=4;
export function currentQuestion(s){const b=s.contractor?.company;if(!b)return null;const arr=BANK[b.category]||BANK.B;const index=Math.min(b.examProgress||0,arr.length-1);const q=arr[index];return {index,total:arr.length,prompt:q[0],choices:q[1]};}
export function submitAnswer(s,index){const b=s.contractor?.company;if(!b||b.license!=='pending-exam')throw Error('Tiada ujian CIDB aktif');if(s.day<(b.examUntil||0))throw Error('Ujian semula selepas hari '+b.examUntil);const q=currentQuestion(s);if(!q)throw Error('Soalan tidak tersedia');const choice=Number(index);if(!Number.isInteger(choice)||choice<0||choice>=q.choices.length)throw Error('Pilihan jawapan tidak sah');b.examCorrect=(b.examCorrect||0)+(choice===BANK[b.category][q.index][2]?1:0);b.examProgress=q.index+1;if(b.examProgress<q.total)return {finished:false,index:b.examProgress,total:q.total};const score=b.examCorrect,passed=score>=PASS_MARK;b.examProgress=0;b.examCorrect=0;b.examAttempts=(b.examAttempts||0)+1;b.lastExam={day:s.day,score,total:q.total,passed};if(passed)b.license='pending-fee';else b.examUntil=s.day+3;return {finished:true,score,total:q.total,passed};}
