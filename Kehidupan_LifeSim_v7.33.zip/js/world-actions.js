// CP02: deterministic, offline-safe Living World action and commitment layer.
// Only livingWorld is owned here; finance, gang, vehicle and contractor changes
// must be performed by their authoritative modules in later integration stages.
import {ensureWorldCore, recordWorldEvent, gameClock} from './world-core.js';
import {npcPromiseOutcome} from './npc-psychology-cp05.js';

const ACTION_TYPES = new Set(['NPC_ENCOUNTER','NPC_CONTACT_UNLOCK','NPC_RELATIONSHIP_NOTE','NPC_COMMITMENT_CREATE','NPC_COMMITMENT_RESOLVE','NPC_APPOINTMENT_NOTE','NPC_PROJECT_REFERRAL']);
const ID = /^[A-Za-z0-9][A-Za-z0-9_:-]{0,99}$/;
const clone = x => structuredClone(x);
function assertId(v, label) { if (typeof v !== 'string' || !ID.test(v)) throw Error(`Invalid ${label}`); }
function assertPlain(value) { if (!value || typeof value !== 'object' || Array.isArray(value)) throw Error('Invalid action payload'); }
function checkAction(state, action) {
  if (!action || !ACTION_TYPES.has(action.type)) throw Error('Unsupported Living World action');
  assertId(action.actionId, 'action ID');
  assertId(action.npcId, 'NPC ID');
  assertPlain(action.payload ?? {});
  if (!state.livingWorld?.npcProfiles?.[action.npcId]) throw Error('Unknown NPC');
  if (action.type === 'NPC_COMMITMENT_CREATE') {
    assertId(action.payload.commitmentId, 'commitment ID');
    if (typeof action.payload.description !== 'string' || !action.payload.description.trim() || action.payload.description.length > 500) throw Error('Invalid commitment description');
    if (action.payload.dueDay != null && (!Number.isSafeInteger(action.payload.dueDay) || action.payload.dueDay < state.day)) throw Error('Invalid commitment due day');
  }
  if (action.type === 'NPC_COMMITMENT_RESOLVE') {
    assertId(action.payload.commitmentId, 'commitment ID');
    if (!['fulfilled','broken','cancelled'].includes(action.payload.outcome)) throw Error('Invalid commitment outcome');
  }
  return action;
}
export function validateNpcAction(state, action) {
  ensureWorldCore(state);
  checkAction(state, action);
  const w = state.livingWorld;
  if (Object.hasOwn(w.processedActions, action.actionId)) return { duplicate: true, eventId: w.processedActions[action.actionId] };
  if (action.type === 'NPC_COMMITMENT_CREATE' && w.commitments.some(c => c.id === action.payload.commitmentId)) throw Error('Commitment ID already exists');
  if (action.type === 'NPC_COMMITMENT_RESOLVE') {
    const c = w.commitments.find(c => c.id === action.payload.commitmentId);
    if (!c || c.npcId !== action.npcId || c.status !== 'open') throw Error('Commitment not open for this NPC');
  }
  return { duplicate: false };
}
export function applyNpcAction(state, action) {
  // Work on a detached world draft so invalid actions never partially mutate world data.
  const current = ensureWorldCore(state);
  const draftState = { day: state.day, hour: state.hour, livingWorld: clone(current) };
  const result = validateNpcAction(draftState, action);
  if (result.duplicate) return { ...result, committed: false };
  const w = draftState.livingWorld;
  const p = clone(action.payload ?? {});
  if (action.type === 'NPC_COMMITMENT_CREATE') {
    w.commitments.push({ id:p.commitmentId, npcId:action.npcId, description:p.description.trim(), dueDay:p.dueDay??null, status:'open', createdDay:state.day, resolvedDay:null, evidenceEventId:null });
  }
  if (action.type === 'NPC_COMMITMENT_RESOLVE') {
    const c = w.commitments.find(c=>c.id===p.commitmentId);
    c.status=p.outcome; c.resolvedDay=state.day;
  }
  const recorded = recordWorldEvent(draftState,{type:action.type,actorId:action.npcId,entityId:p.commitmentId??null,payload:p},action.actionId);
  if (action.type === 'NPC_COMMITMENT_RESOLVE') w.commitments.find(c=>c.id===p.commitmentId).evidenceEventId=recorded.event.id;
  state.livingWorld=w;
  // Apply psychology only after the verified commitment event has been committed.
  if (action.type === 'NPC_COMMITMENT_RESOLVE' && ['fulfilled','broken'].includes(p.outcome) && state.npcs?.[action.npcId]) {
    npcPromiseOutcome(state,action.npcId,p.outcome==='fulfilled',{commitmentId:p.commitmentId});
  }
  return {committed:true,duplicate:false,eventId:recorded.event.id,clock:gameClock(state)};
}
export function listNpcCommitments(state,npcId) {
  ensureWorldCore(state); assertId(npcId,'NPC ID');
  return clone(state.livingWorld.commitments.filter(c=>c.npcId===npcId));
}
