// Explicit activity-based compliance events. An expired document is never itself treated as proof of use.
import {reportObservedOffence} from './compliance-adjudication.js';
const validDay=x=>Number.isInteger(x)&&x>=0;
export function driveVehicle(s,id){
 const v=(s.vehicles||[]).find(x=>x.id===id&&!x.repossessed);
 if(!v)throw Error('Kenderaan tidak tersedia untuk dipandu');
 const findings=[];
 if(!s.licence||!validDay(s.licence.expires)||s.day>s.licence.expires)findings.push('driving');
 const cls=v.kind==='Motosikal'?'B2':'D';
 if(s.licence&&!(s.licence.classes||[s.licence.class]).some(x=>String(x).includes(cls)))findings.push('driving');
 if(!validDay(v.renew)||s.day>v.renew)findings.push('roadtax');
 if(!validDay(v.insuranceExpiry)||s.day>v.insuranceExpiry)findings.push('motorInsurance');
 const rules=[...new Set(findings)];
 s.complianceActivity??={events:[]};
 s.complianceActivity.events.push({day:s.day,kind:'drive',vehicleId:id,violations:rules});
 s.complianceActivity.events=s.complianceActivity.events.slice(-200);
 for(const rule of rules)reportObservedOffence(s,rule,v.name||id,'vehicle:'+id+':'+rule+':'+Math.floor(s.day/7));
 if(!rules.length){s.notices??=[];s.notices.unshift({day:s.day,title:'Perjalanan direkodkan',text:(v.name||id)+' digunakan dengan dokumen yang direkodkan sebagai sah.'});}
 return rules;
}
export function inspectConstructionActivity(s,projectId){
 const c=s.contractor?.company,p=(s.contractor?.projects||[]).find(x=>x.id===projectId);
 if(!c||!p)throw Error('Projek tidak ditemui');
 if(!['active','awaiting-cpc'].includes(p.status))return [];
 const invalid=c.license!=='active';
 if(invalid)reportObservedOffence(s,'cidb',c.name,'project:'+projectId+':'+Math.floor(s.day/7));
 return invalid?['cidb']:[];
}
export function inspectFoodActivity(s,b){
 if(!b||b.closed)return [];
 const foodType=/mamak|cafe|kopi|warung|restaurant|food|restoran|makan|bakery|kafe/i.test([b.type,b.name].join(' '));
 if(!foodType)return [];
 const registrations=(s.documents||[]).filter(d=>d.business===b.id&&/food premises|pendaftaran premis makanan/i.test([d.type,d.title].join(' ')));
 const valid=registrations.some(d=>{const until=d.expires??d.expiryDay??d.validUntil;return validDay(until)&&until>=s.day;});
 if(!valid)reportObservedOffence(s,'food',b.name,b.id+':'+Math.floor(s.day/30));
 return valid?[]:['food'];
}
