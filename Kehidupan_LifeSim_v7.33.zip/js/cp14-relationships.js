// CP14 Phase 1: read-only relationship insights, no save schema changes.
export function relationshipTier(n){const trust=Number(n?.trust)||0,friend=Number(n?.friendship)||0; if(trust>=70&&friend>=60)return 'Sahabat dipercayai';if(trust>=45&&friend>=30)return 'Kenalan rapat';if(trust>=25||friend>=20)return 'Kenalan biasa';return 'Kenalan baharu';}
export function relationshipInsights(state){const ids=[...new Set(state.contacts||[])];return ids.filter(id=>state.npcs?.[id]).map(id=>{const n=state.npcs[id],messages=state.messages?.[id]||[],valid=messages.filter(m=>Number.isFinite(m.day));return {id,name:String(n.name||n.displayName||'NPC'),occupation:String(n.occupation||''),trust:Math.max(0,Math.min(100,Number(n.trust)||0)),friendship:Math.max(0,Math.min(100,Number(n.friendship)||0)),tier:relationshipTier(n),interactions:messages.length+(Array.isArray(n.memory)?n.memory.length:0),lastContact:valid.length?Math.max(...valid.map(m=>m.day)):null};}).sort((a,b)=>b.trust-a.trust||b.friendship-a.friendship||a.name.localeCompare(b.name));}

// Phase 3: timeline uses existing saved messages and NPC memories only.
export function relationshipTimeline(state,id,limit=8){
 if(!(state.contacts||[]).includes(id)||!state.npcs?.[id])return [];
 const messages=(state.messages?.[id]||[]).filter(x=>x&&Number.isFinite(Number(x.day))).map((x,i)=>({day:Number(x.day),type:'message',text:String(x.text||x.message||x.body||'Mesej').slice(0,180),order:i}));
 const memories=(Array.isArray(state.npcs[id].memory)?state.npcs[id].memory:[]).filter(x=>x&&typeof x==='object'&&Number.isFinite(Number(x.day))).map((x,i)=>({day:Number(x.day),type:'memory',text:String(x.text||x.detail||x.event||'Interaksi').slice(0,180),order:i}));
 return [...messages,...memories].sort((a,b)=>b.day-a.day||b.order-a.order).slice(0,Math.max(0,Math.min(30,limit)));
}
export function relationshipSummary(state,id){
 const person=relationshipInsights(state).find(x=>x.id===id);if(!person)return null;
 const timeline=relationshipTimeline(state,id,30);
 const messageCount=(state.messages?.[id]||[]).length;
 return {...person,messageCount,events:timeline.length,hasHistory:timeline.length>0};
}

// CP14 closure: read-only aggregate and portable export, restricted to earned contacts.
export function relationshipOverview(state){const people=relationshipInsights(state);return {total:people.length,trusted:people.filter(p=>p.trust>=70).length,close:people.filter(p=>p.friendship>=60).length,active:people.filter(p=>p.interactions>0).length,averageTrust:people.length?Math.round(people.reduce((a,p)=>a+p.trust,0)/people.length):0};}
export function relationshipExport(state){return JSON.stringify({format:'kehidupan-relationship-export',version:1,generatedAtDay:Number(state.day)||0,contacts:relationshipInsights(state).map(p=>({...p,timeline:relationshipTimeline(state,p.id,30)}))},null,2);}
// CP15 Phase 1: transparent, non-automated social opportunity hints.
export function socialOpportunities(state){return relationshipInsights(state).map(p=>{let title,reason,priority;if(p.interactions===0){title='Mulakan perbualan';reason='Belum ada interaksi direkodkan';priority=3;}else if(p.trust>=70&&p.friendship>=60){title='Kekalkan hubungan baik';reason='Kepercayaan dan persahabatan sudah kukuh';priority=1;}else if(p.trust<30){title='Bina kepercayaan perlahan-lahan';reason='Tahap kepercayaan masih rendah';priority=2;}else{title='Teruskan hubungan';reason='Sudah ada sejarah interaksi';priority=2;}return {...p,title,reason,priority};}).sort((a,b)=>b.priority-a.priority||a.trust-b.trust||a.name.localeCompare(b.name));}
