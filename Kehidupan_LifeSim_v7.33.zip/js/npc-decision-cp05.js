// CP05: bounded, explainable decisions. Does not authorize economic or gang transactions.
import {ensureNpcPsychology,npcDisposition} from './npc-psychology-cp05.js';
import {npcAuthorityProfile,npcSocialGraphSnapshot} from './npc-core-v2.js';
const clamp=(x,a=0,b=100)=>Math.max(a,Math.min(b,x));
export function npcDecision(s,id,action){
 const n=s.npcs?.[id];if(!n)throw Error('NPC tidak ditemui');
 const p=ensureNpcPsychology(s,id),t=p.traits,e=p.emotion,m=p.motives;
 const score=clamp(35+(n.trust||0)*.4+(n.friendship||0)*.15+e.trust*.3+e.joy*.12-e.anger*.55-e.fear*.25-e.stress*.12-(n.resentment||0)*.4+(t.agreeableness-50)*.25);
 const reasons=[];
 if(e.anger>=55)reasons.push('masih marah');
 if(e.stress>=70)reasons.push('sedang tertekan');
 if(m.security>=75&&['network','business','loan'].includes(action))reasons.push('mengutamakan keselamatan');
 if(t.conscientiousness>=75&&['network','business'].includes(action))reasons.push('memerlukan bukti dan rekod kerja');
 // Motivations change willingness by action, but cannot override safety or authority boundaries.
 const motiveAdjust={contact:(m.belonging-50)*.10,network:(m.achievement-50)*.12-(m.security-50)*.08,date:(m.belonging-50)*.12,meeting:(m.belonging-50)*.08-(m.autonomy-50)*.05,business:(m.achievement-50)*.14-(m.security-50)*.10,loan:-(m.security-50)*.16};
 const motiveShift=Math.round(motiveAdjust[action]||0);
 if(motiveShift>=5)reasons.push('motivasi peribadi menyokong permintaan');
 if(motiveShift<=-5)reasons.push('keutamaan peribadi tidak sepadan dengan permintaan');
 const thresholds={contact:32,network:52,date:62,meeting:45,business:67,loan:85};
 const authority=npcAuthorityProfile(s,id),network=npcSocialGraphSnapshot(s,id);const role=authority?.role||n.primaryClass||n.occupation||'';const roleCaution=/banker|legal|government|police|doctor|accountant|pegawai|bank|law/i.test(role)&&['business','loan','network'].includes(action)?9:0;const threshold=(thresholds[action]??45)-motiveShift+roleCaution+(m.security>=75&&['network','business','loan'].includes(action)?12:0)+(t.conscientiousness>=75&&['network','business'].includes(action)?8:0);
 if(roleCaution)reasons.push('terikat dengan tanggungjawab profesional');if(action==='network'&&!(network?.outgoing||[]).some(x=>x.kind!=='rival'&&x.kind!=='authority'&&x.strength>=20&&s.npcs[x.npcId]))reasons.push('tiada hubungan kenalan yang disahkan');const blocked=e.anger>=75||e.fear>=80||(n.available===false&&action!=='contact');if(e.anger>=75)reasons.push('terlalu marah untuk bersetuju');if(e.fear>=80)reasons.push('tidak berasa selamat');if(n.available===false&&action!=='contact')reasons.push('tidak tersedia');
 const eligibleNetwork=(network?.outgoing||[]).some(x=>x.kind!=='rival'&&x.kind!=='authority'&&x.strength>=20&&s.npcs[x.npcId]);const accepted=!blocked&&score>=threshold&&(action!=='network'||eligibleNetwork);if(!blocked&&score<threshold)reasons.push('kepercayaan atau kesediaan belum mencukupi');return {accepted,score:Math.round(score),threshold,disposition:npcDisposition(s,id),reasons,blocked};
}
export function npcDialogueTone(s,id){const d=npcDecision(s,id,'chat');const p=ensureNpcPsychology(s,id);if(p.emotion.anger>=55)return 'Saya masih terasa dengan apa yang berlaku. Bagi saya masa dulu.';if(p.emotion.stress>=70)return 'Maaf, kepala tengah serabut. Kita bincang ringkas dulu.';if(d.disposition==='mesra')return 'Bagus dapat berhubung lagi. Apa perkembangan terbaru?';if(d.disposition==='bermusuhan')return 'Saya tak selesa berbincang panjang sekarang.';return 'Boleh kita berbincang, tapi saya perlu tahu butirannya dahulu.';}
export function npcPsychologyDossier(s,id){const p=ensureNpcPsychology(s,id),d=npcDecision(s,id,'meeting');return {traits:{...p.traits},emotion:{...p.emotion},motives:{...p.motives},disposition:d.disposition,notes:d.reasons.slice(),lastDay:p.lastDay};}

// Phase 04: explainable, non-mutating decision preview; no grant of institutional powers.
export function npcDecisionPreview(s,id,action){
 const result=npcDecision(s,id,action);
 return {action,accepted:result.accepted,score:result.score,threshold:result.threshold,disposition:result.disposition,reasons:[...result.reasons],authorityGranted:false};
}
