// Stabilization pass 02-07: deterministic, bounded, save-persistent social simulation.
// Never grants money, licences, legal outcomes or contracts.
import {living,linkNpc,remember,npcSchedule} from './npc-living-cp06-10.js';
import {getNpcProfile,rosterAcquaintances} from './npc-roster-cp04.js';
const cap=(x,min=0,max=100)=>Math.max(min,Math.min(max,Math.round(Number(x)||0)));
const hash=x=>[...String(x)].reduce((h,c)=>(Math.imul(h,33)^c.charCodeAt(0))>>>0,5381);
const classes={banker:['bank','office'],police_officer:['police'],police_member:['police'],government_officer:['government','office'],contractor:['construction','cowork','office'],legal_professional:['office','legal'],business_owner:['shop','market','cowork'],investor:['cowork','office'],community_figure:['community','park'],skilled_professional:['clinic','hospital','office']};
export function ensureStabilized(s){const w=living(s);w.stabilization??={version:1,lastDay:-1,autonomyLog:[],playerLinks:{},storyOutcomes:{},goals:{},lastSocialMaintenanceDay:null};return w.stabilization;}
export function encounterContext(s,id,venue,{hour=s.hour,day=s.day}={}){
 const n=s.npcs?.[id];if(!n)return {allowed:false,reason:'NPC tidak wujud'};
 if(!n.available)return {allowed:false,reason:'NPC sedang tidak tersedia'};
 const p=getNpcProfile(id);const schedule=npcSchedule(s,id,day);
 if(!schedule.available)return {allowed:false,reason:'NPC mempunyai urusan lain hari ini'};
 if(hour<6||hour>23)return {allowed:false,reason:'Di luar waktu pertemuan munasabah'};
 if(venue?.id&&n.venue&&venue.id!==n.venue)return {allowed:false,reason:'NPC tidak berada di lokasi ini'};
 const role=p?.primaryClass||n.primaryClass;
 const category=String(venue?.type||'').toLowerCase();
 const hints=classes[role];
 // Strong occupational preference is advisory, not a hard block: professionals also have social lives.
 const workHour=hour>=9&&hour<=17&&day%7<5;
 const occupationalMatch=!hints||hints.some(h=>category.includes(h));
 return {allowed:true,reason:'',schedule,context:workHour?(occupationalMatch?'urusan kerja':'urusan peribadi'):'masa lapang',occupationalMatch};
}
export function playerRelationship(s,id,{kind='professional',delta=0,reason='interaction'}={}){
 if(!s.npcs?.[id])throw Error('NPC unknown');
 if(!['professional','friend','rival','family','authority'].includes(kind))throw Error('Invalid relationship');
 const st=ensureStabilized(s);const previous=st.playerLinks[id]||{kind,strength:0,history:[]};
 previous.kind=kind;previous.strength=cap(previous.strength+delta);previous.history.push({day:s.day,reason:String(reason).slice(0,100),delta:cap(delta,-100,100)});
 previous.history=previous.history.slice(-24);st.playerLinks[id]=previous;
 return structuredClone(previous);
}
export function socialAutonomyDay(s){
 const st=ensureStabilized(s);if(st.lastDay>=s.day)return {processed:false,events:[]};
 const start=st.lastDay<0?s.day:st.lastDay+1;
 const events=[];const ids=Object.keys(s.npcs||{}).sort();
 // Process at most 90 simulated days per call; fast-forward conservatively.
 for(let day=Math.max(start,s.day-89);day<=s.day;day++){
  const active=ids.filter(id=>s.npcs[id].importance!=='background'||s.contacts?.includes(id));
  if(!active.length)continue;
  for(const id of active.slice(0,80)){
   const n=s.npcs[id];const roll=hash(id+':'+day)%29;
   const goals=['career','family','network','rest','community'];const goal=goals[hash('goal:'+id+':'+Math.floor(day/7))%goals.length];
   const prior=st.goals[id];if(!prior||prior.week!==Math.floor(day/7)){st.goals[id]={goal,week:Math.floor(day/7),startedDay:day,progress:0};events.push({day,npcId:id,type:'goal',detail:`Fokus minggu ini: ${goal}`});}
   if((hash('progress:'+id+':'+day)%4)===0)st.goals[id].progress=Math.min(100,st.goals[id].progress+5); 
   if(roll===0){const change=(hash('career:'+id+day)%2)?1:-1;n.respect=cap((n.respect||0)+change);events.push({day,npcId:id,type:'career',detail:change>0?'Kemajuan kecil dalam kerjaya':'Tekanan kerja sementara'});}
   if(roll===1){n.friendship=cap((n.friendship||0)-1);events.push({day,npcId:id,type:'personal',detail:'Meluangkan masa untuk urusan keluarga'});}
   if(roll===2){const acquaintances=getNpcProfile(id)?rosterAcquaintances(id):[];
    const other=acquaintances.find(a=>s.npcs[a.npcId]);if(other){const existing=living(s).socialLinks[id]?.[other.npcId];if(!existing){linkNpc(s,id,other.npcId,{kind:'professional',strength:25,source:'existing-acquaintance'});events.push({day,npcId:id,type:'network',otherId:other.npcId,detail:'Mengukuhkan hubungan profesional'});}}}
  }
 }
 st.lastDay=s.day;for(const id of Object.keys(st.goals))if(!s.npcs?.[id])delete st.goals[id];st.autonomyLog.push(...events);st.autonomyLog=st.autonomyLog.slice(-250);
 return {processed:true,events};
}
export function recordStoryConsequence(s,thread){
 if(!thread||!thread.id||!['resolved','declined','expired'].includes(thread.status))return false;
 const st=ensureStabilized(s);if(st.storyOutcomes[thread.id])return false;
 const outcome={day:s.day,npcId:thread.npcId,kind:thread.kind,status:thread.status,choice:thread.choice};
 st.storyOutcomes[thread.id]=outcome;
 if(s.npcs?.[thread.npcId]){
  const kind=thread.status==='declined'?'rival':'professional';
  playerRelationship(s,thread.npcId,{kind,delta:thread.status==='resolved'?3:thread.status==='declined'?-2:-1,reason:`story:${thread.id}`});
  remember(s,thread.npcId,{type:'observation',subject:'player',source:'direct',text:`Hasil cerita ${thread.id}: ${thread.status}`});
 }
 return true;
}
