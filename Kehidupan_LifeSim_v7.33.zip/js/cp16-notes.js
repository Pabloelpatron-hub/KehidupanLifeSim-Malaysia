// CP16 Phase 1: private local-only notes. Never writes to game save or unlocks NPCs.
export function safeNotes(raw){try{const o=typeof raw==='string'?JSON.parse(raw):raw;if(!o||typeof o!=='object'||Array.isArray(o))return {};return Object.fromEntries(Object.entries(o).filter(([k,v])=>/^[\w-]{1,80}$/.test(k)&&typeof v==='string').map(([k,v])=>[k,v.slice(0,500)]));}catch{return {};}}
export function noteFor(notes,id){return typeof notes?.[id]==='string'?notes[id]:'';}
export function updateNote(notes,id,value){if(!/^[\w-]{1,80}$/.test(String(id)))throw Error('Invalid contact ID');const next={...safeNotes(notes)};const text=String(value??'').trim().slice(0,500);if(text)next[id]=text;else delete next[id];return next;}
