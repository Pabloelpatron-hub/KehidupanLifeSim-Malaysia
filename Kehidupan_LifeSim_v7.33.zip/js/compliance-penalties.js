// Compliance enforcement simulation. Statutory court maxima are references, NOT automatic fines.
export const COMPLIANCE_RULES=Object.freeze({
 ssm:{agency:'SSM',law:'Akta Pendaftaran Perniagaan 1956 s12(1) — meneruskan perniagaan selepas tamat pendaftaran',maximumRM:50000,minimumRM:0,prison:'Sehingga 2 tahun',url:'https://www.ssm.com.my/acts/fscommand/a0197s0012.htm'},
 premises:{agency:'PBT',law:'Undang-undang kecil pelesenan PBT (berbeza mengikut lokasi dan jenis premis)',maximumRM:null,minimumRM:null,prison:'Bergantung PBT',url:'https://mbi.gov.my/en/pemberitahuan-dan-makluman-kepada-pemohon-lesen'},
 driving:{agency:'JPJ/PDRM',law:'Akta Pengangkutan Jalan 1987 s26(2) — memandu tanpa lesen sah',minimumRM:300,maximumRM:2000,prison:'Sehingga 3 bulan',url:'https://www.jpj.gov.my/en/act-333/'},
 roadtax:{agency:'JPJ/PDRM',law:'Akta Pengangkutan Jalan 1987 s23(1) — menggunakan kenderaan tanpa LKM',minimumRM:0,maximumRM:2000,prison:'Tiada dinyatakan bagi s23(1)',url:'https://www.jpj.gov.my/akta-333/'},
 motorInsurance:{agency:'JPJ/PDRM',law:'Akta Pengangkutan Jalan 1987 s90(1)–(2) — menggunakan kenderaan tanpa insurans pihak ketiga',minimumRM:0,maximumRM:1000,prison:'Sehingga 3 bulan; hilang kelayakan lesen 12 bulan kecuali pengecualian mahkamah',url:'https://rmp2u.rmp.gov.my/content/insuran-perlindungan-kenderaan?lang=en'},
 cidb:{agency:'CIDB',law:'Akta 520 s25/s29 — menjalankan kerja pembinaan tanpa pendaftaran sah',minimumRM:10000,maximumRM:100000,prison:'Arahan berhenti kerja boleh dikeluarkan bawah s30',url:'https://www.cidb.gov.my/pendaftaran-kontraktor/'},
 food:{agency:'KKM',law:'Peraturan-Peraturan Kebersihan Makanan 2009 peraturan 3 — premis makanan tidak berdaftar',minimumRM:0,maximumRM:10000,prison:'Sehingga 2 tahun',url:'https://hq.moh.gov.my/fsq/pendaftaran-premis-makanan'}
});
const day=v=>Number.isInteger(v)&&v>=0;
export function complianceFindings(s){const out=[];const now=s.day;
 for(const b of s.businesses||[]){if(b.closed)continue;
  if(b.structure==='enterprise'&&day(b.registeredUntil)&&now>b.registeredUntil)out.push({key:'ssm:'+b.id+':'+b.registeredUntil,rule:'ssm',name:b.name,days:now-b.registeredUntil,business:b.id});
  if(day(b.licenceUntil)&&now>b.licenceUntil)out.push({key:'premises:'+b.id+':'+b.licenceUntil,rule:'premises',name:b.name,days:now-b.licenceUntil,business:b.id});
 }
 // Licence expiration alone is not the offence: using/driving while expired is the offence.
 if(day(s.licence?.expires)&&now>s.licence.expires)out.push({key:'driving:personal:'+s.licence.expires,rule:'driving',name:'Lesen memandu',days:now-s.licence.expires,conditional:true});
 for(const v of s.vehicles||[]){if(v.repossessed)continue;
  if(day(v.insuranceExpiry)&&now>v.insuranceExpiry)out.push({key:'insurance:'+v.id+':'+v.insuranceExpiry,rule:'motorInsurance',name:v.name||v.id,days:now-v.insuranceExpiry,conditional:true});
  if(day(v.renew)&&now>v.renew)out.push({key:'roadtax:'+v.id+':'+v.renew,rule:'roadtax',name:v.name||v.id,days:now-v.renew,conditional:true});
 }
 const c=s.contractor?.company;
 if(c&&c.license&&['expired','revoked','suspended'].includes(c.license))out.push({key:'cidb:'+c.id+':'+c.license,rule:'cidb',name:c.name,days:0,conditional:true});
 for(const d of s.documents||[]){const expiry=d.expires??d.expiryDay??d.validUntil;if(!day(expiry)||now<=expiry)continue;
  const type=(d.type||'').toLowerCase();if(type.includes('food premises')||type.includes('pendaftaran premis makanan'))out.push({key:'food:'+d.id+':'+expiry,rule:'food',name:d.title||d.type,days:now-expiry,business:d.business||null});
 }
 return out;
}
export function applyComplianceEnforcement(s){s.complianceEnforcement??={seen:{},history:[]};const state=s.complianceEnforcement;state.seen??={};state.history??=[];
 const findings=complianceFindings(s);const active=new Set(findings.map(f=>f.key));
 for(const b of s.businesses||[]){if(b.complianceHold&&!findings.some(f=>f.business===b.id&&f.days>30&&!f.conditional)){b.complianceHold=false;s.notices.unshift({day:s.day,title:'Sekatan pematuhan ditarik balik',text:b.name+' boleh beroperasi semula selepas isu lesen/pendaftaran diselesaikan.'});}}
 for(const f of findings){const r=COMPLIANCE_RULES[f.rule];if(!r)continue;
  // Not a conviction: notification, enforcement inspection and operating restrictions are distinct.
  if(f.days>30&&!f.conditional&&f.business){const b=s.businesses?.find(x=>x.id===f.business);if(b&&!b.complianceHold){b.complianceHold=true;s.notices.unshift({day:s.day,title:'OPERASI DIHENTIKAN — '+b.name,text:`Simulasi arahan pematuhan ${r.agency}: ${f.rule==='ssm'?'pendaftaran':'lesen premis'} telah luput ${f.days} hari. Perbaharui untuk sambung operasi. Penalti mahkamah tidak dikenakan secara automatik.`});}}
  const stage=f.days>30?'30+':f.days>7?'7+':'expired';const event=f.key+':'+stage;
  if(state.seen[event])continue;state.seen[event]=s.day+1;
  const record={day:s.day,key:f.key,rule:f.rule,stage,agency:r.agency,law:r.law,name:f.name,days:f.days,conditional:!!f.conditional,status:'warning',fineRM:0};state.history.push(record);
  s.notices.unshift({day:s.day,title:`${r.agency}: ${f.name} — ${stage}`,text:`${f.days} hari lewat. ${r.law}. ${f.conditional?'Kesalahan bergantung kepada penggunaan/aktiviti tanpa lesen, bukan tamat tempoh semata-mata. ':''}${r.maximumRM!==null?'Jika disabitkan, julat denda undang-undang sehingga RM'+r.maximumRM.toLocaleString('ms-MY')+'. ':''}Tiada denda mahkamah automatik; selesaikan pembaharuan segera.`});
 }
 state.history=state.history.slice(-250);s.notices=s.notices.slice(0,100);return findings;
}
