import assert from 'node:assert/strict';
import {avatar} from './ui.js';
const html=avatar('npc-cp04-001');
assert.match(html,/npc-cp04-001\.webp/);
assert.match(html,/loading=\"lazy\"/);
assert.match(html,/onerror=\"this\.remove\(\)\"/);
assert.match(avatar('unknown-npc'),/portraits-real\.webp/);
console.log('CP12 avatar image and fallback integration OK');
