// Experimental photo grooming overlays: calibrated per-photo facial anchors; NOT true photo replacement.
import {portraitLandmarks} from './portrait-landmarks.js';
import {deformPortraitPoint} from './face-mesh.js';
export const hairNames=['Asal (foto)','Buzz cut','Crew cut','French crop','Caesar','Ivy League','Side part','Comb over','Slick back','Quiff','Pompadour','Textured crop','Spiky','Undercut','Low fade','High fade','Curtains','Wavy medium','Long layered','Bald / shaved','Tapered fringe'];
export const browNames=['Asal (foto)','Lurus','Lengkung lembut','Lengkung tinggi','Tebal','Nipis','Bersudut','Natural feathered'];
export const beardNames=['Asal (foto)','Licin (simulasi)','Misai nipis','Misai tebal','Chevron','Handlebar','Pencil moustache','Goatee','Circle beard','Soul patch','Chin strap','Stubble ringan','Stubble tebal','Short boxed beard','Full beard','Ducktail','Van Dyke','Balbo','Mutton chops','Janggut panjang','Anchor beard'];
const profiles=[
{top:.125,eye:.36,mouth:.55,chin:.69,cx:.50,rx:.205},
{top:.135,eye:.37,mouth:.55,chin:.70,cx:.50,rx:.205},
{top:.12,eye:.36,mouth:.55,chin:.70,cx:.50,rx:.205},
{top:.13,eye:.37,mouth:.56,chin:.70,cx:.50,rx:.20},
{top:.13,eye:.36,mouth:.55,chin:.70,cx:.50,rx:.215},
{top:.14,eye:.37,mouth:.55,chin:.69,cx:.50,rx:.205},
{top:.12,eye:.36,mouth:.55,chin:.70,cx:.50,rx:.205},
{top:.14,eye:.37,mouth:.55,chin:.70,cx:.50,rx:.205},
{top:.12,eye:.36,mouth:.55,chin:.70,cx:.50,rx:.205},
{top:.12,eye:.36,mouth:.55,chin:.70,cx:.50,rx:.205},
{top:.12,eye:.36,mouth:.55,chin:.70,cx:.50,rx:.205},
{top:.13,eye:.37,mouth:.55,chin:.70,cx:.50,rx:.205}];
const hijabPresets=new Set([1,7]);
const renderCache=new WeakMap();
function draw(canvas){
 const parent=canvas.parentElement;if(!parent)return;
 const mesh=parent.querySelector('.face-landmark-canvas');
 const meshState=['fw','jw','cl','cf','fore'].map(k=>mesh?.dataset?.[k]||'0').join(',');
 const dpr=Math.min(2,Math.max(1,typeof devicePixelRatio==='number'?devicePixelRatio:1));
 const signature=[canvas.dataset.preset,canvas.dataset.hair,canvas.dataset.brow,canvas.dataset.beard,meshState,dpr,parent.clientWidth,parent.clientHeight].join('|');
 if(renderCache.get(canvas)===signature)return;
 const w=Math.max(1,Math.round(parent.clientWidth)),h=Math.max(1,Math.round(parent.clientHeight));
 canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);
 const ctx=canvas.getContext('2d');if(!ctx)return;
 ctx.setTransform(dpr,0,0,dpr,0,0);
 renderCache.set(canvas,signature);
 const preset=Math.max(0,Math.min(11,Number(canvas.dataset.preset)||0));
 const clampStyle=(v,max)=>Math.max(0,Math.min(max,Math.trunc(Number(v)||0)));
 const hair=clampStyle(canvas.dataset.hair,20),brow=clampStyle(canvas.dataset.brow,7),beard=clampStyle(canvas.dataset.beard,20);
 if(!hair&&!brow&&!beard)return;
 // Match grooming anchors to the individual portrait rather than a universal face template.
 // The underlying photo still retains its original hair/brows/beard; this is alignment only.
 const lm=portraitLandmarks[preset]||portraitLandmarks[0];
 const template=profiles[preset];
 const raw={...template,cx:lm[0],rx:lm[5],eye:lm[1]+.052,
   mouth:lm[2]+(lm[4]-lm[2])*.52,chin:lm[4],
   top:template.top+(lm[1]-.305)*.25};
 // Couple grooming anchors to the same anatomical sliders as the portrait mesh.
 const param=(key)=>Math.max(-30,Math.min(30,Number(mesh?.dataset?.[key])||0))/30;
 const jaw=param('jw'),chin=param('cl'),face=param('fw'),cheek=param('cf'),forehead=param('fore');
 // Use the EXACT mesh deformation function for grooming anchors, avoiding a
 // second, conflicting anatomy model. All positions are tile-normalised.
 const sliders=['fw','jw','cl','cf','fore'].map(k=>Number(mesh?.dataset?.[k])||0);
 const at=(x,y)=>deformPortraitPoint(x,y,sliders,preset);
 const centerBrow=at(raw.cx,lm[1]);
 const centerMouth=at(raw.cx,raw.mouth);
 const centerChin=at(raw.cx,raw.chin);
 const leftCheek=at(raw.cx-lm[5],lm[2]);
 const rightCheek=at(raw.cx+lm[5],lm[2]);
 const leftJaw=at(raw.cx-lm[6],lm[3]);
 const rightJaw=at(raw.cx+lm[6],lm[3]);
 const leftForehead=at(raw.cx-lm[7],lm[1]);
 const rightForehead=at(raw.cx+lm[7],lm[1]);
 const p={...raw,cx:centerBrow[0],eye:centerBrow[1]+.052,
   mouth:centerMouth[1],chin:centerChin[1],
   rx:(rightForehead[0]-leftForehead[0])*.5,
   top:raw.top-forehead*.008};
 const jawHalf=(rightJaw[0]-leftJaw[0])*.5;
 const cheekHalf=(rightCheek[0]-leftCheek[0])*.5;
 const X=v=>v*w,Y=v=>v*h;
 // Limit facial hair to an anatomical silhouette instead of allowing it to float past the jaw.
 const faceMask=()=>{ctx.beginPath();ctx.moveTo(X(p.cx-cheekHalf),Y(p.eye+.04));ctx.bezierCurveTo(X(p.cx-cheekHalf*1.05),Y(p.mouth+.02),X(p.cx-jawHalf),Y(p.chin-.04),X(p.cx),Y(p.chin+.015));ctx.bezierCurveTo(X(p.cx+jawHalf),Y(p.chin-.04),X(p.cx+cheekHalf*1.05),Y(p.mouth+.02),X(p.cx+cheekHalf),Y(p.eye+.04));ctx.closePath()};
 // Original photographic hair and facial hair remain under these overlays.
 let seed=(preset+1)*417+(hair+1)*199+(beard+1)*71;
 const rnd=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296};
 const base=['#16120f','#1b1613','#29221e','#201713','#231b17','#191614','#1b1511','#231c18','#1b1714','#231b17','#35302b','#211916'][preset];
 const fill=(path,color=base)=>{ctx.fillStyle=color;ctx.beginPath();path();ctx.fill()};
 const ellipse=(x,y,rx,ry)=>ctx.ellipse(X(x),Y(y),X(rx),Y(ry),0,0,Math.PI*2);
 if(hair && !hijabPresets.has(preset)){
   const configs=[null,[.075,.025,0],[.085,.045,0],[.095,.05,1],[.09,.04,1],[.075,.06,2],[.075,.075,2],[.065,.09,2],[.07,.07,3],[.07,.105,3],[.06,.13,3],[.09,.075,1],[.075,.10,4],[.08,.08,2],[.095,.04,1],[.105,.025,1],[.07,.095,5],[.06,.12,5],[.05,.16,5],[.11,.012,0],[.085,.065,1]];
   const [height,volume,shape]=configs[hair]||configs[1];
   const y=p.top+(hair===19?.06:0)-forehead*.012,left=p.cx-p.rx*1.08,right=p.cx+p.rx*1.08;
   if(hair!==19){
    fill(()=>{ctx.moveTo(X(left),Y(y+.075));ctx.bezierCurveTo(X(left-.018),Y(y-height),X(p.cx-.1),Y(y-height-volume),X(p.cx),Y(y-height-volume));ctx.bezierCurveTo(X(p.cx+.12),Y(y-height-volume*.85),X(right+.025),Y(y-height*.5),X(right),Y(y+.07));ctx.lineTo(X(right-.045),Y(y+.02));ctx.quadraticCurveTo(X(p.cx),Y(y+.02+(shape===1?.025:0)),X(left+.04),Y(y+.025));ctx.closePath()});
    if([16,17,18].includes(hair)){
      for(let side of [-1,1])fill(()=>{const sx=p.cx+side*p.rx*.87;ctx.moveTo(X(sx),Y(y+.01));ctx.quadraticCurveTo(X(sx+side*.065),Y(y+.18),X(sx+side*.02),Y(y+.33));ctx.lineTo(X(sx-side*.035),Y(y+.28));ctx.closePath()},base);
    }
    ctx.lineWidth=.65;for(let i=0;i<320;i++){
      const t=rnd(),xx=left+(right-left)*t, yy=y-height*(.25+.6*rnd())-volume*(1-Math.abs(t-.5)*2);
      ctx.strokeStyle=rnd()>.5?'rgba(185,155,123,.16)':'rgba(0,0,0,.24)';ctx.beginPath();ctx.moveTo(X(xx),Y(yy));ctx.quadraticCurveTo(X(xx+(shape===2?.018:-.014)),Y(yy+.015),X(xx+(shape===4?.008:.014)),Y(yy+.038));ctx.stroke();
    }
   }else{ctx.fillStyle='rgba(49,41,36,.20)';ctx.beginPath();ellipse(p.cx,y+.045,p.rx,.045);ctx.fill()}
 }
 if(brow){
  const thick=[0,.008,.012,.011,.021,.005,.012,.009][brow];
  for(const side of [-1,1]){
   const x=p.cx+side*.108,yy=p.eye-.047;
   ctx.lineCap='round';ctx.strokeStyle='rgba(22,17,14,.9)';ctx.lineWidth=Y(thick);
   ctx.beginPath();ctx.moveTo(X(x-side*.065),Y(yy+(brow===6?.014:0)));
   ctx.quadraticCurveTo(X(x),Y(yy-(brow===3?.028:brow===2?.018:.008)),X(x+side*.06),Y(yy+.007));ctx.stroke();
   ctx.strokeStyle='rgba(126,95,70,.3)';ctx.lineWidth=.55;
   for(let i=0;i<32;i++){const t=rnd(),xx=x+side*(t-.5)*.12;ctx.beginPath();ctx.moveTo(X(xx),Y(yy-.002));ctx.lineTo(X(xx+side*.006),Y(yy-.007-rnd()*.006));ctx.stroke()}
  }
 }
 if(beard){
  ctx.save();
  // A full-face clipping path must not truncate long beards below the chin.
  if(![15,19].includes(beard)){faceMask();ctx.clip()}
  const moustache=[2,3,4,5,6,8,16,17,20].includes(beard)||[13,14,15,19].includes(beard);
  const chin=[7,8,9,10,11,12,13,14,15,16,17,19,20].includes(beard);
  const sides=[10,11,12,13,14,15,18,19].includes(beard);
  const density=beard===1?.09:beard===11?.18:beard===12?.38:beard===14?.83:beard===19?.85:.67;
  if(moustache){fill(()=>{ctx.moveTo(X(p.cx-.086),Y(p.mouth-.035));ctx.quadraticCurveTo(X(p.cx-.04),Y(p.mouth-.062),X(p.cx),Y(p.mouth-.038));ctx.quadraticCurveTo(X(p.cx+.04),Y(p.mouth-.062),X(p.cx+.086),Y(p.mouth-.035));ctx.quadraticCurveTo(X(p.cx+.055),Y(p.mouth-.018),X(p.cx),Y(p.mouth-.028));ctx.quadraticCurveTo(X(p.cx-.055),Y(p.mouth-.018),X(p.cx-.086),Y(p.mouth-.035))},`rgba(30,23,19,${density})`)}
  if(chin){const len=beard===19?.13:beard===15?.09:.035;fill(()=>{ctx.moveTo(X(p.cx-.095),Y(p.mouth+.035));ctx.quadraticCurveTo(X(p.cx-.11),Y(p.chin+.005),X(p.cx),Y(p.chin+len));ctx.quadraticCurveTo(X(p.cx+.11),Y(p.chin+.005),X(p.cx+.095),Y(p.mouth+.035));ctx.quadraticCurveTo(X(p.cx),Y(p.mouth+.1),X(p.cx-.095),Y(p.mouth+.035))},`rgba(30,23,19,${density*.9})`)}
  if(sides)for(const side of [-1,1])fill(()=>{const sx=p.cx+side*p.rx*.78;ctx.moveTo(X(sx),Y(p.eye+.055));ctx.quadraticCurveTo(X(sx+side*.03),Y(p.mouth+.12),X(p.cx+side*.075),Y(p.chin+.01));ctx.lineTo(X(p.cx+side*.105),Y(p.mouth+.045));ctx.closePath()},`rgba(30,23,19,${density*.78})`);
  if(beard!==1){ctx.lineWidth=.5;for(let i=0;i<Math.round(600*density);i++){
    const x=p.cx+(rnd()-.5)*.34,y=p.mouth-.06+rnd()*.19;
    const region=(moustache&&y<p.mouth-.015&&Math.abs(x-p.cx)<.095)||(chin&&y>p.mouth+.04&&Math.abs(x-p.cx)<.115)||(sides&&Math.abs(x-p.cx)>.11&&y>p.eye+.06);
    if(!region)continue;ctx.strokeStyle=rnd()>.5?'rgba(20,16,13,.35)':'rgba(140,117,91,.30)';ctx.beginPath();ctx.moveTo(X(x),Y(y));ctx.lineTo(X(x+(rnd()-.5)*.008),Y(y+.008+rnd()*.012));ctx.stroke();
  }}
  ctx.restore();
 }
}
export function renderGrooming(root=document){root.querySelectorAll('.face-grooming-canvas').forEach(draw)}
let pendingFrame=0;
export function scheduleGrooming(){
 if(pendingFrame)return;
 pendingFrame=requestAnimationFrame(()=>{pendingFrame=0;renderGrooming(document)});
}
