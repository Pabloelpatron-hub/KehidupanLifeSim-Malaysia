import {recordNpcInteraction} from './npc-unified-interaction-v2.js';
import {AUTHORED_STORIES} from './npc-story-authored-120.js';
import {applyStoryDepth} from './npc-story-depth-pass05.js';
import {recordStoryConsequence} from './npc-stabilization-cp11.js';
// CP06-CP10: persistent, bounded social knowledge, relationships, autonomous schedules and story events.
// All mutations are owned by livingWorld; no direct money, police, contractor or gang grants.
import {ensureWorldCore,recordWorldEvent} from './world-core.js';
import {getNpcProfile,NPC_ROSTER_CP04} from './npc-roster-cp04.js';
import {npcDecision} from './npc-decision-cp05.js';
import {ensureNpcPsychology,reactNpc} from './npc-psychology-cp05.js';
const clamp=(n,a=0,b=100)=>Math.max(a,Math.min(b,Math.round(n)));
const hash=x=>[...String(x)].reduce((h,c)=>(Math.imul(h,31)+c.charCodeAt(0))>>>0,19);
const clone=x=>structuredClone(x);
export function living(s){const w=ensureWorldCore(s);w.socialMemory??={};w.socialLinks??={};w.schedules??={};w.storyThreads??={};w.storyLog??=[];w.storySeen??={};w.lastSocialDay??=-1;return w;}
export function remember(s,id,{type='observation',subject='player',text='',source='direct',confidence=1,privateInfo=false}={}){
 if(!s.npcs?.[id])throw Error('NPC unknown');if(!['observation','fact','promise','rumour'].includes(type))throw Error('Memory type');
 if(!['direct','player','introduced','rumour','public'].includes(source))throw Error('Memory source');
 if(typeof text!=='string'||!text.trim()||text.length>320)throw Error('Memory text');
 const w=living(s),items=w.socialMemory[id]??=[];
 const key=type+':'+subject+':'+text.toLowerCase().trim();
 const old=items.find(m=>m.key===key);if(old){old.lastDay=s.day;return clone(old);}
 const entry={id:`MEM-${id}-${hash(key)}`,key,type,subject,text:text.trim(),source,confidence:clamp(confidence*100)/100,privateInfo:!!privateInfo,day:s.day,lastDay:s.day};
 items.push(entry);if(items.length>48)items.splice(0,items.length-48);return clone(entry);
}
export function npcKnows(s,id,subject){return clone((living(s).socialMemory[id]||[]).filter(m=>m.subject===subject));}
export function linkNpc(s,from,to,{kind='professional',strength=30,source='public'}={}){
 if(from===to||!s.npcs?.[from]||!s.npcs?.[to])throw Error('Unknown relationship');
 if(!['professional','family','friend','rival','authority'].includes(kind))throw Error('Relationship kind');
 const w=living(s);w.socialLinks[from]??={};const prev=w.socialLinks[from][to];
 w.socialLinks[from][to]={kind,strength:clamp(strength),source,metDay:prev?.metDay??s.day};return clone(w.socialLinks[from][to]);
}
export function relationships(s,id){return clone(living(s).socialLinks[id]||{});}
export function npcSchedule(s,id,day=s.day){const n=s.npcs?.[id];if(!n)throw Error('NPC unknown');const p=getNpcProfile(id);const role=p?.primaryClass||n.primaryClass||'social_contact';const h=hash(id+':'+day);const weekend=day%7===5||day%7===6;
 const shift=['doctor','police_officer','security_personnel'].includes(role);
 const available=shift?(h%5!==0):(weekend?h%4!==0:h%6!==0);
 const phase=day%7===0?'family':weekend?'leisure':shift?'shift':'work';
 return {day,phase,available,place:available?n.venue:null,reason:available?'':'Urusan peribadi atau kerja',nextDay:day+1};}
export function canMeet(s,id){const schedule=npcSchedule(s,id);return {allowed:!!s.npcs[id]?.available&&schedule.available,reason:schedule.available?'':'NPC tidak berada di lokasi hari ini',schedule};}
export const STORY_TEMPLATES=AUTHORED_STORIES;
export function offerStory(s,id){const n=s.npcs?.[id];if(!n)throw Error('NPC unknown');const w=living(s),trust=n.trust||0;const available=STORY_TEMPLATES.filter(t=>trust>=t.minTrust&&!w.storySeen[`${id}:${t.id}`]);if(!available.length||openStories(s,id).length)return null;const decision=npcDecision(s,id,'meeting');if(!decision.accepted)return null;
 const t=available[hash(`${id}:${s.day}:${w.storyLog.length}`)%available.length];const key=`${id}:${t.id}`;
 w.nextStorySequence=Math.max(Number(w.nextStorySequence)||0,...Object.keys(w.storyThreads).map(x=>Number(x.match(/^THREAD-(\d+)$/)?.[1])||0))+1;
 const thread={id:'THREAD-'+String(w.nextStorySequence),npcId:id,templateId:t.id,kind:t.kind,title:t.title,description:t.description,choices:t.choices,status:'open',createdDay:s.day,dueDay:s.day+7,choice:null,resolvedDay:null};
 w.storyThreads[thread.id]=thread;recordNpcInteraction(s,id,{channel:'story',kind:'offer',text:t.title,eventId:`story:${thread.id}:offer`});w.storySeen[key]=true;w.storyLog.push({day:s.day,type:'offer',threadId:thread.id,npcId:id});
 recordWorldEvent(s,{type:'NPC_STORY_OFFER',actorId:id,payload:{threadId:thread.id,templateId:t.id}},`story:${thread.id}:offer`);
 return clone(thread);
}
export function resolveStory(s,threadId,choice){const w=living(s),t=w.storyThreads[threadId];if(!t||t.status!=='open')throw Error('Story is not open');if(s.day>t.dueDay){t.status='expired';t.resolvedDay=s.day;w.storyLog.push({day:s.day,type:'expired',threadId:t.id});throw Error('Story deadline expired');}if(![0,1,2].includes(choice))throw Error('Invalid story choice');
 t.choice=choice;t.status=choice===2?'declined':'resolved';t.resolvedDay=s.day;recordNpcInteraction(s,t.npcId,{channel:'story',kind:'resolve',text:`${t.title} - pilihan ${choice}`,eventId:`story:${threadId}:resolve`});
 const n=s.npcs[t.npcId];if(n){n.trust=clamp((n.trust||0)+(choice===0?3:choice===1?1:-1));reactNpc(s,t.npcId,choice===2?'apologise':'chat',{intensity:0.5});remember(s,t.npcId,{type:'observation',text:`Player ${['menerima','menangguhkan','menolak'][choice]}: ${t.title}`,subject:'player'});}
 w.storyLog.push({day:s.day,type:'resolve',threadId,choice});recordStoryConsequence(s,t);applyStoryDepth(s,t);recordWorldEvent(s,{type:'NPC_STORY_RESOLVE',actorId:t.npcId,payload:{threadId,choice}},`story:${threadId}:resolve`);return clone(t);
}
export function openStories(s,id=null){return Object.values(living(s).storyThreads).filter(t=>t.status==='open'&&(!id||t.npcId===id)).map(clone);}
export function npcLivingDay(s){const w=living(s);if(w.lastSocialDay>=s.day)return;w.lastSocialDay=s.day;
 for(const t of Object.values(w.storyThreads)){if(t.status==='open'&&s.day>t.dueDay){t.status='expired';t.resolvedDay=s.day;w.storyLog.push({day:s.day,type:'expired',threadId:t.id});recordStoryConsequence(s,t);applyStoryDepth(s,t);}}
 const ids=Object.keys(s.npcs||{}).filter(id=>s.npcs[id]?.importance!=='background');
 for(const id of ids.slice(0,100)){w.schedules[id]=npcSchedule(s,id);const p=ensureNpcPsychology(s,id);if(s.day%7===0&&p.emotion.stress>40)p.emotion.stress=clamp(p.emotion.stress-2);}
 if(s.day%4===0&&ids.length){const id=ids[hash(s.day)%ids.length];if(!openStories(s,id).length&&npcDecision(s,id,'meeting').accepted)offerStory(s,id);}
 w.storyLog=w.storyLog.slice(-300);
}
export function npcLivingDossier(s,id){return {memory:npcKnows(s,id,'player').slice(-8),relationships:relationships(s,id),schedule:npcSchedule(s,id),stories:openStories(s,id)};}
