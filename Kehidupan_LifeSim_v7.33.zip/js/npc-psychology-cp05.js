// CP05: deterministic personality and bounded emotional state; saved in livingWorld.
// Identity templates remain immutable; no NPC has access to hidden player information.
import {ensureWorldCore} from './world-core.js';
import {getNpcProfile} from './npc-roster-cp04.js';
const traits=['openness','conscientiousness','extraversion','agreeableness','neuroticism'];
const hash=t=>[...String(t)].reduce((h,c)=>(Math.imul(h,33)+c.charCodeAt(0))>>>0,5381);
const clamp=(v,a=0,b=100)=>Math.max(a,Math.min(b,Math.round(v)));
export function defaultPsychology(id){
 const p=getNpcProfile(id),seed=hash(id),t={};
 traits.forEach((k,i)=>t[k]=15+hash(`${seed}:${k}:${i}`)%71);
 const role=p?.primaryClass||'social_contact';
 if(['banker','legal_professional','government_officer'].includes(role))t.conscientiousness=clamp(t.conscientiousness+20);
 if(['broker','politician','business_owner'].includes(role))t.extraversion=clamp(t.extraversion+15);
 return {traits:t,emotion:{trust:0,stress:20,anger:0,joy:45,fear:10},motives:{security:35+hash(id+'security')%51,achievement:35+hash(id+'achievement')%51,belonging:35+hash(id+'belonging')%51,autonomy:35+hash(id+'autonomy')%51},lastDay:0,history:[]};
}
export function ensureNpcPsychology(s,id){if(!s?.npcs?.[id])throw Error('NPC tidak ditemui');const w=ensureWorldCore(s);w.psychology??={};return w.psychology[id]??=defaultPsychology(id);}
export function reactNpc(s,id,action,{intensity=1,context={}}={}){
 const psych=ensureNpcPsychology(s,id),npc=s.npcs[id];
 if(!['introduce','chat','contact','network','date','apologise','message','promise_kept','promise_broken','insult'].includes(action))throw Error('Unknown psychology action');
 if(!Number.isFinite(intensity)||intensity<0||intensity>3)throw Error('Invalid intensity');
 const {emotion:e,traits:t}=psych;const factor=intensity;
 const changes={introduce:{joy:3,trust:1},chat:{joy:4,stress:-2,trust:2},contact:{trust:3},network:{trust:2,stress:1},date:{joy:8,trust:3},apologise:{anger:-9,trust:2},message:{joy:2},promise_kept:{trust:12,joy:6,stress:-3},promise_broken:{trust:-17,anger:15,stress:8},insult:{anger:17,trust:-11,fear:2}}[action];
 const sensitivity=1+(t.neuroticism-50)/200;
 for(const [k,v] of Object.entries(changes))e[k]=clamp(e[k]+v*factor*(k==='anger'||k==='stress'||k==='fear'?sensitivity:1));
 if(action==='promise_broken'||action==='insult')npc.resentment=clamp((npc.resentment||0)+8*factor);
 if(action==='promise_kept')npc.resentment=clamp((npc.resentment||0)-5*factor);
 psych.lastDay=s.day;
 psych.history.push({day:s.day,action,emotion:{...e}});if(psych.history.length>24)psych.history.splice(0,psych.history.length-24);
 return {emotion:{...e},disposition:npcDisposition(s,id)};
}
export function npcDisposition(s,id){const p=ensureNpcPsychology(s,id),e=p.emotion,t=p.traits;
 const score=e.trust+e.joy*.3+((s.npcs[id].trust||0)*.4)-e.anger*.7-e.fear*.25-e.stress*.2+(t.agreeableness-50)*.15;
 return score>=60?'mesra':score>=25?'terbuka':score>=0?'berhati-hati':'bermusuhan';
}
export function psychologyDay(s){const w=ensureWorldCore(s);if(!w.psychology)return;for(const [id,p] of Object.entries(w.psychology)){
 if(!s.npcs?.[id])continue;const elapsed=Math.max(0,Math.min(365,s.day-(p.lastDay??s.day)));if(!elapsed)continue;
 for(const [key,baseline] of Object.entries({trust:0,stress:20,anger:0,joy:45,fear:10})){
 const delta=baseline-p.emotion[key];p.emotion[key]=clamp(p.emotion[key]+Math.sign(delta)*Math.min(Math.abs(delta),Math.ceil(elapsed/3)));
 }p.lastDay=s.day;
 }}
export function validatePsychology(s){const w=ensureWorldCore(s);for(const [id,p] of Object.entries(w.psychology||{})){
 if(!id||!p||!p.traits||!p.emotion||!p.motives)throw Error('Invalid psychology record');
 for(const value of [...Object.values(p.traits),...Object.values(p.emotion),...Object.values(p.motives)])if(!Number.isFinite(value)||value<0||value>100)throw Error('Invalid psychology score');
 }return true;}

// Phase 03: bounded, saved emotional context. No inference of private facts.
export function npcEmotionalContext(s,id){
 const p=ensureNpcPsychology(s,id),e=p.emotion;
 const dominant=e.anger>=55?'angry':e.fear>=65?'afraid':e.stress>=70?'stressed':e.joy>=70?'happy':'neutral';
 return {dominant,disposition:npcDisposition(s,id),emotion:{...e},lastInteraction:p.history.at(-1)?.action??null};
}
// Phase 03: player-visible consequences must be tied to an actual event, not free-form text alone.
export function npcPromiseOutcome(s,id,kept,{commitmentId}={}){
 const w=ensureWorldCore(s),commitment=(w.commitments||[]).find(c=>c.id===commitmentId&&c.npcId===id);
 if(!commitment||commitment.status!==(kept?'fulfilled':'broken'))throw Error('Verified commitment outcome required');
 w.psychologyOutcomes??={};const key=`${commitmentId}:${commitment.status}`;
 if(w.psychologyOutcomes[key])return {duplicate:true,emotion:{...ensureNpcPsychology(s,id).emotion}};
 const result=reactNpc(s,id,kept?'promise_kept':'promise_broken');
 w.psychologyOutcomes[key]={day:s.day,npcId:id,action:kept?'promise_kept':'promise_broken'};
 return {...result,duplicate:false};
}
