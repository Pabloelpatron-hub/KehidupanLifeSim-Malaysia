import {inspectConstructionActivity} from './compliance-activity.js';
import {tenderBoard,staffPerks} from './contractor-expansion2-cp2.js';
// Contractor vertical slice CP1. Monetary amounts are integer sen.
import {account,transfer,spend,income,post} from './finance.js';
import {random} from './state.js';
export const GRADES=[null,{cap:500000,limit:20000000,fee:2000,staff:0},{cap:2500000,limit:50000000,fee:8000,staff:0},{cap:5000000,limit:100000000,fee:15000,staff:0},{cap:15000000,limit:300000000,fee:35000,staff:1},{cap:25000000,limit:500000000,fee:70000,staff:1},{cap:50000000,limit:1000000000,fee:100000,staff:2},{cap:75000000,limit:Infinity,fee:140000,staff:2}];
const quiz={B:['Apakah tujuan curing konkrit?','Mengurangkan kehilangan kelembapan'],CE:['Apakah fungsi pemadatan tanah?','Meningkatkan ketumpatan dan kestabilan'],ME:['Apakah tindakan selamat sebelum kerja elektrik?','Asingkan bekalan dan sahkan tiada voltan'],F:['Apakah langkah awal pengurusan fasiliti?','Semak aset dan jadual penyelenggaraan']};
// CP1.3: transparent indicative tender cost model, not a supplier quotation.
// Fractions are budget allocations for each work category. All calculations are integer sen.
export const COST_PROFILES={
 B:{materials:.43,labour:.28,plant:.12,overhead:.17,label:'Bangunan'},
 CE:{materials:.35,labour:.24,plant:.27,overhead:.14,label:'Kejuruteraan awam'},
 ME:{materials:.53,labour:.25,plant:.10,overhead:.12,label:'Mekanikal & elektrik'},
 F:{materials:.25,labour:.48,plant:.10,overhead:.17,label:'Fasiliti'}
};
export function costEstimate(price,category,margin=12){
 const profile=COST_PROFILES[category]||COST_PROFILES.B;
 const rate=Number(margin);
 if(!Number.isFinite(price)||price<=0||!Number.isFinite(rate)||rate<0||rate>45)throw Error('Anggaran BQ tidak sah');
 // Margin is markup on cost, not profit as a percentage of revenue.
 const budget=Math.round(price/(1+rate/100));
 const materials=Math.round(budget*profile.materials),labour=Math.round(budget*profile.labour),plant=Math.round(budget*profile.plant);
 const overhead=budget-materials-labour-plant;
 return {budget,materials,labour,plant,overhead,estimatedProfit:price-budget,category,markup:rate};
}
// CP2 indicative unit-rate reference model. MYR values converted to sen.
// These are adjustable GAME ASSUMPTIONS, not JKR schedule rates or quotations.
export const UNIT_RATES={
 B:[['readyMix','Konkrit siap bancuh', 'm³',355],['reinforcement','Tetulang keluli','kg',4.15],['formwork','Acuan konkrit','m²',78],['masonry','Dinding bata','m²',115]],
 CE:[['earthworks','Kerja tanah','m³',32],['drainage','Longkang konkrit','m',285],['roadbase','Lapisan asas jalan','m²',48],['asphalt','Turapan asfalt','m²',62]],
 ME:[['cabling','Pendawaian dan pemasangan','point',175],['distribution','Papan agihan','unit',2400],['piping','Paip mekanikal','m',125],['fixtures','Pemasangan peralatan','unit',480]],
 F:[['inspection','Pemeriksaan aset','unit',95],['servicing','Servis peralatan','unit',280],['repair','Pembaikan kecil','unit',380],['cleaning','Pembersihan kawasan','m²',8.5]]
};
export function quantityBQ(project,overrides={}){
 const rows=UNIT_RATES[project.category]||UNIT_RATES.B;
 const target=costEstimate(project.price,project.category,project.margin).materials;
 const shares=[.32,.28,.24,.16];
 const items=rows.map(([code,label,unit,rate],i)=>{
  const unitRate=Math.round(rate*100),suggested=Math.max(1,Math.round(target*shares[i]/unitRate));
  const qty=Object.hasOwn(overrides,code)?Number(overrides[code]):suggested;
  if(!Number.isInteger(qty)||qty<0||qty>10000000)throw Error('Kuantiti BQ tidak sah');
  return {code,label,unit,unitRate,qty,subtotal:unitRate*qty};
 });
 return {items,materialTotal:items.reduce((sum,i)=>sum+i.subtotal,0),note:'Kadar unit indikatif untuk simulasi; bukan kadar rasmi JKR.'};
}
export function financialPosition(s,p){
 const b=ensure(s).company;const pending=(p.claims||[]).filter(c=>c.status!=='paid').reduce((v,c)=>v+c.net,0);
 const remaining=Math.max(0,costEstimate(p.price,p.category,p.margin).budget-(p.cost||0));
 return {cash:s.accounts[b.id].balance,receivable:pending,remainingCost:remaining,retention:p.retained||0,lockedBond:p.bond||0,forecastCash:s.accounts[b.id].balance+pending-remaining,profitToDate:(p.paid||0)+(p.retained||0)-(p.cost||0)};
}
export function costBreakdown(project){
 const est=costEstimate(project.price,project.category,project.margin);
 return {estimate:est,actual:project.costParts||{materials:0,labour:0,plant:0,overhead:0},spent:project.cost||0};
}
export function ensure(s){if(!s.contractor)s.contractor={company:null,projects:[],offers:[],lastOfferDay:-1};return s.contractor;}
export function setup(s,{name,structure,grade,category,staff}){const c=ensure(s);if(c.company)throw Error('Syarikat kontraktor sudah didaftarkan');grade=Number(grade);staff=Number(staff);const g=GRADES[grade];if(!g||!quiz[category])throw Error('Gred atau kategori tidak sah');if(staff<g.staff)throw Error('Personel teknikal tidak mencukupi');if(!name?.trim()||name.length>60)throw Error('Masukkan nama syarikat');if(!['enterprise','company'].includes(structure))throw Error('Jenis entiti tidak sah');const fee=structure==='company'?100000:6000;if(s.accounts.main.balance<g.cap+fee)throw Error('Modal peribadi tidak cukup untuk pendaftaran dan suntikan modal');spend(s,'main',fee,'SSM pendaftaran '+name,'registration');const id='contractor-'+(++s.sequence);account(s,id,name.trim(),id,'asset',1);transfer(s,'main',id,g.cap,'Modal syarikat kontraktor','capital');c.company={id,name:name.trim(),ssmNumber:'SIM-SSM-'+String(s.sequence).padStart(7,'0'),structure,grade,category,categories:[category],staff,capital:g.cap,registrationDay:s.day,license:'pending-exam',examUntil:0,examAttempts:0,spkk:false,stb:false,history:[],reputation:50};}
export const EXAM_BANK={
 B:[['Apakah tujuan curing konkrit?','Mengurangkan kehilangan kelembapan','Mempercepatkan karat','Menggantikan tetulang'],['Sebelum kerja konkrit, apakah yang perlu diperiksa?','Acuan, tetulang dan kelulusan pemeriksaan','Warna lori','Harga cat'],['Jika konkrit tidak mencapai kekuatan spesifikasi?','Hentikan penerimaan dan rujuk jurutera','Teruskan kerja tanpa rekod','Tutup dengan plaster']],
 CE:[['Apakah fungsi pemadatan tanah?','Meningkatkan ketumpatan dan kestabilan','Menambah kandungan air','Mengurangkan kawalan kualiti'],['Sebelum pengorekan berhampiran utiliti?','Semak pelan utiliti dan permit','Korek terus','Tunggu sehingga malam'],['Apakah tujuan kawalan hakisan?','Mengurangkan kelodak masuk saliran','Mempercepat banjir','Menghapuskan pengukuran']],
 ME:[['Apakah tindakan selamat sebelum kerja elektrik?','Asingkan bekalan dan sahkan tiada voltan','Sentuh kabel untuk uji','Langkau permit'],['Sebelum menghidupkan papan agihan?','Uji penebatan, pembumian dan perlindungan','Tutup panel sahaja','Ubah label tanpa ujian'],['Apabila kerja melibatkan ruang terkurung?','Penilaian risiko, permit dan pemantauan','Masuk seorang diri','Abaikan pengudaraan']],
 F:[['Apakah langkah awal pengurusan fasiliti?','Semak aset dan jadual penyelenggaraan','Hapus rekod aset','Tunggu kerosakan'],['Apakah maksud penyelenggaraan pencegahan?','Servis berkala sebelum kerosakan','Baiki selepas gagal sahaja','Tidak perlu rekod'],['Apabila menerima aduan kebocoran?','Asingkan risiko, periksa dan rekod tindakan','Padam aduan','Tangguh tanpa pemeriksaan']]
};
export function examQuestion(s){const b=ensure(s).company;if(!b)return null;const questions=EXAM_BANK[b.category]||EXAM_BANK.B;return questions[Math.min(b.examProgress||0,questions.length-1)];}
export function exam(s,answer){const b=ensure(s).company;if(!b||b.license!=='pending-exam')throw Error('Tiada ujian yang perlu diambil');if(s.day<b.examUntil)throw Error('Ujian semula selepas hari '+b.examUntil);const q=examQuestion(s);b.examAttempts=(b.examAttempts||0)+1;if(answer!==q[1]){b.examUntil=s.day+3;b.examProgress=0;return false;}b.examProgress=(b.examProgress||0)+1;if(b.examProgress>=EXAM_BANK[b.category].length){b.license='pending-fee';b.examProgress=0;return true;}return 'next';}

export function activate(s){const b=ensure(s).company;if(!b||b.license!=='pending-fee')throw Error('Lulus ujian dahulu');const fee=5000+GRADES[b.grade].fee;spend(s,b.id,fee,'CIDB PPK yuran proses dan pendaftaran (simulasi)','licensing');b.license='processing';b.approvalDay=s.day+3;}
export function certificate(s,type){
 const b=ensure(s).company;if(!b||b.license!=='active')throw Error('PPK belum aktif');
 if(!['spkk','stb'].includes(type))throw Error('Sijil tidak sah');
 if(b[type])throw Error('Sijil sudah aktif');
 b.certificateApplications??={};
 if(b.certificateApplications[type]?.status==='processing')throw Error('Permohonan sedang diproses');
 // STB eligibility is a player-declared game flag, not inferred from identity.
 if(type==='stb'&&!b.bumiputeraDeclared)throw Error('STB hanya untuk syarikat yang memilih kelayakan Bumiputera secara manual dalam simulasi');
 b.certificateApplications[type]={status:'processing',submitted:s.day,decisionDay:s.day+(type==='spkk'?5:7)};
 return b.certificateApplications[type];
}
export function setBumiputeraDeclaration(s,eligible){
 const b=ensure(s).company;if(!b||b.license!=='active')throw Error('PPK belum aktif');
 b.bumiputeraDeclared=!!eligible;
 return b.bumiputeraDeclared;
}

export function offers(s){return tenderBoard(s);}
function resolveBidImmediately(s,id,margin){const c=ensure(s),b=c.company;const o=c.pendingTenderSnapshot||offers(s).find(x=>x.id===id);if(!o||!b||b.license!=='active')throw Error('Tender tidak tersedia');if(b.blacklistedUntil>s.day)throw Error('Syarikat disekat daripada tender sehingga hari '+b.blacklistedUntil);if(!activeCategories(b).includes(o.category))throw Error('Kategori PPK tidak sepadan');if(b.grade<o.grade)throw Error('Gred PPK tidak mencukupi untuk tender G'+o.grade);if(o.government&&!b.spkk)throw Error('Tender kerajaan memerlukan SPKK');if(o.value>GRADES[b.grade].limit)throw Error('Had gred CIDB tidak mencukupi');margin=Number(margin);if(!Number.isFinite(margin)||margin<0||margin>45)throw Error('Margin 0–45% sahaja');const price=Math.round(o.value*(1+margin/100));if(price>GRADES[b.grade].limit)throw Error('Harga bidaan melebihi had gred');const evaluation=tenderEvaluation(o,margin,Math.min(100,b.reputation+(staffPerks(s).tender||0)));const won=random(s)<evaluation.chance;if(won){const requiredBond=Math.round(price*o.bondRate);if(s.accounts[b.id].balance<requiredBond)throw Error('Dana syarikat tidak cukup untuk bon pelaksanaan');}c.weeklyBoard=c.weeklyBoard.filter(x=>x.id!==id);c.offers=c.offers.filter(x=>x.id!==id);if(!won){b.history.push({day:s.day,title:o.name,result:'Kalah tender',price});return false;}const bond=Math.round(price*o.bondRate);if(bond)spend(s,b.id,bond,'Bon pelaksanaan diikat: '+o.name,'bond');const project={...o,bq:quantityBQ({price,category:o.category,margin}),procurement:{materials:'standard',subcontract:null},variations:[],siteQuality:75,siteLog:[],costParts:{materials:0,labour:0,plant:0,overhead:0},id:'project-'+(++s.sequence),price,margin,progress:0,cost:0,paid:0,claimable:0,retained:0,bond,status:'active',start:s.day,deadline:s.day+o.days,delay:0,crises:0,pendingCrisis:null,defectDue:0,defectsResolved:0,unpaidLad:0};c.projects.push(project);if(o.advanceRate){const adv=Math.round(price*o.advanceRate);income(s,b.id,adv,'Pendahuluan projek '+o.name,'project-advance');project.paid+=adv;}return true;}
export function bid(s,id,margin){
 const c=ensure(s),b=c.company,o=offers(s).find(x=>x.id===id);
 if(!o||!b||b.license!=='active')throw Error('Syarikat belum aktif atau tender telah tamat');
 if(b.blacklistedUntil>s.day)throw Error('Syarikat disekat daripada tender');
 if(!activeCategories(b).includes(o.category)||b.grade<o.grade||o.value>GRADES[b.grade].limit)throw Error('Kategori atau gred CIDB tidak layak');
 if(o.government&&!b.spkk)throw Error('Tender kerajaan memerlukan SPKK aktif');
 margin=Number(margin);if(!Number.isFinite(margin)||margin<0||margin>45)throw Error('Margin 0–45% sahaja');
 const price=Math.round(o.value*(1+margin/100));if(price>GRADES[b.grade].limit)throw Error('Harga bidaan melebihi had gred');
 if((s.accounts[b.id]?.balance||0)<Math.round(price*o.bondRate))throw Error('Tunai untuk bon pelaksanaan tidak mencukupi');
 c.tenderApplications??=[];
 if(c.tenderApplications.some(a=>a.offerId===id))throw Error('Tender ini sudah dipohon');
 const application={id:'application-'+(++s.sequence),offerId:id,offer:{...o},margin,price,submittedDay:s.day,decisionDay:s.day+5+(o.catalogId%12),status:'evaluation',notified:false};
 c.tenderApplications.push(application);return application;
}
export function tenderDecisionDaily(s){
 const c=ensure(s),b=c.company;if(!b)return;
 for(const a of c.tenderApplications||[]){
  if(a.status!=='evaluation'||s.day<a.decisionDay)continue;
  c.pendingTenderSnapshot=a.offer;
  try {const won=resolveBidImmediately(s,a.offerId,a.margin);a.status=won?'won':'lost';a.resolvedDay=s.day;
   if(won){const p=c.projects[c.projects.length-1];a.projectId=p?.id;}}
  catch(e){a.status='unable-to-award';a.reason=String(e.message||e);a.resolvedDay=s.day;}
  finally{delete c.pendingTenderSnapshot;}
 }
}
export function acknowledgeTender(s,id){const c=ensure(s),a=(c.tenderApplications||[]).find(x=>x.id===id);if(!a||a.status==='evaluation')throw Error('Keputusan belum tersedia');a.notified=true;return a;}
export function jobHistory(s){return ensure(s).projects.filter(p=>p.status==='closed'||p.status==='terminated').map(p=>({...p,finalLabel:p.status==='closed'?'SIAP 100%':'TERGENDALA'}));}

export function work(s,id,choice='normal'){const c=ensure(s),b=c.company,p=c.projects.find(x=>x.id===id);if(!p||p.status!=='active')throw Error('Projek tidak aktif');inspectConstructionActivity(s,id);if(p.pendingCrisis)throw Error('Selesaikan krisis tapak dahulu');const remaining=100-p.progress,delta=Math.min(remaining,choice==='fast'?20:10);const estimate=costEstimate(p.price,p.category,p.margin);const adjustedMaterials=p.bq?.materialTotal??estimate.materials;const budget=estimate.budget-estimate.materials+adjustedMaterials;const base=Math.round(budget*delta/100);const extra=choice==='fast'?1.3:choice==='cheap'?.8:1;const procurement=p.procurement||{};const procurementFactor=procurement.materials==='premium'?1.09:procurement.materials==='budget'?.94:1;const subcontractFactor=procurement.subcontract==='specialist'?1.075:procurement.subcontract==='economy'?.965:1;const cost=Math.round(base*extra*procurementFactor*subcontractFactor);const materialsDue=Math.round(cost*estimate.materials/Math.max(1,estimate.budget));const stockUsed=Math.min(materialsDue,p.materialStockValue||0);const stockCashUsed=stockUsed?Math.min(p.materialStockCashValue||0,Math.round((p.materialStockCashValue||0)*stockUsed/Math.max(1,p.materialStockValue||0))):0;const cashDue=cost-stockUsed;if(s.accounts[b.id].balance<cashDue){p.delay++;p.stalled=(p.stalled||0)+1;p.shortfall=Math.max(0,cashDue-s.accounts[b.id].balance);return 'stalled';}p.shortfall=0;if(cashDue)spend(s,b.id,cashDue,'Kos kerja tapak: '+p.name,'project-cost');p.materialStockValue=(p.materialStockValue||0)-stockUsed;p.materialStockCashValue=Math.max(0,(p.materialStockCashValue||0)-stockCashUsed);p.materialStockConsumed=(p.materialStockConsumed||0)+stockUsed;p.prepaidRealizedSaving=(p.prepaidRealizedSaving||0)+Math.max(0,stockUsed-stockCashUsed);p.cost+=cashDue;p.costParts??={materials:0,labour:0,plant:0,overhead:0};const parts=['materials','labour','plant'];let allocated=0;for(const key of parts){const amount=Math.round(cashDue*estimate[key]/Math.max(1,estimate.budget));p.costParts[key]+=amount;allocated+=amount;}p.costParts.overhead+=cashDue-allocated;p.progress+=delta;p.siteLog??=[];p.siteLog.push({day:s.day,kind:'work',progress:delta,cost:cashDue,stockUsed,materials:procurement.materials||'standard',subcontract:procurement.subcontract||'none'});if(procurement.materials==='budget'&&random(s)<.16)p.siteQuality=Math.max(0,(p.siteQuality??75)-6);if(procurement.subcontract==='specialist')p.siteQuality=Math.min(100,(p.siteQuality??75)+2);if(random(s)<.18){p.crises++;p.pendingCrisis={kind:['safety','supply','weather','machinery','design','labour'][Math.floor(random(s)*6)],day:s.day};}p.claimable=Math.max(0,Math.round(p.price*p.progress/100)-p.paid-p.retained-(p.pendingClaimAmount||0));if(p.progress>=100)p.status='awaiting-cpc';}
export const CRISIS={safety:{title:'Pemeriksaan keselamatan mengejut',description:'Pemeriksa menemui PPE atau dokumen keselamatan pekerja tidak lengkap.',choices:[['comply','Hentikan kerja dan betulkan pematuhan'],['replace','Panggil pasukan bertauliah tambahan'],['ignore','Teruskan kerja — risiko tindakan penguatkuasaan']]},supply:{title:'Bekalan bahan lewat',description:'Pembekal gagal menghantar bahan mengikut jadual.',choices:[['wait','Tunggu pembekal asal'],['replace','Beli stok daripada pembekal alternatif'],['ignore','Gunakan bahan sedia ada — risiko kualiti']]},weather:{title:'Cuaca buruk di tapak',description:'Hujan lebat menjejaskan jadual kerja.',choices:[['wait','Tangguhkan kerja demi keselamatan'],['replace','Sediakan perlindungan dan saliran sementara'],['ignore','Teruskan kerja — risiko kemalangan']]},machinery:{title:'Jentera rosak',description:'Excavator rosak semasa kerja kritikal.',choices:[['wait','Tunggu alat ganti'],['replace','Sewa jentera gantian'],['ignore','Teruskan dengan jentera rosak']]},design:{title:'Percanggahan lukisan',description:'Pelan jurutera dan ukuran tapak tidak sepadan.',choices:[['wait','Dapatkan arahan bertulis perunding'],['replace','Lantik jurukur tambahan'],['ignore','Teruskan tanpa pengesahan']]},labour:{title:'Kekurangan tenaga kerja',description:'Subkontraktor gagal menyediakan pekerja.',choices:[['wait','Susun semula jadual'],['replace','Ambil pasukan pengganti'],['ignore','Paksa kerja lebih masa tanpa kawalan']]}};

// CP4 procurement and approved variation instructions. All financial values are integer sen.
// Rates, outcomes and timelines are illustrative gameplay assumptions, not statutory JKR terms.
export const PROCUREMENT_OPTIONS={materials:['standard','premium','budget'],subcontract:['none','specialist','economy']};
export function setProcurement(s,id,materials,subcontract){
 const p=ensure(s).projects.find(x=>x.id===id);
 if(!p||p.status!=='active'||p.pendingCrisis)throw Error('Projek tidak tersedia untuk perolehan');
 if(!PROCUREMENT_OPTIONS.materials.includes(materials)||!PROCUREMENT_OPTIONS.subcontract.includes(subcontract))throw Error('Pilihan perolehan tidak sah');
 p.procurement={materials,subcontract};p.siteLog??=[];p.siteLog.push({day:s.day,kind:'procurement',materials,subcontract});return p.procurement;
}
export function requestVariation(s,id,percent,reason){
 const c=ensure(s),b=c.company,p=c.projects.find(x=>x.id===id);
 if(!p||p.status!=='active'||p.pendingCrisis)throw Error('Projek tidak aktif atau krisis belum selesai');
 percent=Number(percent);if(!Number.isFinite(percent)||percent<1||percent>15)throw Error('Variasi mestilah 1–15%');
 if(!['client','site','design'].includes(reason))throw Error('Sebab variasi tidak sah');
 if((p.variations||[]).some(v=>v.status==='pending'))throw Error('Satu permohonan VO sedang diproses');
 const increase=Math.round(p.price*percent/100),approvedDay=s.day+(p.government?10:5);
 const v={id:'vo-'+(++s.sequence),reason,percent,increase,requestedDay:s.day,decisionDay:approvedDay,status:'pending'};
 p.variations??=[];p.variations.push(v);return v;
}
export function cp4Daily(s){
 const b=ensure(s).company;if(!b)return;
 for(const p of ensure(s).projects){for(const v of p.variations||[]){if(v.status!=='pending'||s.day<v.decisionDay)continue;
 const chance=v.reason==='client'?.83:v.reason==='design'?.7:.58;
 if(random(s)<chance){v.status='approved';p.price+=v.increase;p.deadline+=Math.max(1,Math.round(p.days*v.percent/100));p.scope+=' · VO '+v.percent+'%';p.bq=quantityBQ({price:p.price,category:p.category,margin:p.margin});}
 else{v.status='rejected';b.reputation=Math.max(0,b.reputation-1);}
 p.siteLog??=[];p.siteLog.push({day:s.day,kind:'variation',result:v.status,amount:v.status==='approved'?v.increase:0});
 }}
}
export function resolveCrisis(s,id,choice){const c=ensure(s),b=c.company,p=c.projects.find(x=>x.id===id);if(!p||!['active','awaiting-cpc'].includes(p.status)||!p.pendingCrisis)throw Error('Tiada krisis aktif');if(!['comply','replace','wait','ignore'].includes(choice))throw Error('Pilihan tidak sah');const kind=p.pendingCrisis.kind;let cost=0;if(choice==='replace'){cost=Math.round(p.price*.012);p.delay+=1;}else if(choice==='comply'){cost=Math.round(p.price*.006);p.delay+=2;}else if(choice==='wait'){p.delay+=3;}else{if(random(s)<.65){cost=Math.round(p.price*.025);p.delay+=5;b.reputation=Math.max(0,b.reputation-12);b.complianceStrikes=(b.complianceStrikes||0)+1;}else b.reputation=Math.max(0,b.reputation-3);}if(cost){if(s.accounts[b.id].balance<cost)throw Error('Tunai syarikat tidak mencukupi untuk tindakan ini');spend(s,b.id,cost,'Tindakan krisis tapak: '+kind,'site-crisis');p.cost+=cost;}p.crisisLog??=[];p.crisisLog.push({day:s.day,kind,choice,cost});p.pendingCrisis=null;return {cost,delay:p.delay};}
export function repairDefect(s,id){const c=ensure(s),b=c.company,p=c.projects.find(x=>x.id===id);if(!p||p.status!=='dlp'||!p.defectDue)throw Error('Tiada kecacatan belum dibaiki');if(s.accounts[b.id].balance<p.defectDue)throw Error('Tunai tidak cukup untuk pembaikan DLP');spend(s,b.id,p.defectDue,'Pembaikan kecacatan DLP: '+p.name,'defect-repair');p.cost+=p.defectDue;p.defectDue=0;p.defectsResolved++;}
export function terminate(s,id){const c=ensure(s),b=c.company,p=c.projects.find(x=>x.id===id);if(!p||p.status!=='active')throw Error('Projek tidak aktif');if(p.bond){p.cost+=p.bond;p.bond=0;}p.status='terminated';p.pendingCrisis=null;b.reputation=Math.max(0,b.reputation-20);b.history.push({day:s.day,title:p.name,result:'Ditamatkan',price:p.price,profit:p.paid-p.cost});}
// Claims are certified and paid after a contract-dependent delay; all amounts in sen.
export function claim(s,id){const b=ensure(s).company,p=ensure(s).projects.find(x=>x.id===id);if(!p||!['active','awaiting-cpc'].includes(p.status)||p.claimable<=0)throw Error('Tiada kerja yang layak dituntut');const amount=p.claimable;p.claims??=[];const retention=Math.round(amount*p.retentionRate);const approvalDays=p.government?7:4;const paymentDays=p.government?21:14;const rec={id:'claim-'+(++s.sequence),submitted:s.day,approved:s.day+approvalDays,payDay:s.day+approvalDays+paymentDays,gross:amount,retention,net:amount-retention,status:'submitted'};p.claims.push(rec);p.claimable=0;p.pendingClaimAmount=(p.pendingClaimAmount||0)+amount;return rec;}
export function finish(s,id){const b=ensure(s).company,p=ensure(s).projects.find(x=>x.id===id);if(!p||p.status!=='awaiting-cpc')throw Error('Kerja belum 100%');if(p.claimable>0)throw Error('Hantar tuntutan akhir dahulu');if(p.pendingCrisis)throw Error('Selesaikan krisis tapak dahulu');p.status='dlp';p.dlpEnd=s.day+365;const late=Math.max(0,s.day-p.deadline);const lad=Math.min(Math.round(p.price*.1),late*p.lad);if(lad){const payable=Math.min(lad,s.accounts[b.id].balance);if(payable){spend(s,b.id,payable,'LAD kelewatan: '+p.name,'lad');p.cost+=payable;}p.unpaidLad=lad-payable;}if(p.bond){income(s,b.id,p.bond,'Bon pelaksanaan dilepaskan: '+p.name,'bond-release');p.bond=0;}b.history.push({day:s.day,title:p.name,result:'CPC',price:p.price,profit:p.paid+p.retained-p.cost});b.reputation=Math.min(100,b.reputation+(late?0:3));}
export function daily(s){categoryDaily(s);tenderDecisionDaily(s);accrueProjectInterest(s);cp3Daily(s);cp4Daily(s);cp5Daily(s);const c=ensure(s),b=c.company;if(!b)return;if(b.license==='processing'&&s.day>=b.approvalDay)b.license='active';for(const p of c.projects){for(const claim of p.claims||[]){if(claim.status==='submitted'&&s.day>=claim.approved)claim.status='certified';if(claim.status==='certified'&&s.day>=claim.payDay){income(s,b.id,claim.net,'Progress claim diterima: '+p.name,'progress-claim');p.paid+=claim.net;p.retained+=claim.retention;p.pendingClaimAmount=Math.max(0,(p.pendingClaimAmount||0)-claim.gross);claim.status='paid';}}if(p.status==='active'&&s.day>p.deadline){p.overdueDays=s.day-p.deadline;}if(p.status==='dlp'&&!p.defectChecked&&s.day>=p.dlpEnd-30){p.defectChecked=true;if(random(s)<Math.min(.75,.3+Math.max(0,75-(p.siteQuality??75))*.01))p.defectDue=Math.max(10000,Math.round(p.price*.004));}if(p.status==='dlp'&&s.day>=p.dlpEnd&&!p.defectDue&&!p.unpaidLad&&!(p.claims||[]).some(c=>c.status!=='paid')){if(p.retained)income(s,b.id,p.retained,'Retention dilepaskan: '+p.name,'retention');p.retained=0;p.status='closed';}}}
export function settleLad(s,id){const b=ensure(s).company,p=ensure(s).projects.find(x=>x.id===id);if(!p||!p.unpaidLad)throw Error('Tiada LAD tertunggak');if(s.accounts[b.id].balance<p.unpaidLad)throw Error('Tunai syarikat tidak mencukupi');spend(s,b.id,p.unpaidLad,'Bayar LAD tertunggak: '+p.name,'lad');p.cost+=p.unpaidLad;p.unpaidLad=0;}
export function question(category,s){return s?examQuestion(s):EXAM_BANK[category]?.[0]||quiz[category];}
// CP2: simplified working-capital financing, deliberately distinct from official bank products.
export function financeProject(s,id,amount){
 const c=ensure(s),b=c.company,p=c.projects.find(x=>x.id===id);
 if(!b||!p||p.status!=='active')throw Error('Pembiayaan hanya untuk projek aktif');
 amount=Math.round(Number(amount)*100);
 if(!Number.isSafeInteger(amount)||amount<100000||amount>Math.min(p.price*.35,200000000))throw Error('Amaun pembiayaan tidak layak');
 const outstanding=(b.projectLoans||[]).filter(x=>x.balance>0).reduce((a,x)=>a+x.balance,0);
 if(outstanding+amount>p.price*.45)throw Error('Had pembiayaan projek telah dicapai');
 if(b.reputation<30)throw Error('Reputasi syarikat terlalu rendah untuk pembiayaan');
 const loanAccount='contractor-debt-'+(++s.sequence);account(s,loanAccount,'Hutang modal pusingan: '+p.name,b.id,'liability');post(s,'Pembiayaan modal pusingan: '+p.name,[{account:b.id,amount},{account:loanAccount,amount:-amount}],'contractor-loan');
 b.projectLoans??=[];b.projectLoans.push({id:loanAccount,projectId:id,principal:amount,balance:amount,rateAnnual:.085,started:s.day,interestAccrued:0,lastInterestDay:s.day});
 return amount;
}
export function repayProjectLoan(s,loanId,amount){
 const b=ensure(s).company,l=(b?.projectLoans||[]).find(x=>x.id===loanId);
 if(!l||l.balance<=0)throw Error('Pinjaman tidak aktif');
 amount=Math.round(Number(amount)*100);
 if(!Number.isSafeInteger(amount)||amount<=0)throw Error('Amaun tidak sah');
 const due=l.balance+l.interestAccrued,pay=Math.min(amount,due);
 if(s.accounts[b.id].balance<pay)throw Error('Tunai tidak mencukupi');
 const interest=Math.min(pay,l.interestAccrued),principal=pay-interest;
 if(interest)spend(s,b.id,interest,'Faedah pembiayaan kontraktor','contractor-loan-interest');
 if(principal)post(s,'Bayaran balik prinsipal kontraktor',[{account:b.id,amount:-principal},{account:l.id,amount:principal}],'contractor-loan-repayment');
 l.interestAccrued-=interest;l.balance-=principal;
 return pay;
}
export function accrueProjectInterest(s){
 const b=ensure(s).company;if(!b)return;
 for(const l of b.projectLoans||[]){if(l.balance<=0)continue;
 const days=Math.max(0,s.day-(l.lastInterestDay??s.day));
 if(days){l.interestAccrued+=Math.round(l.balance*l.rateAnnual*days/365);l.lastInterestDay=s.day;}
 }
}

// CP3: tiered registration upgrades are additional GAMEPLAY progression rules,
// not a representation of statutory CIDB track-record requirements.
export const UPGRADE_REQUIREMENTS={
 2:{completed:1,minValue:10000000,fee:8000,days:4},
 3:{completed:2,minValue:20000000,fee:12000,days:5},
 4:{completed:2,minValue:50000000,fee:20000,days:7},
 5:{completed:3,minValue:100000000,fee:30000,days:8},
 6:{completed:3,minValue:250000000,fee:45000,days:10},
 7:{completed:4,minValue:500000000,fee:60000,days:14}
};
export function upgradeAudit(s){
 const b=ensure(s).company;if(!b||b.license!=='active')throw Error('PPK aktif diperlukan');
 if(b.grade>=7)return {max:true,eligible:false,reasons:['Gred G7 ialah gred maksimum']};
 const target=b.grade+1,g=GRADES[target],r=UPGRADE_REQUIREMENTS[target];
 const cash=s.accounts[b.id]?.balance||0;
 const completed=b.history.filter(h=>h.result==='CPC'&&h.price>=r.minValue).length;
 const reasons=[];
 if(cash<g.cap)reasons.push('Tunai/modal syarikat '+(g.cap/100).toLocaleString('ms-MY')+' RM diperlukan');
 if((b.staff||0)<g.staff)reasons.push('Perlu '+g.staff+' personel teknikal berkelayakan');
 if(completed<r.completed)reasons.push('Perlu '+r.completed+' projek CPC bernilai minimum RM'+(r.minValue/100).toLocaleString('ms-MY')+' setiap satu (peraturan progression game)');
 if((b.complianceStrikes||0)>=3||b.blacklistedUntil>s.day)reasons.push('Rekod pematuhan/sekatan belum bersih');
 if(b.upgradeApplication?.status==='processing')reasons.push('Permohonan sedang diproses');
 return {target,eligible:reasons.length===0,reasons,completed,required:r.completed,fee:r.fee,days:r.days,cash,technical:g.staff};
}
export function applyUpgrade(s){
 const b=ensure(s).company,a=upgradeAudit(s);
 if(!a.eligible)throw Error('Tidak layak: '+a.reasons.join('; '));
 const total=a.fee+GRADES[a.target].fee;
 if(s.accounts[b.id].balance<GRADES[a.target].cap+total)throw Error('Tunai tidak cukup selepas yuran permohonan');
 spend(s,b.id,total,'Yuran permohonan naik gred G'+a.target+' (simulasi)','cidb-upgrade');
 b.upgradeApplication={target:a.target,status:'processing',appliedDay:s.day,decisionDay:s.day+a.days,fee:total};
 return b.upgradeApplication;
}
export function hireTechnical(s,quantity=1){
 const b=ensure(s).company;if(!b||b.license!=='active')throw Error('Syarikat belum aktif');
 quantity=Number(quantity);if(!Number.isInteger(quantity)||quantity<1||quantity>5)throw Error('Bilangan staf tidak sah');
 const monthly=450000; // RM4,500/staf/bulan: simulation assumption, not salary survey
 const first=Math.round(monthly*quantity/30);
 if(s.accounts[b.id].balance<first)throw Error('Tunai tidak cukup untuk gaji harian');
 b.staff=(b.staff||0)+quantity;b.technicalPayrollMonthly=(b.technicalPayrollMonthly||0)+monthly*quantity;b.technicalRoster??=[];for(let i=0;i<quantity;i++)b.technicalRoster.push({id:'technical-'+(++s.sequence),qualification:b.grade>=6?'degree':'diploma',salary:monthly,joined:s.day});
 b.lastPayrollDay=s.day;
 return b.staff;
}
export function cp3Daily(s){
 const b=ensure(s).company;if(!b)return;
 const a=b.upgradeApplication;
 if(a?.status==='processing'&&s.day>=a.decisionDay){
  const compliance=(b.complianceStrikes||0)<3&&!(b.blacklistedUntil>s.day);
  if(compliance&&b.staff>=GRADES[a.target].staff&&s.accounts[b.id].balance>=GRADES[a.target].cap){
   b.grade=a.target;a.status='approved';b.history.push({day:s.day,title:'CIDB upgrade G'+a.target,result:'Upgrade approved',price:0});
  }else{a.status='rejected';b.history.push({day:s.day,title:'CIDB upgrade G'+a.target,result:'Upgrade rejected',price:0});}
 }
 if(b.technicalPayrollMonthly&&s.day>(b.lastPayrollDay??s.day)){
  const days=s.day-b.lastPayrollDay;
  const due=Math.round(b.technicalPayrollMonthly*days/30);
  const available=s.accounts[b.id].balance;
  const paid=Math.min(available,due);
  if(paid)spend(s,b.id,paid,'Gaji personel teknikal kontraktor','contractor-payroll');
  b.payrollArrears=(b.payrollArrears||0)+due-paid;
  b.lastPayrollDay=s.day;
  if(b.payrollArrears>0)b.reputation=Math.max(0,b.reputation-1);
 }
}
export function settlePayroll(s){
 const b=ensure(s).company;if(!b?.payrollArrears)throw Error('Tiada tunggakan gaji');
 if(s.accounts[b.id].balance<b.payrollArrears)throw Error('Tunai tidak cukup');
 spend(s,b.id,b.payrollArrears,'Bayar tunggakan gaji teknikal','contractor-payroll');b.payrollArrears=0;
}
export function complianceOverview(s){const b=ensure(s).company;return {ssm:!!b,ppk:b?.license==='active',technical:b?.staff||0,grade:b?.grade||0,spkk:!!b?.spkk,stb:!!b?.stb,arrears:b?.payrollArrears||0};}

// CP5: additive integration and reporting. Amounts are sen; no external network dependencies.
export function cp5Daily(s){
 const b=ensure(s).company;if(!b)return;
 for(const [kind,a] of Object.entries(b.certificateApplications||{})){
  if(a.status==='processing'&&s.day>=a.decisionDay){
   if((b.complianceStrikes||0)>=3||b.payrollArrears>0){a.status='rejected';}
   else{a.status='approved';b[kind]=true;}
   b.history.push({day:s.day,title:kind.toUpperCase(),result:a.status,price:0});
  }
 }
 // A serious record may temporarily block new tenders, without wiping existing projects.
 if((b.complianceStrikes||0)>=4&&!b.blacklistedUntil){b.blacklistedUntil=s.day+90;}
 if(b.blacklistedUntil&&s.day>=b.blacklistedUntil){b.blacklistedUntil=0;b.complianceStrikes=Math.max(0,(b.complianceStrikes||0)-2);}
}
export function companyReport(s){
 const c=ensure(s),b=c.company;if(!b)return null;
 const projects=c.projects||[],cash=s.accounts[b.id]?.balance||0;
 const pending=projects.flatMap(p=>p.claims||[]).filter(x=>x.status!=='paid').reduce((n,x)=>n+x.net,0);
 const retention=projects.reduce((n,p)=>n+(p.retained||0),0);
 const bonds=projects.reduce((n,p)=>n+(p.bond||0),0);
 const loans=(b.projectLoans||[]).reduce((n,l)=>n+l.balance+(l.interestAccrued||0),0);
 const totalCost=projects.reduce((n,p)=>n+(p.cost||0),0);
 const received=projects.reduce((n,p)=>n+(p.paid||0),0);
 return {cash,pending,retention,bonds,loans,totalCost,received,netPosition:cash+pending+retention+bonds-loans-(b.payrollArrears||0),active:projects.filter(p=>['active','awaiting-cpc'].includes(p.status)).length,dlp:projects.filter(p=>p.status==='dlp').length,completed:projects.filter(p=>p.status==='closed').length};
}
export function projectDocuments(s,id){
 const p=ensure(s).projects.find(x=>x.id===id);if(!p)throw Error('Projek tidak ditemui');
 return [{name:'Surat Setuju Terima (simulasi)',status:'issued',day:p.start},
 {name:'Bon pelaksanaan',status:p.bond?'held':p.bondRate===0?'not-required':'released',day:p.start},
 {name:'BQ / Anggaran kos',status:'issued',day:p.start},
 ...(p.claims||[]).map(x=>({name:'Progress Claim '+x.id,status:x.status,day:x.submitted})),
 ...(p.variations||[]).map(x=>({name:'Variation Order '+x.id,status:x.status,day:x.requestedDay})),
 ...(p.status==='dlp'||p.status==='closed'?[{name:'Certificate of Practical Completion (CPC)',status:'issued',day:p.dlpEnd-365}]:[]),
 ...(p.status==='closed'?[{name:'Penutupan DLP & retention',status:'released',day:p.dlpEnd}]:[])];
}
export function tenderEvaluation(offer,markup,reputation=50){
 const bidPrice=Math.round(offer.value*(1+markup/100));
 const competition=offer.government?3:2;
 const relativePrice=bidPrice/offer.value;
 const quality=Math.max(0,Math.min(100,reputation));
 const chance=Math.max(.08,Math.min(.9,.7-(relativePrice-1)*1.15+(quality-50)*.002-(competition-2)*.06));
 return {bidPrice,competition,relativePrice,chance,description:'Model simulasi penilaian harga dan reputasi; bukan kaedah tender rasmi.'};
}
export function updateBQ(s,id,quantities){
 const p=ensure(s).projects.find(x=>x.id===id);
 if(!p||p.status!=='active'||p.progress>0)throw Error('BQ hanya boleh diedit sebelum kerja tapak bermula');
 const bq=quantityBQ(p,quantities);
 if(bq.materialTotal>p.price*1.5)throw Error('Kos bahan BQ melebihi had munasabah');
 p.bq=bq;p.siteLog??=[];p.siteLog.push({day:s.day,kind:'bq-revised',total:bq.materialTotal});return bq;
}

// Inventory purchases are paid upfront and applied against material costs when work progresses.
// Indicative unit rates are game estimates, not binding supplier quotations.
export function buyMaterials(s,id,code,qty){
 const c=ensure(s),b=c.company,p=c.projects.find(x=>x.id===id);
 if(!b||!p||p.status!=='active')throw Error('Projek tidak aktif');
 const item=(p.bq?.items||[]).find(x=>x.code===code);qty=Number(qty);
 if(!item||!Number.isInteger(qty)||qty<1||qty>100000)throw Error('Item atau kuantiti tidak sah');
 const referenceCost=qty*item.unitRate;
 const discountRate=Math.min(.12,.035+Math.min(.085,qty/Math.max(1,item.qty)*.06));
 const cost=Math.round(referenceCost*(1-discountRate));
 if(!Number.isSafeInteger(cost)||s.accounts[b.id].balance<cost)throw Error('Tunai tidak cukup untuk pembelian');
 spend(s,b.id,cost,'Pesanan bahan: '+item.label+' ('+qty+' '+item.unit+')','contractor-material-purchase');
 p.inventory??={};p.inventory[code]??={qty:0,unit:item.unit,label:item.label,spent:0};
 p.inventory[code].qty+=qty;p.inventory[code].spent+=cost;
 p.materialStockValue=(p.materialStockValue||0)+referenceCost;p.materialStockCashValue=(p.materialStockCashValue||0)+cost;p.prepaidPotentialSaving=(p.prepaidPotentialSaving||0)+(referenceCost-cost);p.cost+=cost;
 p.costParts??={materials:0,labour:0,plant:0,overhead:0};p.costParts.materials+=cost;
 p.purchaseOrders??=[];p.purchaseOrders.push({id:'po-'+(++s.sequence),day:s.day,code,qty,unitRate:item.unitRate,referenceCost,cost,saving:referenceCost-cost,status:'delivered'});
 p.siteLog??=[];p.siteLog.push({day:s.day,kind:'material-purchase',code,qty,cost});return cost;
}
export function sitePayrollReport(s,id){const p=ensure(s).projects.find(x=>x.id===id);if(!p)throw Error('Projek tidak ditemui');return {labourPaid:p.costParts?.labour||0,technicalPayrollMonthly:ensure(s).company?.technicalPayrollMonthly||0,technicalArrears:ensure(s).company?.payrollArrears||0,note:'Upah pekerja tapak telah termasuk dalam kos kerja tapak. Tidak didebitkan sekali lagi.'};}

// Category management is a game simulation, not an official CIDB application.
export const CIDB_CATEGORIES=['B','CE','ME','F'];
export function activeCategories(b){return [...new Set((b?.categories?.length?b.categories:[b?.category]).filter(x=>CIDB_CATEGORIES.includes(x)))].slice(0,2);}
export function applyCategory(s,target,replace=''){
 const b=ensure(s).company;if(!b||b.license!=='active')throw Error('PPK mesti aktif');
 if(!CIDB_CATEGORIES.includes(target))throw Error('Kategori tidak sah');
 const current=activeCategories(b);if(current.includes(target))throw Error('Kategori sudah aktif');
 if(b.categoryApplication?.status==='processing')throw Error('Permohonan kategori masih diproses');
 if(replace&&!current.includes(replace))throw Error('Kategori untuk diganti tidak sah');
 if(current.length>=2&&!replace)throw Error('Maksimum dua kategori. Pilih kategori untuk diganti');
 if(replace&&current.length<1)throw Error('Tiada kategori untuk diganti');
 const fee=15000;if(s.accounts[b.id].balance<fee)throw Error('Baki akaun syarikat tidak cukup untuk yuran permohonan');
 spend(s,b.id,fee,'Permohonan perubahan kategori PPK (simulasi)','cidb-category');
 b.categoryApplication={target,replace,status:'processing',submittedDay:s.day,decisionDay:s.day+5+CIDB_CATEGORIES.indexOf(target)*2,fee,documents:['SSM','PPK','Maklumat personel teknikal']};
 return b.categoryApplication;
}
export function categoryDaily(s){const b=ensure(s).company,a=b?.categoryApplication;if(!a||a.status!=='processing'||s.day<a.decisionDay)return;const categories=activeCategories(b);if(a.replace){const idx=categories.indexOf(a.replace);if(idx<0){a.status='rejected';a.reason='Kategori lama tidak aktif';return;}categories.splice(idx,1);}if(categories.length>=2){a.status='rejected';a.reason='Had kategori';return;}categories.push(a.target);b.categories=categories;b.category=categories[0];a.status='approved';a.resolvedDay=s.day;}
export function materialSavings(p){return {potential:p.prepaidPotentialSaving||0,realized:p.prepaidRealizedSaving||0,unused:p.materialStockValue||0,forecastProfit:p.price-(p.cost||0)-Math.max(0,costEstimate(p.price,p.category,p.margin).budget-(p.cost||0))+(p.prepaidRealizedSaving||0)};}
