// Non-destructive migration of legacy messages into the NPC interaction timeline.
// Stable synthetic IDs for ID-less entries allow repeatable save/load migration.
import {recordNpcInteraction,npcInteractionTimeline} from './npc-unified-interaction-v2.js';
const signature=(day,channel,kind,text)=>JSON.stringify([day,channel,kind,String(text).slice(0,240)]);
export function migrateNpcInteractionHistory(s){
 let added=0;
 for(const [id,messages] of Object.entries(s.messages||{})){
  if(!s.npcs?.[id]||!Array.isArray(messages))continue;
  const log=npcInteractionTimeline(s,id);
  const existingIds=new Set(log.map(e=>e.eventId).filter(Boolean));
  const existingSignatures=new Set(log.map(e=>signature(e.day,e.channel,e.kind,e.text)));
  for(let i=0;i<messages.length;i++){
   const m=messages[i];
   if(!m||typeof m.text!=='string'||!Number.isInteger(m.day)||m.day<0||m.day>s.day)continue;
   const channel=m.channel==='call'||m.call===true?'call':'whatsapp';
   const kind=m.from==='you'?'player_message':'npc_reply';
   const sig=signature(m.day,channel,kind,m.text);
   const stableId=typeof m.id==='string'&&m.id.length>0&&m.id.length<100?m.id:null;
   // Do not re-import events already logged by the live interaction engine.
   if((stableId&&existingIds.has(stableId))||existingSignatures.has(sig))continue;
   // Prefix and index make old ID-less messages repeatable without modifying the original save.
   const eventId=stableId||`legacy:${id}:${i}`;
   if(existingIds.has(eventId))continue;
   if(recordNpcInteraction(s,id,{channel,kind,text:m.text,eventId})){
    const entry=npcInteractionTimeline(s,id).at(-1);
    entry.day=m.day;existingIds.add(eventId);existingSignatures.add(sig);added++;
   }
  }
 }
 return added;
}
