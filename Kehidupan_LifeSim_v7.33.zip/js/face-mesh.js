import {portraitLandmarks} from './portrait-landmarks.js';
export {portraitLandmarks};
// Offline 2D triangle-mesh texture deformation for the supplied 4x3 portrait atlas.
// Facial coordinates are approximate, manually calibrated to the bundled portraits.
const atlas=new Image();atlas.decoding="async";atlas.src=new URL('../assets/portraits-real.webp',import.meta.url).href;
let ready=false;atlas.onload=()=>{ready=true;if(typeof document!=='undefined')renderFaceMeshes(document)};
atlas.onerror=()=>{console.warn('Portrait atlas unavailable; showing unmodified photos')};
// Hand-calibrated per-photo landmarks in tile-normalised coordinates (not AI-detected).
// cx, browY, cheekY, jawY, chinY, halfFaceWidth, jawHalfWidth, foreheadHalfWidth.
// Head coverings and hair are deliberately excluded from the facial deformation.

const gauss=(x,y,cx,cy,rx,ry)=>Math.exp(-2.3*((x-cx)**2/(rx*rx)+(y-cy)**2/(ry*ry)));
export function deformPortraitPoint(x,y,v,p){
 const [cx,brow,cheek,jaw,chin,half,jawHalf,foreHalf]=portraitLandmarks[p]||portraitLandmarks[0];
 const [fw,jw,cl,cf,fo]=v.map(t=>Math.max(-30,Math.min(30,t))/30);
 const side=x<cx?-1:1,abs=Math.abs(x-cx);
 const boundary=(y)=>y<cheek?foreHalf+(half-foreHalf)*Math.max(0,(y-brow)/(cheek-brow)):half+(jawHalf-half)*Math.min(1,(y-cheek)/(jaw-cheek));
 const edge=boundary(y),edgeWeight=Math.exp(-Math.pow((abs-edge)/.065,2)*1.5);
 const jawWeight=gauss(x,y,cx+side*jawHalf,jaw,.105,.112);
 const cheekWeight=gauss(x,y,cx+side*half*.88,cheek,.096,.090);
 const foreheadWeight=gauss(x,y,cx+side*foreHalf,brow+.007,.085,.082);
 // The eye/nose/mouth core receives minimal displacement; no hair or backdrop scaling.
 const coreProtection=Math.min(1,Math.max(0,(abs-.055)/.105));
 let mx=side*(.014*fw*edgeWeight*coreProtection+.014*jw*jawWeight+.010*cf*cheekWeight+.010*fo*foreheadWeight);
 let my=.017*cl*gauss(x,y,cx,chin,.115,.083);
 // Pin outside the face and fade towards hairline and neck.
 const skinZone=Math.min(1,Math.max(0,(y-(brow-.085))/.075))*Math.min(1,Math.max(0,((chin+.052)-y)/.075));
 const horizontalZone=Math.min(1,Math.max(0,(edge+.085-abs)/.065));
 return [x+mx*skinZone*horizontalZone,y+my*skinZone*horizontalZone];
}
function triangle(ctx,img,source,dest,sw,sh){
 const [a,b,c]=source,[d,e,f]=dest;
 const den=(a[0]*(b[1]-c[1])+b[0]*(c[1]-a[1])+c[0]*(a[1]-b[1]));if(Math.abs(den)<.00001)return;
 const m=(d[0]*(b[1]-c[1])+e[0]*(c[1]-a[1])+f[0]*(a[1]-b[1]))/den;
 const n=(d[1]*(b[1]-c[1])+e[1]*(c[1]-a[1])+f[1]*(a[1]-b[1]))/den;
 const o=(d[0]*(c[0]-b[0])+e[0]*(a[0]-c[0])+f[0]*(b[0]-a[0]))/den;
 const q=(d[1]*(c[0]-b[0])+e[1]*(a[0]-c[0])+f[1]*(b[0]-a[0]))/den;
 const tx=d[0]-m*a[0]-o*a[1],ty=d[1]-n*a[0]-q*a[1];
 ctx.save();ctx.beginPath();ctx.moveTo(d[0],d[1]);ctx.lineTo(e[0],e[1]);ctx.lineTo(f[0],f[1]);ctx.closePath();ctx.clip();ctx.transform(m,n,o,q,tx,ty);ctx.drawImage(img,0,0,sw,sh);ctx.restore();
}
const tileCache=new Map();
function sourceTile(id,w,h){
 const key=`${id}:${w}:${h}`;if(tileCache.has(key))return tileCache.get(key);
 if(tileCache.size>36)tileCache.clear();
 const tileW=atlas.naturalWidth/4,tileH=atlas.naturalHeight/3;
 const scratch=document.createElement('canvas');scratch.width=w;scratch.height=h;
 scratch.getContext('2d').drawImage(atlas,(id%4)*tileW,Math.floor(id/4)*tileH,tileW,tileH,0,0,w,h);
 tileCache.set(key,scratch);return scratch;
}
let scheduled=false;
export function scheduleFaceMeshes(){if(scheduled)return;scheduled=true;requestAnimationFrame(()=>{scheduled=false;renderFaceMeshes(document)})}
export function renderFaceMeshes(root=document){if(!ready)return;
 for(const canvas of root.querySelectorAll('.face-landmark-canvas')){
  const vals=['fw','jw','cl','cf','fore'].map(k=>Number(canvas.dataset[k])||0);
  if(vals.every(v=>v===0)){canvas.style.display='none';continue;}
  const parent=canvas.parentElement,w=Math.round(parent.clientWidth),h=Math.round(parent.clientHeight);
  if(!w||!h)continue;canvas.style.display='block';if(canvas.width!==w)canvas.width=w;if(canvas.height!==h)canvas.height=h;
  const id=Math.max(0,Math.min(11,Number(canvas.dataset.preset)||0));
  const scratch=sourceTile(id,w,h);
  const ctx=canvas.getContext('2d');if(!ctx)return;
  // Prevent stale triangle pixels when changing sliders or portrait.
  ctx.clearRect(0,0,w,h);
  const N=32,vertices=[];for(let j=0;j<=N;j++){const row=[];for(let i=0;i<=N;i++)row.push(deformPortraitPoint(i/N,j/N,vals,id));vertices.push(row);}
  const s=(i,j)=>[i*w/N,j*h/N],d=(i,j)=>[vertices[j][i][0]*w,vertices[j][i][1]*h];
  // Render each triangular patch with affine texture mapping. Source image stays photographic.
  for(let j=0;j<N;j++)for(let i=0;i<N;i++){
   triangle(ctx,scratch,[s(i,j),s(i+1,j),s(i,j+1)],[d(i,j),d(i+1,j),d(i,j+1)],w,h);
   triangle(ctx,scratch,[s(i+1,j),s(i+1,j+1),s(i,j+1)],[d(i+1,j),d(i+1,j+1),d(i,j+1)],w,h);
  }
 }
}

// Refresh when layout changes (mobile rotation / responsive panels).
if(typeof window!=='undefined')window.addEventListener('resize',scheduleFaceMeshes,{passive:true});
