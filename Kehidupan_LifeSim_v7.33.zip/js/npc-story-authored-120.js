// 120 distinct incident premises, contextual complications, and 360 scenario-specific follow-up results.
export const AUTHORED_STORIES=Object.freeze([
  {
    "id": "ST-001",
    "kind": "community",
    "title": "Penduduk mahu membaiki taman permainan yang rosak",
    "description": "Penduduk mahu membaiki taman permainan yang rosak. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Tawarkan bantuan dengan skop yang jelas",
      "Minta butiran masa dan tugas",
      "Tolak kerana komitmen lain"
    ],
    "minTrust": 0,
    "weight": 1,
    "contextIndex": 0,
    "followUpChoices": [
      "Tetapkan giliran sukarelawan (ST-001)",
      "Semak keperluan penduduk (ST-001)",
      "Serahkan kepada jawatankuasa (ST-001)"
    ],
    "complication": "jawatankuasa meminta sebut harga sebelum kerja bermula",
    "followUpScene": "Ketika isu \"penduduk mahu membaiki taman permainan yang rosak\" diteruskan, jawatankuasa meminta sebut harga sebelum kerja bermula. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Tetapkan giliran sukarelawan. Walaupun jawatankuasa meminta sebut harga sebelum kerja bermula, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak keperluan penduduk. Disebabkan jawatankuasa meminta sebut harga sebelum kerja bermula, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Serahkan kepada jawatankuasa. Apabila jawatankuasa meminta sebut harga sebelum kerja bermula, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-002",
    "kind": "business",
    "title": "Pemilik kedai mempertimbangkan pembekal baharu selepas stok lambat tiba",
    "description": "Pemilik kedai mempertimbangkan pembekal baharu selepas stok lambat tiba. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Minta bukti kos dan runding syarat",
      "Semak dokumen sebelum beri jawapan",
      "Tolak tawaran tanpa komitmen"
    ],
    "minTrust": 8,
    "weight": 1,
    "contextIndex": 0,
    "followUpChoices": [
      "Sahkan skop dan dokumen (ST-002)",
      "Audit kos serta risiko (ST-002)",
      "Batalkan rundingan (ST-002)"
    ],
    "complication": "pembekal mengubah tempoh penghantaran",
    "followUpScene": "Ketika isu \"pemilik kedai mempertimbangkan pembekal baharu selepas stok lambat tiba\" diteruskan, pembekal mengubah tempoh penghantaran. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sahkan skop dan dokumen. Walaupun pembekal mengubah tempoh penghantaran, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Audit kos serta risiko. Disebabkan pembekal mengubah tempoh penghantaran, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Batalkan rundingan. Apabila pembekal mengubah tempoh penghantaran, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-003",
    "kind": "friendship",
    "title": "Kawan lama mengajak bertemu selepas lama tidak berhubung",
    "description": "Kawan lama mengajak bertemu selepas lama tidak berhubung. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Luangkan masa dan dengar cerita",
      "Cadangkan masa lain untuk berbual",
      "Terangkan batasan dengan sopan"
    ],
    "minTrust": 12,
    "weight": 1,
    "contextIndex": 0,
    "followUpChoices": [
      "Atur pertemuan peribadi (ST-003)",
      "Tanya keselesaan kedua-dua pihak (ST-003)",
      "Berikan ruang kepada kenalan (ST-003)"
    ],
    "complication": "kenalan menjelaskan sebab lama menyepi",
    "followUpScene": "Ketika isu \"kawan lama mengajak bertemu selepas lama tidak berhubung\" diteruskan, kenalan menjelaskan sebab lama menyepi. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Atur pertemuan peribadi. Walaupun kenalan menjelaskan sebab lama menyepi, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Tanya keselesaan kedua-dua pihak. Disebabkan kenalan menjelaskan sebab lama menyepi, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Berikan ruang kepada kenalan. Apabila kenalan menjelaskan sebab lama menyepi, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-004",
    "kind": "career",
    "title": "Rakan sekerja mendapat tawaran berpindah jabatan",
    "description": "Rakan sekerja mendapat tawaran berpindah jabatan. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu merancang langkah seterusnya",
      "Minta maklumat kerja yang lengkap",
      "Tolak penglibatan secara profesional"
    ],
    "minTrust": 15,
    "weight": 1,
    "contextIndex": 0,
    "followUpChoices": [
      "Susun langkah kerjaya (ST-004)",
      "Semak peluang dan syarat (ST-004)",
      "Tidak menjadi perantara (ST-004)"
    ],
    "complication": "penyelia meminta alasan rasmi sebelum menyokong permohonan",
    "followUpScene": "Ketika isu \"rakan sekerja mendapat tawaran berpindah jabatan\" diteruskan, penyelia meminta alasan rasmi sebelum menyokong permohonan. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Susun langkah kerjaya. Walaupun penyelia meminta alasan rasmi sebelum menyokong permohonan, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak peluang dan syarat. Disebabkan penyelia meminta alasan rasmi sebelum menyokong permohonan, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Tidak menjadi perantara. Apabila penyelia meminta alasan rasmi sebelum menyokong permohonan, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-005",
    "kind": "conflict",
    "title": "Jiran mendakwa bunyi bising berpunca daripada rumah sebelah",
    "description": "Jiran mendakwa bunyi bising berpunca daripada rumah sebelah. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Dengar kedua-dua pihak dan cadang mediasi",
      "Minta masa untuk semak fakta",
      "Enggan masuk campur dalam pertikaian"
    ],
    "minTrust": 20,
    "weight": 1,
    "contextIndex": 0,
    "followUpChoices": [
      "Adakan mediasi bersemuka (ST-005)",
      "Kumpulkan bukti neutral (ST-005)",
      "Berundur daripada pertikaian (ST-005)"
    ],
    "complication": "rakaman dan keterangan saksi tidak sepadan",
    "followUpScene": "Ketika isu \"jiran mendakwa bunyi bising berpunca daripada rumah sebelah\" diteruskan, rakaman dan keterangan saksi tidak sepadan. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Adakan mediasi bersemuka. Walaupun rakaman dan keterangan saksi tidak sepadan, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Kumpulkan bukti neutral. Disebabkan rakaman dan keterangan saksi tidak sepadan, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Berundur daripada pertikaian. Apabila rakaman dan keterangan saksi tidak sepadan, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-006",
    "kind": "family",
    "title": "Saudara merancang majlis kecil dengan bajet terhad",
    "description": "Saudara merancang majlis kecil dengan bajet terhad. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu menyusun keperluan keluarga",
      "Tanya jadual dan tanggungjawab",
      "Tolak dengan alasan yang jelas"
    ],
    "minTrust": 0,
    "weight": 1,
    "contextIndex": 0,
    "followUpChoices": [
      "Agihkan tanggungjawab keluarga (ST-006)",
      "Semak kemampuan dan masa (ST-006)",
      "Beri keputusan tidak terlibat (ST-006)"
    ],
    "complication": "ahli keluarga berbeza pandangan tentang keputusan itu",
    "followUpScene": "Ketika isu \"saudara merancang majlis kecil dengan bajet terhad\" diteruskan, ahli keluarga berbeza pandangan tentang keputusan itu. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Agihkan tanggungjawab keluarga. Walaupun ahli keluarga berbeza pandangan tentang keputusan itu, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak kemampuan dan masa. Disebabkan ahli keluarga berbeza pandangan tentang keputusan itu, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Beri keputusan tidak terlibat. Apabila ahli keluarga berbeza pandangan tentang keputusan itu, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-007",
    "kind": "civic",
    "title": "Wakil penduduk mengadakan dialog tentang lampu jalan",
    "description": "Wakil penduduk mengadakan dialog tentang lampu jalan. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Sertai perbincangan dan beri cadangan",
      "Minta dokumen isu terlebih dahulu",
      "Tidak sertai forum kali ini"
    ],
    "minTrust": 10,
    "weight": 1,
    "contextIndex": 0,
    "followUpChoices": [
      "Sediakan cadangan komuniti (ST-007)",
      "Sahkan prosedur pihak berkuasa (ST-007)",
      "Serahkan urusan kepada wakil (ST-007)"
    ],
    "complication": "penganjur meminta pengesahan identiti peserta",
    "followUpScene": "Ketika isu \"wakil penduduk mengadakan dialog tentang lampu jalan\" diteruskan, penganjur meminta pengesahan identiti peserta. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sediakan cadangan komuniti. Walaupun penganjur meminta pengesahan identiti peserta, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Sahkan prosedur pihak berkuasa. Disebabkan penganjur meminta pengesahan identiti peserta, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Serahkan urusan kepada wakil. Apabila penganjur meminta pengesahan identiti peserta, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-008",
    "kind": "health",
    "title": "Kenalan mencari teman untuk berjalan santai setiap petang",
    "description": "Kenalan mencari teman untuk berjalan santai setiap petang. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Dengar dan galakkan sokongan sesuai",
      "Cadangkan berbincang kemudian",
      "Hormati privasi dan tidak terlibat"
    ],
    "minTrust": 5,
    "weight": 1,
    "contextIndex": 0,
    "followUpChoices": [
      "Rancang sokongan yang selamat (ST-008)",
      "Tanya keperluan dan batasan (ST-008)",
      "Hormati privasi kenalan (ST-008)"
    ],
    "complication": "kenalan mahu menjaga kerahsiaan perkara peribadi",
    "followUpScene": "Ketika isu \"kenalan mencari teman untuk berjalan santai setiap petang\" diteruskan, kenalan mahu menjaga kerahsiaan perkara peribadi. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Rancang sokongan yang selamat. Walaupun kenalan mahu menjaga kerahsiaan perkara peribadi, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Tanya keperluan dan batasan. Disebabkan kenalan mahu menjaga kerahsiaan perkara peribadi, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Hormati privasi kenalan. Apabila kenalan mahu menjaga kerahsiaan perkara peribadi, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-009",
    "kind": "travel",
    "title": "Rakan mahu merancang perjalanan sehari menggunakan tren",
    "description": "Rakan mahu merancang perjalanan sehari menggunakan tren. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu susun jadual dan bajet",
      "Semak pengangkutan dan cuaca dahulu",
      "Tidak ikut perjalanan ini"
    ],
    "minTrust": 8,
    "weight": 1,
    "contextIndex": 0,
    "followUpChoices": [
      "Sahkan jadual perjalanan (ST-009)",
      "Periksa bajet dan pengangkutan (ST-009)",
      "Batalkan penyertaan (ST-009)"
    ],
    "complication": "jadual pengangkutan berubah tanpa notis awal",
    "followUpScene": "Ketika isu \"rakan mahu merancang perjalanan sehari menggunakan tren\" diteruskan, jadual pengangkutan berubah tanpa notis awal. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sahkan jadual perjalanan. Walaupun jadual pengangkutan berubah tanpa notis awal, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Periksa bajet dan pengangkutan. Disebabkan jadual pengangkutan berubah tanpa notis awal, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Batalkan penyertaan. Apabila jadual pengangkutan berubah tanpa notis awal, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-010",
    "kind": "reputation",
    "title": "Kenalan terdengar khabar yang belum dapat disahkan",
    "description": "Kenalan terdengar khabar yang belum dapat disahkan. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Semak sumber sebelum memberi penjelasan",
      "Minta masa mengesahkan maklumat",
      "Tidak mengulas khabar yang belum sah"
    ],
    "minTrust": 15,
    "weight": 1,
    "contextIndex": 0,
    "followUpChoices": [
      "Betulkan maklumat dengan bukti (ST-010)",
      "Sahkan sumber sebelum bertindak (ST-010)",
      "Elakkan menyebar cerita (ST-010)"
    ],
    "complication": "sumber asal khabar angin tidak dapat dikenal pasti",
    "followUpScene": "Ketika isu \"kenalan terdengar khabar yang belum dapat disahkan\" diteruskan, sumber asal khabar angin tidak dapat dikenal pasti. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Betulkan maklumat dengan bukti. Walaupun sumber asal khabar angin tidak dapat dikenal pasti, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Sahkan sumber sebelum bertindak. Disebabkan sumber asal khabar angin tidak dapat dikenal pasti, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Elakkan menyebar cerita. Apabila sumber asal khabar angin tidak dapat dikenal pasti, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-011",
    "kind": "education",
    "title": "Kenalan mahu belajar asas perakaunan peribadi",
    "description": "Kenalan mahu belajar asas perakaunan peribadi. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu cari bahan pembelajaran",
      "Semak jadual dan tahap kursus",
      "Tidak menyertai sesi pembelajaran"
    ],
    "minTrust": 10,
    "weight": 1,
    "contextIndex": 0,
    "followUpChoices": [
      "Atur sesi pembelajaran (ST-011)",
      "Semak kelayakan dan jadual (ST-011)",
      "Tolak penglibatan (ST-011)"
    ],
    "complication": "tarikh pendaftaran lebih awal daripada jangkaan",
    "followUpScene": "Ketika isu \"kenalan mahu belajar asas perakaunan peribadi\" diteruskan, tarikh pendaftaran lebih awal daripada jangkaan. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Atur sesi pembelajaran. Walaupun tarikh pendaftaran lebih awal daripada jangkaan, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak kelayakan dan jadual. Disebabkan tarikh pendaftaran lebih awal daripada jangkaan, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Tolak penglibatan. Apabila tarikh pendaftaran lebih awal daripada jangkaan, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-012",
    "kind": "network",
    "title": "Kenalan mahu mempertemukan player dengan pemilik perniagaan",
    "description": "Kenalan mahu mempertemukan player dengan pemilik perniagaan. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Setuju diperkenalkan dengan izin semua pihak",
      "Minta profil dan tujuan pertemuan",
      "Tolak pengenalan buat masa ini"
    ],
    "minTrust": 18,
    "weight": 1,
    "contextIndex": 0,
    "followUpChoices": [
      "Sahkan persetujuan kedua-dua pihak (ST-012)",
      "Semak tujuan pengenalan (ST-012)",
      "Batalkan pengenalan (ST-012)"
    ],
    "complication": "kenalan yang ingin diperkenalkan meminta tujuan jelas",
    "followUpScene": "Ketika isu \"kenalan mahu mempertemukan player dengan pemilik perniagaan\" diteruskan, kenalan yang ingin diperkenalkan meminta tujuan jelas. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sahkan persetujuan kedua-dua pihak. Walaupun kenalan yang ingin diperkenalkan meminta tujuan jelas, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak tujuan pengenalan. Disebabkan kenalan yang ingin diperkenalkan meminta tujuan jelas, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Batalkan pengenalan. Apabila kenalan yang ingin diperkenalkan meminta tujuan jelas, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-013",
    "kind": "community",
    "title": "Jiran memerlukan sukarelawan untuk gotong-royong selepas banjir",
    "description": "Jiran memerlukan sukarelawan untuk gotong-royong selepas banjir. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Tawarkan bantuan dengan skop yang jelas",
      "Minta butiran masa dan tugas",
      "Tolak kerana komitmen lain"
    ],
    "minTrust": 2,
    "weight": 2,
    "contextIndex": 1,
    "followUpChoices": [
      "Tetapkan giliran sukarelawan (ST-013)",
      "Semak keperluan penduduk (ST-013)",
      "Serahkan kepada jawatankuasa (ST-013)"
    ],
    "complication": "sebahagian penduduk mahu menukar lokasi aktiviti",
    "followUpScene": "Ketika isu \"jiran memerlukan sukarelawan untuk gotong-royong selepas banjir\" diteruskan, sebahagian penduduk mahu menukar lokasi aktiviti. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Tetapkan giliran sukarelawan. Walaupun sebahagian penduduk mahu menukar lokasi aktiviti, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak keperluan penduduk. Disebabkan sebahagian penduduk mahu menukar lokasi aktiviti, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Serahkan kepada jawatankuasa. Apabila sebahagian penduduk mahu menukar lokasi aktiviti, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-014",
    "kind": "business",
    "title": "Rakan niaga memerlukan semakan invois yang bercanggah",
    "description": "Rakan niaga memerlukan semakan invois yang bercanggah. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Minta bukti kos dan runding syarat",
      "Semak dokumen sebelum beri jawapan",
      "Tolak tawaran tanpa komitmen"
    ],
    "minTrust": 10,
    "weight": 2,
    "contextIndex": 1,
    "followUpChoices": [
      "Sahkan skop dan dokumen (ST-014)",
      "Audit kos serta risiko (ST-014)",
      "Batalkan rundingan (ST-014)"
    ],
    "complication": "harga baharu tidak sepadan dengan sebut harga awal",
    "followUpScene": "Ketika isu \"rakan niaga memerlukan semakan invois yang bercanggah\" diteruskan, harga baharu tidak sepadan dengan sebut harga awal. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sahkan skop dan dokumen. Walaupun harga baharu tidak sepadan dengan sebut harga awal, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Audit kos serta risiko. Disebabkan harga baharu tidak sepadan dengan sebut harga awal, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Batalkan rundingan. Apabila harga baharu tidak sepadan dengan sebut harga awal, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-015",
    "kind": "friendship",
    "title": "Kenalan terasa hati kerana mesejnya tidak dibalas",
    "description": "Kenalan terasa hati kerana mesejnya tidak dibalas. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Luangkan masa dan dengar cerita",
      "Cadangkan masa lain untuk berbual",
      "Terangkan batasan dengan sopan"
    ],
    "minTrust": 14,
    "weight": 2,
    "contextIndex": 1,
    "followUpChoices": [
      "Atur pertemuan peribadi (ST-015)",
      "Tanya keselesaan kedua-dua pihak (ST-015)",
      "Berikan ruang kepada kenalan (ST-015)"
    ],
    "complication": "seorang rakan lain terasa tidak diajak",
    "followUpScene": "Ketika isu \"kenalan terasa hati kerana mesejnya tidak dibalas\" diteruskan, seorang rakan lain terasa tidak diajak. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Atur pertemuan peribadi. Walaupun seorang rakan lain terasa tidak diajak, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Tanya keselesaan kedua-dua pihak. Disebabkan seorang rakan lain terasa tidak diajak, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Berikan ruang kepada kenalan. Apabila seorang rakan lain terasa tidak diajak, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-016",
    "kind": "career",
    "title": "Mentor menawarkan sesi latihan di luar waktu kerja",
    "description": "Mentor menawarkan sesi latihan di luar waktu kerja. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu merancang langkah seterusnya",
      "Minta maklumat kerja yang lengkap",
      "Tolak penglibatan secara profesional"
    ],
    "minTrust": 17,
    "weight": 2,
    "contextIndex": 1,
    "followUpChoices": [
      "Susun langkah kerjaya (ST-016)",
      "Semak peluang dan syarat (ST-016)",
      "Tidak menjadi perantara (ST-016)"
    ],
    "complication": "jawatan yang ditawarkan mempunyai syarat tambahan",
    "followUpScene": "Ketika isu \"mentor menawarkan sesi latihan di luar waktu kerja\" diteruskan, jawatan yang ditawarkan mempunyai syarat tambahan. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Susun langkah kerjaya. Walaupun jawatan yang ditawarkan mempunyai syarat tambahan, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak peluang dan syarat. Disebabkan jawatan yang ditawarkan mempunyai syarat tambahan, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Tidak menjadi perantara. Apabila jawatan yang ditawarkan mempunyai syarat tambahan, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-017",
    "kind": "conflict",
    "title": "Rakan tersalah faham maksud mesej ringkas",
    "description": "Rakan tersalah faham maksud mesej ringkas. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Dengar kedua-dua pihak dan cadang mediasi",
      "Minta masa untuk semak fakta",
      "Enggan masuk campur dalam pertikaian"
    ],
    "minTrust": 22,
    "weight": 2,
    "contextIndex": 1,
    "followUpChoices": [
      "Adakan mediasi bersemuka (ST-017)",
      "Kumpulkan bukti neutral (ST-017)",
      "Berundur daripada pertikaian (ST-017)"
    ],
    "complication": "satu pihak enggan hadir pertemuan mediasi",
    "followUpScene": "Ketika isu \"rakan tersalah faham maksud mesej ringkas\" diteruskan, satu pihak enggan hadir pertemuan mediasi. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Adakan mediasi bersemuka. Walaupun satu pihak enggan hadir pertemuan mediasi, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Kumpulkan bukti neutral. Disebabkan satu pihak enggan hadir pertemuan mediasi, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Berundur daripada pertikaian. Apabila satu pihak enggan hadir pertemuan mediasi, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-018",
    "kind": "family",
    "title": "Keluarga mahu menyusun giliran menjaga warga emas",
    "description": "Keluarga mahu menyusun giliran menjaga warga emas. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu menyusun keperluan keluarga",
      "Tanya jadual dan tanggungjawab",
      "Tolak dengan alasan yang jelas"
    ],
    "minTrust": 2,
    "weight": 2,
    "contextIndex": 1,
    "followUpChoices": [
      "Agihkan tanggungjawab keluarga (ST-018)",
      "Semak kemampuan dan masa (ST-018)",
      "Beri keputusan tidak terlibat (ST-018)"
    ],
    "complication": "tarikh majlis bertembung dengan komitmen kerja",
    "followUpScene": "Ketika isu \"keluarga mahu menyusun giliran menjaga warga emas\" diteruskan, tarikh majlis bertembung dengan komitmen kerja. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Agihkan tanggungjawab keluarga. Walaupun tarikh majlis bertembung dengan komitmen kerja, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak kemampuan dan masa. Disebabkan tarikh majlis bertembung dengan komitmen kerja, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Beri keputusan tidak terlibat. Apabila tarikh majlis bertembung dengan komitmen kerja, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-019",
    "kind": "civic",
    "title": "Komuniti mahu menghantar cadangan lintasan pejalan kaki",
    "description": "Komuniti mahu menghantar cadangan lintasan pejalan kaki. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Sertai perbincangan dan beri cadangan",
      "Minta dokumen isu terlebih dahulu",
      "Tidak sertai forum kali ini"
    ],
    "minTrust": 12,
    "weight": 2,
    "contextIndex": 1,
    "followUpChoices": [
      "Sediakan cadangan komuniti (ST-019)",
      "Sahkan prosedur pihak berkuasa (ST-019)",
      "Serahkan urusan kepada wakil (ST-019)"
    ],
    "complication": "dokumen awam menunjukkan maklumat yang bercanggah",
    "followUpScene": "Ketika isu \"komuniti mahu menghantar cadangan lintasan pejalan kaki\" diteruskan, dokumen awam menunjukkan maklumat yang bercanggah. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sediakan cadangan komuniti. Walaupun dokumen awam menunjukkan maklumat yang bercanggah, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Sahkan prosedur pihak berkuasa. Disebabkan dokumen awam menunjukkan maklumat yang bercanggah, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Serahkan urusan kepada wakil. Apabila dokumen awam menunjukkan maklumat yang bercanggah, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-020",
    "kind": "health",
    "title": "Rakan mahu menyusun jadual tidur lebih konsisten",
    "description": "Rakan mahu menyusun jadual tidur lebih konsisten. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Dengar dan galakkan sokongan sesuai",
      "Cadangkan berbincang kemudian",
      "Hormati privasi dan tidak terlibat"
    ],
    "minTrust": 7,
    "weight": 2,
    "contextIndex": 1,
    "followUpChoices": [
      "Rancang sokongan yang selamat (ST-020)",
      "Tanya keperluan dan batasan (ST-020)",
      "Hormati privasi kenalan (ST-020)"
    ],
    "complication": "maklumat kesihatan daripada media sosial bercanggah",
    "followUpScene": "Ketika isu \"rakan mahu menyusun jadual tidur lebih konsisten\" diteruskan, maklumat kesihatan daripada media sosial bercanggah. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Rancang sokongan yang selamat. Walaupun maklumat kesihatan daripada media sosial bercanggah, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Tanya keperluan dan batasan. Disebabkan maklumat kesihatan daripada media sosial bercanggah, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Hormati privasi kenalan. Apabila maklumat kesihatan daripada media sosial bercanggah, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-021",
    "kind": "travel",
    "title": "Kenalan mencadangkan lawatan ke muzium tempatan",
    "description": "Kenalan mencadangkan lawatan ke muzium tempatan. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu susun jadual dan bajet",
      "Semak pengangkutan dan cuaca dahulu",
      "Tidak ikut perjalanan ini"
    ],
    "minTrust": 10,
    "weight": 2,
    "contextIndex": 1,
    "followUpChoices": [
      "Sahkan jadual perjalanan (ST-021)",
      "Periksa bajet dan pengangkutan (ST-021)",
      "Batalkan penyertaan (ST-021)"
    ],
    "complication": "penginapan yang dicadangkan tidak lagi tersedia",
    "followUpScene": "Ketika isu \"kenalan mencadangkan lawatan ke muzium tempatan\" diteruskan, penginapan yang dicadangkan tidak lagi tersedia. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sahkan jadual perjalanan. Walaupun penginapan yang dicadangkan tidak lagi tersedia, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Periksa bajet dan pengangkutan. Disebabkan penginapan yang dicadangkan tidak lagi tersedia, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Batalkan penyertaan. Apabila penginapan yang dicadangkan tidak lagi tersedia, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-022",
    "kind": "reputation",
    "title": "Rakan melihat salah faham tentang peranan player dalam acara",
    "description": "Rakan melihat salah faham tentang peranan player dalam acara. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Semak sumber sebelum memberi penjelasan",
      "Minta masa mengesahkan maklumat",
      "Tidak mengulas khabar yang belum sah"
    ],
    "minTrust": 17,
    "weight": 2,
    "contextIndex": 1,
    "followUpChoices": [
      "Betulkan maklumat dengan bukti (ST-022)",
      "Sahkan sumber sebelum bertindak (ST-022)",
      "Elakkan menyebar cerita (ST-022)"
    ],
    "complication": "tangkapan skrin dipetik tanpa konteks",
    "followUpScene": "Ketika isu \"rakan melihat salah faham tentang peranan player dalam acara\" diteruskan, tangkapan skrin dipetik tanpa konteks. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Betulkan maklumat dengan bukti. Walaupun tangkapan skrin dipetik tanpa konteks, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Sahkan sumber sebelum bertindak. Disebabkan tangkapan skrin dipetik tanpa konteks, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Elakkan menyebar cerita. Apabila tangkapan skrin dipetik tanpa konteks, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-023",
    "kind": "education",
    "title": "Rakan mencari kursus bahasa hujung minggu",
    "description": "Rakan mencari kursus bahasa hujung minggu. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu cari bahan pembelajaran",
      "Semak jadual dan tahap kursus",
      "Tidak menyertai sesi pembelajaran"
    ],
    "minTrust": 12,
    "weight": 2,
    "contextIndex": 1,
    "followUpChoices": [
      "Atur sesi pembelajaran (ST-023)",
      "Semak kelayakan dan jadual (ST-023)",
      "Tolak penglibatan (ST-023)"
    ],
    "complication": "syarat kemasukan memerlukan dokumen tambahan",
    "followUpScene": "Ketika isu \"rakan mencari kursus bahasa hujung minggu\" diteruskan, syarat kemasukan memerlukan dokumen tambahan. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Atur sesi pembelajaran. Walaupun syarat kemasukan memerlukan dokumen tambahan, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak kelayakan dan jadual. Disebabkan syarat kemasukan memerlukan dokumen tambahan, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Tolak penglibatan. Apabila syarat kemasukan memerlukan dokumen tambahan, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-024",
    "kind": "network",
    "title": "Rakan mencadangkan pertemuan dengan pakar industri",
    "description": "Rakan mencadangkan pertemuan dengan pakar industri. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Setuju diperkenalkan dengan izin semua pihak",
      "Minta profil dan tujuan pertemuan",
      "Tolak pengenalan buat masa ini"
    ],
    "minTrust": 20,
    "weight": 2,
    "contextIndex": 1,
    "followUpChoices": [
      "Sahkan persetujuan kedua-dua pihak (ST-024)",
      "Semak tujuan pengenalan (ST-024)",
      "Batalkan pengenalan (ST-024)"
    ],
    "complication": "pertemuan profesional ditangguhkan",
    "followUpScene": "Ketika isu \"rakan mencadangkan pertemuan dengan pakar industri\" diteruskan, pertemuan profesional ditangguhkan. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sahkan persetujuan kedua-dua pihak. Walaupun pertemuan profesional ditangguhkan, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak tujuan pengenalan. Disebabkan pertemuan profesional ditangguhkan, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Batalkan pengenalan. Apabila pertemuan profesional ditangguhkan, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-025",
    "kind": "community",
    "title": "Persatuan penduduk mempertikaikan jadual kutipan sampah",
    "description": "Persatuan penduduk mempertikaikan jadual kutipan sampah. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Tawarkan bantuan dengan skop yang jelas",
      "Minta butiran masa dan tugas",
      "Tolak kerana komitmen lain"
    ],
    "minTrust": 4,
    "weight": 3,
    "contextIndex": 2,
    "followUpChoices": [
      "Tetapkan giliran sukarelawan (ST-025)",
      "Semak keperluan penduduk (ST-025)",
      "Serahkan kepada jawatankuasa (ST-025)"
    ],
    "complication": "sukarelawan utama menarik diri pada saat akhir",
    "followUpScene": "Ketika isu \"persatuan penduduk mempertikaikan jadual kutipan sampah\" diteruskan, sukarelawan utama menarik diri pada saat akhir. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Tetapkan giliran sukarelawan. Walaupun sukarelawan utama menarik diri pada saat akhir, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak keperluan penduduk. Disebabkan sukarelawan utama menarik diri pada saat akhir, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Serahkan kepada jawatankuasa. Apabila sukarelawan utama menarik diri pada saat akhir, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-026",
    "kind": "business",
    "title": "Pengusaha kecil mahu menguji permintaan produk baharu",
    "description": "Pengusaha kecil mahu menguji permintaan produk baharu. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Minta bukti kos dan runding syarat",
      "Semak dokumen sebelum beri jawapan",
      "Tolak tawaran tanpa komitmen"
    ],
    "minTrust": 12,
    "weight": 3,
    "contextIndex": 2,
    "followUpChoices": [
      "Sahkan skop dan dokumen (ST-026)",
      "Audit kos serta risiko (ST-026)",
      "Batalkan rundingan (ST-026)"
    ],
    "complication": "rekod inventori menunjukkan kekurangan stok",
    "followUpScene": "Ketika isu \"pengusaha kecil mahu menguji permintaan produk baharu\" diteruskan, rekod inventori menunjukkan kekurangan stok. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sahkan skop dan dokumen. Walaupun rekod inventori menunjukkan kekurangan stok, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Audit kos serta risiko. Disebabkan rekod inventori menunjukkan kekurangan stok, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Batalkan rundingan. Apabila rekod inventori menunjukkan kekurangan stok, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-027",
    "kind": "friendship",
    "title": "Rakan memerlukan teman selepas hari yang sukar",
    "description": "Rakan memerlukan teman selepas hari yang sukar. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Luangkan masa dan dengar cerita",
      "Cadangkan masa lain untuk berbual",
      "Terangkan batasan dengan sopan"
    ],
    "minTrust": 16,
    "weight": 3,
    "contextIndex": 2,
    "followUpChoices": [
      "Atur pertemuan peribadi (ST-027)",
      "Tanya keselesaan kedua-dua pihak (ST-027)",
      "Berikan ruang kepada kenalan (ST-027)"
    ],
    "complication": "masa pertemuan berubah akibat urusan keluarga",
    "followUpScene": "Ketika isu \"rakan memerlukan teman selepas hari yang sukar\" diteruskan, masa pertemuan berubah akibat urusan keluarga. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Atur pertemuan peribadi. Walaupun masa pertemuan berubah akibat urusan keluarga, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Tanya keselesaan kedua-dua pihak. Disebabkan masa pertemuan berubah akibat urusan keluarga, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Berikan ruang kepada kenalan. Apabila masa pertemuan berubah akibat urusan keluarga, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-028",
    "kind": "career",
    "title": "Penyelia meminta bantuan menyiapkan pembentangan",
    "description": "Penyelia meminta bantuan menyiapkan pembentangan. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu merancang langkah seterusnya",
      "Minta maklumat kerja yang lengkap",
      "Tolak penglibatan secara profesional"
    ],
    "minTrust": 19,
    "weight": 3,
    "contextIndex": 2,
    "followUpChoices": [
      "Susun langkah kerjaya (ST-028)",
      "Semak peluang dan syarat (ST-028)",
      "Tidak menjadi perantara (ST-028)"
    ],
    "complication": "tarikh temu duga bertindih dengan tugasan semasa",
    "followUpScene": "Ketika isu \"penyelia meminta bantuan menyiapkan pembentangan\" diteruskan, tarikh temu duga bertindih dengan tugasan semasa. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Susun langkah kerjaya. Walaupun tarikh temu duga bertindih dengan tugasan semasa, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak peluang dan syarat. Disebabkan tarikh temu duga bertindih dengan tugasan semasa, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Tidak menjadi perantara. Apabila tarikh temu duga bertindih dengan tugasan semasa, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-029",
    "kind": "conflict",
    "title": "Dua peniaga bertikai tentang ruang parkir",
    "description": "Dua peniaga bertikai tentang ruang parkir. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Dengar kedua-dua pihak dan cadang mediasi",
      "Minta masa untuk semak fakta",
      "Enggan masuk campur dalam pertikaian"
    ],
    "minTrust": 24,
    "weight": 3,
    "contextIndex": 2,
    "followUpChoices": [
      "Adakan mediasi bersemuka (ST-029)",
      "Kumpulkan bukti neutral (ST-029)",
      "Berundur daripada pertikaian (ST-029)"
    ],
    "complication": "aduan kedua muncul daripada jiran lain",
    "followUpScene": "Ketika isu \"dua peniaga bertikai tentang ruang parkir\" diteruskan, aduan kedua muncul daripada jiran lain. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Adakan mediasi bersemuka. Walaupun aduan kedua muncul daripada jiran lain, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Kumpulkan bukti neutral. Disebabkan aduan kedua muncul daripada jiran lain, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Berundur daripada pertikaian. Apabila aduan kedua muncul daripada jiran lain, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-030",
    "kind": "family",
    "title": "Sepupu memerlukan bantuan berpindah rumah",
    "description": "Sepupu memerlukan bantuan berpindah rumah. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu menyusun keperluan keluarga",
      "Tanya jadual dan tanggungjawab",
      "Tolak dengan alasan yang jelas"
    ],
    "minTrust": 4,
    "weight": 3,
    "contextIndex": 2,
    "followUpChoices": [
      "Agihkan tanggungjawab keluarga (ST-030)",
      "Semak kemampuan dan masa (ST-030)",
      "Beri keputusan tidak terlibat (ST-030)"
    ],
    "complication": "orang yang sepatutnya membantu tidak dapat hadir",
    "followUpScene": "Ketika isu \"sepupu memerlukan bantuan berpindah rumah\" diteruskan, orang yang sepatutnya membantu tidak dapat hadir. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Agihkan tanggungjawab keluarga. Walaupun orang yang sepatutnya membantu tidak dapat hadir, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak kemampuan dan masa. Disebabkan orang yang sepatutnya membantu tidak dapat hadir, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Beri keputusan tidak terlibat. Apabila orang yang sepatutnya membantu tidak dapat hadir, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-031",
    "kind": "civic",
    "title": "Penduduk mahu menyemak jadual perkhidmatan bas",
    "description": "Penduduk mahu menyemak jadual perkhidmatan bas. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Sertai perbincangan dan beri cadangan",
      "Minta dokumen isu terlebih dahulu",
      "Tidak sertai forum kali ini"
    ],
    "minTrust": 14,
    "weight": 3,
    "contextIndex": 2,
    "followUpChoices": [
      "Sediakan cadangan komuniti (ST-031)",
      "Sahkan prosedur pihak berkuasa (ST-031)",
      "Serahkan urusan kepada wakil (ST-031)"
    ],
    "complication": "tarikh sesi pendengaran dipinda",
    "followUpScene": "Ketika isu \"penduduk mahu menyemak jadual perkhidmatan bas\" diteruskan, tarikh sesi pendengaran dipinda. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sediakan cadangan komuniti. Walaupun tarikh sesi pendengaran dipinda, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Sahkan prosedur pihak berkuasa. Disebabkan tarikh sesi pendengaran dipinda, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Serahkan urusan kepada wakil. Apabila tarikh sesi pendengaran dipinda, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-032",
    "kind": "health",
    "title": "Kenalan bertanya cara menyokong ahli keluarga yang tertekan",
    "description": "Kenalan bertanya cara menyokong ahli keluarga yang tertekan. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Dengar dan galakkan sokongan sesuai",
      "Cadangkan berbincang kemudian",
      "Hormati privasi dan tidak terlibat"
    ],
    "minTrust": 9,
    "weight": 3,
    "contextIndex": 2,
    "followUpChoices": [
      "Rancang sokongan yang selamat (ST-032)",
      "Tanya keperluan dan batasan (ST-032)",
      "Hormati privasi kenalan (ST-032)"
    ],
    "complication": "temujanji susulan perlu diatur dengan profesional",
    "followUpScene": "Ketika isu \"kenalan bertanya cara menyokong ahli keluarga yang tertekan\" diteruskan, temujanji susulan perlu diatur dengan profesional. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Rancang sokongan yang selamat. Walaupun temujanji susulan perlu diatur dengan profesional, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Tanya keperluan dan batasan. Disebabkan temujanji susulan perlu diatur dengan profesional, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Hormati privasi kenalan. Apabila temujanji susulan perlu diatur dengan profesional, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-033",
    "kind": "travel",
    "title": "Kumpulan rakan tidak sepakat tentang bajet penginapan",
    "description": "Kumpulan rakan tidak sepakat tentang bajet penginapan. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu susun jadual dan bajet",
      "Semak pengangkutan dan cuaca dahulu",
      "Tidak ikut perjalanan ini"
    ],
    "minTrust": 12,
    "weight": 3,
    "contextIndex": 2,
    "followUpChoices": [
      "Sahkan jadual perjalanan (ST-033)",
      "Periksa bajet dan pengangkutan (ST-033)",
      "Batalkan penyertaan (ST-033)"
    ],
    "complication": "kos perjalanan meningkat daripada anggaran",
    "followUpScene": "Ketika isu \"kumpulan rakan tidak sepakat tentang bajet penginapan\" diteruskan, kos perjalanan meningkat daripada anggaran. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sahkan jadual perjalanan. Walaupun kos perjalanan meningkat daripada anggaran, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Periksa bajet dan pengangkutan. Disebabkan kos perjalanan meningkat daripada anggaran, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Batalkan penyertaan. Apabila kos perjalanan meningkat daripada anggaran, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-034",
    "kind": "reputation",
    "title": "Penganjur memuji sumbangan seseorang tetapi terlupa menyebut nama",
    "description": "Penganjur memuji sumbangan seseorang tetapi terlupa menyebut nama. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Semak sumber sebelum memberi penjelasan",
      "Minta masa mengesahkan maklumat",
      "Tidak mengulas khabar yang belum sah"
    ],
    "minTrust": 19,
    "weight": 3,
    "contextIndex": 2,
    "followUpChoices": [
      "Betulkan maklumat dengan bukti (ST-034)",
      "Sahkan sumber sebelum bertindak (ST-034)",
      "Elakkan menyebar cerita (ST-034)"
    ],
    "complication": "kenalan meminta pembetulan dibuat secara tertutup",
    "followUpScene": "Ketika isu \"penganjur memuji sumbangan seseorang tetapi terlupa menyebut nama\" diteruskan, kenalan meminta pembetulan dibuat secara tertutup. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Betulkan maklumat dengan bukti. Walaupun kenalan meminta pembetulan dibuat secara tertutup, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Sahkan sumber sebelum bertindak. Disebabkan kenalan meminta pembetulan dibuat secara tertutup, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Elakkan menyebar cerita. Apabila kenalan meminta pembetulan dibuat secara tertutup, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-035",
    "kind": "education",
    "title": "Mentor menawarkan bengkel komunikasi profesional",
    "description": "Mentor menawarkan bengkel komunikasi profesional. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu cari bahan pembelajaran",
      "Semak jadual dan tahap kursus",
      "Tidak menyertai sesi pembelajaran"
    ],
    "minTrust": 14,
    "weight": 3,
    "contextIndex": 2,
    "followUpChoices": [
      "Atur sesi pembelajaran (ST-035)",
      "Semak kelayakan dan jadual (ST-035)",
      "Tolak penglibatan (ST-035)"
    ],
    "complication": "kursus alternatif mempunyai kandungan berbeza",
    "followUpScene": "Ketika isu \"mentor menawarkan bengkel komunikasi profesional\" diteruskan, kursus alternatif mempunyai kandungan berbeza. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Atur sesi pembelajaran. Walaupun kursus alternatif mempunyai kandungan berbeza, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak kelayakan dan jadual. Disebabkan kursus alternatif mempunyai kandungan berbeza, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Tolak penglibatan. Apabila kursus alternatif mempunyai kandungan berbeza, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-036",
    "kind": "network",
    "title": "Kenalan meminta persetujuan sebelum berkongsi nombor telefon",
    "description": "Kenalan meminta persetujuan sebelum berkongsi nombor telefon. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Setuju diperkenalkan dengan izin semua pihak",
      "Minta profil dan tujuan pertemuan",
      "Tolak pengenalan buat masa ini"
    ],
    "minTrust": 22,
    "weight": 3,
    "contextIndex": 2,
    "followUpChoices": [
      "Sahkan persetujuan kedua-dua pihak (ST-036)",
      "Semak tujuan pengenalan (ST-036)",
      "Batalkan pengenalan (ST-036)"
    ],
    "complication": "seorang pihak meminta maklumat sulit yang tidak wajar dikongsi",
    "followUpScene": "Ketika isu \"kenalan meminta persetujuan sebelum berkongsi nombor telefon\" diteruskan, seorang pihak meminta maklumat sulit yang tidak wajar dikongsi. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sahkan persetujuan kedua-dua pihak. Walaupun seorang pihak meminta maklumat sulit yang tidak wajar dikongsi, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak tujuan pengenalan. Disebabkan seorang pihak meminta maklumat sulit yang tidak wajar dikongsi, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Batalkan pengenalan. Apabila seorang pihak meminta maklumat sulit yang tidak wajar dikongsi, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-037",
    "kind": "community",
    "title": "Surau dan dewan komuniti berebut slot program hujung minggu",
    "description": "Surau dan dewan komuniti berebut slot program hujung minggu. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Tawarkan bantuan dengan skop yang jelas",
      "Minta butiran masa dan tugas",
      "Tolak kerana komitmen lain"
    ],
    "minTrust": 6,
    "weight": 1,
    "contextIndex": 3,
    "followUpChoices": [
      "Tetapkan giliran sukarelawan (ST-037)",
      "Semak keperluan penduduk (ST-037)",
      "Serahkan kepada jawatankuasa (ST-037)"
    ],
    "complication": "bahan sumbangan belum mendapat kelulusan penggunaan",
    "followUpScene": "Ketika isu \"surau dan dewan komuniti berebut slot program hujung minggu\" diteruskan, bahan sumbangan belum mendapat kelulusan penggunaan. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Tetapkan giliran sukarelawan. Walaupun bahan sumbangan belum mendapat kelulusan penggunaan, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak keperluan penduduk. Disebabkan bahan sumbangan belum mendapat kelulusan penggunaan, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Serahkan kepada jawatankuasa. Apabila bahan sumbangan belum mendapat kelulusan penggunaan, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-038",
    "kind": "business",
    "title": "Pembekal meminta tempoh bayaran lebih panjang",
    "description": "Pembekal meminta tempoh bayaran lebih panjang. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Minta bukti kos dan runding syarat",
      "Semak dokumen sebelum beri jawapan",
      "Tolak tawaran tanpa komitmen"
    ],
    "minTrust": 14,
    "weight": 1,
    "contextIndex": 3,
    "followUpChoices": [
      "Sahkan skop dan dokumen (ST-038)",
      "Audit kos serta risiko (ST-038)",
      "Batalkan rundingan (ST-038)"
    ],
    "complication": "pelanggan utama meminta jaminan bertulis",
    "followUpScene": "Ketika isu \"pembekal meminta tempoh bayaran lebih panjang\" diteruskan, pelanggan utama meminta jaminan bertulis. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sahkan skop dan dokumen. Walaupun pelanggan utama meminta jaminan bertulis, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Audit kos serta risiko. Disebabkan pelanggan utama meminta jaminan bertulis, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Batalkan rundingan. Apabila pelanggan utama meminta jaminan bertulis, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-039",
    "kind": "friendship",
    "title": "Dua sahabat bertelagah dan meminta pendapat berkecuali",
    "description": "Dua sahabat bertelagah dan meminta pendapat berkecuali. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Luangkan masa dan dengar cerita",
      "Cadangkan masa lain untuk berbual",
      "Terangkan batasan dengan sopan"
    ],
    "minTrust": 18,
    "weight": 1,
    "contextIndex": 3,
    "followUpChoices": [
      "Atur pertemuan peribadi (ST-039)",
      "Tanya keselesaan kedua-dua pihak (ST-039)",
      "Berikan ruang kepada kenalan (ST-039)"
    ],
    "complication": "perbualan menyentuh janji lama yang belum selesai",
    "followUpScene": "Ketika isu \"dua sahabat bertelagah dan meminta pendapat berkecuali\" diteruskan, perbualan menyentuh janji lama yang belum selesai. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Atur pertemuan peribadi. Walaupun perbualan menyentuh janji lama yang belum selesai, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Tanya keselesaan kedua-dua pihak. Disebabkan perbualan menyentuh janji lama yang belum selesai, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Berikan ruang kepada kenalan. Apabila perbualan menyentuh janji lama yang belum selesai, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-040",
    "kind": "career",
    "title": "Kenalan mahu berlatih untuk temu duga",
    "description": "Kenalan mahu berlatih untuk temu duga. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu merancang langkah seterusnya",
      "Minta maklumat kerja yang lengkap",
      "Tolak penglibatan secara profesional"
    ],
    "minTrust": 21,
    "weight": 1,
    "contextIndex": 3,
    "followUpChoices": [
      "Susun langkah kerjaya (ST-040)",
      "Semak peluang dan syarat (ST-040)",
      "Tidak menjadi perantara (ST-040)"
    ],
    "complication": "rekod prestasi perlu disemak secara adil",
    "followUpScene": "Ketika isu \"kenalan mahu berlatih untuk temu duga\" diteruskan, rekod prestasi perlu disemak secara adil. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Susun langkah kerjaya. Walaupun rekod prestasi perlu disemak secara adil, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak peluang dan syarat. Disebabkan rekod prestasi perlu disemak secara adil, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Tidak menjadi perantara. Apabila rekod prestasi perlu disemak secara adil, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-041",
    "kind": "conflict",
    "title": "Kenalan mendakwa janji pertemuan tidak ditepati",
    "description": "Kenalan mendakwa janji pertemuan tidak ditepati. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Dengar kedua-dua pihak dan cadang mediasi",
      "Minta masa untuk semak fakta",
      "Enggan masuk campur dalam pertikaian"
    ],
    "minTrust": 26,
    "weight": 1,
    "contextIndex": 3,
    "followUpChoices": [
      "Adakan mediasi bersemuka (ST-041)",
      "Kumpulkan bukti neutral (ST-041)",
      "Berundur daripada pertikaian (ST-041)"
    ],
    "complication": "bukti baharu mengubah kronologi kejadian",
    "followUpScene": "Ketika isu \"kenalan mendakwa janji pertemuan tidak ditepati\" diteruskan, bukti baharu mengubah kronologi kejadian. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Adakan mediasi bersemuka. Walaupun bukti baharu mengubah kronologi kejadian, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Kumpulkan bukti neutral. Disebabkan bukti baharu mengubah kronologi kejadian, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Berundur daripada pertikaian. Apabila bukti baharu mengubah kronologi kejadian, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-042",
    "kind": "family",
    "title": "Keluarga berbincang tentang pembahagian tugas kenduri",
    "description": "Keluarga berbincang tentang pembahagian tugas kenduri. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu menyusun keperluan keluarga",
      "Tanya jadual dan tanggungjawab",
      "Tolak dengan alasan yang jelas"
    ],
    "minTrust": 6,
    "weight": 1,
    "contextIndex": 3,
    "followUpChoices": [
      "Agihkan tanggungjawab keluarga (ST-042)",
      "Semak kemampuan dan masa (ST-042)",
      "Beri keputusan tidak terlibat (ST-042)"
    ],
    "complication": "belanja yang dirancang melebihi kemampuan",
    "followUpScene": "Ketika isu \"keluarga berbincang tentang pembahagian tugas kenduri\" diteruskan, belanja yang dirancang melebihi kemampuan. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Agihkan tanggungjawab keluarga. Walaupun belanja yang dirancang melebihi kemampuan, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak kemampuan dan masa. Disebabkan belanja yang dirancang melebihi kemampuan, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Beri keputusan tidak terlibat. Apabila belanja yang dirancang melebihi kemampuan, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-043",
    "kind": "civic",
    "title": "Forum awam membincangkan kebersihan pasar",
    "description": "Forum awam membincangkan kebersihan pasar. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Sertai perbincangan dan beri cadangan",
      "Minta dokumen isu terlebih dahulu",
      "Tidak sertai forum kali ini"
    ],
    "minTrust": 16,
    "weight": 1,
    "contextIndex": 3,
    "followUpChoices": [
      "Sediakan cadangan komuniti (ST-043)",
      "Sahkan prosedur pihak berkuasa (ST-043)",
      "Serahkan urusan kepada wakil (ST-043)"
    ],
    "complication": "wakil komuniti meminta soalan dikumpulkan dahulu",
    "followUpScene": "Ketika isu \"forum awam membincangkan kebersihan pasar\" diteruskan, wakil komuniti meminta soalan dikumpulkan dahulu. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sediakan cadangan komuniti. Walaupun wakil komuniti meminta soalan dikumpulkan dahulu, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Sahkan prosedur pihak berkuasa. Disebabkan wakil komuniti meminta soalan dikumpulkan dahulu, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Serahkan urusan kepada wakil. Apabila wakil komuniti meminta soalan dikumpulkan dahulu, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-044",
    "kind": "health",
    "title": "Rakan mahu mencuba aktiviti regangan ringan",
    "description": "Rakan mahu mencuba aktiviti regangan ringan. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Dengar dan galakkan sokongan sesuai",
      "Cadangkan berbincang kemudian",
      "Hormati privasi dan tidak terlibat"
    ],
    "minTrust": 11,
    "weight": 1,
    "contextIndex": 3,
    "followUpChoices": [
      "Rancang sokongan yang selamat (ST-044)",
      "Tanya keperluan dan batasan (ST-044)",
      "Hormati privasi kenalan (ST-044)"
    ],
    "complication": "rutin yang dicadangkan tidak sesuai dengan jadual",
    "followUpScene": "Ketika isu \"rakan mahu mencuba aktiviti regangan ringan\" diteruskan, rutin yang dicadangkan tidak sesuai dengan jadual. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Rancang sokongan yang selamat. Walaupun rutin yang dicadangkan tidak sesuai dengan jadual, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Tanya keperluan dan batasan. Disebabkan rutin yang dicadangkan tidak sesuai dengan jadual, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Hormati privasi kenalan. Apabila rutin yang dicadangkan tidak sesuai dengan jadual, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-045",
    "kind": "travel",
    "title": "Rakan mahu menyusun jadual perjalanan balik kampung",
    "description": "Rakan mahu menyusun jadual perjalanan balik kampung. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu susun jadual dan bajet",
      "Semak pengangkutan dan cuaca dahulu",
      "Tidak ikut perjalanan ini"
    ],
    "minTrust": 14,
    "weight": 1,
    "contextIndex": 3,
    "followUpChoices": [
      "Sahkan jadual perjalanan (ST-045)",
      "Periksa bajet dan pengangkutan (ST-045)",
      "Batalkan penyertaan (ST-045)"
    ],
    "complication": "seorang peserta menarik diri",
    "followUpScene": "Ketika isu \"rakan mahu menyusun jadual perjalanan balik kampung\" diteruskan, seorang peserta menarik diri. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sahkan jadual perjalanan. Walaupun seorang peserta menarik diri, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Periksa bajet dan pengangkutan. Disebabkan seorang peserta menarik diri, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Batalkan penyertaan. Apabila seorang peserta menarik diri, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-046",
    "kind": "reputation",
    "title": "Kenalan meminta izin berkongsi pencapaian player",
    "description": "Kenalan meminta izin berkongsi pencapaian player. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Semak sumber sebelum memberi penjelasan",
      "Minta masa mengesahkan maklumat",
      "Tidak mengulas khabar yang belum sah"
    ],
    "minTrust": 21,
    "weight": 1,
    "contextIndex": 3,
    "followUpChoices": [
      "Betulkan maklumat dengan bukti (ST-046)",
      "Sahkan sumber sebelum bertindak (ST-046)",
      "Elakkan menyebar cerita (ST-046)"
    ],
    "complication": "saksi baharu memberikan versi yang berbeza",
    "followUpScene": "Ketika isu \"kenalan meminta izin berkongsi pencapaian player\" diteruskan, saksi baharu memberikan versi yang berbeza. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Betulkan maklumat dengan bukti. Walaupun saksi baharu memberikan versi yang berbeza, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Sahkan sumber sebelum bertindak. Disebabkan saksi baharu memberikan versi yang berbeza, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Elakkan menyebar cerita. Apabila saksi baharu memberikan versi yang berbeza, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-047",
    "kind": "education",
    "title": "Kenalan mahu membina portfolio kerja",
    "description": "Kenalan mahu membina portfolio kerja. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu cari bahan pembelajaran",
      "Semak jadual dan tahap kursus",
      "Tidak menyertai sesi pembelajaran"
    ],
    "minTrust": 16,
    "weight": 1,
    "contextIndex": 3,
    "followUpChoices": [
      "Atur sesi pembelajaran (ST-047)",
      "Semak kelayakan dan jadual (ST-047)",
      "Tolak penglibatan (ST-047)"
    ],
    "complication": "jadual kelas bertindih dengan kerja",
    "followUpScene": "Ketika isu \"kenalan mahu membina portfolio kerja\" diteruskan, jadual kelas bertindih dengan kerja. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Atur sesi pembelajaran. Walaupun jadual kelas bertindih dengan kerja, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak kelayakan dan jadual. Disebabkan jadual kelas bertindih dengan kerja, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Tolak penglibatan. Apabila jadual kelas bertindih dengan kerja, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-048",
    "kind": "network",
    "title": "Penganjur mencari peserta sesi jaringan profesional",
    "description": "Penganjur mencari peserta sesi jaringan profesional. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Setuju diperkenalkan dengan izin semua pihak",
      "Minta profil dan tujuan pertemuan",
      "Tolak pengenalan buat masa ini"
    ],
    "minTrust": 24,
    "weight": 1,
    "contextIndex": 3,
    "followUpChoices": [
      "Sahkan persetujuan kedua-dua pihak (ST-048)",
      "Semak tujuan pengenalan (ST-048)",
      "Batalkan pengenalan (ST-048)"
    ],
    "complication": "kepentingan kedua-dua pihak tidak sepadan",
    "followUpScene": "Ketika isu \"penganjur mencari peserta sesi jaringan profesional\" diteruskan, kepentingan kedua-dua pihak tidak sepadan. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sahkan persetujuan kedua-dua pihak. Walaupun kepentingan kedua-dua pihak tidak sepadan, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak tujuan pengenalan. Disebabkan kepentingan kedua-dua pihak tidak sepadan, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Batalkan pengenalan. Apabila kepentingan kedua-dua pihak tidak sepadan, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-049",
    "kind": "community",
    "title": "Penganjur bazar mencari penyelaras gerai kecil",
    "description": "Penganjur bazar mencari penyelaras gerai kecil. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Tawarkan bantuan dengan skop yang jelas",
      "Minta butiran masa dan tugas",
      "Tolak kerana komitmen lain"
    ],
    "minTrust": 8,
    "weight": 2,
    "contextIndex": 4,
    "followUpChoices": [
      "Tetapkan giliran sukarelawan (ST-049)",
      "Semak keperluan penduduk (ST-049)",
      "Serahkan kepada jawatankuasa (ST-049)"
    ],
    "complication": "aduan keselamatan memerlukan pemeriksaan dahulu",
    "followUpScene": "Ketika isu \"penganjur bazar mencari penyelaras gerai kecil\" diteruskan, aduan keselamatan memerlukan pemeriksaan dahulu. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Tetapkan giliran sukarelawan. Walaupun aduan keselamatan memerlukan pemeriksaan dahulu, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak keperluan penduduk. Disebabkan aduan keselamatan memerlukan pemeriksaan dahulu, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Serahkan kepada jawatankuasa. Apabila aduan keselamatan memerlukan pemeriksaan dahulu, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-050",
    "kind": "business",
    "title": "Pelanggan korporat meminta sebut harga sebelum mesyuarat",
    "description": "Pelanggan korporat meminta sebut harga sebelum mesyuarat. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Minta bukti kos dan runding syarat",
      "Semak dokumen sebelum beri jawapan",
      "Tolak tawaran tanpa komitmen"
    ],
    "minTrust": 16,
    "weight": 2,
    "contextIndex": 4,
    "followUpChoices": [
      "Sahkan skop dan dokumen (ST-050)",
      "Audit kos serta risiko (ST-050)",
      "Batalkan rundingan (ST-050)"
    ],
    "complication": "salah satu invois belum dapat disahkan",
    "followUpScene": "Ketika isu \"pelanggan korporat meminta sebut harga sebelum mesyuarat\" diteruskan, salah satu invois belum dapat disahkan. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sahkan skop dan dokumen. Walaupun salah satu invois belum dapat disahkan, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Audit kos serta risiko. Disebabkan salah satu invois belum dapat disahkan, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Batalkan rundingan. Apabila salah satu invois belum dapat disahkan, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-051",
    "kind": "friendship",
    "title": "Rakan mahu meraikan pencapaian peribadinya",
    "description": "Rakan mahu meraikan pencapaian peribadinya. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Luangkan masa dan dengar cerita",
      "Cadangkan masa lain untuk berbual",
      "Terangkan batasan dengan sopan"
    ],
    "minTrust": 20,
    "weight": 2,
    "contextIndex": 4,
    "followUpChoices": [
      "Atur pertemuan peribadi (ST-051)",
      "Tanya keselesaan kedua-dua pihak (ST-051)",
      "Berikan ruang kepada kenalan (ST-051)"
    ],
    "complication": "kenalan meminta perkara peribadi tidak disebarkan",
    "followUpScene": "Ketika isu \"rakan mahu meraikan pencapaian peribadinya\" diteruskan, kenalan meminta perkara peribadi tidak disebarkan. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Atur pertemuan peribadi. Walaupun kenalan meminta perkara peribadi tidak disebarkan, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Tanya keselesaan kedua-dua pihak. Disebabkan kenalan meminta perkara peribadi tidak disebarkan, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Berikan ruang kepada kenalan. Apabila kenalan meminta perkara peribadi tidak disebarkan, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-052",
    "kind": "career",
    "title": "Rakan sekerja berdepan pertikaian pembahagian tugas",
    "description": "Rakan sekerja berdepan pertikaian pembahagian tugas. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu merancang langkah seterusnya",
      "Minta maklumat kerja yang lengkap",
      "Tolak penglibatan secara profesional"
    ],
    "minTrust": 23,
    "weight": 2,
    "contextIndex": 4,
    "followUpChoices": [
      "Susun langkah kerjaya (ST-052)",
      "Semak peluang dan syarat (ST-052)",
      "Tidak menjadi perantara (ST-052)"
    ],
    "complication": "calon lain turut memohon peluang sama",
    "followUpScene": "Ketika isu \"rakan sekerja berdepan pertikaian pembahagian tugas\" diteruskan, calon lain turut memohon peluang sama. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Susun langkah kerjaya. Walaupun calon lain turut memohon peluang sama, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak peluang dan syarat. Disebabkan calon lain turut memohon peluang sama, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Tidak menjadi perantara. Apabila calon lain turut memohon peluang sama, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-053",
    "kind": "conflict",
    "title": "Rakan sekerja menuduh orang lain mengambil kredit kerjanya",
    "description": "Rakan sekerja menuduh orang lain mengambil kredit kerjanya. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Dengar kedua-dua pihak dan cadang mediasi",
      "Minta masa untuk semak fakta",
      "Enggan masuk campur dalam pertikaian"
    ],
    "minTrust": 28,
    "weight": 2,
    "contextIndex": 4,
    "followUpChoices": [
      "Adakan mediasi bersemuka (ST-053)",
      "Kumpulkan bukti neutral (ST-053)",
      "Berundur daripada pertikaian (ST-053)"
    ],
    "complication": "nada mesej lama mencetuskan salah faham",
    "followUpScene": "Ketika isu \"rakan sekerja menuduh orang lain mengambil kredit kerjanya\" diteruskan, nada mesej lama mencetuskan salah faham. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Adakan mediasi bersemuka. Walaupun nada mesej lama mencetuskan salah faham, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Kumpulkan bukti neutral. Disebabkan nada mesej lama mencetuskan salah faham, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Berundur daripada pertikaian. Apabila nada mesej lama mencetuskan salah faham, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-054",
    "kind": "family",
    "title": "Saudara jauh mahu mengadakan pertemuan semula",
    "description": "Saudara jauh mahu mengadakan pertemuan semula. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu menyusun keperluan keluarga",
      "Tanya jadual dan tanggungjawab",
      "Tolak dengan alasan yang jelas"
    ],
    "minTrust": 8,
    "weight": 2,
    "contextIndex": 4,
    "followUpChoices": [
      "Agihkan tanggungjawab keluarga (ST-054)",
      "Semak kemampuan dan masa (ST-054)",
      "Beri keputusan tidak terlibat (ST-054)"
    ],
    "complication": "seorang saudara mahu isu diselesaikan secara tertutup",
    "followUpScene": "Ketika isu \"saudara jauh mahu mengadakan pertemuan semula\" diteruskan, seorang saudara mahu isu diselesaikan secara tertutup. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Agihkan tanggungjawab keluarga. Walaupun seorang saudara mahu isu diselesaikan secara tertutup, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak kemampuan dan masa. Disebabkan seorang saudara mahu isu diselesaikan secara tertutup, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Beri keputusan tidak terlibat. Apabila seorang saudara mahu isu diselesaikan secara tertutup, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-055",
    "kind": "civic",
    "title": "Jawatankuasa mengumpul pandangan tentang parkir",
    "description": "Jawatankuasa mengumpul pandangan tentang parkir. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Sertai perbincangan dan beri cadangan",
      "Minta dokumen isu terlebih dahulu",
      "Tidak sertai forum kali ini"
    ],
    "minTrust": 18,
    "weight": 2,
    "contextIndex": 4,
    "followUpChoices": [
      "Sediakan cadangan komuniti (ST-055)",
      "Sahkan prosedur pihak berkuasa (ST-055)",
      "Serahkan urusan kepada wakil (ST-055)"
    ],
    "complication": "peraturan tempat mengehadkan jumlah peserta",
    "followUpScene": "Ketika isu \"jawatankuasa mengumpul pandangan tentang parkir\" diteruskan, peraturan tempat mengehadkan jumlah peserta. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sediakan cadangan komuniti. Walaupun peraturan tempat mengehadkan jumlah peserta, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Sahkan prosedur pihak berkuasa. Disebabkan peraturan tempat mengehadkan jumlah peserta, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Serahkan urusan kepada wakil. Apabila peraturan tempat mengehadkan jumlah peserta, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-056",
    "kind": "health",
    "title": "Kenalan mencari kumpulan sokongan gaya hidup sihat",
    "description": "Kenalan mencari kumpulan sokongan gaya hidup sihat. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Dengar dan galakkan sokongan sesuai",
      "Cadangkan berbincang kemudian",
      "Hormati privasi dan tidak terlibat"
    ],
    "minTrust": 13,
    "weight": 2,
    "contextIndex": 4,
    "followUpChoices": [
      "Rancang sokongan yang selamat (ST-056)",
      "Tanya keperluan dan batasan (ST-056)",
      "Hormati privasi kenalan (ST-056)"
    ],
    "complication": "kenalan meminta sokongan emosi tanpa nasihat perubatan",
    "followUpScene": "Ketika isu \"kenalan mencari kumpulan sokongan gaya hidup sihat\" diteruskan, kenalan meminta sokongan emosi tanpa nasihat perubatan. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Rancang sokongan yang selamat. Walaupun kenalan meminta sokongan emosi tanpa nasihat perubatan, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Tanya keperluan dan batasan. Disebabkan kenalan meminta sokongan emosi tanpa nasihat perubatan, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Hormati privasi kenalan. Apabila kenalan meminta sokongan emosi tanpa nasihat perubatan, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-057",
    "kind": "travel",
    "title": "Kenalan mencari teman untuk aktiviti mendaki mudah",
    "description": "Kenalan mencari teman untuk aktiviti mendaki mudah. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu susun jadual dan bajet",
      "Semak pengangkutan dan cuaca dahulu",
      "Tidak ikut perjalanan ini"
    ],
    "minTrust": 16,
    "weight": 2,
    "contextIndex": 4,
    "followUpChoices": [
      "Sahkan jadual perjalanan (ST-057)",
      "Periksa bajet dan pengangkutan (ST-057)",
      "Batalkan penyertaan (ST-057)"
    ],
    "complication": "cuaca memerlukan rancangan alternatif",
    "followUpScene": "Ketika isu \"kenalan mencari teman untuk aktiviti mendaki mudah\" diteruskan, cuaca memerlukan rancangan alternatif. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sahkan jadual perjalanan. Walaupun cuaca memerlukan rancangan alternatif, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Periksa bajet dan pengangkutan. Disebabkan cuaca memerlukan rancangan alternatif, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Batalkan penyertaan. Apabila cuaca memerlukan rancangan alternatif, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-058",
    "kind": "reputation",
    "title": "Jiran menyebarkan cerita yang bercanggah tentang perniagaan",
    "description": "Jiran menyebarkan cerita yang bercanggah tentang perniagaan. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Semak sumber sebelum memberi penjelasan",
      "Minta masa mengesahkan maklumat",
      "Tidak mengulas khabar yang belum sah"
    ],
    "minTrust": 23,
    "weight": 2,
    "contextIndex": 4,
    "followUpChoices": [
      "Betulkan maklumat dengan bukti (ST-058)",
      "Sahkan sumber sebelum bertindak (ST-058)",
      "Elakkan menyebar cerita (ST-058)"
    ],
    "complication": "mesej yang disebarkan rupanya sudah lama",
    "followUpScene": "Ketika isu \"jiran menyebarkan cerita yang bercanggah tentang perniagaan\" diteruskan, mesej yang disebarkan rupanya sudah lama. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Betulkan maklumat dengan bukti. Walaupun mesej yang disebarkan rupanya sudah lama, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Sahkan sumber sebelum bertindak. Disebabkan mesej yang disebarkan rupanya sudah lama, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Elakkan menyebar cerita. Apabila mesej yang disebarkan rupanya sudah lama, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-059",
    "kind": "education",
    "title": "Rakan mengajak menyertai kumpulan belajar digital",
    "description": "Rakan mengajak menyertai kumpulan belajar digital. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu cari bahan pembelajaran",
      "Semak jadual dan tahap kursus",
      "Tidak menyertai sesi pembelajaran"
    ],
    "minTrust": 18,
    "weight": 2,
    "contextIndex": 4,
    "followUpChoices": [
      "Atur sesi pembelajaran (ST-059)",
      "Semak kelayakan dan jadual (ST-059)",
      "Tolak penglibatan (ST-059)"
    ],
    "complication": "yuran sebenar lebih tinggi daripada iklan",
    "followUpScene": "Ketika isu \"rakan mengajak menyertai kumpulan belajar digital\" diteruskan, yuran sebenar lebih tinggi daripada iklan. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Atur sesi pembelajaran. Walaupun yuran sebenar lebih tinggi daripada iklan, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak kelayakan dan jadual. Disebabkan yuran sebenar lebih tinggi daripada iklan, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Tolak penglibatan. Apabila yuran sebenar lebih tinggi daripada iklan, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-060",
    "kind": "network",
    "title": "Rakan mahu memperkenalkan calon pekerja kepada majikan",
    "description": "Rakan mahu memperkenalkan calon pekerja kepada majikan. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Setuju diperkenalkan dengan izin semua pihak",
      "Minta profil dan tujuan pertemuan",
      "Tolak pengenalan buat masa ini"
    ],
    "minTrust": 26,
    "weight": 2,
    "contextIndex": 4,
    "followUpChoices": [
      "Sahkan persetujuan kedua-dua pihak (ST-060)",
      "Semak tujuan pengenalan (ST-060)",
      "Batalkan pengenalan (ST-060)"
    ],
    "complication": "kenalan mahu persetujuan bertulis sebelum pengenalan",
    "followUpScene": "Ketika isu \"rakan mahu memperkenalkan calon pekerja kepada majikan\" diteruskan, kenalan mahu persetujuan bertulis sebelum pengenalan. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sahkan persetujuan kedua-dua pihak. Walaupun kenalan mahu persetujuan bertulis sebelum pengenalan, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak tujuan pengenalan. Disebabkan kenalan mahu persetujuan bertulis sebelum pengenalan, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Batalkan pengenalan. Apabila kenalan mahu persetujuan bertulis sebelum pengenalan, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-061",
    "kind": "community",
    "title": "Warga emas memerlukan bantuan menguruskan pengangkutan",
    "description": "Warga emas memerlukan bantuan menguruskan pengangkutan. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Tawarkan bantuan dengan skop yang jelas",
      "Minta butiran masa dan tugas",
      "Tolak kerana komitmen lain"
    ],
    "minTrust": 10,
    "weight": 3,
    "contextIndex": 5,
    "followUpChoices": [
      "Tetapkan giliran sukarelawan (ST-061)",
      "Semak keperluan penduduk (ST-061)",
      "Serahkan kepada jawatankuasa (ST-061)"
    ],
    "complication": "penduduk berbeza pendapat tentang pembahagian tugas",
    "followUpScene": "Ketika isu \"warga emas memerlukan bantuan menguruskan pengangkutan\" diteruskan, penduduk berbeza pendapat tentang pembahagian tugas. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Tetapkan giliran sukarelawan. Walaupun penduduk berbeza pendapat tentang pembahagian tugas, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak keperluan penduduk. Disebabkan penduduk berbeza pendapat tentang pembahagian tugas, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Serahkan kepada jawatankuasa. Apabila penduduk berbeza pendapat tentang pembahagian tugas, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-062",
    "kind": "business",
    "title": "Pemilik bengkel mahu berkongsi ruang simpanan",
    "description": "Pemilik bengkel mahu berkongsi ruang simpanan. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Minta bukti kos dan runding syarat",
      "Semak dokumen sebelum beri jawapan",
      "Tolak tawaran tanpa komitmen"
    ],
    "minTrust": 18,
    "weight": 3,
    "contextIndex": 5,
    "followUpChoices": [
      "Sahkan skop dan dokumen (ST-062)",
      "Audit kos serta risiko (ST-062)",
      "Batalkan rundingan (ST-062)"
    ],
    "complication": "rakan niaga mahu menukar kaedah pembayaran",
    "followUpScene": "Ketika isu \"pemilik bengkel mahu berkongsi ruang simpanan\" diteruskan, rakan niaga mahu menukar kaedah pembayaran. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sahkan skop dan dokumen. Walaupun rakan niaga mahu menukar kaedah pembayaran, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Audit kos serta risiko. Disebabkan rakan niaga mahu menukar kaedah pembayaran, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Batalkan rundingan. Apabila rakan niaga mahu menukar kaedah pembayaran, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-063",
    "kind": "friendship",
    "title": "Kenalan mengajak menyertai hobi baharu",
    "description": "Kenalan mengajak menyertai hobi baharu. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Luangkan masa dan dengar cerita",
      "Cadangkan masa lain untuk berbual",
      "Terangkan batasan dengan sopan"
    ],
    "minTrust": 22,
    "weight": 3,
    "contextIndex": 5,
    "followUpChoices": [
      "Atur pertemuan peribadi (ST-063)",
      "Tanya keselesaan kedua-dua pihak (ST-063)",
      "Berikan ruang kepada kenalan (ST-063)"
    ],
    "complication": "salah faham mesej lama akhirnya dijelaskan",
    "followUpScene": "Ketika isu \"kenalan mengajak menyertai hobi baharu\" diteruskan, salah faham mesej lama akhirnya dijelaskan. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Atur pertemuan peribadi. Walaupun salah faham mesej lama akhirnya dijelaskan, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Tanya keselesaan kedua-dua pihak. Disebabkan salah faham mesej lama akhirnya dijelaskan, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Berikan ruang kepada kenalan. Apabila salah faham mesej lama akhirnya dijelaskan, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-064",
    "kind": "career",
    "title": "Pekerja kontrak bimbang kontraknya tidak diperbaharui",
    "description": "Pekerja kontrak bimbang kontraknya tidak diperbaharui. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu merancang langkah seterusnya",
      "Minta maklumat kerja yang lengkap",
      "Tolak penglibatan secara profesional"
    ],
    "minTrust": 25,
    "weight": 3,
    "contextIndex": 5,
    "followUpChoices": [
      "Susun langkah kerjaya (ST-064)",
      "Semak peluang dan syarat (ST-064)",
      "Tidak menjadi perantara (ST-064)"
    ],
    "complication": "kenalan bimbang tentang risiko menukar kerjaya",
    "followUpScene": "Ketika isu \"pekerja kontrak bimbang kontraknya tidak diperbaharui\" diteruskan, kenalan bimbang tentang risiko menukar kerjaya. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Susun langkah kerjaya. Walaupun kenalan bimbang tentang risiko menukar kerjaya, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak peluang dan syarat. Disebabkan kenalan bimbang tentang risiko menukar kerjaya, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Tidak menjadi perantara. Apabila kenalan bimbang tentang risiko menukar kerjaya, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-065",
    "kind": "conflict",
    "title": "Jiran berselisih tentang sempadan pagar",
    "description": "Jiran berselisih tentang sempadan pagar. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Dengar kedua-dua pihak dan cadang mediasi",
      "Minta masa untuk semak fakta",
      "Enggan masuk campur dalam pertikaian"
    ],
    "minTrust": 30,
    "weight": 3,
    "contextIndex": 5,
    "followUpChoices": [
      "Adakan mediasi bersemuka (ST-065)",
      "Kumpulkan bukti neutral (ST-065)",
      "Berundur daripada pertikaian (ST-065)"
    ],
    "complication": "pihak terlibat meminta orang tengah yang neutral",
    "followUpScene": "Ketika isu \"jiran berselisih tentang sempadan pagar\" diteruskan, pihak terlibat meminta orang tengah yang neutral. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Adakan mediasi bersemuka. Walaupun pihak terlibat meminta orang tengah yang neutral, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Kumpulkan bukti neutral. Disebabkan pihak terlibat meminta orang tengah yang neutral, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Berundur daripada pertikaian. Apabila pihak terlibat meminta orang tengah yang neutral, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-066",
    "kind": "family",
    "title": "Keluarga mahu memilih lokasi bercuti bersama",
    "description": "Keluarga mahu memilih lokasi bercuti bersama. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu menyusun keperluan keluarga",
      "Tanya jadual dan tanggungjawab",
      "Tolak dengan alasan yang jelas"
    ],
    "minTrust": 10,
    "weight": 3,
    "contextIndex": 5,
    "followUpChoices": [
      "Agihkan tanggungjawab keluarga (ST-066)",
      "Semak kemampuan dan masa (ST-066)",
      "Beri keputusan tidak terlibat (ST-066)"
    ],
    "complication": "maklumat penting tidak sampai kepada semua ahli keluarga",
    "followUpScene": "Ketika isu \"keluarga mahu memilih lokasi bercuti bersama\" diteruskan, maklumat penting tidak sampai kepada semua ahli keluarga. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Agihkan tanggungjawab keluarga. Walaupun maklumat penting tidak sampai kepada semua ahli keluarga, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak kemampuan dan masa. Disebabkan maklumat penting tidak sampai kepada semua ahli keluarga, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Beri keputusan tidak terlibat. Apabila maklumat penting tidak sampai kepada semua ahli keluarga, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-067",
    "kind": "civic",
    "title": "Sukarelawan mengadakan penerangan hak pengguna",
    "description": "Sukarelawan mengadakan penerangan hak pengguna. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Sertai perbincangan dan beri cadangan",
      "Minta dokumen isu terlebih dahulu",
      "Tidak sertai forum kali ini"
    ],
    "minTrust": 20,
    "weight": 3,
    "contextIndex": 5,
    "followUpChoices": [
      "Sediakan cadangan komuniti (ST-067)",
      "Sahkan prosedur pihak berkuasa (ST-067)",
      "Serahkan urusan kepada wakil (ST-067)"
    ],
    "complication": "cadangan perlu dihantar melalui saluran rasmi",
    "followUpScene": "Ketika isu \"sukarelawan mengadakan penerangan hak pengguna\" diteruskan, cadangan perlu dihantar melalui saluran rasmi. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sediakan cadangan komuniti. Walaupun cadangan perlu dihantar melalui saluran rasmi, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Sahkan prosedur pihak berkuasa. Disebabkan cadangan perlu dihantar melalui saluran rasmi, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Serahkan urusan kepada wakil. Apabila cadangan perlu dihantar melalui saluran rasmi, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-068",
    "kind": "health",
    "title": "Rakan berasa malu untuk bertanya doktor tentang simptom",
    "description": "Rakan berasa malu untuk bertanya doktor tentang simptom. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Dengar dan galakkan sokongan sesuai",
      "Cadangkan berbincang kemudian",
      "Hormati privasi dan tidak terlibat"
    ],
    "minTrust": 15,
    "weight": 3,
    "contextIndex": 5,
    "followUpChoices": [
      "Rancang sokongan yang selamat (ST-068)",
      "Tanya keperluan dan batasan (ST-068)",
      "Hormati privasi kenalan (ST-068)"
    ],
    "complication": "keluarga mahu turut serta tetapi persetujuan belum diberi",
    "followUpScene": "Ketika isu \"rakan berasa malu untuk bertanya doktor tentang simptom\" diteruskan, keluarga mahu turut serta tetapi persetujuan belum diberi. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Rancang sokongan yang selamat. Walaupun keluarga mahu turut serta tetapi persetujuan belum diberi, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Tanya keperluan dan batasan. Disebabkan keluarga mahu turut serta tetapi persetujuan belum diberi, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Hormati privasi kenalan. Apabila keluarga mahu turut serta tetapi persetujuan belum diberi, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-069",
    "kind": "travel",
    "title": "Rakan mahu mencuba laluan bas antara bandar",
    "description": "Rakan mahu mencuba laluan bas antara bandar. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu susun jadual dan bajet",
      "Semak pengangkutan dan cuaca dahulu",
      "Tidak ikut perjalanan ini"
    ],
    "minTrust": 18,
    "weight": 3,
    "contextIndex": 5,
    "followUpChoices": [
      "Sahkan jadual perjalanan (ST-069)",
      "Periksa bajet dan pengangkutan (ST-069)",
      "Batalkan penyertaan (ST-069)"
    ],
    "complication": "dokumen perjalanan perlu diperiksa semula",
    "followUpScene": "Ketika isu \"rakan mahu mencuba laluan bas antara bandar\" diteruskan, dokumen perjalanan perlu diperiksa semula. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sahkan jadual perjalanan. Walaupun dokumen perjalanan perlu diperiksa semula, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Periksa bajet dan pengangkutan. Disebabkan dokumen perjalanan perlu diperiksa semula, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Batalkan penyertaan. Apabila dokumen perjalanan perlu diperiksa semula, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-070",
    "kind": "reputation",
    "title": "Rakan mahu membetulkan maklumat salah dalam kumpulan chat",
    "description": "Rakan mahu membetulkan maklumat salah dalam kumpulan chat. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Semak sumber sebelum memberi penjelasan",
      "Minta masa mengesahkan maklumat",
      "Tidak mengulas khabar yang belum sah"
    ],
    "minTrust": 25,
    "weight": 3,
    "contextIndex": 5,
    "followUpChoices": [
      "Betulkan maklumat dengan bukti (ST-070)",
      "Sahkan sumber sebelum bertindak (ST-070)",
      "Elakkan menyebar cerita (ST-070)"
    ],
    "complication": "pihak terlibat mahu peluang menjelaskan sendiri",
    "followUpScene": "Ketika isu \"rakan mahu membetulkan maklumat salah dalam kumpulan chat\" diteruskan, pihak terlibat mahu peluang menjelaskan sendiri. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Betulkan maklumat dengan bukti. Walaupun pihak terlibat mahu peluang menjelaskan sendiri, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Sahkan sumber sebelum bertindak. Disebabkan pihak terlibat mahu peluang menjelaskan sendiri, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Elakkan menyebar cerita. Apabila pihak terlibat mahu peluang menjelaskan sendiri, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-071",
    "kind": "education",
    "title": "Mentor meminta bantuan menyemak bahan latihan",
    "description": "Mentor meminta bantuan menyemak bahan latihan. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu cari bahan pembelajaran",
      "Semak jadual dan tahap kursus",
      "Tidak menyertai sesi pembelajaran"
    ],
    "minTrust": 20,
    "weight": 3,
    "contextIndex": 5,
    "followUpChoices": [
      "Atur sesi pembelajaran (ST-071)",
      "Semak kelayakan dan jadual (ST-071)",
      "Tolak penglibatan (ST-071)"
    ],
    "complication": "tenaga pengajar menukar format pembelajaran",
    "followUpScene": "Ketika isu \"mentor meminta bantuan menyemak bahan latihan\" diteruskan, tenaga pengajar menukar format pembelajaran. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Atur sesi pembelajaran. Walaupun tenaga pengajar menukar format pembelajaran, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak kelayakan dan jadual. Disebabkan tenaga pengajar menukar format pembelajaran, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Tolak penglibatan. Apabila tenaga pengajar menukar format pembelajaran, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-072",
    "kind": "network",
    "title": "Kenalan menjemput player ke sesi perkongsian kerjaya",
    "description": "Kenalan menjemput player ke sesi perkongsian kerjaya. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Setuju diperkenalkan dengan izin semua pihak",
      "Minta profil dan tujuan pertemuan",
      "Tolak pengenalan buat masa ini"
    ],
    "minTrust": 28,
    "weight": 3,
    "contextIndex": 5,
    "followUpChoices": [
      "Sahkan persetujuan kedua-dua pihak (ST-072)",
      "Semak tujuan pengenalan (ST-072)",
      "Batalkan pengenalan (ST-072)"
    ],
    "complication": "orang tengah bimbang reputasinya terjejas",
    "followUpScene": "Ketika isu \"kenalan menjemput player ke sesi perkongsian kerjaya\" diteruskan, orang tengah bimbang reputasinya terjejas. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sahkan persetujuan kedua-dua pihak. Walaupun orang tengah bimbang reputasinya terjejas, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak tujuan pengenalan. Disebabkan orang tengah bimbang reputasinya terjejas, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Batalkan pengenalan. Apabila orang tengah bimbang reputasinya terjejas, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-073",
    "kind": "community",
    "title": "Jiran baharu belum diterima dalam kumpulan penduduk",
    "description": "Jiran baharu belum diterima dalam kumpulan penduduk. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Tawarkan bantuan dengan skop yang jelas",
      "Minta butiran masa dan tugas",
      "Tolak kerana komitmen lain"
    ],
    "minTrust": 12,
    "weight": 1,
    "contextIndex": 6,
    "followUpChoices": [
      "Tetapkan giliran sukarelawan (ST-073)",
      "Semak keperluan penduduk (ST-073)",
      "Serahkan kepada jawatankuasa (ST-073)"
    ],
    "complication": "pemilik tapak meminta kebenaran bertulis",
    "followUpScene": "Ketika isu \"jiran baharu belum diterima dalam kumpulan penduduk\" diteruskan, pemilik tapak meminta kebenaran bertulis. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Tetapkan giliran sukarelawan. Walaupun pemilik tapak meminta kebenaran bertulis, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak keperluan penduduk. Disebabkan pemilik tapak meminta kebenaran bertulis, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Serahkan kepada jawatankuasa. Apabila pemilik tapak meminta kebenaran bertulis, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-074",
    "kind": "business",
    "title": "Usahawan mahu mengadakan jualan percubaan di pasar minggu",
    "description": "Usahawan mahu mengadakan jualan percubaan di pasar minggu. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Minta bukti kos dan runding syarat",
      "Semak dokumen sebelum beri jawapan",
      "Tolak tawaran tanpa komitmen"
    ],
    "minTrust": 20,
    "weight": 1,
    "contextIndex": 6,
    "followUpChoices": [
      "Sahkan skop dan dokumen (ST-074)",
      "Audit kos serta risiko (ST-074)",
      "Batalkan rundingan (ST-074)"
    ],
    "complication": "kontrak mempunyai klausa pembatalan yang kabur",
    "followUpScene": "Ketika isu \"usahawan mahu mengadakan jualan percubaan di pasar minggu\" diteruskan, kontrak mempunyai klausa pembatalan yang kabur. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sahkan skop dan dokumen. Walaupun kontrak mempunyai klausa pembatalan yang kabur, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Audit kos serta risiko. Disebabkan kontrak mempunyai klausa pembatalan yang kabur, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Batalkan rundingan. Apabila kontrak mempunyai klausa pembatalan yang kabur, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-075",
    "kind": "friendship",
    "title": "Kawan meminta bantuan menguruskan kejutan hari lahir",
    "description": "Kawan meminta bantuan menguruskan kejutan hari lahir. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Luangkan masa dan dengar cerita",
      "Cadangkan masa lain untuk berbual",
      "Terangkan batasan dengan sopan"
    ],
    "minTrust": 24,
    "weight": 1,
    "contextIndex": 6,
    "followUpChoices": [
      "Atur pertemuan peribadi (ST-075)",
      "Tanya keselesaan kedua-dua pihak (ST-075)",
      "Berikan ruang kepada kenalan (ST-075)"
    ],
    "complication": "kenalan mahu membawa seorang teman bersama",
    "followUpScene": "Ketika isu \"kawan meminta bantuan menguruskan kejutan hari lahir\" diteruskan, kenalan mahu membawa seorang teman bersama. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Atur pertemuan peribadi. Walaupun kenalan mahu membawa seorang teman bersama, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Tanya keselesaan kedua-dua pihak. Disebabkan kenalan mahu membawa seorang teman bersama, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Berikan ruang kepada kenalan. Apabila kenalan mahu membawa seorang teman bersama, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-076",
    "kind": "career",
    "title": "Mentor menyarankan kursus untuk naik pangkat",
    "description": "Mentor menyarankan kursus untuk naik pangkat. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu merancang langkah seterusnya",
      "Minta maklumat kerja yang lengkap",
      "Tolak penglibatan secara profesional"
    ],
    "minTrust": 27,
    "weight": 1,
    "contextIndex": 6,
    "followUpChoices": [
      "Susun langkah kerjaya (ST-076)",
      "Semak peluang dan syarat (ST-076)",
      "Tidak menjadi perantara (ST-076)"
    ],
    "complication": "surat tawaran belum menjelaskan semua manfaat",
    "followUpScene": "Ketika isu \"mentor menyarankan kursus untuk naik pangkat\" diteruskan, surat tawaran belum menjelaskan semua manfaat. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Susun langkah kerjaya. Walaupun surat tawaran belum menjelaskan semua manfaat, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak peluang dan syarat. Disebabkan surat tawaran belum menjelaskan semua manfaat, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Tidak menjadi perantara. Apabila surat tawaran belum menjelaskan semua manfaat, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-077",
    "kind": "conflict",
    "title": "Pelanggan mengadu layanan tidak adil",
    "description": "Pelanggan mengadu layanan tidak adil. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Dengar kedua-dua pihak dan cadang mediasi",
      "Minta masa untuk semak fakta",
      "Enggan masuk campur dalam pertikaian"
    ],
    "minTrust": 32,
    "weight": 1,
    "contextIndex": 6,
    "followUpChoices": [
      "Adakan mediasi bersemuka (ST-077)",
      "Kumpulkan bukti neutral (ST-077)",
      "Berundur daripada pertikaian (ST-077)"
    ],
    "complication": "cadangan kompromi ditolak tanpa alasan jelas",
    "followUpScene": "Ketika isu \"pelanggan mengadu layanan tidak adil\" diteruskan, cadangan kompromi ditolak tanpa alasan jelas. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Adakan mediasi bersemuka. Walaupun cadangan kompromi ditolak tanpa alasan jelas, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Kumpulkan bukti neutral. Disebabkan cadangan kompromi ditolak tanpa alasan jelas, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Berundur daripada pertikaian. Apabila cadangan kompromi ditolak tanpa alasan jelas, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-078",
    "kind": "family",
    "title": "Adik-beradik tidak sepakat tentang jadual lawatan",
    "description": "Adik-beradik tidak sepakat tentang jadual lawatan. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu menyusun keperluan keluarga",
      "Tanya jadual dan tanggungjawab",
      "Tolak dengan alasan yang jelas"
    ],
    "minTrust": 12,
    "weight": 1,
    "contextIndex": 6,
    "followUpChoices": [
      "Agihkan tanggungjawab keluarga (ST-078)",
      "Semak kemampuan dan masa (ST-078)",
      "Beri keputusan tidak terlibat (ST-078)"
    ],
    "complication": "tanggungjawab penjagaan perlu dibahagi semula",
    "followUpScene": "Ketika isu \"adik-beradik tidak sepakat tentang jadual lawatan\" diteruskan, tanggungjawab penjagaan perlu dibahagi semula. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Agihkan tanggungjawab keluarga. Walaupun tanggungjawab penjagaan perlu dibahagi semula, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak kemampuan dan masa. Disebabkan tanggungjawab penjagaan perlu dibahagi semula, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Beri keputusan tidak terlibat. Apabila tanggungjawab penjagaan perlu dibahagi semula, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-079",
    "kind": "civic",
    "title": "Penduduk mahu membuat aduan longkang tersumbat",
    "description": "Penduduk mahu membuat aduan longkang tersumbat. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Sertai perbincangan dan beri cadangan",
      "Minta dokumen isu terlebih dahulu",
      "Tidak sertai forum kali ini"
    ],
    "minTrust": 22,
    "weight": 1,
    "contextIndex": 6,
    "followUpChoices": [
      "Sediakan cadangan komuniti (ST-079)",
      "Sahkan prosedur pihak berkuasa (ST-079)",
      "Serahkan urusan kepada wakil (ST-079)"
    ],
    "complication": "dua kumpulan mempunyai keutamaan berbeza",
    "followUpScene": "Ketika isu \"penduduk mahu membuat aduan longkang tersumbat\" diteruskan, dua kumpulan mempunyai keutamaan berbeza. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sediakan cadangan komuniti. Walaupun dua kumpulan mempunyai keutamaan berbeza, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Sahkan prosedur pihak berkuasa. Disebabkan dua kumpulan mempunyai keutamaan berbeza, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Serahkan urusan kepada wakil. Apabila dua kumpulan mempunyai keutamaan berbeza, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-080",
    "kind": "health",
    "title": "Kenalan mahu mengurangkan masa skrin sebelum tidur",
    "description": "Kenalan mahu mengurangkan masa skrin sebelum tidur. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Dengar dan galakkan sokongan sesuai",
      "Cadangkan berbincang kemudian",
      "Hormati privasi dan tidak terlibat"
    ],
    "minTrust": 17,
    "weight": 1,
    "contextIndex": 6,
    "followUpChoices": [
      "Rancang sokongan yang selamat (ST-080)",
      "Tanya keperluan dan batasan (ST-080)",
      "Hormati privasi kenalan (ST-080)"
    ],
    "complication": "kenalan keliru tentang sumber maklumat yang dipercayai",
    "followUpScene": "Ketika isu \"kenalan mahu mengurangkan masa skrin sebelum tidur\" diteruskan, kenalan keliru tentang sumber maklumat yang dipercayai. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Rancang sokongan yang selamat. Walaupun kenalan keliru tentang sumber maklumat yang dipercayai, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Tanya keperluan dan batasan. Disebabkan kenalan keliru tentang sumber maklumat yang dipercayai, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Hormati privasi kenalan. Apabila kenalan keliru tentang sumber maklumat yang dipercayai, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-081",
    "kind": "travel",
    "title": "Kumpulan mahu membahagikan kos petrol secara adil",
    "description": "Kumpulan mahu membahagikan kos petrol secara adil. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu susun jadual dan bajet",
      "Semak pengangkutan dan cuaca dahulu",
      "Tidak ikut perjalanan ini"
    ],
    "minTrust": 20,
    "weight": 1,
    "contextIndex": 6,
    "followUpChoices": [
      "Sahkan jadual perjalanan (ST-081)",
      "Periksa bajet dan pengangkutan (ST-081)",
      "Batalkan penyertaan (ST-081)"
    ],
    "complication": "tempat lawatan mempunyai had tempahan",
    "followUpScene": "Ketika isu \"kumpulan mahu membahagikan kos petrol secara adil\" diteruskan, tempat lawatan mempunyai had tempahan. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sahkan jadual perjalanan. Walaupun tempat lawatan mempunyai had tempahan, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Periksa bajet dan pengangkutan. Disebabkan tempat lawatan mempunyai had tempahan, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Batalkan penyertaan. Apabila tempat lawatan mempunyai had tempahan, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-082",
    "kind": "reputation",
    "title": "Kenalan mengingatkan tentang janji awam yang belum ditunaikan",
    "description": "Kenalan mengingatkan tentang janji awam yang belum ditunaikan. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Semak sumber sebelum memberi penjelasan",
      "Minta masa mengesahkan maklumat",
      "Tidak mengulas khabar yang belum sah"
    ],
    "minTrust": 27,
    "weight": 1,
    "contextIndex": 6,
    "followUpChoices": [
      "Betulkan maklumat dengan bukti (ST-082)",
      "Sahkan sumber sebelum bertindak (ST-082)",
      "Elakkan menyebar cerita (ST-082)"
    ],
    "complication": "permohonan maaf tidak diterima semua orang",
    "followUpScene": "Ketika isu \"kenalan mengingatkan tentang janji awam yang belum ditunaikan\" diteruskan, permohonan maaf tidak diterima semua orang. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Betulkan maklumat dengan bukti. Walaupun permohonan maaf tidak diterima semua orang, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Sahkan sumber sebelum bertindak. Disebabkan permohonan maaf tidak diterima semua orang, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Elakkan menyebar cerita. Apabila permohonan maaf tidak diterima semua orang, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-083",
    "kind": "education",
    "title": "Kenalan mahu belajar keselamatan siber asas",
    "description": "Kenalan mahu belajar keselamatan siber asas. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu cari bahan pembelajaran",
      "Semak jadual dan tahap kursus",
      "Tidak menyertai sesi pembelajaran"
    ],
    "minTrust": 22,
    "weight": 1,
    "contextIndex": 6,
    "followUpChoices": [
      "Atur sesi pembelajaran (ST-083)",
      "Semak kelayakan dan jadual (ST-083)",
      "Tolak penglibatan (ST-083)"
    ],
    "complication": "kenalan memerlukan rancangan belajar yang realistik",
    "followUpScene": "Ketika isu \"kenalan mahu belajar keselamatan siber asas\" diteruskan, kenalan memerlukan rancangan belajar yang realistik. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Atur sesi pembelajaran. Walaupun kenalan memerlukan rancangan belajar yang realistik, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak kelayakan dan jadual. Disebabkan kenalan memerlukan rancangan belajar yang realistik, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Tolak penglibatan. Apabila kenalan memerlukan rancangan belajar yang realistik, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-084",
    "kind": "network",
    "title": "Usahawan mahu membentuk kumpulan pembelian bersama",
    "description": "Usahawan mahu membentuk kumpulan pembelian bersama. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Setuju diperkenalkan dengan izin semua pihak",
      "Minta profil dan tujuan pertemuan",
      "Tolak pengenalan buat masa ini"
    ],
    "minTrust": 30,
    "weight": 1,
    "contextIndex": 6,
    "followUpChoices": [
      "Sahkan persetujuan kedua-dua pihak (ST-084)",
      "Semak tujuan pengenalan (ST-084)",
      "Batalkan pengenalan (ST-084)"
    ],
    "complication": "mesyuarat pertama hanya boleh dibuat secara ringkas",
    "followUpScene": "Ketika isu \"usahawan mahu membentuk kumpulan pembelian bersama\" diteruskan, mesyuarat pertama hanya boleh dibuat secara ringkas. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sahkan persetujuan kedua-dua pihak. Walaupun mesyuarat pertama hanya boleh dibuat secara ringkas, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak tujuan pengenalan. Disebabkan mesyuarat pertama hanya boleh dibuat secara ringkas, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Batalkan pengenalan. Apabila mesyuarat pertama hanya boleh dibuat secara ringkas, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-085",
    "kind": "community",
    "title": "Pasukan sukarela kekurangan orang untuk program kebersihan sungai",
    "description": "Pasukan sukarela kekurangan orang untuk program kebersihan sungai. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Tawarkan bantuan dengan skop yang jelas",
      "Minta butiran masa dan tugas",
      "Tolak kerana komitmen lain"
    ],
    "minTrust": 14,
    "weight": 2,
    "contextIndex": 7,
    "followUpChoices": [
      "Tetapkan giliran sukarelawan (ST-085)",
      "Semak keperluan penduduk (ST-085)",
      "Serahkan kepada jawatankuasa (ST-085)"
    ],
    "complication": "tarikh gotong-royong bertembung dengan acara lain",
    "followUpScene": "Ketika isu \"pasukan sukarela kekurangan orang untuk program kebersihan sungai\" diteruskan, tarikh gotong-royong bertembung dengan acara lain. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Tetapkan giliran sukarelawan. Walaupun tarikh gotong-royong bertembung dengan acara lain, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak keperluan penduduk. Disebabkan tarikh gotong-royong bertembung dengan acara lain, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Serahkan kepada jawatankuasa. Apabila tarikh gotong-royong bertembung dengan acara lain, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-086",
    "kind": "business",
    "title": "Pemborong menerima tawaran eksklusif yang berisiko",
    "description": "Pemborong menerima tawaran eksklusif yang berisiko. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Minta bukti kos dan runding syarat",
      "Semak dokumen sebelum beri jawapan",
      "Tolak tawaran tanpa komitmen"
    ],
    "minTrust": 22,
    "weight": 2,
    "contextIndex": 7,
    "followUpChoices": [
      "Sahkan skop dan dokumen (ST-086)",
      "Audit kos serta risiko (ST-086)",
      "Batalkan rundingan (ST-086)"
    ],
    "complication": "permintaan pasaran menurun sebelum perjanjian dimeterai",
    "followUpScene": "Ketika isu \"pemborong menerima tawaran eksklusif yang berisiko\" diteruskan, permintaan pasaran menurun sebelum perjanjian dimeterai. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sahkan skop dan dokumen. Walaupun permintaan pasaran menurun sebelum perjanjian dimeterai, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Audit kos serta risiko. Disebabkan permintaan pasaran menurun sebelum perjanjian dimeterai, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Batalkan rundingan. Apabila permintaan pasaran menurun sebelum perjanjian dimeterai, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-087",
    "kind": "friendship",
    "title": "Rakan mahu meminjam barang yang bernilai sentimental",
    "description": "Rakan mahu meminjam barang yang bernilai sentimental. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Luangkan masa dan dengar cerita",
      "Cadangkan masa lain untuk berbual",
      "Terangkan batasan dengan sopan"
    ],
    "minTrust": 26,
    "weight": 2,
    "contextIndex": 7,
    "followUpChoices": [
      "Atur pertemuan peribadi (ST-087)",
      "Tanya keselesaan kedua-dua pihak (ST-087)",
      "Berikan ruang kepada kenalan (ST-087)"
    ],
    "complication": "perancangan bersama memerlukan persetujuan kedua-dua pihak",
    "followUpScene": "Ketika isu \"rakan mahu meminjam barang yang bernilai sentimental\" diteruskan, perancangan bersama memerlukan persetujuan kedua-dua pihak. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Atur pertemuan peribadi. Walaupun perancangan bersama memerlukan persetujuan kedua-dua pihak, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Tanya keselesaan kedua-dua pihak. Disebabkan perancangan bersama memerlukan persetujuan kedua-dua pihak, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Berikan ruang kepada kenalan. Apabila perancangan bersama memerlukan persetujuan kedua-dua pihak, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-088",
    "kind": "career",
    "title": "Kenalan mendapat tawaran kerja di negeri lain",
    "description": "Kenalan mendapat tawaran kerja di negeri lain. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu merancang langkah seterusnya",
      "Minta maklumat kerja yang lengkap",
      "Tolak penglibatan secara profesional"
    ],
    "minTrust": 29,
    "weight": 2,
    "contextIndex": 7,
    "followUpChoices": [
      "Susun langkah kerjaya (ST-088)",
      "Semak peluang dan syarat (ST-088)",
      "Tidak menjadi perantara (ST-088)"
    ],
    "complication": "jadual latihan tidak serasi dengan waktu kerja",
    "followUpScene": "Ketika isu \"kenalan mendapat tawaran kerja di negeri lain\" diteruskan, jadual latihan tidak serasi dengan waktu kerja. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Susun langkah kerjaya. Walaupun jadual latihan tidak serasi dengan waktu kerja, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak peluang dan syarat. Disebabkan jadual latihan tidak serasi dengan waktu kerja, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Tidak menjadi perantara. Apabila jadual latihan tidak serasi dengan waktu kerja, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-089",
    "kind": "conflict",
    "title": "Dua sahabat bertelagah kerana khabar angin",
    "description": "Dua sahabat bertelagah kerana khabar angin. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Dengar kedua-dua pihak dan cadang mediasi",
      "Minta masa untuk semak fakta",
      "Enggan masuk campur dalam pertikaian"
    ],
    "minTrust": 34,
    "weight": 2,
    "contextIndex": 7,
    "followUpChoices": [
      "Adakan mediasi bersemuka (ST-089)",
      "Kumpulkan bukti neutral (ST-089)",
      "Berundur daripada pertikaian (ST-089)"
    ],
    "complication": "isu kecil mula menjejaskan hubungan kejiranan",
    "followUpScene": "Ketika isu \"dua sahabat bertelagah kerana khabar angin\" diteruskan, isu kecil mula menjejaskan hubungan kejiranan. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Adakan mediasi bersemuka. Walaupun isu kecil mula menjejaskan hubungan kejiranan, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Kumpulkan bukti neutral. Disebabkan isu kecil mula menjejaskan hubungan kejiranan, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Berundur daripada pertikaian. Apabila isu kecil mula menjejaskan hubungan kejiranan, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-090",
    "kind": "family",
    "title": "Saudara meminta bantuan mencari kelas tambahan anak",
    "description": "Saudara meminta bantuan mencari kelas tambahan anak. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu menyusun keperluan keluarga",
      "Tanya jadual dan tanggungjawab",
      "Tolak dengan alasan yang jelas"
    ],
    "minTrust": 14,
    "weight": 2,
    "contextIndex": 7,
    "followUpChoices": [
      "Agihkan tanggungjawab keluarga (ST-090)",
      "Semak kemampuan dan masa (ST-090)",
      "Beri keputusan tidak terlibat (ST-090)"
    ],
    "complication": "keputusan lama menimbulkan rasa tidak puas hati",
    "followUpScene": "Ketika isu \"saudara meminta bantuan mencari kelas tambahan anak\" diteruskan, keputusan lama menimbulkan rasa tidak puas hati. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Agihkan tanggungjawab keluarga. Walaupun keputusan lama menimbulkan rasa tidak puas hati, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak kemampuan dan masa. Disebabkan keputusan lama menimbulkan rasa tidak puas hati, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Beri keputusan tidak terlibat. Apabila keputusan lama menimbulkan rasa tidak puas hati, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-091",
    "kind": "civic",
    "title": "Penganjur dialog meminta soalan tentang kemudahan awam",
    "description": "Penganjur dialog meminta soalan tentang kemudahan awam. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Sertai perbincangan dan beri cadangan",
      "Minta dokumen isu terlebih dahulu",
      "Tidak sertai forum kali ini"
    ],
    "minTrust": 24,
    "weight": 2,
    "contextIndex": 7,
    "followUpChoices": [
      "Sediakan cadangan komuniti (ST-091)",
      "Sahkan prosedur pihak berkuasa (ST-091)",
      "Serahkan urusan kepada wakil (ST-091)"
    ],
    "complication": "pihak berkuasa belum memberi jawapan bertulis",
    "followUpScene": "Ketika isu \"penganjur dialog meminta soalan tentang kemudahan awam\" diteruskan, pihak berkuasa belum memberi jawapan bertulis. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sediakan cadangan komuniti. Walaupun pihak berkuasa belum memberi jawapan bertulis, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Sahkan prosedur pihak berkuasa. Disebabkan pihak berkuasa belum memberi jawapan bertulis, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Serahkan urusan kepada wakil. Apabila pihak berkuasa belum memberi jawapan bertulis, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-092",
    "kind": "health",
    "title": "Rakan meminta teman untuk pemeriksaan rutin",
    "description": "Rakan meminta teman untuk pemeriksaan rutin. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Dengar dan galakkan sokongan sesuai",
      "Cadangkan berbincang kemudian",
      "Hormati privasi dan tidak terlibat"
    ],
    "minTrust": 19,
    "weight": 2,
    "contextIndex": 7,
    "followUpChoices": [
      "Rancang sokongan yang selamat (ST-092)",
      "Tanya keperluan dan batasan (ST-092)",
      "Hormati privasi kenalan (ST-092)"
    ],
    "complication": "bantuan praktikal perlu diselaraskan dengan masa rehat",
    "followUpScene": "Ketika isu \"rakan meminta teman untuk pemeriksaan rutin\" diteruskan, bantuan praktikal perlu diselaraskan dengan masa rehat. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Rancang sokongan yang selamat. Walaupun bantuan praktikal perlu diselaraskan dengan masa rehat, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Tanya keperluan dan batasan. Disebabkan bantuan praktikal perlu diselaraskan dengan masa rehat, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Hormati privasi kenalan. Apabila bantuan praktikal perlu diselaraskan dengan masa rehat, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-093",
    "kind": "travel",
    "title": "Kenalan mahu mengelakkan tempat sesak semasa cuti",
    "description": "Kenalan mahu mengelakkan tempat sesak semasa cuti. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu susun jadual dan bajet",
      "Semak pengangkutan dan cuaca dahulu",
      "Tidak ikut perjalanan ini"
    ],
    "minTrust": 22,
    "weight": 2,
    "contextIndex": 7,
    "followUpChoices": [
      "Sahkan jadual perjalanan (ST-093)",
      "Periksa bajet dan pengangkutan (ST-093)",
      "Batalkan penyertaan (ST-093)"
    ],
    "complication": "keutamaan peserta tentang aktiviti tidak sama",
    "followUpScene": "Ketika isu \"kenalan mahu mengelakkan tempat sesak semasa cuti\" diteruskan, keutamaan peserta tentang aktiviti tidak sama. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sahkan jadual perjalanan. Walaupun keutamaan peserta tentang aktiviti tidak sama, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Periksa bajet dan pengangkutan. Disebabkan keutamaan peserta tentang aktiviti tidak sama, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Batalkan penyertaan. Apabila keutamaan peserta tentang aktiviti tidak sama, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-094",
    "kind": "reputation",
    "title": "Seorang pelanggan menulis ulasan tanpa konteks penuh",
    "description": "Seorang pelanggan menulis ulasan tanpa konteks penuh. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Semak sumber sebelum memberi penjelasan",
      "Minta masa mengesahkan maklumat",
      "Tidak mengulas khabar yang belum sah"
    ],
    "minTrust": 29,
    "weight": 2,
    "contextIndex": 7,
    "followUpChoices": [
      "Betulkan maklumat dengan bukti (ST-094)",
      "Sahkan sumber sebelum bertindak (ST-094)",
      "Elakkan menyebar cerita (ST-094)"
    ],
    "complication": "sebahagian maklumat terbukti tidak tepat",
    "followUpScene": "Ketika isu \"seorang pelanggan menulis ulasan tanpa konteks penuh\" diteruskan, sebahagian maklumat terbukti tidak tepat. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Betulkan maklumat dengan bukti. Walaupun sebahagian maklumat terbukti tidak tepat, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Sahkan sumber sebelum bertindak. Disebabkan sebahagian maklumat terbukti tidak tepat, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Elakkan menyebar cerita. Apabila sebahagian maklumat terbukti tidak tepat, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-095",
    "kind": "education",
    "title": "Rakan mencari cara mengurus jadual ulang kaji",
    "description": "Rakan mencari cara mengurus jadual ulang kaji. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu cari bahan pembelajaran",
      "Semak jadual dan tahap kursus",
      "Tidak menyertai sesi pembelajaran"
    ],
    "minTrust": 24,
    "weight": 2,
    "contextIndex": 7,
    "followUpChoices": [
      "Atur sesi pembelajaran (ST-095)",
      "Semak kelayakan dan jadual (ST-095)",
      "Tolak penglibatan (ST-095)"
    ],
    "complication": "tempat latihan hampir penuh",
    "followUpScene": "Ketika isu \"rakan mencari cara mengurus jadual ulang kaji\" diteruskan, tempat latihan hampir penuh. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Atur sesi pembelajaran. Walaupun tempat latihan hampir penuh, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak kelayakan dan jadual. Disebabkan tempat latihan hampir penuh, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Tolak penglibatan. Apabila tempat latihan hampir penuh, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-096",
    "kind": "network",
    "title": "Rakan menghubungkan dua komuniti yang belum pernah bekerjasama",
    "description": "Rakan menghubungkan dua komuniti yang belum pernah bekerjasama. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Setuju diperkenalkan dengan izin semua pihak",
      "Minta profil dan tujuan pertemuan",
      "Tolak pengenalan buat masa ini"
    ],
    "minTrust": 32,
    "weight": 2,
    "contextIndex": 7,
    "followUpChoices": [
      "Sahkan persetujuan kedua-dua pihak (ST-096)",
      "Semak tujuan pengenalan (ST-096)",
      "Batalkan pengenalan (ST-096)"
    ],
    "complication": "pihak baharu mahu rujukan kerja yang boleh disahkan",
    "followUpScene": "Ketika isu \"rakan menghubungkan dua komuniti yang belum pernah bekerjasama\" diteruskan, pihak baharu mahu rujukan kerja yang boleh disahkan. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sahkan persetujuan kedua-dua pihak. Walaupun pihak baharu mahu rujukan kerja yang boleh disahkan, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak tujuan pengenalan. Disebabkan pihak baharu mahu rujukan kerja yang boleh disahkan, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Batalkan pengenalan. Apabila pihak baharu mahu rujukan kerja yang boleh disahkan, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-097",
    "kind": "community",
    "title": "Penduduk mahu membuat tinjauan keselamatan jalan",
    "description": "Penduduk mahu membuat tinjauan keselamatan jalan. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Tawarkan bantuan dengan skop yang jelas",
      "Minta butiran masa dan tugas",
      "Tolak kerana komitmen lain"
    ],
    "minTrust": 16,
    "weight": 3,
    "contextIndex": 8,
    "followUpChoices": [
      "Tetapkan giliran sukarelawan (ST-097)",
      "Semak keperluan penduduk (ST-097)",
      "Serahkan kepada jawatankuasa (ST-097)"
    ],
    "complication": "sumbangan barangan tidak cukup untuk semua peserta",
    "followUpScene": "Ketika isu \"penduduk mahu membuat tinjauan keselamatan jalan\" diteruskan, sumbangan barangan tidak cukup untuk semua peserta. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Tetapkan giliran sukarelawan. Walaupun sumbangan barangan tidak cukup untuk semua peserta, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak keperluan penduduk. Disebabkan sumbangan barangan tidak cukup untuk semua peserta, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Serahkan kepada jawatankuasa. Apabila sumbangan barangan tidak cukup untuk semua peserta, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-098",
    "kind": "business",
    "title": "Rakan kongsi bercanggah tentang pembahagian tugas",
    "description": "Rakan kongsi bercanggah tentang pembahagian tugas. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Minta bukti kos dan runding syarat",
      "Semak dokumen sebelum beri jawapan",
      "Tolak tawaran tanpa komitmen"
    ],
    "minTrust": 24,
    "weight": 3,
    "contextIndex": 8,
    "followUpChoices": [
      "Sahkan skop dan dokumen (ST-098)",
      "Audit kos serta risiko (ST-098)",
      "Batalkan rundingan (ST-098)"
    ],
    "complication": "penghantaran percubaan menunjukkan isu kualiti",
    "followUpScene": "Ketika isu \"rakan kongsi bercanggah tentang pembahagian tugas\" diteruskan, penghantaran percubaan menunjukkan isu kualiti. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sahkan skop dan dokumen. Walaupun penghantaran percubaan menunjukkan isu kualiti, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Audit kos serta risiko. Disebabkan penghantaran percubaan menunjukkan isu kualiti, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Batalkan rundingan. Apabila penghantaran percubaan menunjukkan isu kualiti, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-099",
    "kind": "friendship",
    "title": "Kenalan menyampaikan cerita peribadi secara sulit",
    "description": "Kenalan menyampaikan cerita peribadi secara sulit. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Luangkan masa dan dengar cerita",
      "Cadangkan masa lain untuk berbual",
      "Terangkan batasan dengan sopan"
    ],
    "minTrust": 28,
    "weight": 3,
    "contextIndex": 8,
    "followUpChoices": [
      "Atur pertemuan peribadi (ST-099)",
      "Tanya keselesaan kedua-dua pihak (ST-099)",
      "Berikan ruang kepada kenalan (ST-099)"
    ],
    "complication": "kenalan mengakui sedang menghadapi tekanan kerja",
    "followUpScene": "Ketika isu \"kenalan menyampaikan cerita peribadi secara sulit\" diteruskan, kenalan mengakui sedang menghadapi tekanan kerja. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Atur pertemuan peribadi. Walaupun kenalan mengakui sedang menghadapi tekanan kerja, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Tanya keselesaan kedua-dua pihak. Disebabkan kenalan mengakui sedang menghadapi tekanan kerja, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Berikan ruang kepada kenalan. Apabila kenalan mengakui sedang menghadapi tekanan kerja, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-100",
    "kind": "career",
    "title": "Rakan mahu meminta kenaikan gaji tetapi kurang yakin",
    "description": "Rakan mahu meminta kenaikan gaji tetapi kurang yakin. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu merancang langkah seterusnya",
      "Minta maklumat kerja yang lengkap",
      "Tolak penglibatan secara profesional"
    ],
    "minTrust": 31,
    "weight": 3,
    "contextIndex": 8,
    "followUpChoices": [
      "Susun langkah kerjaya (ST-100)",
      "Semak peluang dan syarat (ST-100)",
      "Tidak menjadi perantara (ST-100)"
    ],
    "complication": "maklumat gaji berbeza daripada perbincangan awal",
    "followUpScene": "Ketika isu \"rakan mahu meminta kenaikan gaji tetapi kurang yakin\" diteruskan, maklumat gaji berbeza daripada perbincangan awal. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Susun langkah kerjaya. Walaupun maklumat gaji berbeza daripada perbincangan awal, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak peluang dan syarat. Disebabkan maklumat gaji berbeza daripada perbincangan awal, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Tidak menjadi perantara. Apabila maklumat gaji berbeza daripada perbincangan awal, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-101",
    "kind": "conflict",
    "title": "Penganjur acara menyalahkan sukarelawan atas kelewatan",
    "description": "Penganjur acara menyalahkan sukarelawan atas kelewatan. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Dengar kedua-dua pihak dan cadang mediasi",
      "Minta masa untuk semak fakta",
      "Enggan masuk campur dalam pertikaian"
    ],
    "minTrust": 36,
    "weight": 3,
    "contextIndex": 8,
    "followUpChoices": [
      "Adakan mediasi bersemuka (ST-101)",
      "Kumpulkan bukti neutral (ST-101)",
      "Berundur daripada pertikaian (ST-101)"
    ],
    "complication": "seorang saksi menarik balik kenyataan awal",
    "followUpScene": "Ketika isu \"penganjur acara menyalahkan sukarelawan atas kelewatan\" diteruskan, seorang saksi menarik balik kenyataan awal. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Adakan mediasi bersemuka. Walaupun seorang saksi menarik balik kenyataan awal, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Kumpulkan bukti neutral. Disebabkan seorang saksi menarik balik kenyataan awal, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Berundur daripada pertikaian. Apabila seorang saksi menarik balik kenyataan awal, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-102",
    "kind": "family",
    "title": "Keluarga mahu menyambut kepulangan ahli keluarga",
    "description": "Keluarga mahu menyambut kepulangan ahli keluarga. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu menyusun keperluan keluarga",
      "Tanya jadual dan tanggungjawab",
      "Tolak dengan alasan yang jelas"
    ],
    "minTrust": 16,
    "weight": 3,
    "contextIndex": 8,
    "followUpChoices": [
      "Agihkan tanggungjawab keluarga (ST-102)",
      "Semak kemampuan dan masa (ST-102)",
      "Beri keputusan tidak terlibat (ST-102)"
    ],
    "complication": "rancangan berubah selepas mendapat berita baharu",
    "followUpScene": "Ketika isu \"keluarga mahu menyambut kepulangan ahli keluarga\" diteruskan, rancangan berubah selepas mendapat berita baharu. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Agihkan tanggungjawab keluarga. Walaupun rancangan berubah selepas mendapat berita baharu, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak kemampuan dan masa. Disebabkan rancangan berubah selepas mendapat berita baharu, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Beri keputusan tidak terlibat. Apabila rancangan berubah selepas mendapat berita baharu, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-103",
    "kind": "civic",
    "title": "Komuniti mahu menilai akses kerusi roda",
    "description": "Komuniti mahu menilai akses kerusi roda. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Sertai perbincangan dan beri cadangan",
      "Minta dokumen isu terlebih dahulu",
      "Tidak sertai forum kali ini"
    ],
    "minTrust": 26,
    "weight": 3,
    "contextIndex": 8,
    "followUpChoices": [
      "Sediakan cadangan komuniti (ST-103)",
      "Sahkan prosedur pihak berkuasa (ST-103)",
      "Serahkan urusan kepada wakil (ST-103)"
    ],
    "complication": "perbincangan memerlukan moderator berkecuali",
    "followUpScene": "Ketika isu \"komuniti mahu menilai akses kerusi roda\" diteruskan, perbincangan memerlukan moderator berkecuali. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sediakan cadangan komuniti. Walaupun perbincangan memerlukan moderator berkecuali, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Sahkan prosedur pihak berkuasa. Disebabkan perbincangan memerlukan moderator berkecuali, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Serahkan urusan kepada wakil. Apabila perbincangan memerlukan moderator berkecuali, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-104",
    "kind": "health",
    "title": "Kenalan mahu berkongsi resipi makanan seimbang",
    "description": "Kenalan mahu berkongsi resipi makanan seimbang. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Dengar dan galakkan sokongan sesuai",
      "Cadangkan berbincang kemudian",
      "Hormati privasi dan tidak terlibat"
    ],
    "minTrust": 21,
    "weight": 3,
    "contextIndex": 8,
    "followUpChoices": [
      "Rancang sokongan yang selamat (ST-104)",
      "Tanya keperluan dan batasan (ST-104)",
      "Hormati privasi kenalan (ST-104)"
    ],
    "complication": "isu pengangkutan menyukarkan lawatan yang dirancang",
    "followUpScene": "Ketika isu \"kenalan mahu berkongsi resipi makanan seimbang\" diteruskan, isu pengangkutan menyukarkan lawatan yang dirancang. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Rancang sokongan yang selamat. Walaupun isu pengangkutan menyukarkan lawatan yang dirancang, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Tanya keperluan dan batasan. Disebabkan isu pengangkutan menyukarkan lawatan yang dirancang, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Hormati privasi kenalan. Apabila isu pengangkutan menyukarkan lawatan yang dirancang, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-105",
    "kind": "travel",
    "title": "Rakan mahu melawat pasar malam di bandar berdekatan",
    "description": "Rakan mahu melawat pasar malam di bandar berdekatan. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu susun jadual dan bajet",
      "Semak pengangkutan dan cuaca dahulu",
      "Tidak ikut perjalanan ini"
    ],
    "minTrust": 24,
    "weight": 3,
    "contextIndex": 8,
    "followUpChoices": [
      "Sahkan jadual perjalanan (ST-105)",
      "Periksa bajet dan pengangkutan (ST-105)",
      "Batalkan penyertaan (ST-105)"
    ],
    "complication": "masa pulang bertembung dengan komitmen penting",
    "followUpScene": "Ketika isu \"rakan mahu melawat pasar malam di bandar berdekatan\" diteruskan, masa pulang bertembung dengan komitmen penting. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sahkan jadual perjalanan. Walaupun masa pulang bertembung dengan komitmen penting, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Periksa bajet dan pengangkutan. Disebabkan masa pulang bertembung dengan komitmen penting, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Batalkan penyertaan. Apabila masa pulang bertembung dengan komitmen penting, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-106",
    "kind": "reputation",
    "title": "Rakan menasihatkan agar tidak membalas provokasi terbuka",
    "description": "Rakan menasihatkan agar tidak membalas provokasi terbuka. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Semak sumber sebelum memberi penjelasan",
      "Minta masa mengesahkan maklumat",
      "Tidak mengulas khabar yang belum sah"
    ],
    "minTrust": 31,
    "weight": 3,
    "contextIndex": 8,
    "followUpChoices": [
      "Betulkan maklumat dengan bukti (ST-106)",
      "Sahkan sumber sebelum bertindak (ST-106)",
      "Elakkan menyebar cerita (ST-106)"
    ],
    "complication": "tindakan terburu-buru berisiko memburukkan keadaan",
    "followUpScene": "Ketika isu \"rakan menasihatkan agar tidak membalas provokasi terbuka\" diteruskan, tindakan terburu-buru berisiko memburukkan keadaan. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Betulkan maklumat dengan bukti. Walaupun tindakan terburu-buru berisiko memburukkan keadaan, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Sahkan sumber sebelum bertindak. Disebabkan tindakan terburu-buru berisiko memburukkan keadaan, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Elakkan menyebar cerita. Apabila tindakan terburu-buru berisiko memburukkan keadaan, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-107",
    "kind": "education",
    "title": "Kenalan mahu mengikuti kelas kemahiran tangan",
    "description": "Kenalan mahu mengikuti kelas kemahiran tangan. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu cari bahan pembelajaran",
      "Semak jadual dan tahap kursus",
      "Tidak menyertai sesi pembelajaran"
    ],
    "minTrust": 26,
    "weight": 3,
    "contextIndex": 8,
    "followUpChoices": [
      "Atur sesi pembelajaran (ST-107)",
      "Semak kelayakan dan jadual (ST-107)",
      "Tolak penglibatan (ST-107)"
    ],
    "complication": "sijil yang ditawarkan perlu disahkan pengiktirafannya",
    "followUpScene": "Ketika isu \"kenalan mahu mengikuti kelas kemahiran tangan\" diteruskan, sijil yang ditawarkan perlu disahkan pengiktirafannya. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Atur sesi pembelajaran. Walaupun sijil yang ditawarkan perlu disahkan pengiktirafannya, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak kelayakan dan jadual. Disebabkan sijil yang ditawarkan perlu disahkan pengiktirafannya, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Tolak penglibatan. Apabila sijil yang ditawarkan perlu disahkan pengiktirafannya, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-108",
    "kind": "network",
    "title": "Kenalan mahu mengatur perbualan bersama mentor",
    "description": "Kenalan mahu mengatur perbualan bersama mentor. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Setuju diperkenalkan dengan izin semua pihak",
      "Minta profil dan tujuan pertemuan",
      "Tolak pengenalan buat masa ini"
    ],
    "minTrust": 34,
    "weight": 3,
    "contextIndex": 8,
    "followUpChoices": [
      "Sahkan persetujuan kedua-dua pihak (ST-108)",
      "Semak tujuan pengenalan (ST-108)",
      "Batalkan pengenalan (ST-108)"
    ],
    "complication": "peluang kerjasama memerlukan semakan konflik kepentingan",
    "followUpScene": "Ketika isu \"kenalan mahu mengatur perbualan bersama mentor\" diteruskan, peluang kerjasama memerlukan semakan konflik kepentingan. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sahkan persetujuan kedua-dua pihak. Walaupun peluang kerjasama memerlukan semakan konflik kepentingan, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak tujuan pengenalan. Disebabkan peluang kerjasama memerlukan semakan konflik kepentingan, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Batalkan pengenalan. Apabila peluang kerjasama memerlukan semakan konflik kepentingan, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-109",
    "kind": "community",
    "title": "Penganjur pesta kejiranan berdepan pembatalan lokasi",
    "description": "Penganjur pesta kejiranan berdepan pembatalan lokasi. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Tawarkan bantuan dengan skop yang jelas",
      "Minta butiran masa dan tugas",
      "Tolak kerana komitmen lain"
    ],
    "minTrust": 18,
    "weight": 1,
    "contextIndex": 9,
    "followUpChoices": [
      "Tetapkan giliran sukarelawan (ST-109)",
      "Semak keperluan penduduk (ST-109)",
      "Serahkan kepada jawatankuasa (ST-109)"
    ],
    "complication": "wakil penduduk mahu laporan kemajuan yang terbuka",
    "followUpScene": "Ketika isu \"penganjur pesta kejiranan berdepan pembatalan lokasi\" diteruskan, wakil penduduk mahu laporan kemajuan yang terbuka. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Tetapkan giliran sukarelawan. Walaupun wakil penduduk mahu laporan kemajuan yang terbuka, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak keperluan penduduk. Disebabkan wakil penduduk mahu laporan kemajuan yang terbuka, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Serahkan kepada jawatankuasa. Apabila wakil penduduk mahu laporan kemajuan yang terbuka, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-110",
    "kind": "business",
    "title": "Peniaga mahu menutup cawangan yang tidak menguntungkan",
    "description": "Peniaga mahu menutup cawangan yang tidak menguntungkan. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Minta bukti kos dan runding syarat",
      "Semak dokumen sebelum beri jawapan",
      "Tolak tawaran tanpa komitmen"
    ],
    "minTrust": 26,
    "weight": 1,
    "contextIndex": 9,
    "followUpChoices": [
      "Sahkan skop dan dokumen (ST-110)",
      "Audit kos serta risiko (ST-110)",
      "Batalkan rundingan (ST-110)"
    ],
    "complication": "pihak ketiga menawarkan syarat yang lebih baik",
    "followUpScene": "Ketika isu \"peniaga mahu menutup cawangan yang tidak menguntungkan\" diteruskan, pihak ketiga menawarkan syarat yang lebih baik. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sahkan skop dan dokumen. Walaupun pihak ketiga menawarkan syarat yang lebih baik, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Audit kos serta risiko. Disebabkan pihak ketiga menawarkan syarat yang lebih baik, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Batalkan rundingan. Apabila pihak ketiga menawarkan syarat yang lebih baik, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-111",
    "kind": "friendship",
    "title": "Rakan mahu memperbaiki persahabatan yang renggang",
    "description": "Rakan mahu memperbaiki persahabatan yang renggang. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Luangkan masa dan dengar cerita",
      "Cadangkan masa lain untuk berbual",
      "Terangkan batasan dengan sopan"
    ],
    "minTrust": 30,
    "weight": 1,
    "contextIndex": 9,
    "followUpChoices": [
      "Atur pertemuan peribadi (ST-111)",
      "Tanya keselesaan kedua-dua pihak (ST-111)",
      "Berikan ruang kepada kenalan (ST-111)"
    ],
    "complication": "hubungan diuji apabila bantuan tidak dapat diberi segera",
    "followUpScene": "Ketika isu \"rakan mahu memperbaiki persahabatan yang renggang\" diteruskan, hubungan diuji apabila bantuan tidak dapat diberi segera. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Atur pertemuan peribadi. Walaupun hubungan diuji apabila bantuan tidak dapat diberi segera, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Tanya keselesaan kedua-dua pihak. Disebabkan hubungan diuji apabila bantuan tidak dapat diberi segera, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Berikan ruang kepada kenalan. Apabila hubungan diuji apabila bantuan tidak dapat diberi segera, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-112",
    "kind": "career",
    "title": "Pekerja baharu memerlukan panduan budaya pejabat",
    "description": "Pekerja baharu memerlukan panduan budaya pejabat. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu merancang langkah seterusnya",
      "Minta maklumat kerja yang lengkap",
      "Tolak penglibatan secara profesional"
    ],
    "minTrust": 33,
    "weight": 1,
    "contextIndex": 9,
    "followUpChoices": [
      "Susun langkah kerjaya (ST-112)",
      "Semak peluang dan syarat (ST-112)",
      "Tidak menjadi perantara (ST-112)"
    ],
    "complication": "pihak pengurusan menangguhkan keputusan",
    "followUpScene": "Ketika isu \"pekerja baharu memerlukan panduan budaya pejabat\" diteruskan, pihak pengurusan menangguhkan keputusan. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Susun langkah kerjaya. Walaupun pihak pengurusan menangguhkan keputusan, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak peluang dan syarat. Disebabkan pihak pengurusan menangguhkan keputusan, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Tidak menjadi perantara. Apabila pihak pengurusan menangguhkan keputusan, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-113",
    "kind": "conflict",
    "title": "Kenalan meminta maaf selepas pertengkaran terbuka",
    "description": "Kenalan meminta maaf selepas pertengkaran terbuka. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Dengar kedua-dua pihak dan cadang mediasi",
      "Minta masa untuk semak fakta",
      "Enggan masuk campur dalam pertikaian"
    ],
    "minTrust": 38,
    "weight": 1,
    "contextIndex": 9,
    "followUpChoices": [
      "Adakan mediasi bersemuka (ST-113)",
      "Kumpulkan bukti neutral (ST-113)",
      "Berundur daripada pertikaian (ST-113)"
    ],
    "complication": "kedua-dua pihak bersetuju hanya jika ada rekod bertulis",
    "followUpScene": "Ketika isu \"kenalan meminta maaf selepas pertengkaran terbuka\" diteruskan, kedua-dua pihak bersetuju hanya jika ada rekod bertulis. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Adakan mediasi bersemuka. Walaupun kedua-dua pihak bersetuju hanya jika ada rekod bertulis, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Kumpulkan bukti neutral. Disebabkan kedua-dua pihak bersetuju hanya jika ada rekod bertulis, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Berundur daripada pertikaian. Apabila kedua-dua pihak bersetuju hanya jika ada rekod bertulis, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-114",
    "kind": "family",
    "title": "Saudara memerlukan teman untuk urusan penting",
    "description": "Saudara memerlukan teman untuk urusan penting. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu menyusun keperluan keluarga",
      "Tanya jadual dan tanggungjawab",
      "Tolak dengan alasan yang jelas"
    ],
    "minTrust": 18,
    "weight": 1,
    "contextIndex": 9,
    "followUpChoices": [
      "Agihkan tanggungjawab keluarga (ST-114)",
      "Semak kemampuan dan masa (ST-114)",
      "Beri keputusan tidak terlibat (ST-114)"
    ],
    "complication": "keluarga meminta keputusan dibuat tanpa tekanan",
    "followUpScene": "Ketika isu \"saudara memerlukan teman untuk urusan penting\" diteruskan, keluarga meminta keputusan dibuat tanpa tekanan. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Agihkan tanggungjawab keluarga. Walaupun keluarga meminta keputusan dibuat tanpa tekanan, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak kemampuan dan masa. Disebabkan keluarga meminta keputusan dibuat tanpa tekanan, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Beri keputusan tidak terlibat. Apabila keluarga meminta keputusan dibuat tanpa tekanan, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-115",
    "kind": "civic",
    "title": "Penduduk membincangkan penggunaan dewan serbaguna",
    "description": "Penduduk membincangkan penggunaan dewan serbaguna. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Sertai perbincangan dan beri cadangan",
      "Minta dokumen isu terlebih dahulu",
      "Tidak sertai forum kali ini"
    ],
    "minTrust": 28,
    "weight": 1,
    "contextIndex": 9,
    "followUpChoices": [
      "Sediakan cadangan komuniti (ST-115)",
      "Sahkan prosedur pihak berkuasa (ST-115)",
      "Serahkan urusan kepada wakil (ST-115)"
    ],
    "complication": "maklum balas penduduk perlu direkodkan secara telus",
    "followUpScene": "Ketika isu \"penduduk membincangkan penggunaan dewan serbaguna\" diteruskan, maklum balas penduduk perlu direkodkan secara telus. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sediakan cadangan komuniti. Walaupun maklum balas penduduk perlu direkodkan secara telus, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Sahkan prosedur pihak berkuasa. Disebabkan maklum balas penduduk perlu direkodkan secara telus, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Serahkan urusan kepada wakil. Apabila maklum balas penduduk perlu direkodkan secara telus, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-116",
    "kind": "health",
    "title": "Rakan mahu mencari aktiviti rekreasi yang tidak membebankan",
    "description": "Rakan mahu mencari aktiviti rekreasi yang tidak membebankan. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Dengar dan galakkan sokongan sesuai",
      "Cadangkan berbincang kemudian",
      "Hormati privasi dan tidak terlibat"
    ],
    "minTrust": 23,
    "weight": 1,
    "contextIndex": 9,
    "followUpChoices": [
      "Rancang sokongan yang selamat (ST-116)",
      "Tanya keperluan dan batasan (ST-116)",
      "Hormati privasi kenalan (ST-116)"
    ],
    "complication": "kenalan memilih untuk berbincang dengan petugas kesihatan",
    "followUpScene": "Ketika isu \"rakan mahu mencari aktiviti rekreasi yang tidak membebankan\" diteruskan, kenalan memilih untuk berbincang dengan petugas kesihatan. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Rancang sokongan yang selamat. Walaupun kenalan memilih untuk berbincang dengan petugas kesihatan, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Tanya keperluan dan batasan. Disebabkan kenalan memilih untuk berbincang dengan petugas kesihatan, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Hormati privasi kenalan. Apabila kenalan memilih untuk berbincang dengan petugas kesihatan, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-117",
    "kind": "travel",
    "title": "Kumpulan mahu menunda perjalanan kerana cuaca tidak menentu",
    "description": "Kumpulan mahu menunda perjalanan kerana cuaca tidak menentu. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu susun jadual dan bajet",
      "Semak pengangkutan dan cuaca dahulu",
      "Tidak ikut perjalanan ini"
    ],
    "minTrust": 26,
    "weight": 1,
    "contextIndex": 9,
    "followUpChoices": [
      "Sahkan jadual perjalanan (ST-117)",
      "Periksa bajet dan pengangkutan (ST-117)",
      "Batalkan penyertaan (ST-117)"
    ],
    "complication": "laluan alternatif lebih selamat tetapi lebih panjang",
    "followUpScene": "Ketika isu \"kumpulan mahu menunda perjalanan kerana cuaca tidak menentu\" diteruskan, laluan alternatif lebih selamat tetapi lebih panjang. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sahkan jadual perjalanan. Walaupun laluan alternatif lebih selamat tetapi lebih panjang, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Periksa bajet dan pengangkutan. Disebabkan laluan alternatif lebih selamat tetapi lebih panjang, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Batalkan penyertaan. Apabila laluan alternatif lebih selamat tetapi lebih panjang, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-118",
    "kind": "reputation",
    "title": "Kenalan mahu menjadi saksi kepada penjelasan secara tertutup",
    "description": "Kenalan mahu menjadi saksi kepada penjelasan secara tertutup. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Semak sumber sebelum memberi penjelasan",
      "Minta masa mengesahkan maklumat",
      "Tidak mengulas khabar yang belum sah"
    ],
    "minTrust": 33,
    "weight": 1,
    "contextIndex": 9,
    "followUpChoices": [
      "Betulkan maklumat dengan bukti (ST-118)",
      "Sahkan sumber sebelum bertindak (ST-118)",
      "Elakkan menyebar cerita (ST-118)"
    ],
    "complication": "kenalan meminta bukti sebelum nama sesiapa disebut",
    "followUpScene": "Ketika isu \"kenalan mahu menjadi saksi kepada penjelasan secara tertutup\" diteruskan, kenalan meminta bukti sebelum nama sesiapa disebut. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Betulkan maklumat dengan bukti. Walaupun kenalan meminta bukti sebelum nama sesiapa disebut, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Sahkan sumber sebelum bertindak. Disebabkan kenalan meminta bukti sebelum nama sesiapa disebut, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Elakkan menyebar cerita. Apabila kenalan meminta bukti sebelum nama sesiapa disebut, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-119",
    "kind": "education",
    "title": "Mentor mencadangkan program sukarelawan sebagai pengalaman",
    "description": "Mentor mencadangkan program sukarelawan sebagai pengalaman. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Bantu cari bahan pembelajaran",
      "Semak jadual dan tahap kursus",
      "Tidak menyertai sesi pembelajaran"
    ],
    "minTrust": 28,
    "weight": 1,
    "contextIndex": 9,
    "followUpChoices": [
      "Atur sesi pembelajaran (ST-119)",
      "Semak kelayakan dan jadual (ST-119)",
      "Tolak penglibatan (ST-119)"
    ],
    "complication": "keputusan permohonan masih belum diumumkan",
    "followUpScene": "Ketika isu \"mentor mencadangkan program sukarelawan sebagai pengalaman\" diteruskan, keputusan permohonan masih belum diumumkan. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Atur sesi pembelajaran. Walaupun keputusan permohonan masih belum diumumkan, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak kelayakan dan jadual. Disebabkan keputusan permohonan masih belum diumumkan, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Tolak penglibatan. Apabila keputusan permohonan masih belum diumumkan, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  },
  {
    "id": "ST-120",
    "kind": "network",
    "title": "Penganjur mahu memperkenalkan peserta baharu secara beretika",
    "description": "Penganjur mahu memperkenalkan peserta baharu secara beretika. NPC menerangkan keadaan awal dan meminta pendirian player. Keputusan awal menentukan sama ada hubungan ini membawa kepada tindakan, semakan bukti, atau penolakan. Beberapa hari kemudian, perkembangan baharu boleh mengubah rancangan asal.",
    "choices": [
      "Setuju diperkenalkan dengan izin semua pihak",
      "Minta profil dan tujuan pertemuan",
      "Tolak pengenalan buat masa ini"
    ],
    "minTrust": 36,
    "weight": 1,
    "contextIndex": 9,
    "followUpChoices": [
      "Sahkan persetujuan kedua-dua pihak (ST-120)",
      "Semak tujuan pengenalan (ST-120)",
      "Batalkan pengenalan (ST-120)"
    ],
    "complication": "kenalan meminta hubungan itu tidak dijanjikan sebagai pasti",
    "followUpScene": "Ketika isu \"penganjur mahu memperkenalkan peserta baharu secara beretika\" diteruskan, kenalan meminta hubungan itu tidak dijanjikan sebagai pasti. NPC kembali meminta keputusan yang lebih khusus. Player perlu memilih antara menyelesaikan langkah yang dipersetujui, menuntut pengesahan lanjut, atau menarik diri.",
    "followUpResults": [
      "Player memilih: Sahkan persetujuan kedua-dua pihak. Walaupun kenalan meminta hubungan itu tidak dijanjikan sebagai pasti, NPC bersetuju melaksanakan tindakan ini dan merekod siapa yang bertanggungjawab.",
      "Player memilih: Semak tujuan pengenalan. Disebabkan kenalan meminta hubungan itu tidak dijanjikan sebagai pasti, keputusan akhir ditangguh sehingga maklumat boleh disahkan; NPC akan menghubungi semula jika ada perkembangan.",
      "Player memilih: Batalkan pengenalan. Apabila kenalan meminta hubungan itu tidak dijanjikan sebagai pasti, NPC mengambil alih urusan melalui pihak lain; penglibatan player berakhir tanpa janji baharu."
    ]
  }
]);
