// CP20: centralised, save-compatible alerts. No timers or real-world dates.
const validDay=v=>Number.isInteger(v)&&v>=0;
const currency=cents=>'RM '+(cents/100).toLocaleString('ms-MY',{minimumFractionDigits:2,maximumFractionDigits:2});
export function operationalSnapshot(s){
 const claims={};for(const p of s.contractor?.projects||[])for(const c of p.claims||[])claims[c.id]={status:c.status,project:p.name||p.id};
 return {claims};
}
export function scanOperationalAlerts(s,previous=null){
 s.operationalAlerts??={seen:{},queue:[]};const state=s.operationalAlerts;
 if(!state.seen||typeof state.seen!=='object')state.seen={};if(!Array.isArray(state.queue))state.queue=[];
 const emit=(key,title,text,kind='warning')=>{if(state.seen[key])return;state.seen[key]=s.day+1;const item={key,day:s.day,title,text,kind};state.queue.push(item);s.notices.unshift({day:s.day,title,text});};
 // Proactive reminders: player sees expiring obligations before losing access.
 const remind=(key,label,due,destination)=>{
  if(!validDay(due)||due===0||due<s.day)return;
  const left=due-s.day;
  if(![30,7,1,0].includes(left))return;
  emit('advance:'+key+':'+due+':'+left,`${left===0?'HARI TERAKHIR':left+' HARI LAGI'} — ${label}`,`${label} ${left===0?'tamat hari ini':'akan tamat dalam '+left+' hari'}. Pergi ke ${destination} untuk pembaharuan.`,left<=1?'warning':'info');
 };
 for(const b of s.businesses||[]){if(b.closed)continue;
  remind('premises:'+b.id,'Lesen premis '+b.name,b.licenceUntil,'Bisnes');
  if(b.structure==='enterprise')remind('ssm:'+b.id,'Pendaftaran SSM '+b.name,b.registeredUntil,'Bisnes');
 }
 if(s.licence)remind('driving','Lesen memandu',s.licence.expires,'Urusan Kerajaan');
 for(const v of s.vehicles||[]){if(v.repossessed)continue;
  remind('roadtax:'+v.id,'Roadtax '+v.name,v.renew,'Aset');
  remind('insurance:'+v.id,'Insurans '+v.name,v.insuranceExpiry,'Aset');
 }
 for(const d of s.documents||[])remind('document:'+d.id,d.title||d.type||'Dokumen',d.expires??d.expiryDay??d.validUntil,'Dompet Dokumen');
 for(const c of s.complianceAdjudication?.cases||[]){
  if(['closed','withdrawn','paid','court-final'].includes(c.status))continue;
  const deadline=c.status==='judgment'?c.appealUntil:c.deadline;
  remind('case:'+c.id+':'+c.status,'Kes '+c.agency+' · '+c.subject,deadline,'Urusan Kerajaan');
 }
 for(const b of s.businesses||[]){if(b.closed)continue;
  if(Number.isFinite(b.inventory)&&b.inventory<20){const lowKey='stock:'+b.id;const last=state.seen[lowKey];if(!last||s.day+1-last>=7) {delete state.seen[lowKey];emit(lowKey,'Stok hampir habis — '+b.name,`Stok tinggal ${Math.max(0,b.inventory)} unit. Pergi ke Bisnes untuk tambah stok.`);}}
  else delete state.seen['stock:'+b.id];
  for(const [field,label] of [['licenceUntil','Lesen premis'],['registeredUntil','Pendaftaran SSM']]){
   if(field==='registeredUntil'&&b.structure!=='enterprise')continue;
   const due=b[field];if(!validDay(due)||due===0)continue;
   const key='expiry:business:'+b.id+':'+field+':'+due;
   if(s.day>due)emit(key,label+' tamat tempoh — '+b.name,`${label} ${b.name} telah tamat ${s.day-due} hari. Urus pembaharuan segera. Kegagalan mematuhi syarat boleh menyebabkan notis, penalti atau operasi digantung.`);
   if(s.day>due+30){const lateKey='late:'+key;emit(lateKey,'Lebih 30 hari — '+b.name,`${label} tertunggak lebih 30 hari. Risiko tindakan pematuhan. Semak Urusan Kerajaan dan lesen perniagaan.`);}
  }
 }
 if(validDay(s.licence?.expires)&&s.day>s.licence.expires)emit('expiry:driving:'+s.licence.expires,'Lesen memandu tamat tempoh','Lesen memandu telah tamat. Perbaharui di Urusan Kerajaan sebelum memandu.');
 for(const v of s.vehicles||[]){if(v.repossessed)continue;for(const [field,label] of [['insuranceExpiry','Insurans kenderaan'],['renew','Cukai jalan / roadtax']]){
  const due=v[field];if(!validDay(due))continue;
  // Legacy renew is automatically rolled over by the old engine; do not mistake its future date for an expiry.
  if(s.day>due)emit('expiry:vehicle:'+v.id+':'+field+':'+due,label+' tamat — '+v.name,`${label} telah tamat. Semak pembaharuan dalam Aset / Kenderaan.`);
 }}
 for(const d of s.documents||[]){const due=d.expires??d.expiryDay??d.validUntil;if(!validDay(due)||s.day<=due)continue;emit('expiry:document:'+d.id+':'+due,'Dokumen tamat — '+(d.title||d.type||'Dokumen'),`Dokumen ${d.title||d.type||''} telah tamat tempoh. Urus pembaharuan dengan segera.`);}
 if(previous?.claims){for(const p of s.contractor?.projects||[])for(const c of p.claims||[]){const before=previous.claims[c.id];if(before?.status!=='paid'&&c.status==='paid'&&before){emit('claim:paid:'+c.id,'Bayaran tuntutan kontraktor diterima',`${p.name||p.id}: ${currency(c.net)} telah dikreditkan ke akaun syarikat.`, 'success');}}}
 state.queue=state.queue.slice(-60);s.notices=s.notices.slice(0,100);return state.queue;
}
export function takeOperationalAlert(s){const q=s.operationalAlerts?.queue;if(!Array.isArray(q)||!q.length)return null;return q.shift();}
