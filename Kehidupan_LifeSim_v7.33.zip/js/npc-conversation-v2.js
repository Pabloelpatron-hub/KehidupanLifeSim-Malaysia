// Additive offline follow-up resolver. Uses existing message history and NPC state.
// No new save fields and no claims of unrestricted language comprehension.
import {npcAuthorityProfile,npcSocialGraphSnapshot} from './npc-core-v2.js';
import {npcInteractionTimeline} from './npc-unified-interaction-v2.js';
const normalize=t=>String(t||'').toLowerCase().replace(/[^\p{L}\p{N}\s]/gu,' ').replace(/\s+/g,' ').trim();
const trivial=/^(?:ok|okay|baik|ya|yes|hello|hai|hi|terima kasih|thanks|noted|setuju|boleh|👍)[.! ]*$/i;
const meaningful=e=>e&&Number.isInteger(e.day)&&e.day>=0&&['whatsapp','call','face_to_face','story'].includes(e.channel)&&!['missed_call','player_message','legacy_player_message'].includes(e.kind)&&typeof e.text==='string'&&e.text.trim()&&!trivial.test(e.text.trim());
const newest=events=>events.reduce((best,e,i)=>!best||e.day>best.event.day||(e.day===best.event.day&&i>best.index)?{event:e,index:i}:best,null)?.event;

export function npcConversationFollowup(s,id,text){
 const q=normalize(text),history=(s.messages?.[id]||[]).slice(0,-1);
 const recent=history.slice(-8),prior=recent.filter(m=>m.from===id).at(-1)?.text||'';
 const dialogue=normalize(prior),authority=npcAuthorityProfile(s,id),graph=npcSocialGraphSnapshot(s,id);
 const timeline=npcInteractionTimeline(s,id);
 // Date-specific recollection must not silently substitute an older conversation.
 // "Semalam" and "kelmarin" are exact game-day references, not generic follow-ups.
 if(!/^(?:jangan|tak payah|xpayah|usah|dont|do not)\b/.test(q)&&/\b(?:semalam|kelmarin)\b/.test(q)&&/\b(?:bincang|borak|cakap|sembang|cerita|call|telefon|whatsapp|mesej|jumpa|meeting|ingat|pasal)\b/.test(q)){
  const offset=/\bkelmarin\b/.test(q)?2:1;
  const target=Number(s.day)-offset;
  const events=timeline.filter(e=>meaningful(e)&&e.day===target);
  const last=newest(events);
  if(!last)return `Saya tak jumpa rekod perbualan kita pada hari ${target}. Boleh jelaskan yang mana satu?`;
  return `Pada hari ${target}, kita ada bincang: “${String(last.text).replace(/\s+/g,' ').slice(0,110)}”. Awak nak sambung bahagian mana?`;
 }
 // Open story choices take priority over a generic recollection; do not imply resolution.
 const threads=Object.values(s.livingWorld?.storyThreads||{}).filter(t=>t.npcId===id&&t.status==='open');
 if(threads.length&&/^(cerita|kisah|story|hal tadi|pasal tadi|apa jadi|sambung cerita)/.test(q))return 'Tentang perkara yang kita bincangkan tadi, kita perlu selesaikan pilihan dalam peristiwa tersebut dahulu. Saya tak mahu anggap keputusan awak tanpa persetujuan.';
 // Resolve generic follow-ups against the latest real NPC exchange across channels.
 // A missing or future-dated event must never become a fabricated recollection.
 if(!/^(?:jangan|tak payah|xpayah|usah|dont|do not|bukan)\b/.test(q)&&/^(?:sambung|continue|follow up|followup|pasal tadi|tentang tadi|yang tadi|yg tadi|hal tadi|apa kita bincang|apa kita borak)(?:\s|$)/.test(q)){
  const last=newest(timeline.filter(e=>meaningful(e)&&e.day<=s.day));
  if(!last)return 'Saya tak jumpa rekod perbincangan kita sebelum ini. Boleh jelaskan perkara yang awak maksudkan?';
  const channel=last.channel==='face_to_face'?'masa kita berjumpa':last.channel==='call'?'dalam panggilan':last.channel==='story'?'dalam peristiwa itu':'melalui WhatsApp';
  const detail=String(last.text).replace(/\s+/g,' ').slice(0,110);
  return `Kali terakhir kita bincang ${channel} pada hari ${last.day}: “${detail}”. Awak nak sambung bahagian mana?`;
 }
 // Ground cross-channel references in recorded interactions, never invent a meeting.
 if(!/^(?:jangan|tak payah|xpayah|usah|dont|do not|bukan)\b/.test(q)&&/(?:masa|waktu|time|hari)\s+(?:kita\s+)?(?:jumpa|bertemu|meet)|(?:jumpa|bertemu)\s+(?:hari\s+)?(?:tu|tadi|dulu)/.test(q)){
  const meeting=newest(timeline.filter(e=>e&&Number.isInteger(e.day)&&e.day>=0&&e.channel==='face_to_face'&&e.day<=s.day));
  if(!meeting)return 'Saya tak jumpa rekod pertemuan kita sebelum ini. Awak maksudkan pertemuan yang mana?';
  return `Kita ada berjumpa pada hari ${meeting.day}. ${meeting.kind==='chat'?'Kita sempat berbual.':'Kita bincang urusan '+meeting.kind+'.'} Apa yang awak nak sambung?`;
 }
 // Recall actual story events, including outcomes, without inventing resolution.
 if(!/^(?:jangan|tak payah|xpayah|usah|dont|do not|bukan)\b/.test(q)&&/(?:cerita|story|kisah|peristiwa|hal)\s+(?:yang\s+)?(?:hari\s+)?(?:tu|tadi|dulu)|(?:apa\s+jadi|macam\s+mana)\s+(?:dengan\s+)?(?:cerita|story|kisah)/.test(q)){
  const story=newest(timeline.filter(e=>e&&Number.isInteger(e.day)&&e.day>=0&&e.channel==='story'&&e.day<=s.day));
  if(!story)return 'Saya tak jumpa rekod cerita kita sebelum ini. Cerita yang mana awak maksudkan?';
  const title=String(story.text||'perkara itu').slice(0,100);
  return story.kind==='resolve'?`Tentang ${title}, keputusan itu sudah direkodkan pada hari ${story.day}. Awak nak bincang perkara lain yang berkaitan?`:`Kita ada bincang ${title} pada hari ${story.day}. Perkara itu belum semestinya selesai; kita perlu semak statusnya dahulu.`;
 }
 const intro=(s.npcIntroductions||[]).filter(r=>r.from===id||r.to===id).at(-1);
 if(/\b(perkenalan|kenalkan|contact|nombor|number|intro)\b/.test(q)&&intro){
  const other=s.npcs?.[intro.from===id?intro.to:intro.from];
  if(intro.status==='pending')return `Permintaan perkenalan dengan ${other?.name||'kenalan'} masih menunggu jawapan. Saya belum boleh kongsi nombor telefon.`;
  if(intro.status==='accepted')return `${other?.name||'Kenalan'} sudah bersetuju diperkenalkan. Jumpa dia secara langsung untuk minta nombor telefon.`;
  if(intro.status==='declined'||intro.status==='expired')return 'Perkenalan itu tidak diteruskan. Saya tidak boleh berkongsi nombor tanpa persetujuan.';
  if(intro.status==='completed')return 'Perkenalan itu sudah selesai. Kamu boleh hubungi kenalan tersebut melalui telefon.';
 }
 const asksClarification=/^(pengalaman|macam mana|camne|camana|mcmne|mcm mana|yg mana|yang mana|apa maksud|maksud|kenapa|why|how|contoh|contohnya|boleh explain|jelaskan)/.test(q);
 if(asksClarification&&/pengalaman|kerja|jawatan|temu duga|rujukan|vacancy/.test(dialogue))return 'Saya maksudkan pengalaman kerja awak sebelum ini: bidang apa, berapa lama, dan kemahiran apa yang awak ada? Saya tak boleh janjikan jawatan tanpa proses permohonan.';
 if(asksClarification&&/kenalan|kenalkan|perkenalkan|contact/.test(dialogue))return (graph?.outgoing||[]).some(e=>e.kind==='professional'&&e.strength>=20)?'Saya maksudkan kenalan profesional yang saya benar-benar kenal. Awak cari orang dalam bidang apa? Saya perlu pastikan urusannya sesuai dahulu.':'Saya belum ada kenalan yang sesuai untuk urusan itu. Awak cari orang dalam bidang apa sebenarnya?';
 if(asksClarification&&/projek|kontrak|tender/.test(dialogue))return 'Saya maksudkan butiran projek: skop kerja, nilai anggaran, tempoh dan kelayakan syarikat. Sebarang kelulusan mesti ikut proses rasmi.';
 if(/^(tgh|tengah|sedang|you|ko|kau|awak|encik|puan|hang|wyd|watpe|buatpe)/.test(q)&&(/buat\s*apa|watpe|buatpe|wyd/.test(q))){const role=authority?.role||'';return /government|police|banker|legal/.test(role)?'Saya sedang urus kerja sekarang. Ada perkara tertentu yang awak mahu bincangkan?':'Tengah urus hal kerja sikit. Kau pula macam mana hari ni?';}
 return null;
}
