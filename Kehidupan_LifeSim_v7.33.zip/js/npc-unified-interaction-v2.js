// Additive, bounded interaction timeline. No gameplay rewards or NPC identity mutations.
import {ensureWorldCore} from './world-core.js';
const allowed=new Set(['whatsapp','call','face_to_face','story']);
export function npcInteractionTimeline(s,id){
 const w=ensureWorldCore(s);w.npcInteractionTimeline??={};
 return w.npcInteractionTimeline[id]??=[];
}
export function recordNpcInteraction(s,id,{channel,kind='conversation',text='',eventId}={}){
 if(!s.npcs?.[id])throw Error('NPC unknown');
 if(!allowed.has(channel))throw Error('Invalid interaction channel');
 const log=npcInteractionTimeline(s,id);
 if(eventId&&log.some(e=>e.eventId===eventId))return false;
 log.push({eventId:eventId||null,day:s.day,channel,kind,text:String(text).slice(0,240)});
 if(log.length>80)log.splice(0,log.length-80);
 return true;
}
export function npcInteractionSummary(s,id){
 const log=npcInteractionTimeline(s,id);
 return {count:log.length,last:log.at(-1)||null,channels:[...new Set(log.map(e=>e.channel))]};
}
