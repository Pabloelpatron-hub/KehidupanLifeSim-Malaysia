// NPC Living World CP01: additive, offline-first integration foundation.
// This module never owns balances, contracts, gang ranks, or vehicle ownership.
export const WORLD_CORE_VERSION = 1;
export function ensureWorldCore(state) {
  if (!state || typeof state !== 'object') throw Error('World Core requires a game state');
  const w = state.livingWorld ??= {};
  if (w.version != null && w.version > WORLD_CORE_VERSION) throw Error('Unsupported future Living World version');
  w.version = WORLD_CORE_VERSION;
  w.events ??= [];
  w.processedActions ??= {};
  w.npcProfiles ??= {};
  w.commitments ??= [];
  w.lastEventSequence ??= 0;
  return w;
}
export function gameClock(state) {
  return { day: state.day, hour: state.hour, tick: state.day * 24 + state.hour };
}
const allowedTypes = /^[A-Z][A-Z0-9_]{2,79}$/;
export function recordWorldEvent(state, event, actionKey) {
  const w = ensureWorldCore(state);
  if (!event || !allowedTypes.test(event.type)) throw Error('Invalid world event type');
  if (actionKey !== undefined && (typeof actionKey !== 'string' || !actionKey || actionKey.length > 160)) throw Error('Invalid action key');
  if (actionKey && Object.prototype.hasOwnProperty.call(w.processedActions, actionKey)) {
    return { event: w.events.find(e => e.id === w.processedActions[actionKey]) ?? null, duplicate: true };
  }
  const clock = gameClock(state);
  const id = 'LWE-' + String(++w.lastEventSequence).padStart(8, '0');
  const entry = { id, type: event.type, day: clock.day, hour: clock.hour, actorId: event.actorId ?? null, entityId: event.entityId ?? null, payload: structuredClone(event.payload ?? {}) };
  w.events.push(entry);
  if (actionKey) w.processedActions[actionKey] = id;
  return { event: entry, duplicate: false };
}
export function registerNpcProfile(state, npcId, profile) {
  if (typeof npcId !== 'string' || !npcId || !profile || typeof profile !== 'object') throw Error('Invalid NPC profile');
  const w = ensureWorldCore(state);
  const old = w.npcProfiles[npcId];
  if (old?.identityLocked && (profile.fullName !== undefined && profile.fullName !== old.fullName || profile.gender !== undefined && profile.gender !== old.gender || profile.portraitId !== undefined && profile.portraitId !== old.portraitId)) throw Error('Locked NPC identity cannot change');
  w.npcProfiles[npcId] = { ...old, ...structuredClone(profile), npcId };
  return w.npcProfiles[npcId];
}
export function lieutenantTitle(profile) {
  if (Number(profile?.rank) !== 3) return '';
  const identity = String(profile?.identityGroup ?? '').toLowerCase();
  return { malay: 'Ayah', indian: 'Don', chinese: 'Taiko' }[identity] ?? '';
}
export function npcDisplayName(profile) {
  if (!profile) return '';
  const base = String(profile.fullName ?? profile.name ?? '').trim();
  const title = lieutenantTitle(profile);
  if (title) return base.startsWith(title + ' ') ? base : title + ' ' + base;
  return [profile.honorific, base].filter(Boolean).join(' ');
}
export function validateWorldCore(state) {
  const w = ensureWorldCore(state);
  if (!Array.isArray(w.events) || !Array.isArray(w.commitments) || !w.npcProfiles || typeof w.npcProfiles !== 'object' || Array.isArray(w.npcProfiles) || !w.processedActions || typeof w.processedActions !== 'object' || Array.isArray(w.processedActions) || !Number.isSafeInteger(w.lastEventSequence) || w.lastEventSequence < 0) throw Error('Invalid Living World data');
  const ids = new Set();
  for (const e of w.events) {
    if (!e || typeof e.id !== 'string' || ids.has(e.id) || !allowedTypes.test(e.type) || !Number.isInteger(e.day) || !Number.isInteger(e.hour)) throw Error('Invalid Living World event');
    ids.add(e.id);
  }
  for (const id of Object.values(w.processedActions)) if (!ids.has(id)) throw Error('Living World action points to missing event');
  const commitments = new Set();
  for (const c of w.commitments) {
    if (!c || typeof c.id !== 'string' || commitments.has(c.id) || typeof c.npcId !== 'string' || !['open','fulfilled','broken','cancelled'].includes(c.status) || !Number.isSafeInteger(c.createdDay) || (c.resolvedDay != null && !Number.isSafeInteger(c.resolvedDay)) || (c.evidenceEventId != null && !ids.has(c.evidenceEventId))) throw Error('Invalid Living World commitment');
    commitments.add(c.id);
  }
  return w;
}
