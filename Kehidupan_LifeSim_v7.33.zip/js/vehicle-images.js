// Objective 12: local photo registry. All 30 uploaded photos assigned to distinct IDs.
export const PHOTO_PATHS = Object.freeze({
  'cp1-001': 'assets/vehicles/cars/cp1-001.webp',
  'cp1-002': 'assets/vehicles/cars/cp1-002.webp',
  'cp1-003': 'assets/vehicles/cars/cp1-003.webp',
  'cp1-005': 'assets/vehicles/cars/cp1-005.webp',
  'cp1-006': 'assets/vehicles/cars/cp1-006.webp',
  'cp1-007': 'assets/vehicles/cars/cp1-007.webp',
  'cp1-013': 'assets/vehicles/cars/cp1-013.webp',
  'cp1-014': 'assets/vehicles/cars/cp1-014.webp',
  'cp1-015': 'assets/vehicles/cars/cp1-015.webp',
  'cp1-017': 'assets/vehicles/cars/cp1-017.webp',
  'cp1-016': 'assets/vehicles/cars/cp1-016.webp',
  'cp1-020': 'assets/vehicles/cars/cp1-020.webp',
  'cp1-019': 'assets/vehicles/cars/cp1-019.webp',
  'cp1-023': 'assets/vehicles/cars/cp1-023.webp',
  'cp1-057': 'assets/vehicles/cars/cp1-057.webp',
  'cp1-059': 'assets/vehicles/cars/cp1-059.webp',
  'cp1-058': 'assets/vehicles/cars/cp1-058.webp',
  'cp1-060': 'assets/vehicles/cars/cp1-060.webp',
  'cp1-079': 'assets/vehicles/cars/cp1-079.webp',
  'cp1-080': 'assets/vehicles/cars/cp1-080.webp',
  'cp1-081': 'assets/vehicles/cars/cp1-081.webp',
  'cp1-082': 'assets/vehicles/cars/cp1-082.webp',
  'cp1-086': 'assets/vehicles/cars/cp1-086.webp',
  'cp1-087': 'assets/vehicles/cars/cp1-087.webp',
  'cp1-146': 'assets/vehicles/cars/cp1-146.webp',
  'cp1-088': 'assets/vehicles/cars/cp1-088.webp',
  'cp1-089': 'assets/vehicles/cars/cp1-089.webp',
  'cp1-091': 'assets/vehicles/cars/cp1-091.webp',
  'cp1-093': 'assets/vehicles/cars/cp1-093.webp',
  'cp1-094': 'assets/vehicles/cars/cp1-094.webp',
});
export function vehicleImagePath(vehicleId){
  if(typeof vehicleId!=='string'||!Object.prototype.hasOwnProperty.call(PHOTO_PATHS,vehicleId))return null;
  return PHOTO_PATHS[vehicleId];
}
export function vehicleImageMarkup(vehicleId,alt,placeholderMarkup){
  const path=vehicleImagePath(vehicleId);
  if(!path)return placeholderMarkup;
  const safeAlt=String(alt||'Kenderaan').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  return `<div class="vehicle-photo-frame"><img src="${path}" alt="${safeAlt}" loading="lazy" decoding="async" onerror="this.hidden=true;this.parentElement.classList.add('vehicle-photo-error')"><span class="vehicle-photo-fallback">Foto belum tersedia</span></div>`;
}
export function catalogVehicleId(owned,catalog){
  const direct=[owned?.vehicleId,owned?.catalogId,owned?.modelId,owned?.sourceVehicleId,owned?.id];
  for(const id of direct)if(catalog.some(v=>v.id===id))return id;
  const name=String(owned?.name||'').trim().toLowerCase(),year=Number(owned?.year);
  if(!name)return null;
  const matches=catalog.filter(v=>v.name.toLowerCase()===name&&Number(v.year)===year);
  return matches.length===1?matches[0].id:null;
}
