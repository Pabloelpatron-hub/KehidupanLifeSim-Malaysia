import {complianceFindings} from './compliance-penalties.js';
export function inspectionCaseSummary(s){return (s.complianceInspections?.cases||[]).filter(c=>c&&typeof c.id==='string').slice(-100).reverse();}
export function reviewInspectionCase(s,id){
 const c=(s.complianceInspections?.cases||[]).find(x=>x.id===id);
 if(!c)throw Error('Rekod pemeriksaan tidak dijumpai.');
 if(c.status==='resolved')return {resolved:true,message:'Kes ini sudah diselesaikan.'};
 const outstanding=complianceFindings(s).some(f=>f.rule===c.rule&&f.name===c.subject&&(!c.business||f.business===c.business));
 c.reviewedDay=s.day;c.reviewCount=(c.reviewCount||0)+1;
 if(outstanding)return {resolved:false,message:`${c.subject}: dokumen masih tidak sah. Selesaikan pembaharuan dahulu. Tiada kompaun atau sabitan automatik.`};
 c.status='resolved';c.resolvedDay=s.day;
 return {resolved:true,message:`${c.subject}: rekod disahkan telah dikemas kini. Kes pemeriksaan ditutup.`};
}
