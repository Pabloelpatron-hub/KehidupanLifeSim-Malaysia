// CP13 Phase 4: deterministic offline NPC replies. Pure, save-schema compatible.
const has=(q,words)=>words.some(w=>q.includes(w));
const norm=x=>String(x??'').toLocaleLowerCase('ms-MY');
const memories=n=>Array.isArray(n.memory)?n.memory.slice(-20):[];
export function cp13Reply(s,n,text){
 const q=norm(text).trim(),trust=Number(n.trust)||0,friend=Number(n.friendship)||0;
 const job=norm(n.occupation),cls=norm(n.primaryClass),person=norm(n.personality);
 const prefix=person==='reserved'?'Saya jawab ringkas ya. ':person==='professional'?'Baik, saya jelaskan. ':'';
 const familiar=memories(n).some(m=>m.type==='message');
 const pastMeet=memories(n).some(m=>['date','meeting','appointment'].includes(m.type));
 if(has(q,['polis','pdrm','laporan polis','balai','siasatan'])){
  if(has(job,['police','polis','inspektor'])||cls.includes('police'))return prefix+'Untuk urusan rasmi, hadir ke balai atau saluran PDRM. Saya tak boleh semak atau ubah rekod secara peribadi.';
  return 'Hal polis lebih baik ikut saluran rasmi. Saya tak mahu beri maklumat yang belum pasti.';
 }
 if(has(q,['racket','kongsi gelap','gangster','mafia','underworld'])){
  if(trust<35)return 'Saya tak selesa bincang hal begitu melalui mesej.';
  return 'Perkara sensitif jangan dibincang sembarangan. Kalau ada urusan yang sah, jelaskan tujuan dahulu.';
 }
 if(has(q,['kontrak','tender','projek','construction','bina'])){
  if(has(job,['contract','construction','engineer','contractor'])||has(cls,['contractor','business_owner']))return trust>=25?prefix+'Boleh bincang skop, bajet dan kelayakan kontraktor. Hantar butiran projek; keputusan tetap bergantung pada semakan.':'Saya perlu tahu pengalaman dan pendaftaran perniagaan awak dahulu.';
  return 'Saya bukan orang yang urus tender, tapi awak boleh semak syarat dan dokumen projek dahulu.';
 }
 if(has(q,['bank','pinjaman bank','loan kereta','loan rumah','credit','ctos','ccris'])){
  if(has(job,['bank','finance','account','investment'])||has(cls,['banker','investor']))return prefix+'Kelayakan bergantung pada pendapatan, komitmen dan rekod kredit. Permohonan perlu dibuat melalui saluran bank.';
  return 'Cuba semak kelayakan terus dengan bank. Jangan serah dokumen peribadi kepada orang tengah yang tak dikenali.';
 }
 if(has(q,['sakit','demam','ubat','hospital','doktor','klinik'])){
  if(has(job,['doctor','medical','nurse'])||cls.includes('professional'))return 'Saya boleh terangkan secara umum, tetapi pemeriksaan klinik diperlukan untuk diagnosis.';
  return 'Kalau tak sihat, baik dapatkan pemeriksaan di klinik.';
 }
 if(has(q,['kenalkan','contact','network','orang dalam','kabel'])){
  if(trust<20)return 'Kita kenal lebih rapat dulu sebelum saya buat pengenalan.';
  return n.connections?.length?'Saya ada beberapa kenalan, tapi kena tahu urusan dan persetujuan mereka dulu.':'Saya boleh cuba bantu, tapi belum ada orang yang sesuai untuk diperkenalkan.';
 }
 if(has(q,['rahsia','percaya','trust','hubungan kita']))return trust>=45?'Saya hargai kepercayaan awak. Kita jaga hubungan baik ini.':'Kepercayaan ambil masa. Kita kenal perlahan-lahan dulu.';
 if(has(q,['terima kasih','thanks','thank you']))return friend>=25?'Sama-sama. Kalau ada apa-apa, boleh tanya lagi.':'Sama-sama, semoga urusan dipermudah.';
 if(has(q,['lama tak jumpa','lama tak berjumpa','ingat lagi','ingat saya']))return familiar?(pastMeet?'Mestilah ingat. Kita pernah berjumpa sebelum ini. Apa perkembangan terbaru?':'Ya, kita pernah berhubung. Apa cerita sekarang?'):'Maaf, kita belum banyak berurusan. Boleh perkenalkan diri semula?';
 if(has(q,['apa khabar','khabar','salam','hello','hai']))return `${prefix}${familiar?'Terima kasih sebab mesej lagi. ':'Hai, salam kenal. '}${friend>=30?'Seronok dapat dengar khabar awak.':'Saya okay, kerja agak sibuk.'}`;
 return null;
}
