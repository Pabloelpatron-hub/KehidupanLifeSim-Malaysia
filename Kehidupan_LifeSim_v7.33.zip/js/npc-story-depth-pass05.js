// Pass 05: category-specific story consequences; no monetary or legal side effects.
import {ensureStabilized,playerRelationship} from './npc-stabilization-cp11.js';
import {remember,living} from './npc-living-cp06-10.js';
import {AUTHORED_STORIES} from './npc-story-authored-120.js';
const STORY_TEMPLATES_BY_ID=Object.fromEntries(AUTHORED_STORIES.map(t=>[t.id,t]));
const clamp=n=>Math.max(0,Math.min(100,Math.round(Number(n)||0)));
export const STORY_OUTCOMES=Object.freeze({
 community:['NPC mengajak player membantu komuniti','NPC mengatur pertemuan penduduk','NPC menghormati keputusan player'],
 business:['NPC membuka ruang perbincangan perniagaan','NPC meminta dokumen sebelum berbincang','NPC menangguhkan urusan komersial'],
 friendship:['NPC merancang aktiviti bersama','NPC meminta ruang untuk berfikir','NPC menghargai penolakan yang sopan'],
 career:['NPC berkongsi peluang latihan','NPC mencadangkan sesi nasihat kerjaya','NPC mencari calon lain'],
 conflict:['NPC bersedia menyelesaikan salah faham','NPC meminta pertemuan susulan','Ketegangan belum dapat diselesaikan'],
 family:['NPC menjemput player ke acara keluarga','NPC akan mengesahkan tarikh kemudian','NPC menghormati komitmen keluarga player'],
 civic:['NPC mengajak player menghadiri forum','NPC menghantar ringkasan isu tempatan','NPC meneruskan forum tanpa player'],
 health:['NPC berkongsi pengalaman penjagaan diri','NPC menangguhkan perbualan peribadi','NPC tidak meneruskan topik sensitif'],
 travel:['NPC merancang perjalanan berkumpulan','NPC menyemak jadual perjalanan','NPC mencari rakan perjalanan lain'],
 reputation:['NPC menjelaskan khabar angin','NPC meminta masa untuk menyemak cerita','NPC tidak menyebarkan maklumat lanjut'],
 education:['NPC berkongsi peluang pembelajaran','NPC mencadangkan kursus alternatif','NPC tidak membuat pendaftaran'],
 network:['NPC mempertimbangkan pengenalan profesional','NPC meminta persetujuan kenalan dahulu','NPC tidak membuat pengenalan']
});
export function applyStoryDepth(s,thread){
 if(!thread?.id||!['resolved','declined','expired'].includes(thread.status))return null;
 const st=ensureStabilized(s);st.storyDetails??={};
 if(st.storyDetails[thread.id])return structuredClone(st.storyDetails[thread.id]);
 const template=STORY_TEMPLATES_BY_ID[thread.templateId];
 const index=thread.status==='expired'?2:thread.choice===0?0:thread.choice===1?1:2;
 const subject=template?.title||thread.title||'perkara tersebut';
 const npc=s.npcs?.[thread.npcId];
 const name=npc?.name||'Kenalan';
 const actions=[
  `${name} menerima persetujuan player untuk menangani isu: ${subject}. Mereka menetapkan langkah praktikal dan bersetuju menyemak kemajuan.`,
  `${name} menerima permintaan player untuk meneliti maklumat sebelum memutuskan isu: ${subject}. Bukti dan jadual perlu disahkan dahulu.`,
  `${name} meneruskan urusan tanpa penglibatan player berkaitan: ${subject}. Hubungan mereka kekal dipengaruhi cara penolakan disampaikan.`
 ];
 const detail={id:thread.id,templateId:thread.templateId,kind:thread.kind,day:s.day,status:thread.status,choice:thread.choice??null,summary:`${(STORY_OUTCOMES[thread.kind]||STORY_OUTCOMES.community)[index]}. ${actions[index]}`,followUpDay:index===2?null:s.day+(index===0?2:3),followUpStatus:index===2?'none':'pending',followUpText:index===0?template?.followUpScene||`Susulan: ${name} membawa perkembangan baharu tentang ${subject}.`:`${template?.followUpScene||`Susulan: ${name} mengumpul maklumat tentang ${subject}.`}`,followUpChoices:template?.followUpChoices||['Teruskan komitmen','Minta semakan lanjut','Tarik diri'],followUpChoice:null,followUpResult:null};
 st.storyDetails[thread.id]=detail;
 if(npc){
  const shifts={conflict:[2,0,-3],friendship:[4,1,-1],business:[2,0,-1],family:[3,1,0],network:[2,0,-1]};
  const change=(shifts[thread.kind]||[2,0,-1])[index];
  npc.friendship=clamp((npc.friendship||0)+change);
  remember(s,thread.npcId,{type:'observation',subject:'player',source:'direct',text:detail.summary});
 }
 return structuredClone(detail);
}

// Playable second scene; no automatic financial, licensing, legal or gang reward.
export function resolveStoryFollowUp(s,threadId,choice){
 if(![0,1,2].includes(choice))throw Error('Pilihan susulan tidak sah');
 const st=ensureStabilized(s),detail=st.storyDetails?.[threadId];
 if(!detail||detail.followUpStatus!=='pending')throw Error('Tiada susulan aktif');
 if(s.day<detail.followUpDay)throw Error('Susulan belum tiba');
 const w=living(s),thread=w.storyThreads?.[threadId];
 const template=STORY_TEMPLATES_BY_ID[detail.templateId];
 const label=template?.title||'isu tersebut';
 const paths=template?.followUpChoices||['Sahkan tindakan untuk isu ini','Minta semakan fakta tambahan','Hentikan penglibatan'];
 const results=[`Keputusan: ${paths[0]}. ${label}. NPC merekod persetujuan dan melaksanakan langkah susulan yang dipersetujui.`,`Keputusan: ${paths[1]}. ${label}. NPC menangguhkan tindakan sehingga maklumat yang diperlukan tersedia.`,`Keputusan: ${paths[2]}. ${label}. NPC meneruskan urusan melalui saluran lain tanpa komitmen player.`];
 detail.followUpChoice=choice;detail.followUpResult=template?.followUpResults?.[choice]||results[choice];detail.followUpStatus='completed';detail.followUpResolvedDay=s.day;
 if(w?.storyLog)w.storyLog.push({day:s.day,type:'follow-up',threadId,npcId:thread?.npcId,choice});
 const npcId=thread?.npcId;if(npcId&&s.npcs?.[npcId]){s.npcs[npcId].friendship=clamp((s.npcs[npcId].friendship||0)+[2,0,-1][choice]);remember(s,npcId,{type:'observation',subject:'player',source:'direct',text:detail.followUpResult.slice(0,320)});}
 return structuredClone(detail);
}
