import {complianceFindings,COMPLIANCE_RULES} from './compliance-penalties.js';
const safeDay=n=>Number.isInteger(n)&&n>=0;
export function ensureEnforcement(s){
 s.enforcementWorkflow??={cases:[],seen:{}};
 const w=s.enforcementWorkflow;
 if(!Array.isArray(w.cases))w.cases=[];
 if(!w.seen||typeof w.seen!=='object'||Array.isArray(w.seen))w.seen={};
 s.operationalAlerts??={seen:{},queue:[]};
 if(!Array.isArray(s.operationalAlerts.queue))s.operationalAlerts.queue=[];
 s.notices??=[];
 return w;
}
function alert(s,key,title,text){const w=ensureEnforcement(s);if(w.seen[key])return;w.seen[key]=s.day+1;
 s.operationalAlerts.queue.push({key:'enforcement:'+key,day:s.day,title,text,kind:'warning'});
 s.notices.unshift({day:s.day,title,text});
 s.operationalAlerts.queue=s.operationalAlerts.queue.slice(-80);s.notices=s.notices.slice(0,100);
}
export function scanEnforcementWorkflow(s){const w=ensureEnforcement(s),findings=complianceFindings(s);
 for(const f of findings){
  const rule=COMPLIANCE_RULES[f.rule];if(!rule)continue;
  // Conditional offences (driving/using vehicle, conducting construction) are NOT presumed from an expiry date.
  if(f.conditional){alert(s,'conditional:'+f.key,`AMARAN ${rule.agency} — ${f.name}`,`Dokumen tidak sah. Jangan jalankan aktiviti yang memerlukan dokumen ini. Pemeriksaan dan kesalahan hanya boleh berlaku jika aktiviti berkenaan benar-benar dilakukan.`);continue;}
  if(f.days<=30)continue;
  const key='case:'+f.key;
  let c=w.cases.find(x=>x.key===key);
  if(!c){c={id:key,key,rule:f.rule,agency:rule.agency,subject:f.name,business:f.business||null,openedDay:s.day,deadline:s.day+7,status:'notice',events:[{day:s.day,type:'notice'}],fineRM:0};w.cases.push(c);
   alert(s,key+':new',`NOTIS PEMATUHAN — ${rule.agency}`,`${f.name}: tertunggak ${f.days} hari. Urus pembaharuan sebelum Hari ${c.deadline+1}. Semak rekod kes dalam Urusan Kerajaan.`);
  }
 }
 for(const c of w.cases){if(c.status==='resolved')continue;
  const active=findings.some(f=>f.rule===c.rule&&f.name===c.subject&&(!c.business||f.business===c.business));
  if(!active){c.status='resolved';c.resolvedDay=s.day;c.events.push({day:s.day,type:'resolved'});alert(s,c.id+':resolved','KES PEMATUHAN SELESAI',`${c.agency}: ${c.subject} telah diperbaharui; kes ditutup tanpa denda automatik.`);continue;}
  if(c.status==='notice'&&s.day>c.deadline){c.status='referred';c.referredDay=s.day;c.events.push({day:s.day,type:'referred'});alert(s,c.id+':referred',`RUJUKAN PENGUATKUASAAN — ${c.agency}`,`${c.subject}: notis tamat tanpa pembetulan. Status dirujuk untuk semakan. Ini bukan keputusan mahkamah atau kompaun automatik.`);}
 }
 w.cases=w.cases.slice(-200);return w.cases;
}
export function reviewEnforcement(s,id,mode='review'){
 const w=ensureEnforcement(s),c=w.cases.find(x=>x.id===id);if(!c)throw Error('Kes tidak dijumpai');
 if(c.status==='resolved')return 'Kes sudah selesai.';
 if(mode==='appeal'){
  if(c.status==='under-review')return 'Permohonan semakan masih dalam proses.';
  c.status='under-review';c.reviewDay=s.day;c.events.push({day:s.day,type:'review-request'});
  alert(s,c.id+':appeal','PERMOHONAN SEMAKAN DIREKODKAN',`${c.agency}: ${c.subject}. Permohonan semakan bukan pembatalan kes; pembaharuan masih diperlukan.`);
  return 'Permohonan semakan direkodkan. Status pematuhan masih perlu dibetulkan.';
 }
 const outstanding=complianceFindings(s).some(f=>f.rule===c.rule&&f.name===c.subject&&(!c.business||f.business===c.business));
 if(outstanding)return 'Dokumen masih tamat tempoh. Perbaharui dokumen dahulu.';
 c.status='resolved';c.resolvedDay=s.day;c.events.push({day:s.day,type:'resolved'});
 return 'Kes ditutup selepas pengesahan pembaharuan.';
}
export function enforcementSummary(s){return (s.enforcementWorkflow?.cases||[]).slice(-100).reverse();}
