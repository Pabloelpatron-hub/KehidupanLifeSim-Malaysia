const dictionary=`Overview|Ringkasan
My life|Kehidupan
Career & education|Kerjaya & pendidikan
Explore Malaysia|Teroka Malaysia
Phone & contacts|Telefon & kenalan
My businesses|Bisnes saya
Banking|Perbankan
Finance & credit|Kewangan & kredit
Property & vehicles|Hartanah & kenderaan
Family & relationships|Keluarga & hubungan
Health & wellbeing|Kesihatan diri
Government services|Urusan kerajaan
The economy|Ekonomi
Document wallet|Dompet dokumen
Settings & saves|Tetapan & simpanan
Investments|Pelaburan
YOUR WORLD|DUNIA ANDA
BUILD YOUR FUTURE|BINA MASA DEPAN
LIFE ADMIN|URUSAN HARIAN
MALAYSIAN LIFE SIMULATOR|SIMULASI KEHIDUPAN MALAYSIA
One day. Endless possibilities.|Satu hari. Pelbagai kemungkinan.
Your world|Dunia anda
Next day|Hari seterusnya
Save game|Simpan game
Open navigation|Buka menu
YOUR LIFE, YOUR WAY|HIDUP ANDA, PILIHAN ANDA
ONE DAY AT A TIME · A NEW CHAPTER|SEPULUH TINDAKAN · SATU HARI
A little progress, a meaningful connection. Make today yours.|Sikit-sikit, lama-lama jadi cerita. Hari ini, kau tentukan.
A life of your|Hidup ikut
own making.|rentak sendiri.
Find your people. Build something meaningful. See where the everyday takes you.|Cari geng lepak. Bina masa depan. Setiap pilihan bawa cerita baharu.
Your next chapter awaits|Bab seterusnya menanti
Available money|Wang boleh guna
Personal liquid accounts|Akaun peribadi boleh guna
Net worth|Nilai bersih
Assets less liabilities|Aset ditolak liabiliti
Monthly salary|Gaji bulanan
Explore your next opportunity|Cari peluang seterusnya
People in your circle|Kenalan dalam telefon
Connections worth making|Hubungan yang bermakna
What will you do today?|Apa rancangan hari ini?
Small choices make a life.|Pilihan kecil, kesan besar.
Explore nearby|Teroka sekitar
Find work|Cari kerja
Keep in touch|Hubungi kenalan
Build a business|Bina bisnes
Your financial journey|Perjalanan kewangan
Net worth · recorded weekly|Nilai bersih · direkod setiap minggu
View finances|Lihat kewangan
Your story starts here|Kisah kau bermula di sini
THE BEGINNING|PERMULAAN
ONE DAY AT A TIME|SEHARI DEMI SEHARI
TODAY|HARI INI
Life lately|Cerita kebelakangan ini
The moments that shape your story.|Peristiwa yang membentuk kisah hidup.
Finding my way|Mencari arah
Employed|Bekerja
Health|Kesihatan
Happiness|Kegembiraan
Intelligence|Kecerdasan
Energy|Tenaga
Stress level|Tahap tekanan
Stress|Tekanan
Take a little time for yourself|Luangkan masa untuk diri sendiri
Around your neighbourhood|Sekitar kawasan kau
A familiar place. A new connection.|Tempat biasa. Kenalan baharu.
Good coffee. Unhurried conversations.|Kopi panas. Borak santai.
Explore your city|Teroka bandar
A new chapter|Bab baharu
You have RM 5,000, a rented room and time to build a life. Start with a job application or explore your neighbourhood.|Kau bermula dengan RM5,000 dan sebuah bilik sewa. Cuba mohon kerja atau teroka kejiranan.
Make room for living.|Hidup pun kena seimbang.
Your choices influence health, stress, spending and opportunity.|Pilihan mempengaruhi kesihatan, tekanan, perbelanjaan dan peluang.
PERSONAL LIFE|KEHIDUPAN PERIBADI
Everyday wellbeing|Kesejahteraan harian
Exercise|Bersenam
Rest|Berehat
Wait until…|Tunggu sehingga…
Choose your pace|Pilih gaya hidup
Lifestyle costs are charged each day.|Kos gaya hidup dicaj setiap hari.
Simple meals and careful spending.|Makan ringkas, belanja berhemah.
A balanced everyday routine.|Rutin harian seimbang.
More choice and room to unwind.|Lebih pilihan untuk bersantai.
Premium dining and daily conveniences.|Santapan premium dan kemudahan harian.
frugal|jimat
moderate|sederhana
comfortable|selesa
luxury|mewah
Selected|Dipilih
Choose|Pilih
A different place, a different life|Tempat baharu, kehidupan baharu
Move cities to change costs, job markets and the people you meet.|Berpindah mengubah kos, peluang kerja dan kenalan.
Relocate|Berpindah
Living cost index|Indeks kos hidup
Salary index|Indeks gaji
Build your working life.|Bina kerjaya anda.
A first opportunity, a new skill, a step forward.|Peluang pertama, kemahiran baharu, langkah ke hadapan.
CAREER & EDUCATION|KERJAYA & PENDIDIKAN
Your current role|Jawatan semasa
Gross monthly|Gaji kasar bulanan
Contribution estimates deducted|Anggaran caruman ditolak
Tenure|Tempoh bekerja
Daily salary accrual|Gaji terakru harian
Performance|Prestasi
Make an extra effort|Usaha tambahan
Resign|Letak jawatan
You are not currently employed. Apply below and check back in three days.|Belum bekerja. Mohon di bawah dan semak semula dalam tiga hari.
Invest in yourself|Tingkatkan kelayakan
Qualifications unlock career options.|Kelayakan membuka pilihan kerjaya.
Studying part time|Belajar separuh masa
Expected completion|Jangkaan tamat
Enrol in study|Daftar pengajian
Education durations, fees and progression are game assumptions. Not real course offers.|Tempoh, yuran dan kemajuan pendidikan ialah andaian game.
An opportunity is waiting|Peluang sedang menanti
Accept offer|Terima tawaran
Opportunities in|Peluang di
Applications include an eligibility check and a delayed hiring decision.|Kelayakan diperiksa; keputusan pengambilan memerlukan masa.
Apply|Mohon
Application history|Sejarah permohonan
Decision date|Tarikh keputusan
Role|Jawatan
Full time|Sepenuh masa
Retail assistant|Pembantu kedai
Warehouse coordinator|Penyelaras gudang
Administrative assistant|Pembantu pentadbiran
Junior developer|Pembangun junior
Accounts executive|Eksekutif akaun
Operations manager|Pengurus operasi
Software engineer|Jurutera perisian
Senior consultant|Perunding kanan
Build something of your own.|Bina sesuatu milik sendiri.
Every sale, every expense, every decision matters.|Setiap jualan, perbelanjaan dan keputusan memberi kesan.
BUSINESS & ENTREPRENEURSHIP|BISNES & KEUSAHAWANAN
Start a business|Mulakan bisnes
Business cash|Tunai bisnes
Not personal money|Bukan wang peribadi
Revenue|Hasil
Operating profit|Untung operasi
Book equity|Ekuiti buku
Cost of goods sold|Kos barang dijual
Operating expenses|Perbelanjaan operasi
Accrued obligations|Liabiliti terakru
Equipment at cost|Kos peralatan
Inventory|Inventori
Selling price|Harga jualan
Staff wages|Gaji pekerja
Marketing|Pemasaran
Restock|Tambah stok
Add capital|Tambah modal
Owner drawing|Ambilan pemilik
Set price|Tetapkan harga
Hire staff|Ambil pekerja
Expand branch|Tambah cawangan
Settle obligations|Jelaskan tanggungan
Close business|Tutup bisnes
Money, with a purpose.|Setiap ringgit ada tujuan.
Transfer money|Pindah wang
Open an account|Buka akaun
Open account|Buka akaun
Pay a bill|Bayar bil
Transaction history|Sejarah transaksi
Account holder|Pemilik akaun
Account number|Nombor akaun
Available balance|Baki tersedia
Bank statement|Penyata bank
Download statement|Muat turun penyata
Your accounts|Akaun anda
Everyday account|Akaun harian
Savings account|Akaun simpanan
Current account|Akaun semasa
Opening savings|Simpanan permulaan
Finance & credit|Kewangan & kredit
Total assets|Jumlah aset
Total liabilities|Jumlah liabiliti
Liquid assets|Aset cair
Outstanding debt|Baki hutang
Monthly commitments|Komitmen bulanan
Apply for financing|Mohon pembiayaan
Settle arrears|Jelaskan tunggakan
Property market|Pasaran hartanah
Vehicle market|Pasaran kenderaan
What you own|Milik anda
Review purchase|Semak pembelian
Illustrative listing|Penyenaraian simulasi
A place to call your own.|Aset untuk kehidupan anda.
Ownership brings opportunities, and ongoing commitments.|Pemilikan membuka peluang dan komitmen berterusan.
PROPERTY & VEHICLES|HARTANAH & KENDERAAN
Apartment|Pangsapuri
Terrace house|Rumah teres
Shop lot|Lot kedai
Your portfolio|Portfolio anda
Buy units|Beli unit
Sell units|Jual unit
Fixed deposit|Deposit tetap
Take care of yourself.|Jaga diri baik-baik.
A sustainable life starts with your wellbeing.|Kehidupan seimbang bermula dengan kesihatan diri.
HEALTHCARE|KESIHATAN
How you are doing|Keadaan diri
Find care|Dapatkan rawatan
Public healthcare|Rawatan awam
Private consultation|Rawatan swasta
Attend consultation|Hadir konsultasi
Book private care|Tempah rawatan swasta
Medical protection|Perlindungan perubatan
Take out medical cover|Ambil perlindungan perubatan
Life admin, connected.|Urusan hidup, saling berkait.
Services affect your records, finances and eligibility.|Urusan mempengaruhi rekod, kewangan dan kelayakan anda.
GOVERNMENT SERVICES|URUSAN KERAJAAN
Register a business|Daftar bisnes
Manage records|Urus rekod
File & pay oldest return|Fail dan bayar taksiran terdahulu
Driving entitlement|Kelayakan memandu
No driving entitlement|Belum mempunyai lesen
Training & test|Latihan & ujian
Renew licence|Baharu lesen
Make this life yours.|Simpan kisah, sambung bila lapang.
Keep your progress safe and take it to another device.|Simpan kemajuan dan pindahkan ke peranti lain.
SETTINGS & SAVES|TETAPAN & SIMPANAN
Export backup|Eksport sandaran
Save & continue|Simpan & sambung
Save checkpoint|Simpan checkpoint
Load checkpoint|Muat checkpoint
Export JSON|Eksport JSON
Import JSON|Import JSON
A new beginning|Permulaan baharu
Start a new life|Cipta kehidupan baharu
Simulation calendar|Kalendar simulasi
What this release actually includes|Kandungan versi ini
Known boundaries|Batas versi semasa
Project overview|Gambaran projek
Roadmap|Pelan pembangunan
Known issues|Isu diketahui
Institution references|Rujukan institusi
Checkpoint saved.|Checkpoint disimpan.
Checkpoint loaded.|Checkpoint dimuatkan.
Load saved checkpoint?|Muatkan checkpoint?
Current progress will be replaced by your manual checkpoint.|Kemajuan semasa akan diganti dengan checkpoint manual.
Actions autosave to this browser. A manual checkpoint stays separate until you save over it. Export JSON for durable backups and cross-device play.|Tindakan disimpan automatik dalam browser ini. Checkpoint manual berasingan. Eksport JSON untuk sandaran dan sambung pada peranti lain.
Start a new character in another Malaysian city. Export your current life first if you want to return to it.|Cipta watak baharu di bandar pilihan. Eksport kehidupan semasa dahulu jika mahu menyambungnya kemudian.
365 days per year, fixed February of 28 days. Time only advances when you choose Next day.|365 hari setahun; Februari kekal 28 hari. Tarikh berubah apabila anda pilih Hari seterusnya.
Cancel|Batal
Confirm|Sahkan
Close|Tutup
Continue|Teruskan
Done|Selesai
Updated|Dikemas kini
A new day.|Hari baharu.
Your story begins.|Kisah anda bermula.
You step inside.|Anda melangkah masuk.
Home|Utama
Explore|Teroka
Phone|Telefon
Money|Wang
Document|Dokumen
Category|Kategori
Issued|Dikeluarkan
View|Lihat
Open|Buka
Date|Tarikh
Description|Keterangan
Amount|Jumlah
Reference|Rujukan
Payment|Pembayaran
Personal|Peribadi
Business|Bisnes
Account type|Jenis akaun
From|Dari
To|Ke
Purpose|Tujuan
Contact details not yet shared|Nombor belum dikongsi
Introduce yourself|Perkenalkan diri
Have a conversation|Borak santai
Exchange numbers|Bertukar nombor
Ask for an introduction|Minta diperkenalkan
Ask on a date|Ajak keluar berdua
Apologise|Minta maaf
Discuss marriage|Bincang perkahwinan
Shared moments|Kenangan bersama
Conversation|Perbualan
Your story together is just beginning.|Kisah bersama baru bermula.
Familiarity|Keakraban
Trust|Kepercayaan
Friendship|Persahabatan
Affection|Kasih sayang
Messages|Mesej
Send|Hantar
Call|Panggil
Search|Cari
All places|Semua tempat
All neighbourhoods|Semua kawasan
Food & dining|Makanan & minuman
Nightlife|Hiburan malam
Entertainment|Hiburan
Healthcare|Kesihatan
Shopping|Membeli-belah
Outdoors|Aktiviti luar
Wellness|Kesejahteraan
Favourites|Kegemaran
Recently visited|Lawatan terkini
Enter venue|Masuk premis
Back to places|Kembali ke tempat
Doctor|Doktor
Nurse|Jururawat
Accountant|Akauntan
Contractor|Kontraktor
Property consultant|Perunding hartanah
Restaurant owner|Pemilik restoran
Waiter|Pelayan
Teacher|Guru
Mechanic|Mekanik
Supplier|Pembekal
Business owner|Pemilik bisnes
years old|tahun
 years| tahun
 days| hari
 / month| / bulan
 / mo| / bulan`;
const pairs=dictionary.split('\n').map(x=>x.split('|'));const exact=new Map(pairs),phrases=pairs.filter(([a])=>a.length>=5).sort((a,b)=>b[0].length-a[0].length);
export function t(text){const clean=text.trim();if(exact.has(clean))return text.replace(clean,exact.get(clean));let out=text;for(const[a,b]of phrases)out=out.split(a).join(b);return out.replace(/\bDay /g,'Hari ').replace(/\b[124]h\b/g,'1 tindakan');}
export function localize(root){const walk=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);let n;while(n=walk.nextNode())if(!n.parentElement.closest('script,style,textarea,input,[data-user-text]'))n.textContent=t(n.textContent);for(const el of root.querySelectorAll('[aria-label],[placeholder]'))for(const key of ['aria-label','placeholder'])if(el.hasAttribute(key))el.setAttribute(key,t(el.getAttribute(key)));}
