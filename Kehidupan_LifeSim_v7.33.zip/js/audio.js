// Centralized, gesture-safe Web Audio feedback. No external audio assets required.
let context;
let lastClickAt=0;
const labels={cash:'TRANSAKSI DIREKOD',message:'NOTIFIKASI',siren:'AMARAN',engine:'KENDERAAN',stamp:'REKOD DIKEMAS KINI',crime:'OPERASI',day:'HARI BAHARU',error:'TINDAKAN GAGAL',success:'BERJAYA',click:'PILIHAN'};
export function unlockAudio(){
 try{
  const C=window.AudioContext||window.webkitAudioContext;
  if(!C)return;
  context??=new C();
  if(context.state==='suspended')return context.resume().catch(()=>{});
 }catch(e){console.warn('Audio unavailable',e);}
}
export function feedback(kind='click',settings={enabled:true,volume:.35}){
 const el=document.getElementById('action-feedback');
 if(el&&kind!=='click'){
  el.textContent=labels[kind]||labels.click;el.dataset.kind=kind;
  el.classList.remove('play');void el.offsetWidth;el.classList.add('play');
 }
 if(!settings?.enabled||Number(settings.volume)<=0)return;
 // Avoid stacking click tones when a button also triggers an immediate result.
 if(kind==='click'){lastClickAt=performance.now();}
 try{
  const C=window.AudioContext||window.webkitAudioContext;if(!C)return;
  context??=new C();
  if(context.state==='suspended'){
   context.resume().then(()=>{if(context.state==='running')play(kind,settings);}).catch(e=>console.warn('Audio resume failed',e));
   return;
  }
  play(kind,settings);
 }catch(e){console.warn('Audio feedback failed',e);}
}
function play(kind,settings){
 const time=context.currentTime+.005,volume=Math.max(0,Math.min(1,Number(settings.volume)||0));
 const tone=(hz,delay,duration,type='sine',end=hz,level=.09)=>{
  const o=context.createOscillator(),g=context.createGain();o.type=type;
  o.frequency.setValueAtTime(Math.max(1,hz),time+delay);
  o.frequency.exponentialRampToValueAtTime(Math.max(1,end),time+delay+duration);
  g.gain.setValueAtTime(.0001,time+delay);
  g.gain.exponentialRampToValueAtTime(Math.max(.00011,level*volume),time+delay+.008);
  g.gain.exponentialRampToValueAtTime(.0001,time+delay+duration);
  o.connect(g);g.connect(context.destination);o.start(time+delay);o.stop(time+delay+duration+.015);
 };
 switch(kind){
 case 'cash':[880,1320,1760].forEach((f,i)=>tone(f,i*.065,.14));break;
 case 'message':tone(740,0,.11);tone(990,.12,.19);break;
 case 'siren':tone(440,0,.32,'sine',880);tone(880,.32,.32,'sine',440);break;
 case 'engine':tone(65,0,.38,'sawtooth',155,.045);break;
 case 'stamp':tone(170,0,.13,'triangle',45);break;
 case 'crime':tone(180,0,.18,'triangle',60);break;
 case 'day':tone(330,0,.19);tone(440,.16,.22);break;
 case 'error':tone(180,0,.17,'triangle',110);break;
 case 'success':tone(520,0,.09);tone(780,.09,.15);break;
 default:tone(490,0,.045,'sine',360,.045);
 }
}
