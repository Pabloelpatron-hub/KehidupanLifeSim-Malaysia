// Personal loan income assessment: values are integer sen per month.
// Business turnover, bank balances and illicit proceeds are not personal income.
export function assessPersonalIncome(s){
 const salary=Math.max(0,Number(s.job?.salary)||0);
 const sources=[];let businessIncome=0;
 for(const b of s.businesses||[]){
  if(b.closed||b.suspended||b.complianceHold)continue;
  const age=Math.max(0,(s.day||0)-(Number.isFinite(b.opened)?b.opened:s.day));
  const recent=(b.history||[]).filter(h=>Number.isFinite(h.day)&&h.day>s.day-90&&h.day<=s.day);
  const observedDays=recent.length?Math.max(...recent.map(h=>h.day))-Math.min(...recent.map(h=>h.day))+1:0;
  const net=recent.reduce((n,h)=>n+(Number(h.revenue)||0)-(Number(h.cogs)||0)-(Number(h.expenses)||0),0);
  const assessed=age>=30&&recent.length>=20&&net>0?Math.round(net/Math.max(30,Math.min(90,observedDays))*30*.55):0;
  businessIncome+=assessed;
  sources.push({name:b.name||'Perniagaan',type:'business',age,days:recent.length,net,assessed,reason:assessed?'Keuntungan operasi diskaun 45%':'Perlu sekurang-kurangnya 30 hari operasi dan 20 rekod harian untung positif'});
 }
 const c=s.contractor?.company;
 if(c&&!c.closed){
  const accountId=c.account||c.id;
  const age=Math.max(0,(s.day||0)-(Number.isFinite(c.opened)?c.opened:Number.isFinite(c.registrationDay)?c.registrationDay:s.day));
  const entries=(s.ledger||[]).filter(l=>l.day>s.day-90&&l.day<=s.day&&l.entries?.some(e=>e.account===accountId));
  const revenueCategories=new Set(['progress-claim','retention']);
  const costCategories=new Set(['project-cost','site-crisis','project-materials','project-stock','lad']);
  let net=0,claims=0;
  for(const l of entries){const delta=l.entries.filter(e=>e.account===accountId).reduce((n,e)=>n+(Number(e.amount)||0),0);if(delta>0&&revenueCategories.has(l.category)){net+=delta;claims++;}if(delta<0&&costCategories.has(l.category))net+=delta;}
  // Contractor claims can be lumpy; require at least 30 days of history and paid claims.
  const assessed=age>=30&&claims>0&&net>0?Math.round(net/Math.max(30,Math.min(90,age))*30*.35):0;
  businessIncome+=assessed;
  sources.push({name:c.name||'Kontraktor',type:'contractor',age,days:entries.length,net,assessed,reason:assessed?'Tuntutan dibayar, ditolak kos dan haircut 65%':'Perlu rekod tuntutan dibayar dan kos projek'});
 }
 return {salary,businessIncome,income:salary+businessIncome,sources,selfEmployed:businessIncome>0,tenure:salary>0?(s.job?.tenure||0):Math.max(0,...sources.filter(x=>x.assessed>0).map(x=>x.age))};
}
