// CP11: persistent journal, story-thread index and player-authored notes.
// Narrative metadata only: no economic, police or gang side effects.
import {living} from './npc-living-cp06-10.js';
const copy=x=>structuredClone(x);
const safeText=(v,max)=>typeof v==='string'?v.trim().slice(0,max):'';
export function journal(s){const w=living(s);w.journalCP11??={version:1,notes:{},pins:{},read:{}};return w.journalCP11;}
export function journalEntries(s,{status='all',npcId=null,kind=null,query=''}={}){
 const w=living(s),j=journal(s),q=safeText(query,100).toLocaleLowerCase();
 return Object.values(w.storyThreads||{}).filter(t=>t&&typeof t==='object')
 .filter(t=>status==='all'||t.status===status)
 .filter(t=>!npcId||t.npcId===npcId).filter(t=>!kind||t.kind===kind)
 .map(t=>({id:t.id,npcId:t.npcId,npcName:s.npcs?.[t.npcId]?.name||'Kenalan',title:t.title||'Cerita',description:t.description||'',outcome:w.stabilization?.storyDetails?.[t.id]?.summary||'',followUpDay:w.stabilization?.storyDetails?.[t.id]?.followUpDay??null,followUpStatus:w.stabilization?.storyDetails?.[t.id]?.followUpStatus||'none',followUpText:w.stabilization?.storyDetails?.[t.id]?.followUpText||'',followUpResult:w.stabilization?.storyDetails?.[t.id]?.followUpResult||'',followUpChoices:w.stabilization?.storyDetails?.[t.id]?.followUpChoices||['Teruskan komitmen','Minta semakan lanjut','Tarik diri'],kind:t.kind||'social',status:t.status||'unknown',createdDay:t.createdDay,dueDay:t.dueDay,resolvedDay:t.resolvedDay,choice:t.choice,choices:t.choices||[],note:j.notes[t.id]||'',pinned:!!j.pins[t.id],read:!!j.read[t.id],events:(w.storyLog||[]).filter(e=>e.threadId===t.id).slice(-15)}))
 .filter(e=>!q||[e.title,e.description,e.npcName,e.note,e.kind].some(v=>String(v).toLocaleLowerCase().includes(q)))
 .sort((a,b)=>Number(b.pinned)-Number(a.pinned)||(b.createdDay||0)-(a.createdDay||0)||a.id.localeCompare(b.id)).map(copy);
}
export function journalSummary(s){const entries=journalEntries(s);return {total:entries.length,open:entries.filter(e=>e.status==='open').length,resolved:entries.filter(e=>['resolved','declined'].includes(e.status)).length,expired:entries.filter(e=>e.status==='expired').length,pinned:entries.filter(e=>e.pinned).length};}
export function journalUpdate(s,threadId,{note,pinned,read}={}){const w=living(s),t=w.storyThreads?.[threadId];if(!t)throw Error('Cerita tidak ditemui');const j=journal(s);if(note!==undefined){if(typeof note!=='string'||note.length>500)throw Error('Nota maksimum 500 aksara');if(note.trim())j.notes[threadId]=note.trim();else delete j.notes[threadId];}if(pinned!==undefined){if(typeof pinned!=='boolean')throw Error('Pin tidak sah');if(pinned)j.pins[threadId]=true;else delete j.pins[threadId];}if(read!==undefined){if(typeof read!=='boolean')throw Error('Status baca tidak sah');if(read)j.read[threadId]=true;else delete j.read[threadId];}return journalEntries(s).find(e=>e.id===threadId);}
export function journalTimeline(s,{limit=100}={}){const w=living(s);return (w.storyLog||[]).slice(-Math.max(1,Math.min(300,limit))).reverse().map(e=>({...copy(e),title:w.storyThreads?.[e.threadId]?.title||'Cerita',npcName:s.npcs?.[e.npcId||w.storyThreads?.[e.threadId]?.npcId]?.name||'Kenalan'}));}
