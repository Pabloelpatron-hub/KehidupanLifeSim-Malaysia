// Derived documents: no duplicated persisted certificates or ghost approvals.
export function contractorDocuments(s){const c=s.contractor?.company;if(!c)return [];const docs=[];const add=(id,title,status,day,detail='')=>docs.push({id:'ctdoc-'+id,title,type:'Contractor',status,day:day??s.day,detail,fictional:true});
add('ssm','Sijil Pendaftaran SSM (simulasi)','Aktif',c.registrationDay,c.ssmNumber||'');
add('ppk','Perakuan Pendaftaran Kontraktor (PPK) G'+c.grade,c.license==='active'?'Aktif':c.license==='processing'?'Dalam proses':c.license==='pending-fee'?'Menunggu bayaran':'Belum diluluskan',c.registrationDay,'Kategori '+c.category);
if(c.lastExam)add('exam','Keputusan Ujian Kompetensi CIDB',c.lastExam.passed?'Lulus':'Gagal',c.lastExam.day,c.lastExam.score+'/'+c.lastExam.total);
for(const kind of ['spkk','stb']){const a=c.certificateApplications?.[kind];if(a||c[kind])add(kind,kind.toUpperCase()+' (simulasi)',c[kind]?'Aktif':a?.status==='processing'?'Dalam proses':a?.status||'Belum diluluskan',a?.submitted||s.day);}
if(c.bumiputeraDeclared!==undefined)add('bumi','Deklarasi status Bumiputera (simulasi)',c.bumiputeraDeclared?'Diisytiharkan':'Tidak diisytiharkan',c.bumiputeraDay||s.day,'Bukan pengesahan rasmi');
for(const p of s.contractor?.projects||[]){add('contract-'+p.id,'Surat Setuju Terima · '+p.name,'Aktif',p.start);if(['dlp','closed'].includes(p.status))add('cpc-'+p.id,'Sijil Siap Praktikal (CPC) · '+p.name,'Dikeluarkan',p.cpcDay||p.start);if(p.status==='closed')add('closure-'+p.id,'Penutupan DLP · '+p.name,'Selesai',p.dlpEnd||s.day);}
return docs;}
export function allDocuments(s){return [...(s.documents||[]),...contractorDocuments(s)];}
