// Explicit, application-specific referral. No blanket employment bonus.
import {jobs} from './catalog.js';
export function requestJobReferral(s,npcId){
 const n=s.npcs?.[npcId];if(!n||!s.contacts?.includes(npcId))return null;
 const pending=s.applications?.filter(a=>a.status==='pending'&&a.due>s.day)||[];
 const eligible=pending.find(a=>{const j=jobs.find(j=>j.id===a.job);return j&&n.employer&&String(n.employer).trim().toLowerCase()===String(j.employer).trim().toLowerCase();});
 if(!eligible)return null;
 s.npcJobReferrals??=[];
 const existing=s.npcJobReferrals.find(r=>r.applicationId===eligible.id&&['pending','verified'].includes(r.status));
 if(existing)return existing;
 const referral={id:`ref-${++s.sequence}`,npcId,applicationId:eligible.id,employer:n.employer,status:'pending',requestedDay:s.day,expiresDay:Math.min(eligible.due,s.day+3)};
 s.npcJobReferrals.push(referral);return referral;
}
export function processJobReferrals(s){
 for(const r of s.npcJobReferrals||[]){
  if(r.status!=='pending')continue;
  const a=s.applications?.find(x=>x.id===r.applicationId),n=s.npcs?.[r.npcId],j=jobs.find(x=>x.id===a?.job);
  if(!a||a.status!=='pending'||s.day>r.expiresDay){r.status='expired';continue;}
  if(s.day<=r.requestedDay)continue;
  r.status=n&&j&&n.employer===j.employer&&n.trust>=25&&n.available!==false&&n.resentment<30?'verified':'declined';r.resolvedDay=s.day;
  s.notices??=[];s.notices.unshift({day:s.day,title:'Rujukan pekerjaan',text:r.status==='verified'?`Rujukan untuk permohonan ${j.employer} telah disahkan. Temu duga dan keputusan majikan masih diperlukan.`:'Permintaan rujukan pekerjaan tidak diterima.'});
 }
}
export function verifiedReferralForApplication(s,app){return (s.npcJobReferrals||[]).some(r=>r.applicationId===app.id&&r.status==='verified'&&s.npcs?.[r.npcId]?.employer===r.employer);}
