// Fictional certificate layout; deliberately distinct from official JPJ security artwork.
const safe=v=>String(v??'—').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function vehicleGrantCard(doc,vehicle={}){
 const row=(label,value)=>`<div class="vg-row"><span>${safe(label)}</span><strong>${safe(value)}</strong></div>`;
 const cc=doc.cc??vehicle.cc??vehicle.engine??null;
 const fuel=doc.fuel||vehicle.fuel||(vehicle.kind==='Motosikal'?'Petrol':'Petrol');
 const body=doc.bodyType||vehicle.bodyType||vehicle.kind||'Motokar';
 const owner=doc.ownerName||vehicle.ownerName;
 return `<article class="vehicle-grant" aria-label="Sijil pemilikan kenderaan simulasi"><div class="vg-watermark">SIMULASI</div><div class="vg-top"><div class="vg-seal">K<span>GAME</span></div><div><h2>SIJIL PEMILIKAN KENDERAAN</h2><p>REKOD PEMILIKAN · KEHIDUPAN LIFE SIMULATOR</p></div></div><div class="vg-alert">DOKUMEN FIKSYEN — BUKAN GERAN JPJ / BUKAN UNTUK URUSAN RASMI</div><div class="vg-fields">${row('No. Pendaftaran',doc.registration)}${row('No. ID Pemilik',doc.ownerId||'ID SIMULASI')}${row('Nama Pemunya Berdaftar',owner)}${row('Alamat',doc.ownerAddress||'Alamat profil permainan')}${row('No. Casis',doc.chassis)}${row('No. Enjin',doc.engineNumber)}${row('Buatan / Nama Model',doc.vehicleName)}${row('Keupayaan Enjin',cc?cc+' cc':vehicle.electric?'Elektrik':'Tidak dinyatakan')}${row('Bahan Bakar',fuel)}${row('Status Asal',doc.origin||vehicle.condition||'Tidak dinyatakan')}${row('Kelas Kegunaan',doc.ownerType==='personal'?'Persendirian':'Syarikat / Perniagaan')}${row('Jenis Badan / Tahun Dibuat',body+' / '+(doc.year||'—'))}${row('Tarikh Pendaftaran (hari game)',doc.day)}${row('Syarat Pendaftaran',doc.loanId?'Tertakluk kepada pembiayaan':'Tiada pembiayaan direkodkan')}</div><div class="vg-footer">KEHIDUPAN · DOKUMEN GAME · TIDAK SAH SEBAGAI PENGENALAN ATAU PEMILIKAN SEBENAR</div></article>`;
}
