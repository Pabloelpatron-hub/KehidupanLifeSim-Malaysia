import {transfer} from './finance.js';
// Accounts are discovered at call time, never from a fixed list.
export function transferableAccounts(s){
 const owners=new Set(['personal',...(s.businesses||[]).filter(b=>!b.closed).map(b=>b.id)]);
 if(s.contractor?.company?.id)owners.add(s.contractor.company.id);
 return Object.values(s.accounts||{}).filter(a=>a&&a.kind==='asset'&&owners.has(a.owner)&&!a.status&&a.id!=='epf'&&!a.id.startsWith('fd-')&&!a.id.startsWith('bail-')&&!a.id.startsWith('loan-')&&!a.id.startsWith('crew-')&&Number.isSafeInteger(a.balance)&&a.balance>=0);
}
export function transferAccountOptions(s,money){return transferableAccounts(s).map(a=>{
 const business=(s.businesses||[]).find(b=>b.id===a.owner);
 const holder=a.owner==='personal'?'Peribadi':business?.name||(s.contractor?.company?.id===a.owner?s.contractor.company.name:'Perniagaan');
 return [a.id,`${holder} · ${a.name} · ${money(a.balance)}`];
});}
export function transferOwnedFunds(s,from,to,ringgit){
 const accounts=transferableAccounts(s),source=accounts.find(a=>a.id===from),target=accounts.find(a=>a.id===to);
 if(!source||!target)throw Error('Akaun tidak aktif atau tidak layak untuk pindahan.');
 if(from===to)throw Error('Sila pilih dua akaun berlainan.');
 const value=Number(ringgit),amount=Math.round(value*100);
 if(!Number.isFinite(value)||value<=0||!Number.isSafeInteger(amount)||amount<=0||Math.abs(value*100-amount)>1e-6)throw Error('Jumlah pindahan tidak sah. Gunakan maksimum dua tempat perpuluhan.');
 if(amount>source.balance)throw Error('Baki akaun tidak mencukupi.');
 const sameOwner=source.owner===target.owner;
 const category=sameOwner?'transfer':source.owner==='personal'?'business-capital':target.owner==='personal'?'owner-drawing':'interbusiness-transfer';
 const label=sameOwner?'Pindahan antara akaun sendiri':category==='business-capital'?'Suntikan modal pemilik':category==='owner-drawing'?'Ambilan pemilik':'Pindahan antara perniagaan';
 return transfer(s,from,to,amount,label,category);
}
