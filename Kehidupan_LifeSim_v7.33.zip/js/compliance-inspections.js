// Gameplay inspections: referrals and warnings only. No automatic criminal convictions or invented compound tariffs.
import {complianceFindings,COMPLIANCE_RULES} from './compliance-penalties.js';
const hash=x=>{let h=2166136261;for(const c of x){h=Math.imul(h^c.charCodeAt(0),16777619);}return h>>>0;};
export function processComplianceInspections(s){
 s.complianceInspections??={cases:[],lastChecked:{}};
 const data=s.complianceInspections;data.cases??=[];data.lastChecked??={};s.notices??=[];
 const findings=complianceFindings(s);
 for(const f of findings){
  if(f.days<=30||f.conditional)continue;
  const last=data.lastChecked[f.key];if(Number.isInteger(last)&&s.day-last<30)continue;
  // Deterministic 1-in-3 check per 30-day interval; no random replay exploits.
  const period=Math.floor(s.day/30),eligible=hash(`${f.key}:${period}`)%3===0;
  data.lastChecked[f.key]=s.day;
  if(!eligible)continue;
  const r=COMPLIANCE_RULES[f.rule];if(!r)continue;
  const id=`${f.key}:inspection:${period}`;
  if(data.cases.some(c=>c.id===id))continue;
  data.cases.push({id,day:s.day,rule:f.rule,subject:f.name,business:f.business||null,agency:r.agency,status:'notice-to-remedy',fineRM:0,deadline:s.day+7});
  s.notices.unshift({day:s.day,title:`PEMERIKSAAN ${r.agency} — ${f.name}`,text:`Notis simulasi: dokumen luput ${f.days} hari. Selesaikan dalam 7 hari permainan. Ini bukan sabitan, saman atau kompaun automatik.`});
 }
 for(const c of data.cases){
  if(c.status==='resolved')continue;
  const still= findings.some(f=>f.rule===c.rule&&f.name===c.subject&&(!c.business||f.business===c.business));
  if(!still){c.status='resolved';c.resolvedDay=s.day;s.notices.unshift({day:s.day,title:'KES PEMATUHAN SELESAI',text:`${c.agency}: ${c.subject} — dokumen telah dikemas kini.`});}
  else if(c.status==='notice-to-remedy'&&s.day>c.deadline){c.status='referred';c.referredDay=s.day;s.notices.unshift({day:s.day,title:`TINDAKAN SUSULAN ${c.agency}`,text:`${c.subject}: tempoh pembetulan tamat. Kes dirujuk untuk tindakan lanjut dalam simulasi. Tiada denda mahkamah dikenakan secara automatik.`});}
 }
 data.cases=data.cases.slice(-200);s.notices=s.notices.slice(0,100);return data.cases;
}
