
import {spend,income} from './finance.js';
const G=100;
export const GOLD_DEALERS=[
{id:'kijang',name:'Kijang Emas (BNM)',kind:'Syiling bullion',weights:[{g:7.7759,label:'¼ oz'},{g:15.5517,label:'½ oz'},{g:31.1035,label:'1 oz'}],premium:.055,buyback:.035},
{id:'maybank',name:'Maybank',kind:'Produk fizikal simulasi (semak tawaran rasmi)',weights:[1,5,10,50,100],premium:.08,buyback:.045,simulated:true},
{id:'cimb',name:'CIMB',kind:'Produk fizikal simulasi (bukan akaun emas)',weights:[5,10,25],premium:.09,buyback:.05,simulated:true},
{id:'rakyat',name:'Bank Rakyat',kind:'Produk fizikal simulasi',weights:[1,4.25,10,20],premium:.085,buyback:.048,simulated:true},
{id:'agro',name:'Agrobank',kind:'Produk fizikal simulasi',weights:[1,5,10],premium:.09,buyback:.05,simulated:true},
{id:'public',name:'Public Gold',kind:'Jongkong & dinar',weights:[1,4.25,5,10,25,50,100,250,500,1000],premium:.045,buyback:.03},
{id:'habib',name:'HABIB Jewels',kind:'Emas 24K',weights:[1,5,10,20,50,100],premium:.075,buyback:.045},
{id:'yapeim',name:'YAPEIM Gold',kind:'Emas fizikal',weights:[1,4.25,5,10,20,50,100],premium:.065,buyback:.038},
{id:'sim-bullion',name:'Bullion Wholesale (Fiksyen)',kind:'Jongkong besar simulasi',weights:[250,500,1000,2000,5000,10000],premium:.028,buyback:.025,simulated:true}
];
function hash(n){let x=(Math.imul((n+9191)|0,1664525)+1013904223)|0;x^=x>>>16;x=Math.imul(x,2246822519);x^=x>>>13;return (x>>>0)/4294967296;}
function normal(n){return Math.sqrt(-2*Math.log(Math.max(1e-8,hash(n*2+1))))*Math.cos(2*Math.PI*hash(n*2+2));}
export function ensureGold(s){if(!s.physicalGold||!Array.isArray(s.physicalGold.history)||!Array.isArray(s.physicalGold.lots))s.physicalGold={version:1,history:[{day:0,open:600,high:603,low:596,close:600,usdMyr:4.5}],lots:[],trades:[]};return s.physicalGold;}
export function goldDay(s){const g=ensureGold(s);if(g.history[g.history.length-1].day>=s.day)return;for(let d=g.history[g.history.length-1].day+1;d<=s.day;d++){const p=g.history[g.history.length-1],econ=s.economy||{},risk=Math.max(0,Math.min(2,(.035-(econ.growth||.03))*10)),regime=Math.sin(d/95)*.00085+Math.sin(d/420)*.0006;const shock=normal(d+404)*(.0085+risk*.0015)+(hash(d+883)<.003?normal(d+300)*.055:0);const fx=Math.max(3.2,Math.min(6.5,p.usdMyr*Math.exp(normal(d+777)*.0025+(.03-(econ.growth||.03))*.001)));const ret=Math.max(-.16,Math.min(.16,.00017+regime+shock+(fx/p.usdMyr-1)));const close=Math.max(100,+(p.close*Math.exp(ret)).toFixed(4));const open=p.close,wick=Math.abs(normal(d+1222))*.0045;g.history.push({day:d,open,high:+(Math.max(open,close)*(1+wick)).toFixed(4),low:+(Math.min(open,close)*(1-wick)).toFixed(4),close,usdMyr:+fx.toFixed(4)});} }
export function goldSpot(s){const h=ensureGold(s).history;return h[h.length-1].close;}
export function dealer(id){return GOLD_DEALERS.find(d=>d.id===id);}
export function productLabel(g){return g===4.25?'1 Dinar':g>=1000?`${g/1000}kg`:`${g}g`;}
export function goldQuote(s,id,g){goldDay(s);const d=dealer(id);if(!d||!d.weights.some(w=>(typeof w==='number'?w:w.g)===g))throw Error('Produk dealer tidak tersedia');const spot=goldSpot(s),premium=d.premium+(g<=1?.045:g<=5?.018:g>=250?-.009:0);return {ask:Math.round(spot*g*(1+premium)*G),bid:Math.round(spot*g*(1-d.buyback)*G),spot:Math.round(spot*g*G),premium,spread:d.buyback+premium};}
export function buyGold(s,id,g){g=Number(g);const d=dealer(id),q=goldQuote(s,id,g);if(!s.accounts.main||s.accounts.main.balance<q.ask)throw Error('Baki akaun utama tidak mencukupi');spend(s,'main',q.ask,`Emas fizikal ${d.name} ${productLabel(g)}`,'physical-gold-buy');const p=ensureGold(s),lot={id:`gold-${++s.sequence}`,dealer:id,weight:g,purity:'999.9 / 24K',kind:id==='kijang'?'Syiling':'Jongkong / dinar',day:s.day,price:q.ask,receipt:`PG-${s.day}-${s.sequence}`,status:'owned'};p.lots.push(lot);s.documents.push({id:'receipt-'+lot.id,type:'Resit emas fizikal',title:`${d.name} · ${productLabel(g)} · ${lot.receipt}`,day:s.day,asset:lot.id,amount:q.ask});return lot;}
export function sellGold(s,id){const p=ensureGold(s),lot=p.lots.find(l=>l.id===id&&l.status==='owned');if(!lot)throw Error('Emas tidak ditemui atau telah dijual');const q=goldQuote(s,lot.dealer,lot.weight);income(s,'main',q.bid,`Jual balik emas ${lot.receipt}`,'physical-gold-sell');lot.status='sold';lot.soldDay=s.day;lot.proceeds=q.bid;lot.realized=q.bid-lot.price;p.trades.push({id:`gold-trade-${++s.sequence}`,lot:lot.id,day:s.day,proceeds:q.bid,profit:lot.realized});return lot;}
