import {carCatalog,motorcycleCatalog,showroomList} from './vehicle-market-cp1.js';
import {instalment,monthlyDebt,spend,transfer} from './finance.js';
export const vehicleById=id=>[...carCatalog,...motorcycleCatalog].find(x=>x.id===id);
export function ensureVehicleMarket(s){
 if(!s.vehicleMarket)s.vehicleMarket={applications:[],nextId:1};
 const m=s.vehicleMarket;
 for(const a of m.applications||[]){
  if(!a.id||!a.vehicleId)continue;
  if(!a.purchaseId)a.purchaseId=a.id;
  if(!a.reservationStatus)a.reservationStatus=['processing','approved','accepted','puspakom-passed','insurance-selected','roadtax-selected','cash-paid'].includes(a.status)?'reserved':a.status==='registered'?'sold':'released';
  if(!a.dealerName)a.dealerName='Showroom asal';
 }
 return m;
}
export function purchaseRecords(s,dealerId=null){return ensureVehicleMarket(s).applications.filter(a=>!dealerId||a.dealerId===dealerId).slice().reverse();}
export function reservedVehicleIds(s,dealerId){return new Set(purchaseRecords(s,dealerId).filter(a=>a.reservationStatus==='reserved').map(a=>a.vehicleId));}

export function financingOptions(v){const age=Math.max(0,2026-v.year);const cashOnly=v.price<12000||age>15;return {cashOnly,minDeposit:cashOnly?100:age>9?35:age>5?20:v.price>1000000?30:10,maxMonths:cashOnly?0:Math.min(age>9?48:age>5?72:108,108),rate:age>9?.075:age>5?.057:.039};}
export function findApplication(s,id){return ensureVehicleMarket(s).applications.find(a=>a.id===id);}
export function eligibility(s,v,depositPct,months,owner='personal'){
 const opts=financingOptions(v),price=v.price*100,dp=Math.round(price*Number(depositPct)/100),principal=price-dp;
 const issues=[];
 const classes=s.licence?.classes||[s.licence?.class];
 if(!s.licence||s.licence.expires<s.day||!classes.includes(v.kind==='Motosikal'?'B2':'D'))issues.push('Lesen memandu tidak sah atau kelas tidak sesuai — perbaharui lesen di JPJ');
 if(opts.cashOnly)issues.push('Kenderaan ini Cash Only — pilih pembelian tunai');
 if(!Number.isFinite(Number(depositPct))||depositPct<opts.minDeposit||depositPct>=100)issues.push('Deposit tidak layak — semak peratus minimum atau pilih Bayar Tunai');
 if(!Number.isFinite(Number(months))||months<12||months>opts.maxMonths)issues.push('Tempoh pembiayaan tidak layak');
 // Financial profile is independent from the registered vehicle owner.
 // Personal applicants may be self-employed through several registered businesses.
 const salary=Math.max(0,s.job?.salary||0);
 const selfEmployed=owner!=='personal'||!s.job;
 const selected=owner==='contractor'?[s.contractor?.company].filter(Boolean):owner==='personal'?[...(s.businesses||[]).filter(b=>!b.closed&&!b.suspended),...(s.contractor?.company?[s.contractor.company]:[])]:[(s.businesses||[]).find(b=>b.id===owner)].filter(Boolean);
 const sources=[];
 for(const c of selected){
   const contractor=c===s.contractor?.company;
   const accountId=contractor?c.id:(c.account||c.id);
   const acct=s.accounts?.[accountId];
   if(!acct)continue;
   const opened=Number.isFinite(c.opened)?c.opened:Number.isFinite(c.registrationDay)?c.registrationDay:s.day;
   const age=Math.max(0,s.day-opened);
   const entries=(s.ledger||[]).filter(l=>l.day>s.day-30&&l.day<=s.day&&l.entries?.some(e=>e.account===accountId));
   let inflows=0,operatingProfit=0;
   if(contractor){
     // Only actual paid project claims count; exclude capital injections, bonds and loans.
     const incomeCategories=new Set(['progress-claim','project-advance','retention']);
     const expenseCategories=new Set(['project-cost','site-crisis','project-materials','project-stock','lad']);
     for(const l of entries){const delta=l.entries.filter(e=>e.account===accountId).reduce((n,e)=>n+e.amount,0);if(incomeCategories.has(l.category)&&delta>0)inflows+=delta;if(expenseCategories.has(l.category)&&delta<0)operatingProfit+=delta;}
     operatingProfit+=inflows;
   }else{
     const recent=(c.history||[]).filter(h=>h.day>s.day-30&&h.day<=s.day);
     inflows=recent.reduce((n,h)=>n+(h.revenue||0),0);
     operatingProfit=recent.reduce((n,h)=>n+(h.revenue||0)-(h.cogs||0)-(h.expenses||0),0);
   }
   // No positive income from mere account balance or owner capital contributions.
   sources.push({name:c.name||'Perniagaan',accountId,statementDays:age,inflows,operatingProfit,assessed:Math.max(0,Math.round(operatingProfit*.65))});
 }
 let monthlyIncome=salary,statementDays=0,statementInflows=0;
 if(selfEmployed){
   if(!selected.length)issues.push('Tiada perniagaan SSM dipautkan — daftar perniagaan atau pilih pemilik yang betul');
   if(selected.length&&!sources.length)issues.push('Akaun bank perniagaan tidak ditemui — semak akaun syarikat dalam Perbankan');
   statementDays=sources.length?Math.min(...sources.map(x=>x.statementDays)):0;
   statementInflows=sources.reduce((n,x)=>n+x.inflows,0);
   const mature=sources.filter(x=>x.statementDays>=30);
   if(sources.length&&!mature.length)issues.push('Penyata perniagaan belum genap 30 hari — teruskan permainan atau pilih perniagaan lebih lama');
   monthlyIncome=(owner==='personal'?salary:0)+mature.reduce((n,x)=>n+x.assessed,0);
   if(mature.length&&monthlyIncome<=0)issues.push('Keuntungan operasi 30 hari terakhir tidak mencukupi — modal dan baki bank bukan pendapatan');
 }else if(!s.job||s.job.tenure<60)issues.push('Tempoh pekerjaan kurang 60 hari');
 const payment=instalment(principal,opts.rate,months);
 const dsr=monthlyIncome?(monthlyDebt(s)+payment)/monthlyIncome:Infinity;
 if(dsr>.6)issues.push('DSR terlalu tinggi / pendapatan tidak mencukupi — kurangkan pinjaman atau tambah deposit');
 if(s.arrears>0||s.loans.some(l=>l.missed>0))issues.push('CCRIS: tunggakan bayaran aktif — selesaikan tunggakan dahulu');
 if(s.crime?.financeRestricted)issues.push('Rekod kredit disekat — semak status kewangan');
 return {issues,dp,principal,payment,dsr,rate:opts.rate,months,monthlyIncome,statementDays,statementInflows,selfEmployed,sources,ready:issues.length===0};
}
export function submitApplication(s,{vehicleId,dealerId,deposit,months,owner='personal'}){
 const market=ensureVehicleMarket(s),v=vehicleById(vehicleId);if(!v)throw Error('Model kenderaan tidak ditemui');
 const dealer=showroomList(s.character.city,s.day).find(d=>d.id===dealerId);if(!dealer?.items.some(x=>x.id===vehicleId))throw Error('Stok showroom sudah berubah. Pilih semula.');
 if(market.applications.some(a=>a.vehicleId===vehicleId&&a.dealerId===dealerId&&['processing','approved','accepted'].includes(a.status)))throw Error('Permohonan model ini di showroom sama masih aktif');
 const q=eligibility(s,v,Number(deposit),Number(months),owner);
 if(q.issues.length)throw Error('Dokumen / kelayakan belum lengkap: '+q.issues.join('; '));
 const id='vehicle-application-'+market.nextId++;const salesmanId='vehicle-salesman-'+dealerId;
 if(!s.npcs[salesmanId])s.npcs[salesmanId]={id:salesmanId,name:'Encik Hakim ('+dealer.name+')',occupation:'Sales Consultant',age:32,personality:'professional',phone:'01X-XXX-XXXX',available:true,venue:null,relationship:0,memory:[]};
 if(!s.contacts.includes(salesmanId))s.contacts.push(salesmanId);
 if(!s.messages[salesmanId])s.messages[salesmanId]=[];
 const a={id,vehicleId,dealerId,dealerName:dealer.name,salesmanId,owner,deposit:Number(deposit),months:Number(months),price:v.price*100,submittedDay:s.day,decisionDay:s.day+7,status:'processing',reservationStatus:'reserved',purchaseId:id,offer:{...q,bank:'Maybank (simulasi)'},reasons:q.issues};
 market.applications.push(a);s.notices.unshift({day:s.day,title:'Permohonan Loan Dihantar',text:v.name+' · '+Math.round(a.price*a.deposit/100)/100+' RM deposit · keputusan hari '+a.decisionDay});return a;
}
export function processVehicleApplications(s){let changed=false;for(const a of ensureVehicleMarket(s).applications){if(a.status!=='processing'||s.day<a.decisionDay)continue;const v=vehicleById(a.vehicleId);a.status=a.reasons.length?'rejected':'approved';if(a.status==='rejected')a.reservationStatus='released';a.decidedDay=s.day;const message=a.status==='approved'?`Salam, permohonan ${v.name} LULUS. Bank: ${a.offer.bank}. Pinjaman RM${(a.offer.principal/100).toFixed(2)}, ansuran RM${(a.offer.payment/100).toFixed(2)}/bulan selama ${a.months} bulan. Buka Teroka Malaysia → Kenderaan → Urusan Pembelian Saya untuk menerima tawaran, walaupun stok showroom berubah.`:`Salam, permohonan ${v.name} TIDAK LULUS. Sebab: ${a.reasons.join('; ')}. Sila semak dokumen dan rekod kredit.`;s.messages[a.salesmanId]??=[];s.messages[a.salesmanId].push({from:'npc',text:message,day:s.day,hour:s.hour,read:false});s.notices.unshift({day:s.day,title:'Keputusan Loan Kenderaan',text:message});changed=true;}return changed;}
export function acceptOffer(s,id){const a=findApplication(s,id);if(!a||a.status!=='approved')throw Error('Tiada tawaran yang boleh diterima');a.status='accepted';a.reservationStatus='reserved';a.acceptedDay=s.day;return a;}
export function cashPurchase(s,{vehicleId,dealerId,owner='personal'}){const v=vehicleById(vehicleId),dealer=showroomList(s.character.city,s.day).find(d=>d.id===dealerId);if(!v||!dealer?.items.some(x=>x.id===vehicleId))throw Error('Stok tidak tersedia');if(!s.licence||s.licence.expires<s.day||!(s.licence.classes||[s.licence.class]).includes(v.kind==='Motosikal'?'B2':'D'))throw Error('Lesen memandu sah diperlukan');const account=owner==='personal'?'main':owner==='contractor'?s.contractor?.company?.id:(s.businesses.find(b=>b.id===owner)?.account||owner);if(!account||!s.accounts[account])throw Error('Akaun pembeli tidak wujud');spend(s,account,v.price*100,'Bayaran tunai '+v.name,'vehicle-purchase');const a={id:'vehicle-cash-'+ensureVehicleMarket(s).nextId++,vehicleId,dealerId,dealerName:dealer.name,owner,price:v.price*100,deposit:100,months:0,status:'cash-paid',reservationStatus:'reserved',submittedDay:s.day};s.vehicleMarket.applications.push(a);return a;}

export function cancelPurchase(s,id){const a=findApplication(s,id);if(!a||!['processing','approved'].includes(a.status))throw Error('Transaksi tidak boleh dibatalkan pada tahap ini');a.status='cancelled';a.reservationStatus='released';a.cancelledDay=s.day;return a;}
