// Logo institusi dan geng. Modul baharu (v1) — tiada kebergantungan, tiada kesan pada save.
// Padanan geng menggunakan ID faction (kekal walaupun Boss menukar nama geng).
export const LOGOS={
  pdrm:{src:'assets/logos/pdrm.webp',alt:'Logo Polis Diraja Malaysia',plate:true,w:258,h:300},
  penjara:{src:'assets/logos/penjara.webp',alt:'Logo Jabatan Penjara Malaysia',plate:true,w:248,h:300},
  tiger99:{src:'assets/logos/tiger-99.webp',alt:'Logo Tiger 99',plate:false,w:320,h:320},
  burongHantu:{src:'assets/logos/burong-hantu.webp',alt:'Logo Burong Hantu',plate:true,w:198,h:320},
  regimenSelatan:{src:'assets/logos/regimen-selatan.webp',alt:'Logo Regimen Selatan',plate:true,w:360,h:229}
};
const GANG_LOGO={'g-merah':'tiger99','g-jade':'burongHantu','g-bara':'regimenSelatan'};
export const gangLogoKey=id=>GANG_LOGO[id]||null;
// size: xs | sm | md | lg. Pulangkan '' jika logo tiada supaya UI asal tidak berubah.
export function logo(key,size='md'){
  const l=LOGOS[key];if(!l)return '';
  return `<span class="logo-mark logo-${size}${l.plate?' logo-plate':''}"><img src="${l.src}" alt="${l.alt}" width="${l.w}" height="${l.h}" decoding="async"></span>`;
}
