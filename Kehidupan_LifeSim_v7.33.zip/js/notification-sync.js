// Unified alert bridge: every new important government notice becomes a persistent popup.
// Preserve existing notice ledger and avoid repeated popups after reload.
export function syncImportantNotices(s, previousNotices=[]){
 s.operationalAlerts??={seen:{},queue:[]};
 const a=s.operationalAlerts;
 a.seen??={};a.queue??=[];
 if(!Array.isArray(s.notices))return 0;
 const old=new Set((previousNotices||[]).map(n=>JSON.stringify([n.day,n.title,n.text])));
 const queued=new Set(a.queue.map(x=>JSON.stringify([x.day,x.title,x.text])));
 let count=0;
 for(const n of s.notices){
  if(!n||typeof n.title!=='string'||typeof n.text!=='string')continue;
  const signature=JSON.stringify([n.day,n.title,n.text]);
  if(old.has(signature)||queued.has(signature))continue;
  // Operational alerts have already been enqueued by their own emitter.
  const existing=a.queue.some(x=>x.title===n.title&&x.text===n.text&&x.day===n.day);
  if(existing)continue;
  const key='notice:'+signature;
  if(a.seen[key])continue;
  a.seen[key]=s.day+1;
  a.queue.push({key,day:n.day,title:n.title,text:n.text,kind:/SELESAI|ditarik balik|DITERIMA/i.test(n.title)?'success':'warning'});
  count++;
 }
 a.queue=a.queue.slice(-100);
 const keys=Object.keys(a.seen);
 if(keys.length>2000)for(const k of keys.slice(0,keys.length-1500))delete a.seen[k];
 return count;
}
