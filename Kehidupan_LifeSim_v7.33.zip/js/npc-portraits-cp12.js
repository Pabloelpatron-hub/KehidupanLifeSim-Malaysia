// CP12: 300 individually rendered illustrated NPC portraits.
// These are functional placeholders, not photorealistic final-QA assets.
export const CP12_PORTRAIT_COUNT=300;
export const CP12_READY_IDS=Object.freeze(Array.from({length:300},(_,i)=>`npc-cp04-${String(i+1).padStart(3,'0')}`));
const ready=new Set(CP12_READY_IDS);
export function npcPortraitAsset(id){
 if(!ready.has(id))return null;
 return `assets/npc-portraits/${id}.webp`;
}
export function portraitCoverage(){return {total:300,ready:ready.size,pending:300-ready.size,quality:'illustrated-placeholder',finalQA:0};}
