// 30 original generative instrumental sketches. No third-party copyrighted audio or external network.
const profiles={
SIN:['pentatonic',78,'glass',0],BKK:['pentatonic',86,'pluck',1],CGK:['pelog',84,'bell',2],MNL:['major',92,'guitar',3],SGN:['pentatonic',72,'pluck',4],PNH:['pentatonic',70,'bell',5],VTE:['pentatonic',68,'flute',6],RGN:['pentatonic',76,'bell',7],BWN:['pelog',66,'pluck',8],ICN:['pentatonic',90,'glass',9],NRT:['japanese',74,'pluck',10],PEK:['pentatonic',70,'pluck',11],TPE:['pentatonic',88,'bell',12],HKG:['pentatonic',98,'glass',13],DEL:['raga',80,'pluck',14],DAC:['raga',76,'flute',15],KTM:['pentatonic',64,'flute',16],CMB:['raga',88,'bell',17],MLE:['major',70,'glass',18],DXB:['hijaz',82,'pluck',19],DOH:['hijaz',72,'flute',20],JED:['hijaz',68,'pluck',21],IST:['hijaz',92,'pluck',22],LHR:['major',84,'piano',23],CDG:['major',94,'piano',24],FRA:['minor',88,'piano',25],AMS:['major',96,'glass',26],SYD:['major',100,'guitar',27],AKL:['major',78,'flute',28],JFK:['blues',102,'piano',29]
};
const scales={pentatonic:[0,2,4,7,9],japanese:[0,1,5,7,8],pelog:[0,1,3,7,8],major:[0,2,4,5,7,9,11],minor:[0,2,3,5,7,8,10],hijaz:[0,1,4,5,7,8,10],raga:[0,2,3,6,7,9,10],blues:[0,3,5,6,7,10]};
let ctx=null,master=null,timer=null,activeCode=null,nextAt=0,step=0,settings={enabled:true,volume:.32};
function note(midi){return 440*Math.pow(2,(midi-69)/12);}
function voice(time,freq,duration,instrument,volume){
 if(!ctx||!master)return;
 const osc=ctx.createOscillator(),gain=ctx.createGain(),filter=ctx.createBiquadFilter();
 osc.type=instrument==='piano'||instrument==='guitar'?'triangle':instrument==='bell'||instrument==='glass'?'sine':instrument==='flute'?'sine':'triangle';
 osc.frequency.setValueAtTime(freq,time);
 filter.type='lowpass';filter.frequency.value=instrument==='flute'?1100:instrument==='glass'?2400:1800;
 const attack=instrument==='flute'?.12:.018;
 gain.gain.setValueAtTime(.00001,time);gain.gain.linearRampToValueAtTime(volume,time+attack);
 gain.gain.exponentialRampToValueAtTime(.00001,time+Math.max(attack+.03,duration));
 osc.connect(filter);filter.connect(gain);gain.connect(master);osc.start(time);osc.stop(time+duration+.04);
}
function schedule(){if(!ctx||ctx.state!=='running'||!activeCode)return;
 const [scaleName,bpm,instrument,seed]=profiles[activeCode],scale=scales[scaleName],beat=60/bpm;
 while(nextAt<ctx.currentTime+.35){
  const n=step,bar=Math.floor(n/8),slot=n%8;
  // Unique per-destination melody, with slowly evolving eight-bar phrases.
  const idx=(seed*7+bar*3+slot*5+Math.floor(seed/3)*slot)%scale.length;
  const base=48+(seed%4)*2;
  if(slot===0||slot===4)voice(nextAt,note(base+scale[(bar+seed)%scale.length]),beat*3.5,'flute',.045);
  if((slot+seed)%3!==1)voice(nextAt,note(base+12+scale[idx]+(slot===7?12:0)),beat*(slot%2?1.25:1.65),instrument,.055);
  if(slot===2||slot===6)voice(nextAt,note(base+7+scale[(seed+bar+2)%scale.length]),beat*.8,'glass',.017);
  nextAt+=beat;step++;
 }
}
export function stopDestinationMusic(){if(timer){clearInterval(timer);timer=null;}activeCode=null;if(master&&ctx){try{master.gain.setTargetAtTime(.00001,ctx.currentTime,.15);}catch{}}}
export function setDestinationMusicVolume(v){settings.volume=Math.max(0,Math.min(1,Number(v)||0));if(master&&ctx)master.gain.setTargetAtTime(settings.volume*.46,ctx.currentTime,.08);}
export function playDestinationMusic(code,opts={}){
 if(!profiles[code]||document.hidden||opts.enabled===false){stopDestinationMusic();return;}
 settings={enabled:true,volume:Math.max(0,Math.min(1,Number(opts.volume??.32)))};
 try{
  const C=window.AudioContext||window.webkitAudioContext;if(!C)return;
  ctx??=new C();if(ctx.state==='suspended'){ctx.resume().then(()=>{if(activeCode===code)schedule();}).catch(()=>{});}
  if(activeCode===code&&timer){setDestinationMusicVolume(settings.volume);return;}
  stopDestinationMusic();if(master){try{master.disconnect();}catch{}}
  master=ctx.createGain();master.gain.value=.00001;master.connect(ctx.destination);
  master.gain.setTargetAtTime(settings.volume*.46,ctx.currentTime,.3);
  activeCode=code;step=0;nextAt=ctx.currentTime+.12;schedule();timer=setInterval(schedule,120);
 }catch(e){console.warn('Destination soundtrack unavailable',e);}
}
export const destinationMusicCount=Object.keys(profiles).length;
