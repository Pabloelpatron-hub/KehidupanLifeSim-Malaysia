// 30 licensed local MP3 tracks; one persistent HTMLMediaElement (no generated oscillator music).
// iOS can interrupt audio during calls/background. Resume is best effort and never bypasses Safari policies.
const tracks={"SIN":{"asset":"assets/audio/destinations/singapore.mp3","title":"Airport Lounge","creator":"Kevin MacLeod"},"BKK":{"asset":"assets/audio/destinations/bangkok.mp3","title":"Dream Culture","creator":"Kevin MacLeod"},"CGK":{"asset":"assets/audio/destinations/jakarta.mp3","title":"Mystic Force","creator":"Kevin MacLeod"},"MNL":{"asset":"assets/audio/destinations/manila.mp3","title":"Carefree","creator":"Kevin MacLeod"},"SGN":{"asset":"assets/audio/destinations/ho-chi-minh-city.mp3","title":"Easy Lemon","creator":"Kevin MacLeod"},"PNH":{"asset":"assets/audio/destinations/phnom-penh.mp3","title":"Nightdreams","creator":"Kevin MacLeod"},"VTE":{"asset":"assets/audio/destinations/vientiane.mp3","title":"Healing","creator":"Kevin MacLeod"},"RGN":{"asset":"assets/audio/destinations/yangon.mp3","title":"Enchanted Journey","creator":"Kevin MacLeod"},"BWN":{"asset":"assets/audio/destinations/bandar-seri-begawan.mp3","title":"Water Lily","creator":"Kevin MacLeod"},"ICN":{"asset":"assets/audio/destinations/seoul.mp3","title":"Reawakening","creator":"Kevin MacLeod"},"NRT":{"asset":"assets/audio/destinations/tokyo.mp3","title":"Ishikari Lore","creator":"Kevin MacLeod"},"PEK":{"asset":"assets/audio/destinations/beijing.mp3","title":"Shenyang","creator":"Kevin MacLeod"},"TPE":{"asset":"assets/audio/destinations/taipei.mp3","title":"Cattails","creator":"Kevin MacLeod"},"HKG":{"asset":"assets/audio/destinations/hong-kong.mp3","title":"Night on the Docks - Sax","creator":"Kevin MacLeod"},"DEL":{"asset":"assets/audio/destinations/new-delhi.mp3","title":"Jalandhar","creator":"Kevin MacLeod"},"DAC":{"asset":"assets/audio/destinations/dhaka.mp3","title":"Dhaka","creator":"Kevin MacLeod"},"CMB":{"asset":"assets/audio/destinations/colombo.mp3","title":"Vadodora Chill Mix","creator":"Kevin MacLeod"},"KTM":{"asset":"assets/audio/destinations/kathmandu.mp3","title":"That Zen Moment","creator":"Kevin MacLeod"},"MLE":{"asset":"assets/audio/destinations/male.mp3","title":"Bossa Antigua","creator":"Kevin MacLeod"},"DXB":{"asset":"assets/audio/destinations/dubai.mp3","title":"Ibn Al-Noor","creator":"Kevin MacLeod"},"DOH":{"asset":"assets/audio/destinations/doha.mp3","title":"Desert City","creator":"Kevin MacLeod"},"JED":{"asset":"assets/audio/destinations/jeddah.mp3","title":"Tabuk","creator":"Kevin MacLeod"},"IST":{"asset":"assets/audio/destinations/istanbul.mp3","title":"Mystery Bazaar","creator":"Kevin MacLeod"},"LHR":{"asset":"assets/audio/destinations/london.mp3","title":"Almost New","creator":"Kevin MacLeod"},"CDG":{"asset":"assets/audio/destinations/paris.mp3","title":"Duet Musette","creator":"Kevin MacLeod"},"FRA":{"asset":"assets/audio/destinations/frankfurt.mp3","title":"Prelude in C (BWV 846)","creator":"Kevin MacLeod"},"AMS":{"asset":"assets/audio/destinations/amsterdam.mp3","title":"Backbay Lounge","creator":"Kevin MacLeod"},"JFK":{"asset":"assets/audio/destinations/new-york.mp3","title":"Night in Venice","creator":"Kevin MacLeod"},"SYD":{"asset":"assets/audio/destinations/sydney.mp3","title":"Clear Air","creator":"Kevin MacLeod"},"AKL":{"asset":"assets/audio/destinations/auckland.mp3","title":"Windswept","creator":"Kevin MacLeod"}};
const audio=new Audio();audio.preload='auto';audio.loop=true;audio.playsInline=true;
let activeCode=null,enabled=true,volume=.32,pendingResume=false,lastAttempt=0;
const key='lifesim-destination-music-positions-v1';
let positions={};try{positions=JSON.parse(localStorage.getItem(key)||'{}')||{};}catch{}
function store(){if(activeCode&&Number.isFinite(audio.currentTime)&&audio.currentTime>=0){positions[activeCode]=audio.currentTime;try{localStorage.setItem(key,JSON.stringify(positions));}catch{}}}
function applyVolume(){audio.volume=Math.max(0,Math.min(1,volume));}
function start(){if(!activeCode||!enabled||document.hidden)return;
 if(!audio.paused)return;
 const now=Date.now();if(now-lastAttempt<450)return;lastAttempt=now;
 const result=audio.play();if(result?.then)result.then(()=>{pendingResume=false;}).catch(()=>{pendingResume=true;});
}
function loadTrack(code){store();activeCode=code;audio.pause();audio.src=new URL(tracks[code].asset,document.baseURI).href;audio.load();
 const resume=Number(positions[code])||0;
 const seek=()=>{try{if(resume>0&&audio.duration>0)audio.currentTime=Math.min(resume,Math.max(0,audio.duration-.25));}catch{}};
 audio.addEventListener('loadedmetadata',seek,{once:true});
 pendingResume=true;
}
export function playDestinationMusic(code,opts={}){
 if(!tracks[code]||opts.enabled===false){stopDestinationMusic();return;}
 enabled=true;volume=Math.max(0,Math.min(1,Number(opts.volume??.32)||0));applyVolume();
 if(activeCode!==code)loadTrack(code);
 if(!document.hidden)start();
}
export function stopDestinationMusic(){store();audio.pause();activeCode=null;pendingResume=false;audio.removeAttribute('src');audio.load();}
export function setDestinationMusicVolume(v){volume=Math.max(0,Math.min(1,Number(v)||0));applyVolume();}
export function resumeDestinationMusic(){if(activeCode&&enabled&&!document.hidden)start();}
export function destinationMusicStatus(){return {code:activeCode,playing:!!activeCode&&!audio.paused,blocked:pendingResume};}
export const destinationMusicCount=Object.keys(tracks).length;
audio.addEventListener('timeupdate',()=>{if(Math.floor(audio.currentTime)%5===0)store();});
audio.addEventListener('pause',()=>{store();if(activeCode)pendingResume=true;});
audio.addEventListener('playing',()=>{pendingResume=false;});
audio.addEventListener('error',()=>{pendingResume=true;console.warn('Destination MP3 could not be loaded',activeCode,audio.error?.code);});
window.addEventListener('pagehide',store);
window.addEventListener('pageshow',resumeDestinationMusic);
window.addEventListener('focus',resumeDestinationMusic);
document.addEventListener('visibilitychange',()=>{if(!document.hidden)resumeDestinationMusic();});
for(const type of ['pointerdown','touchstart','keydown'])document.addEventListener(type,resumeDestinationMusic,{capture:true,passive:true});
